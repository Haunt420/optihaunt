# Domain model and persistence

Implement explicit entities and relationships for Project, Session, InstructionVersion, Prompt, GeneratedImage, PromptVote, InstructionInfluence, ThemeSteer, PromptBatch, GenerationJob, plus prompt-example lineage. Use UUIDs and timestamps. Preserve history; do not cascade-delete historical lineage when a prompt is removed.

Pending influence marks are distinct from committed marks. A pending image is one type at a time (positive OR anti); across different instruction versions the same image can have different committed roles.

Every applied instruction creates a new version. A draft is not an applied version. Theme Steers are queued prompt-writing inputs and are consumed only after a successful usable batch.
