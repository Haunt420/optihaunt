# UI feature map

Primary surfaces: Explore feed; Composer; prompt queue/modal; Influences + AI Help; Theme Steers; strategy controls; session/library; saved/cache/picked views; generation tree; help/settings. The original template markup is in `04_ui_template/ui_markup.html`; the complete runtime is in `05_runtime_javascript/runtime.js`; styles are in `06_styles/styles.css`.

Use source IDs and event behavior as reference, not as an instruction to reproduce the web DOM literally. Build native Compose screens and state flows.
