# Product definition and scope

Source of truth: `02_original_app_spec/modelText_full.txt` and `outputTemplate_full.html`.
Android objective: reproduce OptiHaunt as a continuous AI-assisted visual exploration system, not a one-shot image generator.

Core loop: instruction → prompt batches → upcoming queue → image jobs → feed → votes/influences → deliberate instruction revision → next cycle.

Preserve separate meanings for upvotes, positive influence marks, anti-influence marks, and Theme Steers. Never merge them into a generic like/favorite mechanism.

Required baseline: continuous prompt and image generation, queue, feed, feedback, instruction versioning, AI-assisted revision, strategies, Steers, session persistence, and prompt/image lineage.
