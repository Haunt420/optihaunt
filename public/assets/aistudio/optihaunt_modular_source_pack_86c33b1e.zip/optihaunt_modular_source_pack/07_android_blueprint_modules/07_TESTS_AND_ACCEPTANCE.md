# Acceptance and regression tests

At minimum test: new instruction version; prompt batch queued; 10-second cooldown; prompt edit pause; manual prompt non-pause; user prompt first-use priority; individual image completions; vote score; positive and anti marks remain separate; explicit Apply creates a version; AI suggestion does not auto-apply; Steer consumed only on successful usable batch; independent pauses; fresh-only no fallback; session recovery; provenance and tree lineage; provider switching; network interruption and idempotent recovery.
