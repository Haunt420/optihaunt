# Feedback and instruction evolution

Upvotes affect prompt votes/score and future prompt selection/promotion. Positive/anti-influence marks are inputs to a later instruction revision only; they do not directly change prompt score or generation. Theme Steers directly affect prompt-writing batches.

AI Help is advisory: it proposes text, never silently overwrites or applies. It uses instruction/draft, selected marked prompt wording (not image files), revision note and one of four modes: keep structure, freely restructure, tighten, expand. User must explicitly use as draft or apply.
