# Backend and provider boundaries

Use separate language-model and image-generation provider interfaces. Keep credentials out of the APK. Durable long-running image jobs should be orchestrated by a backend or another durable service. Preserve job IDs and reconcile status on reconnect; do not blindly resubmit jobs.

The downloaded HTML includes Perchance imported-generator source modules under `03_perchance_plugins`. These are the original Perchance plugin implementations/wrappers. They do not by themselves guarantee access to the original remote provider services, authentication, quotas, or compatible APIs. Inspect each plugin before deciding what can be reused versus reimplemented.
