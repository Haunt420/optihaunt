# Generation engine

Separate prompt writing from image generation. Prompt writing produces batches (original default five) which enter the Upcoming queue. The queue provides a 10-second inspection/edit/delete cooldown. Editing an existing prompt pauses generation and freezes timers; manually adding a prompt does not pause. Hand-authored prompts get first-use priority.

Implement event-driven scheduling, persistent jobs, idempotency, retries, concurrency limits, cooldowns, stale handling, fresh-only behavior, prompt selection, prompt mixing, promotion, batch rules, prefix/suffix, and independent pause controls. Do not simplify selection to FIFO or highest score.
