# Build sequence

1. Project skeleton, navigation, database, local session persistence.
2. Domain models and unit tests.
3. Prompt generation adapter, batch parsing, queue and cooldown.
4. Image provider adapter, durable jobs, feed and cache.
5. Votes, scoring, influences, anti-influences.
6. Instruction versions and AI Help.
7. Steers, strategy options, promotion, mixing, batch rules.
8. Sessions, exports, recovery, generation tree.
9. UI polish, performance, provider configuration and APK build.

Each phase must compile and have tests before moving to the next. Do not scaffold every feature as empty screens in one pass.
