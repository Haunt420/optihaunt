# OptiHaunt — Curated Source Extract for Android Port

**Purpose:** Give a coding agent the highest-value source-derived information without requiring it to ingest the 1.9 MB downloaded HTML or the 925 KB extracted text dump.

**Source files inspected:** `optihauntdl.html` (downloaded HTML, ~1.94 MB) and its embedded `preloaded-generator-data`. The actual OptiHaunt app is contained in that embedded data: `modelText` (~115 KB) and `outputTemplate` (~925 KB).

**Important:** This is a source reference, not a complete executable port. The original imports external Perchance plugins (`ai-text-plugin`, `text-to-image-plugin`, `create-media-gallery-plugin`, and `tabbed-comments-plugin-v1`). Their implementation is not included as reusable Android code in this HTML. Reimplement or replace those provider integrations separately.

## 1. What to read first

1. **This document, sections 2–8:** implementation-critical behavior and source excerpts.
2. `modelText` feature specification: source-of-truth descriptions of the app's controls and behaviors.
3. `outputTemplate`: actual HTML structure, UI IDs, and JavaScript implementation.
4. Ignore the outer Perchance runtime/wrapper for a native port unless reproducing the original website hosting environment.

The `modelText` begins with TODO/backlog notes. Those are not all shipped features. Prefer the shipped behavior described in its numbered feature specification and implemented in `outputTemplate`; do not mistake backlog entries for requirements.

## 2. Original integration dependencies

```text
generateText = {import:ai-text-plugin}
generateImage = {import:text-to-image-plugin}
createMediaGallery = {import:create-media-gallery-plugin}
tabbedCommentsPlugin = {import:tabbed-comments-plugin-v1}
```

For the Android port, preserve the separation between text generation and image generation. The HTML does not provide a standalone, provider-neutral API contract for these imported plugins.

## 3. Primary interface structure (actual source HTML)

The following snippets are the high-value UI skeleton. Recreate the behavior natively; do not mechanically translate CSS or DOM manipulation.


### 3.1 Top toolbar and strategy controls

```html
<div id="topBar">
<div id="topLeft">
<button class="tbtn" id="showPromptsBtn" title="View and edit every prompt in this session">📜 <span class="tbtnLabel">Prompts</span></button>
<button class="tbtn" id="showSavedBtn" title="Images you saved with 🖼️ Save, from every session — likes don't go here">🖼️ <span class="tbtnLabel">Saved</span></button>
<button class="tbtn" id="showGalleryBtn" title="Open the public community gallery">🌐 <span class="tbtnLabel">Gallery</span></button>
<button class="tbtn" id="showCacheBtn" title="Every recent image, from all sessions">📷 <span class="tbtnLabel">Image Cache</span></button>
<button class="tbtn" id="showExportBtn" title="This session's upvoted and marked images — browse them and download them">🧺 <span class="tbtnLabel">Picked</span></button>
</div>
<div id="topRight">
<button class="tbtn" id="showTreeBtn" title="Open the prompt generation tree at the current instruction">🌳 <span class="tbtnLabel">Tree</span></button>
<select class="tbtn" id="resolutionSelect" title="Image resolution">
<option value="square">⬜ Square</option>
<option value="turbo">⚡ Turbo (512×512)</option>
<option value="portrait">🖼️ Portrait</option>
<option value="landscape">🌄 Landscape</option>
</select>
<div id="pauseWrap">
<button class="tbtn" id="pauseBtn" title="Pause or resume everything · ▾ to pause just one half"><span id="pauseBtnIcon">⏸️</span> <span class="tbtnLabel" id="pauseBtnLabel">Pause</span></button><button aria-expanded="false" aria-haspopup="true" class="tbtn" id="pauseMenuBtn" title="Pause just one half: writing new prompts, or drawing new images" type="button">▾</button>
<div id="pauseMenu" style="display:none">
<div id="pauseMenuCard">
<div class="strategyPopHeader">⏸️ Pause one half</div>
<button class="pauseMenuItem" id="pausePromptsItem" type="button"><span>✍️ Writing new prompts</span><span class="pauseMenuState" id="pausePromptsState">Running</span></button>
<button class="pauseMenuItem" id="pauseImagesItem" type="button"><span>🖼️ Drawing new images</span><span class="pauseMenuState" id="pauseImagesState">Running</span></button>
<div class="pauseMenuNote">Click a row to pause or resume it. Images already being drawn finish.</div>
</div>
</div>
</div>
<div id="strategyWrap">
<button class="tbtn" id="strategyBtn" title="Improvement Strategy — how the AI evolves your prompts">⚗️ <span class="tbtnLabel" id="strategyBtnLabel">Improvement Strategy</span><span class="strategyLevel" id="strategyBtnLevel"></span><span id="strategyBtnFlags"></span><span class="strategyCaret">▾</span></button>
<div id="strategyPopover" style="display:none">
<div class="strategyPopHeader">⚗️ Improvement Strategy</div>
<div class="strategyItem">
<div class="strategyItemHead strategyItemHeadRow">Creativity<a class="strategyHelpLink" data-help="helpCreativity" href="#" title="What do the three levels do? Opens 📖 Help">?</a></div>
<div class="segCtl" id="creativitySeg">
<span aria-hidden="true" class="segLabel">🎨</span>
<button class="segBtn" data-level="0" title="Stays on your request: free within it, but on-topic" type="button">Faithful</button>
<button class="segBtn" data-level="1" title="Fresh angles and varied mood, lighting &amp; style, keeping your subject and explicit asks" type="button">Balanced</button>
<button class="segBtn" data-level="2" title="Reinterprets and remixes freely, including bold departures" type="button">Creative</button>
</div>
<div class="strategyItemDesc">How far the AI may roam from your instruction.</div>
</div>
<div class="strategyItem">
<label class="strategyToggle"><input id="mixPromptsChk" type="checkbox"/> <span>🔀 Mix in likes from earlier instructions</span><a class="strategyHelpLink" data-help="helpMixPrompts" href="#" title="What does this change? Opens 📖 Help">?</a></label>
<div class="strategyItemDesc">The AI also learns from your likes under <b>all</b> earlier instructions, not just the current one.</div>
</div>
<div class="strategyItem">
<label class="strategyToggle"><input id="promoteUpvotedChk" type="checkbox"/> <span>🎯 Sometimes use a top-liked prompt as the instruction</span><a class="strategyHelpLink" data-help="helpPromoteUpvoted" href="#" title="How often, and which prompts? Opens 📖 Help">?</a></label>
<div class="strategyItemDesc">About 3 batches in 5 are written from a liked prompt instead of your instruction.</div>
</div>
<div class="strategyItem">
<label class="strategyToggle"><input id="freshOnlyChk" type="checkbox"/> <span>⏳ Fresh prompts only</span><a class="strategyHelpLink" data-help="helpFreshOnly" href="#" id="freshOnlyHelp" title="Which prompts does this skip? Opens 📖 Help">?</a></label>
<div class="strategyItemDesc">Each image uses a new prompt written for the current instruction — no <b>📌 stale</b> or reused ones. Also see Settings → Generation.</div>
</div>
<div class="strategySessionNote">Saved with this session only.</div>
</div>
</div>
<div id="miscWrap">
<button class="tbtn" id="miscBtn" title="Session tools — spin off a trimmed copy of this session, and clear its steer history">🧰 <span class="tbtnLabel">Session tools</span><span class="strategyCaret">▾</span></button>
<div id="miscPopover" style="display:none">
<div class="strategyPopHeader">🧰 Session tools</div>
<div class="strategyItem">
<div class="strategyItemHead">↪ Spin off a trimmed copy</div>
<div class="strategyItemDesc">Saves a <b>new</b> session with only your latest instructions and what they made. <b>This session isn't changed.</b></div>
<div id="spinBody">
<div id="spinSliderRow">
<input id="spinSlider" max="1" min="1" type="range" value="1"/>
</div>
<div class="spinSummary" id="spinSummary"></div>
<div class="spinPreview" id="spinPreview"></div>
<label class="spinNameLabel" for="spinNameInput">New session name</label>
<input id="spinNameInput" placeholder="Session name" type="text"/>
<button class="tbtn" id="spinCreateBtn" style="width:100%;margin-top:6px;" type="button">↪ Create trimmed copy</button>
<div class="spinStatus" id="spinStatus"></div>
</div>
</div>
<div class="strategyItem">
<div class="strategyItemHead">Steer history</div>
<button class="tbtn" id="clearSteerHistoryBtn" style="width:100%;margin-top:2px;" type="button">🧹 Clear steer history</button>
<div class="strategyItemDesc">Forgets the steer text behind past 🧲 steered images, so ❓ stops showing it. Can't be undone.</div>
</div>
</div>
</div>
<button class="tbtn" id="saveSessionBtn" style="display:none" title="Name this run to keep it in Saved Sessions — until then, the next new run replaces it">💾 <span class="tbtnLabel">Save as…</span></button>
<button class="autosaveStatus" id="autosaveStatus" style="display:none" type="button"></button>
<button class="tbtn" id="settingsBtn" title="Settings">⚙️</button>
<button class="tbtn" id="commentsBtn" title="Comments">💬</button>
<button class="tbtn" id="helpBtn" title="📖 Help — what each part does and how to use it">📖</button>
<button class="tbtn" id="sidebarExpandBtn" style="display:none" title="Show the prompt queue">🗒 Prompt queue <span class="sbArrowWide">«</span><span class="sbArrowNarrow">▴</span></button>
</div>
</div>
```


### 3.2 Instruction composer

```html
<div id="composerDock">
<div id="composerInner">
<!-- Two columns sharing the row the textarea used to fill alone: the field (with Start and the
         saved/spinner icons still overlaid on it) and a narrow control column. -->
<div id="instWrap">
<div id="instField">
<textarea id="instInput" placeholder='Describe what you want. E.g. "weird meme, low quality"' rows="3"></textarea>
<button id="startBtn">Start ▶</button>
<div class="instIcon" id="instSpinner"><div class="spinner"></div></div>
<div class="instIcon" id="instTick" title="Applied — this is the instruction in use"><span class="tick">✓</span></div>
</div>
<div id="instCol">
<button id="composerCollapseBtn" title="Hide instruction">▼</button>
<button id="discardInstBtn" title="Back to the instruction in use · Ctrl/Cmd+Z in the box brings your edit back" type="button">↺ Discard</button>
<!-- One slot, two occupants: the version tag while the box matches the instruction in use, ✓ Apply
             while an edit is pending — so the version you're on is always in view. -->
<div id="instApplySlot">
<span id="instVerTag" style="display:none"></span>
<button id="applyInstBtn" title="Apply this instruction change (Ctrl/Cmd+Enter)">✓ Apply</button>
</div>
<button class="influencesBtn" id="influencesBtn" type="button">Influences</button>
</div>
</div>
<div id="instEmptyMsg" role="alert">Type what you want to see first</div>
<div class="psfixHint" id="instHint" style="display:none">Ctrl/Cmd+Enter to apply · not in use until then</div>
</div>
</div>
```


### 3.3 Prompt queue / sidebar

```html
<div id="sidebar">
<div id="sidebarTitle">
<span>Prompt queue</span>
<button id="sidebarCollapseBtn" title="Hide the prompt queue"><span class="sbArrowWide">»</span><span class="sbArrowNarrow">▾</span></button>
</div>
<div id="sidebarStatus"></div>
<!-- Single scroll region: everything below the fixed header (title/sub/status) scrolls together,
       with the editable Upcoming list pinned to the bottom so it always gets the room it needs. -->
<div id="sidebarScroll">
<div id="sidebarInject">
<textarea id="sidebarInjectInput" placeholder="✏️ Add a prompt, or paste a list" rows="1"></textarea>
<button id="sidebarInjectBtn" title="Add to the front of the queue (Enter · Shift+Enter for a new line)">Add</button>
</div>
<div id="sidebarInfluence">
<textarea id="sidebarInfluenceInput" placeholder="🧲 Steer the next batch, e.g. neon" rows="1"></textarea>
<button id="sidebarInfluenceBtn" title="Queue this steer — used once, by the next batch (Enter)">Steer</button>
</div>
<div id="sidebarInfluenceChips"></div>
<div id="sidebarInflight"></div>
<div class="sidebarSection">Rules for every prompt</div>
<div id="sidebarPrefixSuffix">
<!-- 📏 Every-batch rule: a standing instruction the LLM follows in every brainstorm batch; \{a|b\} rolled per batch -->
<div class="psfixGroup">
<label for="batchRuleInput">📏 Rule for every batch<span id="batchRuleActive" style="display:none"> · active</span></label>
<div class="batchRuleWrap">
<textarea id="batchRuleInput" placeholder="pick random times of day" rows="2"></textarea>
<button id="batchRuleClearBtn" style="display:none" title="Clear the rule" type="button">✕</button>
</div>
<div class="psfixHint" id="batchRuleHint" style="display:none">Enter to apply · Esc to cancel</div>
</div>
<div class="psfixGroup">
<label for="promptPrefixInput">Prefix</label>
<textarea id="promptPrefixInput" placeholder="masterpiece, best quality," rows="2"></textarea>
<div class="psfixHint" id="promptPrefixHint" style="display:none">Enter to apply · Esc to cancel</div>
</div>
<div class="psfixGroup">
<label for="promptSuffixInput">Suffix</label>
<textarea id="promptSuffixInput" placeholder="4k, highly detailed" rows="2"></textarea>
<div class="psfixHint" id="promptSuffixHint" style="display:none">Enter to apply · Esc to cancel</div>
</div>
</div>
<div class="sidebarSection" title="Click a prompt to edit it — generation pauses while you do">Upcoming (<span id="sidebarUpcomingCount">0</span>)</div>
<div id="sidebarList"></div>
<div id="sidebarQueueActions" style="display:none">
<button class="sidebarQueueClearBtn danger" id="clearQueueBtn" type="button"></button>
<button class="sidebarQueueClearBtn" id="clearNonSteeredBtn" type="button"></button>
</div>
</div>
</div>
```


### 3.4 Main feed and resume surface

```html
<div id="main">
<div id="feedScroll">
<div id="resumePanel" style="display:none">
<div class="resumePanelInner">
<div class="resumePanelIcon" id="resumePanelIcon">📂</div>
<div class="resumePanelBody">
<div class="resumePanelTitle" id="resumePanelTitle">Previous session found</div>
<div class="resumePanelSub" id="resumePanelSub"></div>
</div>
<div class="resumePanelActions">
<button class="resumePanelBtn primary" id="resumeBtn">Resume</button>
<button class="resumePanelBtn" id="resumeSaveBtn" style="display:none" title="Name and save this session without loading it">💾 Save…</button>
<button class="resumePanelBtn" id="allSessionsBtn" title="Load, rename or delete any saved session">📂 All sessions</button>
<button aria-label="Close" class="resumePanelClose" id="resumePanelClose">✕</button>
</div>
</div>
</div>
<div id="feedPlaceholder">
<div id="feedPlaceholderTitle">Image Prompt Optimizer</div>
<div id="feedPlaceholderSub">
<ol id="introSteps">
<li><b>Type what you want to see</b> in the box at the bottom, then press <b>Start ▶</b>.</li>
<li>An AI writes a batch of image prompts from it. They line up in the sidebar, where you can edit or delete them before they're drawn.</li>
<li><b>Tap the images you like.</b> Liked prompts guide the next batches, so the stream drifts toward your taste.</li>
</ol>
<a href="#" id="introHelpLink">📖 Help — how it all works</a>
</div>
</div>
<div id="feed"></div>
<div id="sentinel" style="height:60px"></div>
<button aria-label="Jump to newest image" id="feedJumpBtn" title="Jump to the newest image" type="button"><span id="feedJumpDot"></span><span id="feedJumpLabel">↓ Newest</span></button>
</div>
</div>
```


### 3.5 Prompt management modal

```html
<div id="promptsModal">
<button aria-label="Close" class="modalCloseX" id="promptsCloseX">✕</button>
<div id="promptsModalInner">
<div id="promptsModalTop">
<div><b>Prompts</b> <span id="promptsModalSub">Best-liked first</span></div>
</div>
<div id="promptsFilterRow">
<input autocomplete="off" id="promptsSearch" placeholder="Search prompts…" type="text"/>
<div class="segCtl" id="promptsScopeSeg">
<button class="segBtn active" data-scope="current" type="button">This instruction</button>
<button class="segBtn" data-scope="all" type="button">All</button>
</div>
</div>
<div id="promptsAddBar">
<div id="promptAddExplain">Prompts you add here <b>skip to the front of the queue</b>.</div>
<div id="promptAddRow">
<textarea id="promptAddInput" placeholder="Add a prompt — paste a list for several" rows="1"></textarea>
<button id="addPromptBtn">Add prompt</button>
</div>
</div>
<div id="promptsList"></div>
</div>
</div>
```


### 3.6 Influences / instruction revision panel

`influencesModal` was not found as a static ID in the template; it may be dynamically created.


### 3.7 Generation tree entry point

`treeModal` was not found as a static ID in the template; it may be dynamically created.


## 4. Important source UI IDs

These IDs identify the original controls and are useful when searching the full `outputTemplate`. They are reference names, not a requirement to retain HTML IDs in Kotlin.

### Toolbar / strategy

```text
showPromptsBtn, showSavedBtn, showGalleryBtn, showCacheBtn, showExportBtn, showTreeBtn
resolutionSelect, pauseBtn, pausePromptsItem, pauseImagesItem
strategyBtn, strategyPopover, creativitySeg, mixPromptsChk
promoteUpvotedChk, freshOnlyChk, settingsBtn, helpBtn
```

### Instruction composer

```text
instInput, startBtn, instVerTag, applyInstBtn, discardInstBtn
influencesBtn, influencesBtnMini, composerCollapseBtn
```

### Prompt sidebar

```text
sidebarInjectInput, sidebarInjectBtn
sidebarInfluenceInput, sidebarInfluenceBtn, sidebarInfluenceChips
batchRuleInput, batchRuleClearBtn, promptPrefixInput, promptSuffixInput
sidebarUpcomingCount, sidebarList, clearQueueBtn, clearNonSteeredBtn
```

### Feed / prompt modal / persistence

```text
feed, feedScroll, feedPlaceholder, feedJumpBtn
promptsModal, promptsSearch, promptsScopeSeg, promptAddInput, promptsList
sessionModal, settingsModal, resumePanel, resumeBtn
```

## 5. Source-derived behavioral rules that must survive the port

### 5.1 Separate pipeline stages

There are two independently controllable stages: AI writing prompts and the image generator turning prompts into images. Pausing image generation does not have to stop prompt writing; pausing prompt writing does not have to stop already queued image jobs. The master Pause control pauses/resumes both.

### 5.2 Prompt queue is a real staging area

- Newly brainstormed prompts enter the Upcoming queue; they do not go directly to image generation.
- The source applies a 10-second cooldown so the user can inspect, edit, or delete a prompt before it is used.
- Editing an existing prompt pauses the pipeline while the editor has focus; finishing/collapsing resumes it.
- Manually added prompts are allowed to duplicate existing prompts.
- User-authored prompts are prioritized for their first image, then return to normal selection behavior.
- Prompt selection is not simply top-to-bottom; scoring, freshness, claim state, and cooldowns matter.

### 5.3 Feedback types are distinct

| Source control | What it changes | What it does not do |
|---|---|---|
| Image upvote / like | Updates image feedback and prompt vote/score; affects prompt selection and possible promotion | Does not directly revise the instruction |
| 🔖 Influence mark | Pending positive source for the next instruction revision; becomes a parent relationship when applied | Does not directly change prompt scoring or immediately steer image generation |
| 🚫 Anti-influence mark | Pending negative source for the next instruction revision; becomes a parent relationship when applied | Does not directly penalize prompt score or immediately steer image generation |
| 🧲 Theme Steer | Consumed by a future prompt-writing/brainstorm batch to guide the LLM | Is not an image bookmark and is not an instruction influence mark |

The source stores influence marks with a prompt ID and a text snapshot. Positive and negative marks are separate kinds. One prompt may legitimately be positive for one instruction version and negative for another.

### 5.4 Instruction edits are explicit commits

After Start, editing the instruction only changes a pending draft. The active instruction remains the last applied value. Apply creates a new instruction version, commits the pending influence and anti-influence marks as lineage parents, and updates prompt freshness/staleness. Reloading restores the unapplied draft as a draft; it must not silently apply it.

### 5.5 AI Help is advisory

AI Help uses the current instruction, pending draft, a user note, and wording associated with marked prompts (source cap: 12 most recent marks). It does not send the actual images as visual inputs. It offers rewrite modes: keep structure, freely restructure, tighten, and expand. The user can compare, use as draft, or apply. A suggestion is not itself an instruction version until applied.

### 5.6 Creativity modes

- **Faithful (0):** satisfy the instruction and include its details; do not conflict with it.
- **Balanced (1):** keep the subject and explicit requests fixed; vary rendering choices such as mood, lighting, composition, style, palette, and framing. Do not introduce wild departures or unrequested remixes.
- **Creative (2):** treat the instruction as a springboard; vary subjects, moods, styles, palettes, time periods, and allow bold departures.

The source explicitly separates creativity level from Mix Prompts.

### 5.7 Improvement Strategy switches

- **Mix in likes from earlier instructions:** when enabled, upvoted prompts from earlier instruction versions can be supplied as examples to the prompt-writing model. When disabled, examples are scoped to the current instruction version.
- **Promote Upvoted:** probabilistically use a successful, liked prompt as the effective instruction for a brainstorm batch. The source describes this as approximately 3 of 5 batches when enabled.
- **Fresh prompts only:** image generation waits for unused prompts written for the current instruction version. It does not fall back to stale or reused prompts. If no eligible prompt exists, waiting for another batch is normal.
- **Prioritize Steered Prompts:** allows steer-born prompts to be sent to image generation first.

### 5.8 Theme Steer queue

A Steer is a queued text instruction for a future brainstorm batch. Users can add, remove, and reorder Steers. The source consumes a Steer only after a successful batch produces usable prompts. On a transient generation failure or empty batch, the Steer is restored to the queue. Persist the consumed state atomically with the created prompts to avoid applying it twice after a crash.

### 5.9 Every-batch rule, prefix, suffix

- The Every-batch rule is included in every prompt-writing batch until cleared.
- Curly alternatives such as `{cinematic lighting|natural lighting|dramatic shadows}` are rolled for each batch; store both the source rule and the rolled variant.
- Prefix and suffix are applied when building the final image-generation text, not destructively appended to the stored original prompt. Avoid adding a prefix/suffix twice if already present.

### 5.10 Prompt scoring and selection

The source exposes a prompt score representing the share of generated images from that prompt that were liked. The visible formula in the source is `votes / used_count` (fresh prompts are displayed as Fresh rather than as a percentage). Selection also considers prompt freshness, usage, whether a prompt is already claimed by an in-flight job, exploration, cooldown, stale/current instruction version, and optional stale-bridge behavior. Do not replace this with a naive “highest score always wins” algorithm.

### 5.11 Prompt lineage / generation tree

The tree is more than a chronological list. It records causal relationships: instruction version → generated prompt; promoted prompt → prompts generated from it; prompt-mixing examples → prompts that drew from them; Theme Steer → prompts shaped by it; and marked prompt → instruction version that was revised using it. Support Focused and Whole-session views.

### 5.12 Session persistence

The source has named saved sessions plus an unnamed autosave/recovery slot. It preserves instruction versions, pending instruction draft, prompts, prompt queue/order, feed manifest, marks, Steer queue, settings, and image references. Restore must rebuild the feed and preserve lineage. Export/import supports session JSON and optional images.

## 6. High-value JavaScript source excerpts

These are selected implementation functions from `outputTemplate`. They are included to expose the original control flow and edge cases. They are not Kotlin-ready code.


### `queueSteer()`

```javascript
function queueSteer(text) {
  const t = (text || '').trim();
  if (!t) return 'empty';
  const lower = t.toLowerCase();
  const dupIdx = st.influenceQueue.findIndex(x => x.toLowerCase() === lower);
  if (dupIdx >= 0) return 'duplicate';
  st.influenceQueue.push(t);
  logEvent('influence_queued', { count: st.influenceQueue.length, text: t });
  renderInfluenceChips();
  scheduleAutosave();
  return 'queued';
}
```


### `rollBatchRule()`

```javascript
function rollBatchRule(str) {
  if (typeof str !== 'string') return '';
  const rolled = str.replace(/\{([^{}]*)\}/g, (_, inner) => {
    const opts = inner.split('|').map(x => x.trim());
    return opts[Math.floor(Math.random() * opts.length)];
  });
  return rolled.replace(/[{}]/g, '').replace(/[ \t]{2,}/g, ' ').trim();
}
```


### `infToggleMark()`

```javascript
function infToggleMark(task, anti) {
  if (!task) return false;
  anti = !!anti;
  const i = infPendingIndex(task);
  const markedEvent = anti ? 'anti_influence_marked' : 'influence_marked';
  if (i >= 0 && !!st.markedInfluences[i].anti === anti) {
    st.markedInfluences.splice(i, 1);
    logEvent(anti ? 'anti_influence_unmarked' : 'influence_unmarked', { count: st.markedInfluences.length });
  } else if (i >= 0) {
    const rec = st.markedInfluences[i];
    if (anti) rec.anti = true; else delete rec.anti;
    logEvent(markedEvent, { count: st.markedInfluences.length, switched: true });
  } else {
    const p = st.prompts[task.promptId];
    const rec = {
      taskId: task.id,
      cacheId: task.cacheId != null ? task.cacheId : null,   // may still be null; refreshed on save
      promptId: task.promptId || null,
      // Snapshot the wording now. The prompt can be edited, deleted or trimmed away later, and its exact
      // resolved wording is the only reason this image was worth marking.
      text: task.resolvedText || (p ? p.text : '')
    };
    if (anti) rec.anti = true;
    st.markedInfluences.push(rec);
    logEvent(markedEvent, { count: st.markedInfluences.length });
  }
  infRefreshTile(task);
  updateInfluencesBtn();
  scheduleAutosave();
  return true;
}
```


### `applyInstructionChange()`

```javascript
function applyInstructionChange() {
  st.instruction = instInput.value.trim();
  localStorage.setItem('instruction', st.instruction);

  // What was queued under the old version, read before the bump (getUntestedPrompts matches the current one).
  const queuedBefore = new Set(getUntestedPrompts().map(p => p.id));
  // Mark existing prompts stale and bump instruction version
  st.instVersion++;
  st.instHistory[st.instVersion] = st.instruction;   // so prompts stamped with this version stay traceable
  let keptQueued = 0, setAside = 0;
  const marksCommitted = st.markedInfluences.length;
  for (const id of st.order){
    const p = st.prompts[id];
    if (!p) continue;
    // Mode 2 used to spare 🧲 alone, which quietly dropped hand-written prompts on every Apply; it now
    // spares whatever you put there yourself, the same predicate the sidebar's bulk clear spares, so the
    // glyph pair means one thing everywhere. The widening only ever KEEPS more, so a session saved under
    // the old meaning loses nothing on its next Apply. Rules in keepPromptOnVersionChange().
    //
    // Keeping = re-stamp p.ver to the new version so it re-passes choosePromptForTask; p.influenced /
    // p.influenceText / p.origin ride through untouched (badge + "steered by" survive the change).
    const keep = keepPromptOnVersionChange(p, st.keepPromptsMode);
    if (keep) p.ver = st.instVersion;
    else      p.stale = true;
    if (queuedBefore.has(id)) { if (keep) keptQueued++; else setAside++; }
  }

  // Commit the marked set (🔖 and 🚫 together) to the version this edit just created, then clear it — the
  // next instruction starts with none. This is the single commit path (the composer's ✓ Apply,
  // Ctrl/Cmd+Enter and the Influences panel's Apply all route here), so it's the only place the handover
  // can happen. Marks commit whether or not you visibly used them: you marked them, that was the intent, and
  // there is no way to detect "used" — you retyped the instruction by hand.
  if (st.markedInfluences.length) {
    st.instInfluences[st.instVersion] = st.markedInfluences;
    logEvent('influences_committed', { count: st.markedInfluences.length,
      anti: st.markedInfluences.filter(r => r.anti).length, instVersion: st.instVersion });
    st.markedInfluences = [];
    infClearDiffs();           // those records are history now; nothing in the panel can toggle them again
    updateInfluencesBtn();
    refreshInfluenceFlags();   // pending 🔖 → committed 🔖; the tiles look the same but now say a version
  }

  // 💭 The note lands on the version this edit just created, beside that version's marks. A why on its
  // own is NOT a change — instIsDirty stays text-only, so there is no path that bumps the version and
  // stales the queue for a note. Empty notes are not stored: an absent key means "no note", and a version
  // carrying '' would render an empty 💭 line everywhere the note is shown.
  const infWhyText = (infWhyDraft || '').trim();
  if (infWhyText) st.instWhy[st.instVersion] = infWhyText;
  infResetWhyDraft();
  infSugAfterApply();   // ✨ a suggestion written against the version just replaced is out of date

  logEvent('instruction_updated', { length: st.instruction.length, instVersion: st.instVersion,
    whyLength: infWhyText.length });
  scheduleAutosave();
  ensureQueue();   // harmless before Start due to guard
  schedule();      // harmless before Start due to guard
  // The 100ms sidebar tick and schedule() both sit out a full pause, so without this the 📌 just set on
  // Now Generating rows (and the swept Upcoming list) wouldn't show until an in-flight image finished.
  renderSidebar();
  updateInstDirty();
  // What the Apply did with the queue and the marks happens out of sight, so say it once.
  const parts = [`Applied v${st.instVersion}`];
  if (setAside) parts.push(`${plural(setAside, 'queued prompt')} set aside`);
  else if (keptQueued) parts.push(`kept ${plural(keptQueued, 'queued prompt')}`);
  if (marksCommitted) parts.push(`${plural(marksCommitted, 'mark')} recorded`);
  if (parts.length > 1) showToast(parts.join(' · '));
}
```


### `choosePromptForTask()`

```javascript
function choosePromptForTask(){
  // Main selector: picks the next prompt to be used for an image generation task.
  
  // Only prompts for the current instruction version — and under ⏳ Fresh prompts only, only ones that have
  // never made an image (nor are making one), so the exploit branch and the re-use fallback below find
  // nothing and the untested pick answers.
  const all = getAllPrompts().filter(isDrawablePrompt);

  // CRITICAL: Filter by timer and focus immediately. 
  // Generation worker MUST NOT pick prompts that are still in "cooling down" (<10s) 
  // or currently being edited by the user.
  const now = Date.now();
  let available = all.filter(p => now >= (p.readyAt||0) && p.id !== st.focusedPromptId);

  // If we have literally nothing ready yet, stop here and wait for countdowns
  if (!available.length) return null;

  // ✏️ Prompts you wrote by hand — the Prompts modal, the sidebar Inject box, a lightbox "Add to queue"
  // — always go first, ahead of the 🧲 branch below. You typed them because you wanted to see them, and
  // a hand-written prompt taking a random turn behind 20+ AI ones reads as the tool ignoring you. Same
  // narrowing shape as the steer branch (scope `available` rather than return early) so the exploit /
  // explore / fallback branches stay intact, just scoped to the manual subset.
  //
  // effUsed()===0 is what makes this a one-time queue jump rather than a standing preference: it means
  // the prompt has never produced an image AND isn't already in flight. Once it lands its first image it
  // leaves this pool for good and competes on score like every other prompt, so a batch of manual adds
  // can't hold the feed forever. A generation that FAILS releases its claim without incrementing used,
  // so a failed manual prompt keeps its place at the front for the retry — same deal 🧲 gets.
  //
  // Unconditional, with no setting behind it (unlike "Send 🧲 steered prompts first"): p.origin is
  // assigned once at creation and never mutated, so unlike the transient p.influenced flag there's no
  // state here that can strand a prompt at the head of the queue. Manual and steered pools are disjoint
  // by construction — addPrompts() never inherits p.influenced — so narrowing to manual here simply
  // makes the steer branch below a no-op for this tick, never a second filter that empties the pool.
  const manual = available.filter(p => p.origin === 'manual' && effUsed(p) === 0);
  if (manual.length) available = manual;

  // Session setting: when on, divert the whole pick to ready+unclaimed 🧲 steer-born prompts so a
  // queued theme-steer surfaces in the feed sooner. Narrowing `available` (vs an early return) keeps
  // the exploit/explore/fallback branches below intact, just scoped to the steered subset. Unclaimed-
  // only: if every steered prompt is already in flight we fall through to normal selection rather than
  // force a duplicate or stall. p.influenced is TRANSIENT — cleared on a prompt's first successful
  // image — so this is a one-time queue-jump per steered prompt, not a standing preference: a prompt
  // that failed or is still in flight keeps its place here, but one that has produced an image leaves
  // this pool for good and competes normally. Nothing to filter here; the field does it.
  if (st.prioritizeSteered) {
    const steered = available.filter(p => p.influenced && (p._claimed||0) === 0);
    if (steered.length) available = steered;
  }

  // avoid picking prompts already claimed by other inflight tasks
  const scoredAvailable = available.filter(p=>p.score>0 && p.used>0 && (p._claimed||0)===0);
  const untestedZeroClaim = available.filter(p=>effUsed(p)===0);

  // Option 1: Prefer exploitation (re-using good prompts) some of the time
  if (scoredAvailable.length && Math.random() < (1-st.params.EXPLORATION_RATE)){
    const pool = scoredAvailable.slice().sort((a,b)=>b.score-a.score).slice(0,12);
    const pick = weightedPickByScore(pool) || pool[0];
    if (pick) return pick;
  }

  // Option 2: Exploration - pick from the batch of untested, ready prompts
  if (untestedZeroClaim.length){
    // randomize among untested zero-claim to mix the first batch
    return untestedZeroClaim[Math.floor(Math.random()*untestedZeroClaim.length)];
  }

  // Fallback: prefer unclaimed prompts to prevent duplicates in a batch; last resort allows re-use
  const unclaimed = available.filter(p => (p._claimed||0) === 0);
  return pickBestWeighted(unclaimed.length ? unclaimed : available);
}
```


### `schedule()`

```javascript
async function schedule(){
  // st.paused is both halves — with only one paused there is still work to do below.
  if (!st.started || st.startBusy || st.paused || st.anySidebarFocus) return;
  st.startBusy = true;
  logEvent('scheduler_tick', { waiting: st.waiting.length, inflight: st.inflight });

  try {
    /* Kick off prompt generation in the background */
    ensureUntestedStock(targetUntestedStock());
    ensureQueue();

    // The drawing half of the manual pause. Deliberately below the two calls above: with images paused
    // the AI carries on writing prompts and the queue carries on filling, so that everything is stocked
    // and ready the moment you resume — it just stops handing any of it to the image generator. (The
    // writing half is enforced inside ensureUntestedStock, which is the only thing it stops.) The
    // finally below still clears st.startBusy, so this early return leaves nothing wedged.
    if (st.pausedImages) return;

    // Before first image: wait until we have enough ready prompts from (ideally) multiple LLM batches
    if (!st.firstImageShown && st.inflight === 0) {
      const now = Date.now();
      const readyCount = getAllPrompts().filter(p => !p.stale && p.ver === st.instVersion && now >= (p.readyAt||0)).length;
      if (readyCount < st.params.MIN_PROMPTS_READY) {
        ensureUntestedStock(st.params.MIN_PROMPTS_READY);
        syncPlaceholders();
        scheduleDebounced();
        st.startBusy = false;
        return;
      }
    }

    for (let i = 0; i < st.waiting.length; i++) {
      if (st.inflight >= st.params.PARALLEL) break;
      const task = st.waiting[i];

      let p = choosePromptForTask();

      if (!p) {
        ensureUntestedStock(targetUntestedStock());
        // ⏳ Fresh prompts only takes neither the bridge nor the stale fallback (choosePromptForTask has
        // already refused reuse). The task stays waiting; the next batch landing wakes the scheduler, and
        // freshRetryIfStalled covers a batch that brings nothing.
        if (!st.freshPromptsOnly && st.staleBridgeMode > 0) {
          // Opted-in stale generation: the user asked for proven old prompts to fill exactly this gap, and
          // isBridgeActive() already encodes when that stops (mode 1: a batch exists for this version;
          // mode 2: a prompt for it has been upvoted). So the bridge is consulted ahead of the cooldown
          // guard below, and gets to answer on its own terms.
          if (isBridgeActive()) p = chooseBridgePrompt();
        } else if (!st.freshPromptsOnly && !currentVersionPromptsExist()) {
          // Unasked-for stale generation, and only justified when there is genuinely nothing else. A null
          // pick has two very different causes: no current-version prompts exist at all (this branch), or
          // they exist and are merely inside their PROMPT_WAIT_MS cooldown — the only filter
          // choosePromptForTask applies that simply waiting undoes. (It never returns null over *claimed*
          // prompts; its last fallback re-uses them. A focused prompt can't arise here either — schedule()
          // bails while a sidebar box has focus.) Restoring a session re-stamps every prompt with a fresh
          // cooldown, so a restored full queue sits in the second case for ~10s, and its first round used
          // to be generated entirely from stale prompts while the queue it had just restored waited its
          // turn. Falling through with p null leaves those tasks waiting for the fresh prompts instead.
          p = choosePromptIncludingStaleIfNeeded();
        }

        if (!p && getAllPrompts().length === 0) {
          try { await ensureUntestedStock(5); } catch(_) {}
          // the stale chooser tries choosePromptForTask first, so it needs no second call after it
          p = st.freshPromptsOnly ? choosePromptForTask() : choosePromptIncludingStaleIfNeeded();
        }

        // Nothing to run this tick and prompts are only cooling → re-arm for the soonest one. Without
        // this the run stalls: the scheduler is event-driven (a finished image, a new batch, a blur), and
        // a queue that is merely waiting out its cooldown fires none of those.
        if (!p && drawablePromptsExist()) {
          setTimeout(scheduleDebounced, Math.max(100, soonestReadyAt() - Date.now() + 50));
          break;   // every other waiting task would hit the same wall this tick
        }
        // Under ⏳ nothing else can answer within this tick either — no stale path — so don't repeat the
        // same full-pool passes for every waiting task. (Waiting between batches is ⏳'s normal state.)
        if (!p && st.freshPromptsOnly) break;
      }
      if (!p) continue;

      task.promptId = p.id;
      const resolved = evaluateCurlyFallback(p.text);
      const resolvedPrefix = evaluateCurlyFallback(st.promptPrefix);
      const resolvedSuffix = evaluateCurlyFallback(st.promptSuffix);
      const prefix = resolvedPrefix && !resolved.startsWith(resolvedPrefix) ? resolvedPrefix + ' ' : '';
      const suffix = resolvedSuffix && !resolved.endsWith(resolvedSuffix) ? ' ' + resolvedSuffix : '';
      task.resolvedText = prefix + resolved + suffix;
      p._claimed = (p._claimed || 0) + 1;
      task.state = 'running';
      task.startedAt = Date.now();
      task.epoch = st.epoch;
      st.inflight++;
      st.waiting.splice(i, 1);
      i--;

      logEvent('generation_started', { tid: task.id, promptId: p.id, promptText: p.text });

      (async () => {
        try {
          const promise = generateImage(task.resolvedText, { resolution: RESOLUTIONS[task.resolution] || '768x768' });
          // In plugin viewer mode, read iframeHtml synchronously BEFORE yielding.
          // This sets outputStringHasBeenRead=true inside the plugin, which prevents
          // the plugin's setTimeout from setting shouldRemoveIframeOnFinish=true.
          // The iframe stays alive after generation, preserving the heart button.
          const iframeHtml = st.pluginViewer ? promise.iframeHtml : null;
          // In plugin viewer mode, create the card NOW and insert the iframe directly.
          // We cannot move iframes later — browsers reload them on DOM reparenting,
          // which loses the generated image and restarts generation from scratch.
          // The card starts with CSS order:99999 so it sits at the bottom (with placeholders).
          // When generation completes, order is set to a completion index so it rises to the top.
          if (iframeHtml) {
            const ui = createCard();
            task.ui = ui;
            ui.card.classList.add('plugin-viewer-card');
            ui.card.dataset.tid = task.id;
            ui.card.dataset.idx = String(task.idx);
            ui.card.style.aspectRatio = ASPECT_RATIOS[task.resolution || st.resolution];
            ui.card.style.order = '99999';
            ui.inner.innerHTML = iframeHtml;
            const iframe = ui.inner.querySelector('iframe');
            if (iframe) {
              iframe.style.cssText = 'width:100%;height:100%;border:0;display:block;';
              iframe.dataset.alreadyAddedIntersectionObserver = 'yes';
            }
            feedEl.appendChild(ui.card);
            if (iframe && iframe.dataset.src) {
              iframe.removeAttribute('srcdoc');
              iframe.src = iframe.dataset.src;
            }
          }
          const url = await promise;
          if (task.epoch !== st.epoch) return;    // session changed while we were generating — discard silently
          if (!url || String(url).length < 10) {
            throw new Error('Invalid or empty image URL');
          }
          task.seed = url.inputs?.seed ?? null;
          p.used += 1;
          // 🧲 marks an ACTIVE (unused) steered prompt. The moment it produces its first image it's just
          // another prompt in the pool, so retire the flag here — at the single used-increment site, on
          // the success path only. Every reader of p.influenced turns unused-only for free: the badge in
          // promptProvenance(), "Send steered prompts first" in choosePromptForTask(), the Keep-🧲✏️ sweep
          // in applyInstructionChange(), and the "Keep 🧲 steered + ✏️ yours" tally. A generation that FAILS never
          // reaches here, so a failed steer keeps its badge and its priority for the retry — only a
          // produced image spends the steer. p.influenceText is deliberately KEPT: the ❓ details panel
          // and the 🌳 generation tree still name which steer shaped this prompt, long after the badge
          // is gone. Keep the knowledge, retire the flag.
          //
          // The tile is the one surface that asks a per-IMAGE question — "was THIS image the one the
          // steer shaped?" — and the answer is yes for exactly the image being finished here. It can't
          // read it off the prompt: the card is built a few lines below, by which time the flag is gone,
          // which is why the first steered image was rendering badge-less. So record the answer on the
          // task before clearing, and let populateFlags prefer it (promptProvenance's second arg).
          task.influenced = p.influenced === true;
          if (p.influenced) p.influenced = false;
          recomputeScore(p);
          // In plugin viewer mode the card already exists with the iframe;
          // set order to pull it to the top, then add the overlay bar and upvote logic.
          if (task.ui) {
            task.ui.card.style.order = String(st._iframeCompletionOrder = (st._iframeCompletionOrder || 0) + 1);
            if (st.pendingPool.length > 0) {
              st.pendingPool.shift().remove();
            }
            st.unseenCards.add(task.ui.card);
            if (window.cardIO) window.cardIO.observe(task.ui.card);
            attachIframeOverlay(task, url, p, task.resolvedText);
          } else {
            onTaskComplete(task, url, p, task.resolvedText);
          }
          task.state = 'done';
          st.lastImageAt = Date.now();
          if (task.startedAt) task.genMs = st.lastImageAt - task.startedAt;
          // Success path only, past the epoch guard — a failure is a timeout, not a generation time, and
          // a run that is failing shows up as a small sample count beside a normal average, which is the
          // honest signal. genMs excludes queue wait (startedAt is stamped at dispatch), so the figure
          // stays comparable across sessions with very different queue depths.
          if (task.genMs) recordTiming(st.imageTimes, task.genMs);
          logEvent('generation_succeeded', { tid: task.id, promptId: p.id, score: p.score });
        } catch (e) {
          if (task.epoch !== st.epoch) return;    // zombie — swallow; the finally guard below also bails
          // A failure releases the claim without counting a use, so under ⏳ the same fresh prompt is the
          // first pick again the instant the finally below calls schedule(). Make it wait out the normal
          // cooldown, so a prompt the image generator keeps rejecting can't fill the feed with failures.
          if (st.freshPromptsOnly) p.readyAt = Date.now() + st.params.PROMPT_WAIT_MS;
          onTaskError(task, e);
          task.state = 'error';
          logEvent('generation_failed', { tid: task.id, error: String(e).slice(0, 160) });
        } finally {
          if (task.epoch !== st.epoch) return;  // zombie from a prior session — don't touch current counters
          p._claimed = Math.max(0, (p._claimed || 1) - 1);
          st.inflight--;
          syncPlaceholders();
          renderSidebar();
          schedule();
        }
      })();
    }

    syncPlaceholders();
    renderSidebar();
  } finally {
    st.startBusy = false;
  }
}
```


### `buildSessionData()`

```javascript
async function buildSessionData(sessionName) {
  const domOrder = new Map();
  Array.from(feedEl.children).forEach((c, i) => {
    if (c.dataset.tid) domOrder.set(c.dataset.tid, i);
  });

  // Snapshot the upvote list so a vote/unvote landing during the async thumbnail
  // loop below can't corrupt this save's view of the world. Any change that races
  // in is caught by the autosave single-flight re-run.
  const upvotedSnapshot = st.upvotedTasks.slice();

  const images = [];
  for (const t of upvotedSnapshot) {
    if (t.imgEl) {
      // Cache the compressed thumbnail on the task once; reuse on later saves so
      // autosave-per-vote doesn't re-encode every keeper each time. Seeded from the
      // stored thumbnail on restore (createRestoredCard), so restored sessions
      // re-save with zero re-encoding until a new image is upvoted.
      if (!t._thumb) t._thumb = await compressImage(t.imgEl);
      images.push({
        promptId: t.promptId,
        thumbnail: t._thumb,
        promptText: st.prompts[t.promptId]?.text || '',
        resolvedText: t.resolvedText || '',
        idx: domOrder.get(t.taskId) ?? st.tasksById[t.taskId]?.idx,
        // Re-read from the live task like seed below: cacheImage fills task.cacheId asynchronously, so
        // an upvote that landed before the cache write snapshotted null into this row.
        cacheId: st.tasksById[t.taskId]?.cacheId ?? t.cacheId ?? null,
        seed: st.tasksById[t.taskId]?.seed ?? null,
        // Whether THIS image is the one that spent its prompt's steer (see the p.used += 1 site). The
        // prompt can't answer it after the fact — its 🧲 retires on this very image — so the answer has
        // to ride the image row or the badge wouldn't survive a save/restore. Written only when true;
        // absent means "no" for every image saved before this and every unsteered one.
        ...(st.tasksById[t.taskId]?.influenced ? { influenced: true } : {})
      });
    }
  }

  // Feed manifest: a ~50-byte row per generated image, liked or not, pointing at its full-res blob in
  // the image cache. Deliberately NOT merged into `images` — the Export tab builds its list from
  // `images` (exBuildItems), and unliked images must never appear there. Carries no thumbnail, so a
  // row whose blob has expired simply restores nothing.
  //
  // Pruning is implicit: when the live feed is the complete picture, re-deriving from it drops rows
  // whose cards weren't rebuilt (blob gone). That's only safe when restore actually rebuilt every
  // surviving image — i.e. the cache was reachable AND we weren't in carry-forward mode (cache down at
  // restore, or the user opted out of restoring unliked tiles). In carry-forward mode the feed is
  // incomplete, so we preserve the prior manifest and only fold in newly generated images, never prune.
  const liveRows = [];
  for (const tid in st.tasksById) {
    const t = st.tasksById[tid];
    if (!t || t.state !== 'done' || t.cacheId == null) continue;
    // `influenced` (this image spent its prompt's steer) is written only when true — see the images[]
    // row above for why it lives on the image rather than the prompt.
    liveRows.push({ cacheId: t.cacheId, promptId: t.promptId, idx: domOrder.get(tid) ?? t.idx, seed: t.seed ?? null,
                    ...(t.influenced ? { influenced: true } : {}) });
  }

  const cacheUsable = IC_ENABLED && !!icDB;
  let feedManifest;
  if (cacheUsable && !st.feedManifestCarryForward) {
    feedManifest = liveRows;   // authoritative feed → re-derive and prune
  } else {
    // Union prior rows with any new generation, deduped by cacheId. Prior rows are kept unconditionally
    // (we can't verify them), so they age out only by failing to restore, never by pruning here.
    const byId = new Map();
    for (const r of (st.feedManifest || [])) if (r && r.cacheId != null) byId.set(r.cacheId, r);
    for (const r of liveRows) if (!byId.has(r.cacheId)) byId.set(r.cacheId, r);
    feedManifest = Array.from(byId.values());
  }

  const prompts = {};
  for (const id of st.order) {
    const p = st.prompts[id];
    if (!p) continue;
    prompts[id] = {
      id: p.id,
      text: p.text,
      used: p.used,
      votes: p.votes,
      score: p.score,
      createdAt: p.createdAt,
      ver: p.ver,
      stale: p.stale,
      origin: p.origin || 'generated',
      influenced: !!p.influenced,
      influenceText: p.influenceText || null,
      // Whether that steer is second-hand (copied in by an upvote capture) rather than this prompt's own.
      // Stored, not derived at display time: deriving means walking p.parent, which a spin-off can trim
      // away — and a trimmed lineage would quietly start reading as first-hand, which is worse than not
      // showing it at all. Old saves lack it → null → reads as first-hand, matching how they behaved.
      influenceInherited: p.influenceInherited || null,
      // Prompt generation tree lineage. This clone is a whitelist (not a {...p} spread), so both must be
      // named here or they'd silently not persist. Old saved sessions lack both → restored as a root
      // with no mix-ins (the traversal treats a missing/dangling parent as a root under its version).
      parent: p.parent || null,
      drewFrom: p.drewFrom || null,
      // 📏 the every-batch rule (already {a|b}-rolled) this prompt's batch was written under. Old saves → null.
      batchRule: p.batchRule || null
    };
  }

  // Awaits (thumbnail encoding), so it runs before infIdx below, which must come after the last await.
  const markThumbs = await buildMarkThumbs();

  // 🔖 One cacheId → task pass for every influence list below. Built HERE, after the awaits above, not at
  // the top of the function: cacheImage fills a task's cacheId in asynchronously, and an index snapshotted
  // before that landed would miss the image and save the record with a null id, unmatchable on restore.
  const infIdx = infCacheIndex();

  const sessionData = {
    meta: {
      // The recovery slot stays "unnamed": null sessionName means restoreSession
      // won't adopt a currentSessionName, so resuming it keeps autosaving to the slot.
      sessionName: sessionName === AUTOSAVE_SLOT ? null : sessionName,
      instruction: st.instruction,
      instVersion: st.instVersion,
      instHistory: st.instHistory,
      instWhy: st.instWhy,
      // The unapplied edit, so a reload or a crash brings it back with ✓ Apply still pending. Per SESSION,
      // not the global boot draft in localStorage — that one is for before Start, and sharing it would
      // bleed one session's half-written edit into another. Only when it differs from what's applied (an
      // untouched box is not a draft); its 💭 note rides with it, since a note has no meaning without the
      // edit it explains. ✨ AI help is deliberately not saved: it's cheap to ask again, and a suggestion
      // written against a moment that has passed would need explaining.
      ...(instIsDirty() ? { pendingDraft: instInput.value, pendingWhy: (infWhyDraft || '').trim() || null } : {}),
      resolution: st.resolution,
      numPromptBatchesGenerated: st.numPromptBatchesGenerated,
      savedAt: Date.now(),
      nextIdx: st.nextIdx,
      allowPromptMixing: st.allowPromptMixing,
      creativity: st.creativity,
      promoteUpvoted: st.promoteUpvoted,
      freshPromptsOnly: st.freshPromptsOnly,
      staleBridgeMode: st.staleBridgeMode,
      keepPromptsMode: st.keepPromptsMode,
      autoQueueVariant: st.autoQueueVariant,
      prioritizeSteered: st.prioritizeSteered,
      promptPrefix: st.promptPrefix,
      promptSuffix: st.promptSuffix,
      batchRule: st.batchRule,
      // A brainstorm consumes a steer by shift()-ing it off influenceQueue BEFORE the LLM await; during
      // that in-flight window the steer lives only in st.consumedSteer — neither the queue nor any prompt.
      // Re-queue it into the saved copy so a crash/reload mid-flight doesn't lose it. The dedup guard
      // (case-insensitive, mirroring restoreSteer) covers the sliver where the steer was already handed
      // back to the live queue but st.consumedSteer hasn't been cleared yet.
      influenceQueue: (() => {
        const q = [...st.influenceQueue];
        const s = st.consumedSteer;
        if (s != null && !q.some(x => x.toLowerCase() === s.toLowerCase())) q.unshift(s);
        return q;
      })(),
      // 🔖 marked influences — unrelated to influenceQueue above (that's the 🧲 steer). The PENDING set
      // is saved: six deliberately marked images are accumulated judgement, and re-finding them in an
      // infinite feed is hard.
      // One index shared across every list here, built once per save rather than rebuilt per call.
      markedInfluences: infSerialize(st.markedInfluences, infIdx),
      instInfluences: Object.fromEntries(
        Object.entries(st.instInfluences).map(([v, list]) => [v, infSerialize(list, infIdx)])
      )
    },
    prompts,
    order: [...st.order],
    images,
    feedManifest,
    markThumbs
  };

  return sessionData;
}
```


### `restoreSession()`

```javascript
async function restoreSession(sessionData) {
  clearTimeout(autosaveTimer); autosaveTimer = null;
  restoreInProgress = true;
  try { return await restoreSessionBody(sessionData); }
  finally { restoreInProgress = false; restoreProgressEnd(); }
}
```

### `mgtBuild()` — lineage graph builder

The complete function is ~23 KB and is intentionally not duplicated here. Search `outputTemplate` for `function mgtBuild()` if implementing exact traversal. Its key behavior: build node/edge indexes for instruction versions, prompts, Steers, influence parents, promoted batches, and prompt-mixing “drew from” links; support Focused and Whole-session graph modes.


## 7. What not to port from this HTML

Do not waste the Android agent's context or implementation time on:

- Perchance's outer editor/runtime, iframe messaging, service-worker bootstrap, import-map machinery, and server-rendering wrappers.
- Perchance-specific comment/gallery embedding unless explicitly required in the Android product.
- DOM positioning, hover-only tooltips, CSS layout hacks, browser-specific event handling, and iframe preservation workarounds. Recreate the intent in native UI.
- Website-only links, Perchance metadata, browser storage polyfills, and browser lifecycle workarounds.
- The TODO backlog as if every item were shipped. Some entries explicitly describe unfinished or proposed features.

Do not assume the imported Perchance AI plugins are included in the source dump. They are dependency declarations, not the provider implementations.

## 8. Recommended extraction order for a coding agent

If the agent needs more detail, give it these slices from the original source in this order:

1. `modelText` beginning: integration declarations, product spec, and feature descriptions.
2. `outputTemplate` UI skeleton: `topBar`, `composerDock`, `sidebar`, `main`, and `promptsModal`.
3. `outputTemplate` state initialization: search for `const st =`.
4. `outputTemplate` prompt selection: `choosePromptForTask`, `choosePromptIncludingStaleIfNeeded`, `chooseBridgePrompt`, `recomputeScore`, `toggleUpvote`.
5. `outputTemplate` generation pipeline: `ensureUntestedStock`, `schedule`, and the prompt-writing batch function around `generateText(sys)`.
6. `outputTemplate` instruction and influence logic: `infToggleMark`, `applyInstructionChange`, AI Help request/suggestion handlers.
7. `outputTemplate` persistence: `buildSessionData`, `saveSession`, `loadSession`, `restoreSessionBody`, `restoreFeedManifest`.
8. `outputTemplate` lineage graph: `mgtBuild`, `mgtComputeLineage`, and the Focused/Whole-session view controls.

## 9. Source-derived facts versus port recommendations

**Directly represented in source:** the UI concepts, distinct feedback behaviors, strategy definitions, prompt queue cooldown, independent pause controls, Theme Steer queue, explicit instruction Apply, prompt selection/freshness behavior, session restoration, and lineage relationships.

**Port recommendations added for Android:** Kotlin/Compose, Room, WorkManager/foreground execution where appropriate, backend job orchestration, provider-neutral interfaces, REST/SSE/WebSocket contracts, UUID-based database schema, and idempotent job submission. These are implementation recommendations, not code or architecture supplied by the original HTML.

## 10. Minimal instruction to accompany this extract

> Use this curated source extract as the behavioral reference for the OptiHaunt Android port. Preserve the source's distinctions and control flow. Do not treat the Perchance HTML runtime as application logic that must be copied literally. Reimplement the UI natively and the generation pipeline with provider-independent services. Where this extract identifies a function name, inspect only that function and its immediate dependencies in the original `optihauntdl.html` if more detail is required. Do not ingest the full HTML unless a specific unresolved behavior requires it.
