#!/bin/sh
set -eu
cat original_html_part_*.bin > optihauntdl_reassembled.html
sha256sum optihauntdl_reassembled.html
