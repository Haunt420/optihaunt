# OptiHaunt Android Port — Modular Source Pack

This pack is designed to avoid loading the entire original HTML into a coding agent's context for every task. The original download is preserved byte-for-byte in ordered chunks, and the important embedded application assets are also extracted into readable modules.

## What is included

- `01_original_html_parts/`: complete original `optihauntdl.html` split into 6 binary chunks. Concatenate in filename order to reconstruct the exact original file. Chunk hashes and byte offsets are in `manifest.json`.
- `02_original_app_spec/`: original Perchance `modelText`, original `outputTemplate`, imports/manifest, plus line-bounded modelText pieces.
- `03_perchance_plugins/`: each imported Perchance generator plugin source extracted separately.
- `04_ui_template/ui_markup.html`: original UI markup portion of the output template.
- `05_runtime_javascript/`: original JavaScript runtime, plus manageable line-bounded chunks.
- `06_styles/styles.css`: original styles.
- `07_android_blueprint_modules/`: concise Android implementation modules, each intended to be loaded only for the feature being built.
- `08_reference/curated_source_extract.md`: earlier curated behavioral/source guide.

## Recommended agent loading strategy

**Do not attach the complete pack or the full HTML for every task.** Start with only:
1. The task-specific Android module from `07_android_blueprint_modules/`.
2. `08_reference/curated_source_extract.md` if the task concerns original behavior.
3. The relevant source file(s) from `02_original_app_spec`, `03_perchance_plugins`, `04_ui_template`, `05_runtime_javascript`, or `06_styles`.

Load additional chunks only when the agent identifies a concrete unresolved dependency.

## Source map

- Original modelText: `02_original_app_spec/modelText_full.txt` (1247 lines), also split into 5 line-bounded pieces.
- Original outputTemplate: `02_original_app_spec/outputTemplate_full.html` (16403 lines).
- UI markup: lines 1–886 of outputTemplate.
- Runtime JS: lines 887–15115 of outputTemplate, also split into 10 chunks.
- Styles: lines 15117–16403 of outputTemplate.
- Imported plugin source count: 8.

## Important fidelity rules

- The `.txt`/`.html` extracted files are source material, not an instruction to paste the web implementation into an Android WebView. The target remains native Kotlin/Jetpack Compose per the blueprint.
- Preserve source behavior unless a port-specific change is explicitly documented. Distinguish confirmed source behavior from Android design decisions.
- `modelText` contains a TODO backlog. Do not treat TODO items as shipped functionality.
- Imported Perchance plugin code is present in this download. External provider services, credentials, quota policies, and compatibility are separate concerns and must be verified per plugin.
- Do not claim that an implementation is faithful until the relevant source behavior has been checked and tested.

## Reconstruct exact original HTML

From inside `01_original_html_parts/`, run `sh REASSEMBLE.sh`. It writes `optihauntdl_reassembled.html`. The reconstructed file should match the SHA-256 in `manifest.json`.
