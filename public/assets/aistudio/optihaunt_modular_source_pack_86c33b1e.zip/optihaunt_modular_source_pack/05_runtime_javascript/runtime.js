<script>
/* ===================== State & Logging ===================== */
/* Lifecycle:
   - Tasks are headless (no DOM) until completion:
     waiting[] -> running (generation started) -> done/error (card created)
   - Feed DOM = [finished cards] + [N generic placeholder spinners]
*/

const st = {
  instruction: localStorage.getItem('instruction') || '',
  instVersion: 1,     // bump on instruction changes
  prompts: {},        // id -> { id, text, used, votes, score, createdAt, ver, stale, origin, _claimed? }
  order: [],

  // tasks
  waiting: [],        // headless tasks waiting their turn
  pendingPool: [],    // generic placeholder DOM elements
  tasksById: {},
  inflight: 0,
  epoch: 0,            // bumped on session restore so zombie IIFEs from the old session skip their finally cleanup
  firstImageShown: false,

  // indices for anti-infinite-generation guard
  nextIdx: 0,
  unseenCards: new Set(),  // cards not yet scrolled past by the user
  numPromptBatchesGenerated: 0,

  // sidebar focus tracking: prevent new generation from removing a prompt while being edited
  anySidebarFocus: false,
  focusedPromptId: null,
  focusStartTime: 0,
  focusTimer: null,
  /* The manual pause is two independent halves — writing new prompts, and drawing new images from the
     prompts that exist. The ⏸️ button still flips both at once; its ▾ menu is what reaches one.
     `paused` is kept as a derived reader so the places that mean "the whole pipeline is stopped"
     (the scheduler's top guard, the 100ms sidebar re-render, the pipeline panel's first line) say
     exactly that and don't have to be rewritten every time a third half turns up. Nothing assigns to
     it — see setPauseState(). */
  pausedPrompts: false,
  pausedImages: false,
  get paused() { return this.pausedPrompts && this.pausedImages; },
  sidebarVisible: true,
  composerVisible: true,

  // text generation single-flight
  textGenBusy: false,
  textGenPromise: null,
  // ✨ An Influences-panel instruction suggestion holds the next brainstorm turn, from the moment you ask
  // until it ends. Never saved: a restore stops the ask and clears it (infSugReset).
  suggestBusy: false,
  suggestStartedAt: 0,   // 0 while it is still waiting for a running batch to finish

  // scheduler reentrancy guard
  startBusy: false,

  // hard gate to prevent any generation before Start is clicked
  started: false,

  // event log (last 1000)
  events: [],

  resolution: 'square',   // 'square' | 'turbo' | 'portrait' | 'landscape'

  imageSizeScale: parseFloat(localStorage.getItem('imageSizeScale') || '1'),  // 0.5 to 2.0

  // session save/restore
  upvotedTasks: [],       // [{ taskId, promptId, imgEl, resolvedText }]
  // Only populated on the carry-forward path: a restore that couldn't reach the image cache (or where
  // the user has opted out of restoring unliked tiles) stashes the manifest here so the next save
  // preserves it instead of pruning rows it never rebuilt. feedManifestCarryForward records that we're
  // in that mode, so saveSession keeps the manifest rather than re-deriving it from an incomplete feed.
  feedManifest: [],
  feedManifestCarryForward: false,
  hasSavedSessions: null, // null=unchecked, true/false=checked (any sessions exist?)
  savedSessionToastShown: false,
  savedSessionsList: [],  // [{ name, data }] — all saved (named) sessions, newest first
  // Boot deliberately does NOT fill savedSessionsList: reading every record to find one was the whole
  // reason the resume bar arrived late. Until something scans (📂, or any save/rename/delete/import),
  // the list is empty and MEANINGLESS rather than empty and true — this flag is the difference.
  sessionsListLoaded: false,
  // The one record boot actually reads, via the remembered-latest pointer: { name, data, isAutosave }.
  resumeCand: null,
  currentSessionName: null, // name of the currently loaded/saved session (null = unnamed → autosaves to recovery slot)
  autosaveSlot: null,     // data of the reserved unnamed crash-recovery slot, or null

  allowPromptMixing: false,
  creativity: 0,          // 0 = Faithful, 1 = Balanced, 2 = Creative
  promoteUpvoted: false,
  freshPromptsOnly: false, // ⏳ every image from an unused current-version prompt: no 📌 stale, no reuse
  promptPrefix: '',
  promptSuffix: '',
  batchRule: '',          // 📏 standing instruction added to every brainstorm batch; {a|b} rolled once per batch
  influenceQueue: [],     // FIFO of queued theme-steer prompts (user can drag-reorder the chips); one is consumed per brainstorm batch
  // instVersion → the instruction text in force at that version. Needed because st.instruction is
  // overwritten in place on every edit, so a stale prompt's originating instruction was previously
  // unrecoverable (the event log records its length, not its text). Uncapped: instructions are a
  // sentence or two, against saves that already carry a base64 thumbnail per liked image.
  instHistory: {},
  // 🔖 Marked influences — images you bookmarked while browsing, to reread while rewriting the
  // instruction. Purely an authoring aid: nothing here is sent to the LLM or affects selection. Do NOT
  // confuse with influenceQueue above, which is the 🧲 theme steer and genuinely reshapes a batch.
  // A record is { taskId, cacheId, promptId, text, anti? }: taskId is the live-session handle, cacheId the
  // durable one (restored cards mint fresh task ids, so only cacheId survives a reload), and `text` is
  // task.resolvedText snapshotted at mark time so the record outlives its prompt. `anti: true` makes it a
  // 🚫 anti-influence — an image you DON'T want — which is every bit as inert; absent means 🔖. Both kinds
  // share these two lists, so an image can only ever be pending as one of them.
  markedInfluences: [],   // pending working set; cleared into instInfluences on Apply
  instInfluences: {},     // instVersion → the records committed to it; permanent, parallel to instHistory
  // cacheId → 128px base64 thumbnail of a marked image that isn't liked (liked rows carry their own in
  // images[]), so 🧺 Picked can still show it once its card is gone. Carried forward from save to save
  // and pruned only when no mark record names the cacheId any more — see buildMarkThumbs.
  markThumbs: {},
  // 💭 instVersion → the optional one-line note saying WHY that instruction was written. Provenance
  // only: nothing reads it during generation, exactly like a 🔖 mark. Third dict parallel to
  // instHistory / instInfluences, and pruned with them on a spin-off.
  instWhy: {},
  pluginViewer: localStorage.getItem('ipo_pluginViewer') === 'true',
  staleBridgeMode: 0,      // 0=Off, 1=Until Batch, 2=Until Upvote
  keepPromptsMode: 1,      // 0=Off, 1=Keep all unused, 2=Keep steered (🧲) + hand-written (✏️) unused only — survives instruction edits (session setting; default Keep all)
  autoQueueVariant: true,  // when true, upvoting a {a|b}-variant image pins its resolved wording as a new ⭐ prompt (session setting; default on = original behavior)
  prioritizeSteered: true,  // when true, choosePromptForTask() diverts to ready+unclaimed 🧲 influenced prompts first — a one-time jump, since influenced clears on first use (session setting; default on)
  freshBatchVersion: 0,

  // Pipeline telemetry for the sidebar stats panel. Never persisted — all of it describes work that is
  // either in flight right now or finished moments ago, so a restored session must start blank rather
  // than claim a batch has been running since before the save.
  textGenStartedAt: 0,    // when the in-flight brainstorm was dispatched (0 = none)
  textGenSteer: null,     // steer text consumed by the in-flight batch, or null if unsteered
  textGenBatchRule: null, // 📏 rolled every-batch rule the in-flight batch was sent, or null
  consumedSteer: null,    // steer shift()-ed off influenceQueue but not yet resolved (baked into a prompt or handed back); saveSession re-queues it so an in-flight steer survives a crash/reload
  lastTextGenMs: 0,       // duration of the last completed brainstorm
  lastTextGenCount: 0,    // prompts it produced
  lastImageAt: 0,         // when an image last came back
  // Rolling duration samples behind the panel's two averages. Same non-persistence rule as everything
  // above, and the same reason: they describe how fast THIS run has been going, which a save cannot
  // carry anywhere useful. Chronological by construction — only ever appended with Date.now().
  textGenTimes: [],         // [{t, ms}] one per completed brainstorm batch
  imageTimes: [],           // [{t, ms}] one per successful image
  timingsSince: Date.now(), // when the two buffers started collecting; re-stamped on Start and on restore

  params: {
    MAX_QUEUE: 32,           // keep this many (waiting + running) headless tasks
    PARALLEL: 5,             // parallel image generations
    UNT_MIN_STOCK: 20,       // base floor for untested prompts
    GEN_PROMPTS_BATCH: 6,    // generate text in small batches of 5
    LEAD_CAP: 30,            // max images ahead of last seen/interacted
    EXPLORATION_RATE: 0.50,  // exploration vs exploitation tradeoff of the search algorithm
    PROMPT_WAIT_MS: 10000,   // time new prompts must stay in sidebar before use
    STALE_RECENCY_DECAY: 0.7,// per-version decay when picking stale prompts (0.7^age)
    MIN_PROMPTS_READY: 6     // min ready prompts from different LLM batches before generating images
  }
};

const RESOLUTIONS = {
  square:    '768x768',
  turbo:     '512x512',  // lowest square the backend allows — generates ~2x cheaper than 768²
  portrait:  '512x768',
  landscape: '768x512',
};
const ASPECT_RATIOS = {
  square:    '1 / 1',
  turbo:     '1 / 1',    // same 1:1 footprint as square; only pixel resolution differs
  portrait:  '512 / 768',
  landscape: '768 / 512',
};

/* Friendly descriptions for high‑level event types */
const EVENT_DESCRIPTIONS = {
  'start': 'Started the session and created initial headless tasks.',
  'instruction_updated': 'Instruction edited; prompts will adapt.',
  'queue_fill': 'Filling the visible grid with empty slots.',
  'scheduler_tick': 'Scheduler cycle to claim capacity and dispatch generation.',
  'generation_started': 'Started generating an image from a prompt.',
  'generation_succeeded': 'Image finished generating.',
  'generation_failed': 'Image generation failed.',
  'evo_generate_begin': 'Generating new prompts (batch of 5).',
  'evo_generate_done': 'Finished generating prompts from the LLM and added them.',
  'evo_prompts_added': 'Adding prompt(s) to the population.',
  'manual_prompts_added': 'You manually added prompt(s) in the Prompts panel.',
  'upvote': 'An image was upvoted; boosting its prompt.',
  'session_saved': 'Session saved to browser storage.',
  'session_autosaved': 'Session auto-saved to browser storage.',
  'session_restored': 'Session restored from browser storage.',
  'session_cleared': 'Saved session cleared from browser storage.',
  'session_spun_off': 'Spun off a trimmed copy of the session as a new named session.',
  'steer_history_cleared': 'Cleared recorded steer history from prompts.',
  'resolution_changed': 'Image resolution setting changed.',
  'prompt_mixing_toggled': 'Prompt mixing across instructions was toggled.',
  'creativity_changed': 'Creativity level changed.',
  'promote_upvoted_toggled': 'Promote Upvoted mode was toggled.',
  'stale_bridge_changed': 'The fill-the-gap-with-old-liked-prompts (🌉) mode changed.',
  'keep_prompts_mode_changed': 'Keep-unused-prompts-on-instruction-change mode changed.',
  'auto_queue_variant_toggled': 'Toggled Variant Upvoting (queue resolved variant on like).',
  'fresh_only_toggled': 'Toggled ⏳ Fresh prompts only (images wait for prompts written for the current instruction; no stale or reused ones).',
  'prioritize_steered_toggled': 'Toggled Prioritize Steered Prompts (send 🧲 steer-born prompts first).',
  'manual_prompts_injected': 'Prompts were manually injected via the sidebar input.',
  'influence_queued': 'Queued a theme-steer prompt to influence the next brainstorm batch.',
  'influence_removed': 'Removed a queued theme-steer prompt.',
  'influence_reordered': 'Reordered the queued theme-steer prompts by dragging.',
  'influence_applied': 'Applied a theme-steer prompt to a brainstorm batch.',
  'batch_rule_applied': 'A brainstorm batch was written under the 📏 every-batch rule (text = the rolled variant, source = what the box held).',
  'batch_rule_set': 'The 📏 every-batch rule was changed (applied on Enter / leaving the box).',
  'batch_rule_cleared': 'The 📏 every-batch rule was cleared with its ✕.',
  'undo': 'An Undo button on a toast put back something just removed (what = which kind).',
  'instruction_draft_discarded': 'The unapplied instruction edit was thrown away with ↺ Discard.',
  'autosave_slot_named': 'Before a new run started, the unsaved previous run was given a name and kept.',
  'autosave_slot_discarded': 'Before a new run started, the unsaved previous run was thrown away.',
  // 🔖 marked influences (bookmarked images), NOT the 🧲 theme steer above — worded so a log skimmed
  // months later can't read one as the other.
  'influence_marked': 'Bookmarked an image as a 🔖 influence for the next instruction.',
  'influence_unmarked': 'Removed an image from the 🔖 influences.',
  'anti_influence_marked': 'Marked an image as a 🚫 anti-influence for the next instruction.',
  'anti_influence_unmarked': 'Removed an image from the 🚫 anti-influences.',
  'influences_committed': 'Recorded the marked 🔖 influences and 🚫 anti-influences as parents of the new instruction version.',
  'instruction_history_used': 'Loaded an earlier instruction version into the draft from the Influences panel\'s 🕘 History.',
  'instruction_suggested': 'Asked the AI (✨ AI help in the Influences panel) to draft a new instruction from the marked prompts and a note, or to ▶ Continue one that ran out of room.',
  'manual_pause_toggle': 'Pause prompts / pause images was toggled.',
  'prompt_deleted': 'A queued prompt was deleted from the Upcoming list.',
  'prompts_cleared': 'Queued prompts were bulk-cleared from the Upcoming list (the payload says what was spared).',
  'plugin_viewer_toggled': 'Plugin-viewer (iframe) image mode was toggled.',
  'feed_manifest_restored': 'Rebuilt the feed layout from the saved session manifest.',
  'sidebar_toggle': 'The prompt queue sidebar was collapsed or expanded.',
  'composer_toggle': 'The instruction composer was collapsed or expanded.',
  'tree_mode': 'The 🌳 tree switched between Focused and Whole-session views.',
};
/* Only keep high‑level events; filter out noisy UI events */
const LOG_ALLOWED = new Set(Object.keys(EVENT_DESCRIPTIONS));

/* Metadata‑first logging; drop only huge/unsafe fields (e.g., data URLs) */
function sanitizeForLog(data) {
  const dropKeys = new Set(['url','image','html','data','body','preview']);
  const out = {};
  for (const [k,v] of Object.entries(data||{})) {
    if (dropKeys.has(k)) {
      if (k === 'url') {
        const s = String(v || '');
        out.urlKind = s.startsWith('data:') ? 'data' : (s ? 'http' : 'none');
        out.urlLength = s.length || 0;
      }
      continue;
    }
    if (typeof v === 'string') {
      out[k] = v.length > 280 ? (v.slice(0,280) + `… [omitted ${v.length-280} chars]`) : v;
    } else if (Array.isArray(v)){
      // Clamp strings inside arrays too
      out[k] = v.map(x => typeof x === 'string' ? (x.length>280 ? x.slice(0,280)+'…' : x) : x);
    } else if (typeof v === 'object' && v){
      out[k] = sanitizeForLog(v);
    } else {
      out[k] = v;
    }
  }
  return out;
}

function logEvent(type, data={}) {
  if (!LOG_ALLOWED.has(type)) return;
  const ev = { t: new Date().toISOString(), type, ...sanitizeForLog(data) };
  st.events.push(ev);
  if (st.events.length > 1000) st.events.shift();
  try { console.debug('[EV]', type, ev); } catch(_){}
}

/* ===================== Session Save/Restore (IndexedDB) ===================== */

const SESSION_DB_NAME = 'ipo_saved_session';
const SESSION_DB_VERSION = 1;

// Reserved key holding the latest *unnamed* working session, for crash recovery.
// Excluded from the named-session list (getAllSessions); surfaced specially in the
// resume panel. Overwritten by autosave until the user explicitly names/saves.
const AUTOSAVE_SLOT = '__autosave__';
const AUTOSAVE_DEBOUNCE_MS = 2000;

/* ---- "Which session did I touch last?", remembered instead of re-derived ----
   The resume bar above the title can't be drawn until we know which saved session is the most recent,
   and that used to be worked out by loading EVERY saved session in full — all of their prompts, and the
   embedded preview thumbnail of every liked image in each. With a lot of saved sessions, or big ones,
   that was a visible wait during which the page looked like it had nothing to resume, and then a bar
   appeared and shoved the layout down, sometimes after you had already started typing.

   So: write down the answer whenever a session is saved, and at boot read ONE record. This is a HINT,
   never a source of truth — nothing but the boot path reads it, and every way it can be wrong (stale
   name, deleted session, localStorage unavailable) falls through to the full scan, which is exactly
   what the code did before. It can therefore only ever cost the old speed, never show the wrong bar.

   Kept in localStorage rather than as a reserved record in the session store: an in-store index written
   in the same transaction as each put genuinely cannot diverge, but keeping it honest means threading
   index maintenance through save, rename, delete, spin-off and both import paths, and any one of those
   getting it wrong produces a WRONG resume bar rather than a slow one. Weaker guarantee, weaker failure. */
const LATEST_SESSION_KEY = 'ipo_lastSessionKey';

function readLatestSessionPointer() {
  try {
    const raw = localStorage.getItem(LATEST_SESSION_KEY);
    if (!raw) return null;
    const p = JSON.parse(raw);
    return (p && typeof p.name === 'string') ? p : null;
  } catch (e) { return null; }
}

// Named sessions only. The unnamed recovery slot lives under one fixed key, so boot reads it directly
// and never needs to be told where it is.
// Just the name: a savedAt was stored here at first and never read, because the freshness question boot
// actually asks — is the named session newer than the recovery slot — is answered by comparing the two
// RECORDS' own meta.savedAt in resumeCandidate(). A second copy of a timestamp that nothing consults
// only invites someone to trust it. Still an object rather than a bare string so it stays extensible.
function noteLatestSession(name) {
  try { localStorage.setItem(LATEST_SESSION_KEY, JSON.stringify({ name })); }
  catch (e) { /* storage full or blocked: next boot just does the full scan */ }
}

function forgetLatestSession(onlyIfName) {
  try {
    if (onlyIfName != null) {
      const p = readLatestSessionPointer();
      if (!p || p.name !== onlyIfName) return;
    }
    localStorage.removeItem(LATEST_SESSION_KEY);
  } catch (e) {}
}

// How many saved-image thumbnails to preview in the resume panel and Saved Sessions
// rows. User-configurable (2–4) in Settings; the stored thumbnails are reused as-is,
// never re-encoded. See buildSessionThumbs().
const SESSION_THUMB_DEFAULT = 2;
let SESSION_THUMB_COUNT = (() => {
  const n = parseInt(localStorage.getItem('ipo_sessionThumbCount') || SESSION_THUMB_DEFAULT, 10);
  return (n >= 2 && n <= 4) ? n : SESSION_THUMB_DEFAULT;
})();

function openDB(name, version, onUpgrade) {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(name, version);
    req.onerror = () => reject(req.error);
    req.onsuccess = () => resolve(req.result);
    req.onupgradeneeded = (e) => onUpgrade(e.target.result, e);
  });
}

function openSavedSessionDB() {
  return openDB(SESSION_DB_NAME, SESSION_DB_VERSION, (db) => {
    if (!db.objectStoreNames.contains('session')) db.createObjectStore('session');
  });
}

// MIGRATION: Move legacy single-session ('current' key) to named multi-session format.
// Remove this function and its call in checkForSavedSession() once no users have the old format.
async function migrateLegacySession() {
  const db = await openSavedSessionDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('session', 'readwrite');
    const store = tx.objectStore('session');
    const getReq = store.get('current');
    getReq.onsuccess = () => {
      const data = getReq.result;
      if (!data) return resolve(false);
      const savedAt = data.meta?.savedAt;
      const defaultName = savedAt
        ? `Session – ${new Date(savedAt).toLocaleDateString()}`
        : 'Saved Session';
      data.meta = data.meta || {};
      data.meta.sessionName = defaultName;
      const putReq = store.put(data, defaultName);
      putReq.onsuccess = () => {
        store.delete('current');
        resolve(true);
      };
      putReq.onerror = () => reject(putReq.error);
    };
    getReq.onerror = () => reject(getReq.error);
  });
}

// Keys only — getAllKeys() never touches a record's value, so this costs the same whether the store
// holds two sessions or two hundred megabytes of them. Enough to answer "is there anything saved at
// all?" and "is the remembered key still there?", which is the whole of what boot needs.
async function getSessionKeys() {
  const db = await openSavedSessionDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('session', 'readonly');
    const req = tx.objectStore('session').getAllKeys();
    req.onsuccess = () => resolve((req.result || []).map(String));
    req.onerror = () => reject(req.error);
  });
}

// …the same two reserved keys getAllSessions() skips: the recovery slot is surfaced separately, and
// 'current' is the pre-migration single-session key.
async function getNamedSessionKeys() {
  return (await getSessionKeys()).filter(k => k !== AUTOSAVE_SLOT && k !== 'current');
}

async function getAllSessions() {
  const db = await openSavedSessionDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('session', 'readonly');
    const store = tx.objectStore('session');
    const sessions = [];
    const cursorReq = store.openCursor();
    cursorReq.onsuccess = (e) => {
      const cursor = e.target.result;
      if (cursor) {
        // MIGRATION: skip legacy 'current' key if it somehow still exists.
        // Also skip the reserved autosave slot — it's surfaced separately, not in the named list.
        if (cursor.key !== 'current' && cursor.key !== AUTOSAVE_SLOT) {
          sessions.push({ name: cursor.key, data: cursor.value });
        }
        cursor.continue();
      } else {
        sessions.sort((a, b) => (b.data.meta?.savedAt || 0) - (a.data.meta?.savedAt || 0));
        resolve(sessions);
      }
    };
    cursorReq.onerror = () => reject(cursorReq.error);
  });
}

// The full scan plus all the bookkeeping that has to travel with it. st.sessionsListLoaded flips true
// here and nowhere else: it's what tells resumeCandidate() that st.savedSessionsList is a real answer
// rather than the empty array boot now leaves it as. Every caller sits after a mutation (save-as,
// rename, delete, import, spin-off) or after the 📂 button, so the list going live is always a
// consequence of the user doing something that needs it.
async function refreshSessionsList() {
  st.savedSessionsList = await getAllSessions();
  st.sessionsListLoaded = true;
  st.hasSavedSessions = st.savedSessionsList.length > 0;
  // We're holding the definitive answer, so re-point the boot hint at it here rather than in each of
  // the paths above — one place to be right instead of six places to forget.
  const top = st.savedSessionsList[0];
  if (top) noteLatestSession(top.name);
  else forgetLatestSession();
  // Boot's single-record shortcut is now redundant, and it holds a whole session (thumbnails included).
  st.resumeCand = null;
  return st.savedSessionsList;
}

async function compressImage(imgEl) {
  return new Promise((resolve) => {
    const canvas = document.createElement('canvas');
    const size = 128;
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d');
    
    const naturalSize = Math.min(imgEl.naturalWidth || 128, imgEl.naturalHeight || 128);
    const sx = ((imgEl.naturalWidth || 128) - naturalSize) / 2;
    const sy = ((imgEl.naturalHeight || 128) - naturalSize) / 2;
    
    try {
      ctx.drawImage(imgEl, sx, sy, naturalSize, naturalSize, 0, 0, size, size);
      resolve(canvas.toDataURL('image/jpeg', 0.7));
    } catch (e) {
      resolve('');
    }
  });
}

// 🧺 Thumbnails for marked images, so the Picked dialog's Marked grid still has a picture once the card
// (and, after 72h, the cached original) is gone. CARRIED FORWARD from st.markThumbs, never re-derived from
// the page: the case an entry exists for is exactly the one where its card isn't on the page, so
// rebuilding from live cards would delete it on the very next autosave. Encoded once, from the live
// card's image, the first time a save sees a marked image that isn't liked (liked rows carry their own
// thumbnail in images[], so a liked image never has an entry here). Pruned by reference — an entry whose
// cacheId no mark record names any more is dropped — and once its image is liked. Marks with no cacheId (image caching off) get none; nothing about an unliked image
// survives a reload in that mode anyway.
async function buildMarkThumbs() {
  const idx = infCacheIndex();
  const liked = new Set();
  for (const u of st.upvotedTasks) { const cid = likedCacheId(u); if (cid != null) liked.add(cid); }
  const byCid = new Map();   // cacheId → live task, or null when the image has no card
  for (const r of infAllRecords(st.markedInfluences, st.instInfluences)) {
    const t = infTaskOf(r, idx);
    const cid = (t && t.cacheId != null) ? t.cacheId : r.cacheId;
    if (cid != null && !byCid.get(cid)) byCid.set(cid, t || null);
  }
  const out = {};
  for (const [cid, t] of byCid) {
    // Liked first: its images[] row already carries the thumbnail, so a carried copy would be a duplicate.
    if (liked.has(cid)) continue;
    if (st.markThumbs[cid]) { out[cid] = st.markThumbs[cid]; continue; }
    const img = t && t.ui && t.ui.imgEl;
    if (!img) continue;
    // A restored card whose original aged out shows its saved thumbnail — once un-liked, that data URL
    // is the only copy left, so it's kept as-is (re-encoding a 128px JPEG would only lose detail). Ahead
    // of the decode check: the src is copied, never drawn, so a save before it decodes must not drop it.
    if (img._ipoThumbOnly) { if (/^data:image\//.test(img.src)) out[cid] = img.src; continue; }
    if (!img.complete || !img.naturalWidth) continue;
    const b64 = await compressImage(img);
    if (b64) out[cid] = b64;
  }
  st.markThumbs = out;
  return out;
}

// A liked entry's cacheId, read from its live task first. The entry copies task.cacheId at upvote time and
// never updates it, so an image liked before cacheImage finished would otherwise read as uncached — the
// same rule buildSessionData's images[] rows follow.
function likedCacheId(u) {
  if (!u) return null;
  const t = st.tasksById[u.taskId];
  return t && t.cacheId != null ? t.cacheId : (u.cacheId != null ? u.cacheId : null);
}

// Pure prune for a session-data copy: keep only the markThumbs entries a kept mark record still names.
function pruneMarkThumbs(markThumbs, meta) {
  if (!markThumbs) return {};
  const keep = new Set();
  for (const r of infAllRecords(meta && meta.markedInfluences, meta && meta.instInfluences)) {
    if (r.cacheId != null) keep.add(String(r.cacheId));
  }
  const out = {};
  for (const cid in markThumbs) if (keep.has(String(cid))) out[cid] = markThumbs[cid];
  return out;
}

// Snapshot the live session into a plain sessionData object WITHOUT writing it to disk or
// mutating st.currentSessionName. Shared by saveSession (which persists it) and doSpinOff
// (which trims a copy before persisting), so both reuse the same thumbnail encoding,
// feed-order derivation, and manifest logic. Pure read of live st + DOM.
async function buildSessionData(sessionName) {
  const domOrder = new Map();
  Array.from(feedEl.children).forEach((c, i) => {
    if (c.dataset.tid) domOrder.set(c.dataset.tid, i);
  });

  // Snapshot the upvote list so a vote/unvote landing during the async thumbnail
  // loop below can't corrupt this save's view of the world. Any change that races
  // in is caught by the autosave single-flight re-run.
  const upvotedSnapshot = st.upvotedTasks.slice();

  const images = [];
  for (const t of upvotedSnapshot) {
    if (t.imgEl) {
      // Cache the compressed thumbnail on the task once; reuse on later saves so
      // autosave-per-vote doesn't re-encode every keeper each time. Seeded from the
      // stored thumbnail on restore (createRestoredCard), so restored sessions
      // re-save with zero re-encoding until a new image is upvoted.
      if (!t._thumb) t._thumb = await compressImage(t.imgEl);
      images.push({
        promptId: t.promptId,
        thumbnail: t._thumb,
        promptText: st.prompts[t.promptId]?.text || '',
        resolvedText: t.resolvedText || '',
        idx: domOrder.get(t.taskId) ?? st.tasksById[t.taskId]?.idx,
        // Re-read from the live task like seed below: cacheImage fills task.cacheId asynchronously, so
        // an upvote that landed before the cache write snapshotted null into this row.
        cacheId: st.tasksById[t.taskId]?.cacheId ?? t.cacheId ?? null,
        seed: st.tasksById[t.taskId]?.seed ?? null,
        // Whether THIS image is the one that spent its prompt's steer (see the p.used += 1 site). The
        // prompt can't answer it after the fact — its 🧲 retires on this very image — so the answer has
        // to ride the image row or the badge wouldn't survive a save/restore. Written only when true;
        // absent means "no" for every image saved before this and every unsteered one.
        ...(st.tasksById[t.taskId]?.influenced ? { influenced: true } : {})
      });
    }
  }

  // Feed manifest: a ~50-byte row per generated image, liked or not, pointing at its full-res blob in
  // the image cache. Deliberately NOT merged into `images` — the Export tab builds its list from
  // `images` (exBuildItems), and unliked images must never appear there. Carries no thumbnail, so a
  // row whose blob has expired simply restores nothing.
  //
  // Pruning is implicit: when the live feed is the complete picture, re-deriving from it drops rows
  // whose cards weren't rebuilt (blob gone). That's only safe when restore actually rebuilt every
  // surviving image — i.e. the cache was reachable AND we weren't in carry-forward mode (cache down at
  // restore, or the user opted out of restoring unliked tiles). In carry-forward mode the feed is
  // incomplete, so we preserve the prior manifest and only fold in newly generated images, never prune.
  const liveRows = [];
  for (const tid in st.tasksById) {
    const t = st.tasksById[tid];
    if (!t || t.state !== 'done' || t.cacheId == null) continue;
    // `influenced` (this image spent its prompt's steer) is written only when true — see the images[]
    // row above for why it lives on the image rather than the prompt.
    liveRows.push({ cacheId: t.cacheId, promptId: t.promptId, idx: domOrder.get(tid) ?? t.idx, seed: t.seed ?? null,
                    ...(t.influenced ? { influenced: true } : {}) });
  }

  const cacheUsable = IC_ENABLED && !!icDB;
  let feedManifest;
  if (cacheUsable && !st.feedManifestCarryForward) {
    feedManifest = liveRows;   // authoritative feed → re-derive and prune
  } else {
    // Union prior rows with any new generation, deduped by cacheId. Prior rows are kept unconditionally
    // (we can't verify them), so they age out only by failing to restore, never by pruning here.
    const byId = new Map();
    for (const r of (st.feedManifest || [])) if (r && r.cacheId != null) byId.set(r.cacheId, r);
    for (const r of liveRows) if (!byId.has(r.cacheId)) byId.set(r.cacheId, r);
    feedManifest = Array.from(byId.values());
  }

  const prompts = {};
  for (const id of st.order) {
    const p = st.prompts[id];
    if (!p) continue;
    prompts[id] = {
      id: p.id,
      text: p.text,
      used: p.used,
      votes: p.votes,
      score: p.score,
      createdAt: p.createdAt,
      ver: p.ver,
      stale: p.stale,
      origin: p.origin || 'generated',
      influenced: !!p.influenced,
      influenceText: p.influenceText || null,
      // Whether that steer is second-hand (copied in by an upvote capture) rather than this prompt's own.
      // Stored, not derived at display time: deriving means walking p.parent, which a spin-off can trim
      // away — and a trimmed lineage would quietly start reading as first-hand, which is worse than not
      // showing it at all. Old saves lack it → null → reads as first-hand, matching how they behaved.
      influenceInherited: p.influenceInherited || null,
      // Prompt generation tree lineage. This clone is a whitelist (not a {...p} spread), so both must be
      // named here or they'd silently not persist. Old saved sessions lack both → restored as a root
      // with no mix-ins (the traversal treats a missing/dangling parent as a root under its version).
      parent: p.parent || null,
      drewFrom: p.drewFrom || null,
      // 📏 the every-batch rule (already {a|b}-rolled) this prompt's batch was written under. Old saves → null.
      batchRule: p.batchRule || null
    };
  }

  // Awaits (thumbnail encoding), so it runs before infIdx below, which must come after the last await.
  const markThumbs = await buildMarkThumbs();

  // 🔖 One cacheId → task pass for every influence list below. Built HERE, after the awaits above, not at
  // the top of the function: cacheImage fills a task's cacheId in asynchronously, and an index snapshotted
  // before that landed would miss the image and save the record with a null id, unmatchable on restore.
  const infIdx = infCacheIndex();

  const sessionData = {
    meta: {
      // The recovery slot stays "unnamed": null sessionName means restoreSession
      // won't adopt a currentSessionName, so resuming it keeps autosaving to the slot.
      sessionName: sessionName === AUTOSAVE_SLOT ? null : sessionName,
      instruction: st.instruction,
      instVersion: st.instVersion,
      instHistory: st.instHistory,
      instWhy: st.instWhy,
      // The unapplied edit, so a reload or a crash brings it back with ✓ Apply still pending. Per SESSION,
      // not the global boot draft in localStorage — that one is for before Start, and sharing it would
      // bleed one session's half-written edit into another. Only when it differs from what's applied (an
      // untouched box is not a draft); its 💭 note rides with it, since a note has no meaning without the
      // edit it explains. ✨ AI help is deliberately not saved: it's cheap to ask again, and a suggestion
      // written against a moment that has passed would need explaining.
      ...(instIsDirty() ? { pendingDraft: instInput.value, pendingWhy: (infWhyDraft || '').trim() || null } : {}),
      resolution: st.resolution,
      numPromptBatchesGenerated: st.numPromptBatchesGenerated,
      savedAt: Date.now(),
      nextIdx: st.nextIdx,
      allowPromptMixing: st.allowPromptMixing,
      creativity: st.creativity,
      promoteUpvoted: st.promoteUpvoted,
      freshPromptsOnly: st.freshPromptsOnly,
      staleBridgeMode: st.staleBridgeMode,
      keepPromptsMode: st.keepPromptsMode,
      autoQueueVariant: st.autoQueueVariant,
      prioritizeSteered: st.prioritizeSteered,
      promptPrefix: st.promptPrefix,
      promptSuffix: st.promptSuffix,
      batchRule: st.batchRule,
      // A brainstorm consumes a steer by shift()-ing it off influenceQueue BEFORE the LLM await; during
      // that in-flight window the steer lives only in st.consumedSteer — neither the queue nor any prompt.
      // Re-queue it into the saved copy so a crash/reload mid-flight doesn't lose it. The dedup guard
      // (case-insensitive, mirroring restoreSteer) covers the sliver where the steer was already handed
      // back to the live queue but st.consumedSteer hasn't been cleared yet.
      influenceQueue: (() => {
        const q = [...st.influenceQueue];
        const s = st.consumedSteer;
        if (s != null && !q.some(x => x.toLowerCase() === s.toLowerCase())) q.unshift(s);
        return q;
      })(),
      // 🔖 marked influences — unrelated to influenceQueue above (that's the 🧲 steer). The PENDING set
      // is saved: six deliberately marked images are accumulated judgement, and re-finding them in an
      // infinite feed is hard.
      // One index shared across every list here, built once per save rather than rebuilt per call.
      markedInfluences: infSerialize(st.markedInfluences, infIdx),
      instInfluences: Object.fromEntries(
        Object.entries(st.instInfluences).map(([v, list]) => [v, infSerialize(list, infIdx)])
      )
    },
    prompts,
    order: [...st.order],
    images,
    feedManifest,
    markThumbs
  };

  return sessionData;
}

async function saveSession(sessionName, opts = {}) {
  const db = await openSavedSessionDB();
  const sessionData = await buildSessionData(sessionName);

  return new Promise((resolve, reject) => {
    const tx = db.transaction('session', 'readwrite');
    const store = tx.objectStore('session');
    const request = store.put(sessionData, sessionName);
    request.onsuccess = () => {
      if (sessionName === AUTOSAVE_SLOT) {
        // Recovery slot: keep the in-memory copy fresh (used by the resume panel),
        // but it is NOT a named session — don't claim it as the current session.
        st.autosaveSlot = sessionData;
      } else {
        st.hasSavedSessions = true;
        st.currentSessionName = sessionName;
        // Every write to a named session passes through here, autosaves included, so this is where the
        // "which one did I touch last?" pointer earns its keep. While nothing has scanned the store,
        // keep boot's single-record candidate pointing at what we just wrote too — we're holding it.
        noteLatestSession(sessionName);
        if (!st.sessionsListLoaded) st.resumeCand = { name: sessionName, data: sessionData, isAutosave: false };
        updateSessionButtons();
      }
      logEvent(opts.isAutosave ? 'session_autosaved' : 'session_saved', {
        promptCount: st.order.length,
        imageCount: sessionData.images.length,
        instructionLength: st.instruction.length,
        sessionName
      });
      resolve();
    };
    request.onerror = () => reject(request.error);
  });
}

async function loadSession(sessionName) {
  const db = await openSavedSessionDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('session', 'readonly');
    const store = tx.objectStore('session');
    const request = store.get(sessionName);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function deleteSession(sessionName) {
  const db = await openSavedSessionDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('session', 'readwrite');
    const store = tx.objectStore('session');
    const request = store.delete(sessionName);
    request.onsuccess = async () => {
      if (st.currentSessionName === sessionName) {
        st.currentSessionName = null;
      }
      // A pointer must never outlive what it points at — boot would spend a full scan finding that out.
      forgetLatestSession(sessionName);
      if (st.resumeCand && st.resumeCand.name === sessionName) st.resumeCand = null;
      // Unconditional: the only way to delete is from a Saved Sessions row, which can't exist unless the
      // list was already scanned, so this is the refresh that path always did. (An earlier version forked
      // on sessionsListLoaded to avoid a scan — a dead branch that bought a second store read.)
      await refreshSessionsList();
      updateSessionButtons();
      logEvent('session_cleared', { sessionName });
      resolve();
    };
    request.onerror = () => reject(request.error);
  });
}

// Raw delete of the recovery slot — no logging / no "session_cleared" side effects.
// Used after a first explicit Save promotes an unnamed session to a named one.
async function deleteAutosaveSlot() {
  st.autosaveSlot = null;
  try {
    const db = await openSavedSessionDB();
    await new Promise((resolve, reject) => {
      const tx = db.transaction('session', 'readwrite');
      tx.objectStore('session').delete(AUTOSAVE_SLOT);
      tx.oncomplete = resolve;
      tx.onerror = () => reject(tx.error);
    });
  } catch (e) { /* non-fatal: slot is best-effort */ }
}

/* ===================== Autosave (debounced, single-flight) ===================== */
// Named/loaded session overwrites itself; an unnamed session rolls into the slot.
function autosaveTargetName() { return st.currentSessionName || AUTOSAVE_SLOT; }

let autosaveTimer = null;     // pending debounced save (non-null ⇒ unsaved changes)
let autosaveInFlight = false; // a saveSession() is currently awaiting
let autosaveQueued = false;   // a change arrived mid-save ⇒ re-run once after it resolves
let autosaveFailNotified = false;
// True while the toolbar 'Save as…' button is playing its post-save linger+fade.
// saveSession() sets currentSessionName mid-animation (which would otherwise make
// updateSessionButtons() yank the button instantly), so we hold it off until the fade ends.
let explicitSaveAnimating = false;

// Set while a backup import is rewriting the session store. Autosaves are suppressed
// for the duration so a debounced save of the active session can't race the import
// (resurrecting a "replaced" session or clobbering a freshly-merged one).
let importInProgress = false;

// Set while a session restore rebuilds st. Every caller points st.currentSessionName at the incoming
// session BEFORE restoring, and the restore swaps st over piece by piece across several awaits — so a save
// landing in that window would write a half-built mix into the incoming session's record: the outgoing
// composer text as its pendingDraft, a partly rebuilt images[]. Nothing needs saving afterwards either:
// what was just restored is what's already stored.
let restoreInProgress = false;

// Called by every autosave trigger (vote/unvote, settings change). Coalesces bursts.
function scheduleAutosave() {
  if (!st.started || importInProgress || restoreInProgress) return;
  clearTimeout(autosaveTimer);
  autosaveTimer = setTimeout(() => { autosaveTimer = null; flushAutosave(); }, AUTOSAVE_DEBOUNCE_MS);
}

async function flushAutosave() {
  if (autosaveTimer) { clearTimeout(autosaveTimer); autosaveTimer = null; }
  if (!st.started || importInProgress || restoreInProgress) return;
  // Single-flight: never let two saves race — a stale one finishing last would
  // clobber newer data. Mark dirty and re-run once the in-flight save resolves.
  if (autosaveInFlight) { autosaveQueued = true; return; }
  autosaveInFlight = true;
  autosaveQueued = false;
  try {
    await saveSession(autosaveTargetName(), { isAutosave: true });
    markAutosaved();
  } catch (e) {
    notifyAutosaveFailedOnce(e);
  } finally {
    autosaveInFlight = false;
    if (autosaveQueued) flushAutosave();
  }
}

// Best-effort flush when the tab is hidden/closed — only if changes are pending.
// Not guaranteed to complete during teardown, but shrinks the worst-case loss window.
function flushAutosaveOnHide() { if (autosaveTimer) flushAutosave(); }

// Before switching sessions. restoreSession drops a pending save on purpose (the callers have already
// renamed the target), so a Load from Saved Sessions would otherwise lose up to the debounce's worth of
// changes to the session being left. Waits out a save already in flight too: its finally-block re-run
// would otherwise land after the switch (a queued re-run starts synchronously as the old one ends, so
// autosaveInFlight covers it). Capped so a wedged save can't hold the Load forever.
async function settleAutosave() {
  for (let i = 0; i < 100 && (autosaveTimer || autosaveInFlight); i++) {
    if (!autosaveInFlight) await flushAutosave();
    else await new Promise(r => setTimeout(r, 30));
  }
}

let lastAutosavedAt = 0;

function markAutosaved() {
  autosaveFailNotified = false;  // a successful save re-arms the one-time failure warning
  lastAutosavedAt = Date.now();
  const el = document.getElementById('autosaveStatus');
  if (el) el.classList.remove('failed');
  renderSaveChip();
}

function notifyAutosaveFailedOnce(e) {
  console.warn('Autosave failed:', e);
  if (autosaveFailNotified) return;  // warn once; don't nag on every retry
  autosaveFailNotified = true;
  const el = document.getElementById('autosaveStatus');
  if (el) {
    el.classList.add('failed');
    el.classList.remove('unsaved');
    el.style.display = '';
    el.textContent = '⚠️ Autosave failed (storage full?)';
    el.title = 'Usually the browser\'s storage is full. Click for saved sessions — deleting old ones frees space';
  }
}

// Long names would push the toolbar onto a second row; the CSS max-width backs this up for wide glyphs.
function shortSessionName(name, max = 18) {
  name = String(name || '');
  return name.length > max ? name.slice(0, max - 1).trimEnd() + '…' : name;
}

// The toolbar's 📂 chip: which session this is and that it's saved, and the way into Saved Sessions at
// any time (before, the list was only reachable from the boot-time resume bar). Before Start it reads
// "📂 Sessions" when there are any to open. A failed save keeps its warning until a save lands.
function renderSaveChip() {
  const el = document.getElementById('autosaveStatus');
  if (!el || el.classList.contains('failed')) return;
  const name = st.currentSessionName;
  el.classList.toggle('unsaved', !!st.started && !name);
  if (!st.started) {
    el.style.display = st.hasSavedSessions ? '' : 'none';
    el.textContent = '📂 Sessions';
    el.title = 'Saved sessions — load, rename or delete';
  } else if (!name) {
    el.style.display = '';
    el.textContent = '📂 Unsaved run';
    el.title = 'Not named yet — the next new run replaces it. 💾 Save as… keeps it · click for saved sessions';
  } else {
    el.style.display = '';
    el.textContent = '📂 ' + shortSessionName(name) + ' · saved';
    el.title = `Session “${name}”` + (lastAutosavedAt ? ` · autosaved at ${new Date(lastAutosavedAt).toLocaleTimeString()}` : '') + ' · click for saved sessions';
  }
}

// Thin wrapper so the "Loading n/m…" pill in the ↓ Newest slot is cleared on EVERY exit, including a
// throw part-way through. A button left permanently saying Loading… would be worse than the silence it
// replaced, and the restore has plenty of ways to fail (a closing DB, quota pressure, a bad record).
// Also the one place autosave is held off for a restore (see restoreInProgress). A save still pending
// from the session being left is dropped rather than flushed: the callers have already renamed the target.
async function restoreSession(sessionData) {
  clearTimeout(autosaveTimer); autosaveTimer = null;
  restoreInProgress = true;
  try { return await restoreSessionBody(sessionData); }
  finally { restoreInProgress = false; restoreProgressEnd(); }
}

async function restoreSessionBody(sessionData) {
  const { meta, prompts, order, images, feedManifest } = sessionData;

  st.instruction = meta.instruction || '';
  st.instVersion = meta.instVersion || 1;
  // BACKWARDS_COMPAT: sessions saved before instruction history existed have no instHistory. Seed it
  // with the current version only — earlier instruction texts were never stored anywhere recoverable,
  // so the ❓ panel reports those as "not recorded" rather than guessing.
  st.instHistory = (meta.instHistory && typeof meta.instHistory === 'object') ? { ...meta.instHistory } : {};
  // BACKWARDS_COMPAT: sessions saved before 💭 why notes existed have no instWhy → every version simply
  // has no note, which is exactly right (none was ever written in them).
  st.instWhy = (meta.instWhy && typeof meta.instWhy === 'object') ? { ...meta.instWhy } : {};
  if (st.instruction) st.instHistory[st.instVersion] = st.instruction;
  st.resolution = meta.resolution || 'square';
  // Image size is per device (localStorage only); an older session's imageSizeScale is ignored.
  st.numPromptBatchesGenerated = meta.numPromptBatchesGenerated || 0;
  st.nextIdx = meta.nextIdx || 0;
  st.allowPromptMixing = meta.allowPromptMixing || false;
  // BACKWARDS_COMPAT: old sessions stored a `moreCreative` boolean; map true→2 (Creative), false→0 (Faithful).
  st.creativity = (meta.creativity != null) ? meta.creativity : (meta.moreCreative ? 2 : 0);
  st.promoteUpvoted = meta.promoteUpvoted || false;
  // Absent before ⏳ existed. Its first, stale-only form (skipStalePrompts) is deliberately NOT carried
  // over: this is stricter, and switching it on silently would block reuse nobody asked to block.
  st.freshPromptsOnly = !!meta.freshPromptsOnly;
  st.staleBridgeMode = meta.staleBridgeMode || 0;
  // BACKWARDS_COMPAT: old sessions stored a `keepPromptsOnChange` boolean; map true→1 (Keep all), false→0 (Off).
  st.keepPromptsMode = (meta.keepPromptsMode != null) ? meta.keepPromptsMode : (meta.keepPromptsOnChange ? 1 : 0);  // old sessions stay Off (new sessions default Keep all)
  st.autoQueueVariant = meta.autoQueueVariant !== false;  // default on for old sessions that predate this field
  st.prioritizeSteered = !!meta.prioritizeSteered;  // stays off for old sessions that predate this field (new sessions default on)
  st.freshBatchVersion = 0;
  st.promptPrefix = meta.promptPrefix || '';
  st.promptSuffix = meta.promptSuffix || '';
  st.batchRule = meta.batchRule || '';
  st.influenceQueue = Array.isArray(meta.influenceQueue) ? meta.influenceQueue.slice() : [];
  // BACKWARDS_COMPAT: every session saved before 🔖 marked influences existed has neither field → no
  // pending marks and no committed history, which is exactly right (nothing was ever marked in them).
  st.markedInfluences = infDeserialize(meta.markedInfluences);
  // BACKWARDS_COMPAT: sessions saved before 🧺 Picked's Marked view have no markThumbs → start empty.
  st.markThumbs = (sessionData.markThumbs && typeof sessionData.markThumbs === 'object') ? { ...sessionData.markThumbs } : {};
  st.instInfluences = {};
  if (meta.instInfluences && typeof meta.instInfluences === 'object') {
    for (const v in meta.instInfluences) {
      const list = infDeserialize(meta.instInfluences[v]);
      if (list.length) st.instInfluences[v] = list;
    }
  }
  // Abandon any in-flight steer from the session we're leaving: restoreSteer already refuses to re-queue
  // it (its queueAtSteer identity check now fails), and saveSession re-queues st.consumedSteer, so a stale
  // value here would bleed the old session's steer into this one's saved queue. (A batch left running from
  // the prior session still settles into its own finally, which clears this again, harmlessly.)
  st.consumedSteer = null;
  st.currentSessionName = st.currentSessionName || meta.sessionName || null;
  mixPromptsChk.checked = st.allowPromptMixing;
  updateCreativityUI();
  promoteUpvotedChk.checked = st.promoteUpvoted;
  freshOnlyChk.checked = st.freshPromptsOnly;
  updateStaleBridgeUI();
  updateKeepPromptsUI();
  autoQueueVariantChk.checked = st.autoQueueVariant;
  prioritizeSteeredChk.checked = st.prioritizeSteered;
  promptPrefixInput.value = st.promptPrefix;
  promptSuffixInput.value = st.promptSuffix;
  syncBatchRuleUI();
  st.started = true;
  // Up here, not with the other UI sync at the end of this function, because the restore below can take
  // a while and the welcome splash is a flex sibling of the "Loading n/m…" pill: the pill's margin-top
  // auto claims the column's free space, which is the space the splash was using to sit centred, so
  // leaving the splash up squashes it to the top for the whole restore and then shifts everything again
  // when it finally goes. Hiding it now means the feed really is empty while the pill is there — and a
  // splash pitching the generator is stale the moment you've chosen a session to reopen anyway.
  showStartedState();


  st.prompts = {};
  st.order = order || [];
  for (const id of st.order) {
    const p = prompts[id];
    if (!p) continue;
    st.prompts[id] = {
      ...p,
      // BACK-COMPAT: pre-transient-flag sessions kept p.influenced set on used steered prompts (the flag
      // used to be permanent). It's now cleared on the first successful image, so normalize historical
      // data here — a used prompt must never restore still-flagged, or it would keep its 🧲 badge and
      // "send steered first" priority forever. Gated on used>0 (not effUsed) since _claimed resets to 0
      // just below anyway. Idempotent: a no-op for sessions saved after this shipped.
      influenced: (p.used || 0) > 0 ? false : p.influenced,
      readyAt: Date.now() + st.params.PROMPT_WAIT_MS,
      _claimed: 0
    };
  }

  // "Until Batch" stale-bridging asks whether a batch has been written for the CURRENT instruction
  // version yet, which it tracks as batches are generated (st.freshBatchVersion). A restored session
  // never generated those batches in this page load, so the counter was left at 0 and the bridge read as
  // active — reporting "stale-bridge active" in the pipeline panel, and bridging with stale prompts the
  // moment the pool went momentarily empty, even though the restored queue was full of current-version
  // prompts. The restored pool answers the same question directly, so derive it from that.
  if (currentVersionPromptsExist()) st.freshBatchVersion = st.instVersion;

  st.upvotedTasks = [];
  st.waiting = [];
  st.pendingPool.forEach(el => el.remove());
  st.pendingPool = [];
  st.unseenCards.clear();
  st.tasksById = {};
  st.inflight = 0;
  st.epoch++;          // invalidate zombie IIFEs from the old session so their finally blocks don't touch st.inflight
  // The brainstorm single-flight goes with them. A batch still awaiting the AI is now a zombie whose
  // finally deliberately leaves current state alone — so if this didn't release the flag, nothing would,
  // and the restored session would never brainstorm again until a reload (and anything waiting on
  // textGenPromise, ✨ AI help included, would wait on a promise no one clears). The zombie's own epoch
  // check still throws away whatever it brings back.
  st.textGenBusy = false;
  st.textGenPromise = null;
  st.textGenStartedAt = 0;
  st.textGenSteer = null;
  st.textGenBatchRule = null;
  // Pipeline timings describe the run we are leaving, not the one being resumed — the panel's averages
  // are explicitly "the last N minutes of THIS run". The three last-event fields go with them: they were
  // never reset here, so a resume used to show "Last image 42m ago" inherited from the session it had
  // just replaced, and they double as the averages' "has anything happened yet" test, which would then
  // have contradicted the row beside it.
  st.textGenTimes = [];
  st.imageTimes = [];
  st.timingsSince = Date.now();
  st.lastImageAt = 0;
  st.lastTextGenMs = 0;
  st.lastTextGenCount = 0;
  st.firstImageShown = true;
  // The Influences panel's two pieces of unsaved state go the same way, and for the same reason: they
  // describe an edit to the session being LEFT. The 💭 note is the sharper of the two — it survives a
  // panel close on purpose (no path may lose an edit), so without this a note typed and abandoned in one
  // session is committed as the next session's reason for an unrelated instruction change, then saved and
  // shown on the 🌳 tree forever. infDiffOn is view state over records that no longer exist.
  infResetWhyDraft();
  infClearDiffs();
  infSugReset();   // ✨ the suggestion column, and any ask still running, belong to the session being left
  infHistReset();  // 🕘 likewise the History view and its filter

  feedEl.innerHTML = '';
  
  // Sort restored images in original feed order when idx is available (saved by newer versions).
  // BACKWARDS_COMPAT: older saved sessions don't include idx on images — in that case, fall back
  // to score-descending sort. This fallback can be removed once no old-format sessions exist in the wild.
  const sortedImages = (images || [])
    .filter(img => st.prompts[img.promptId])
    .sort((a, b) => {
      const hasIdxA = a.idx !== undefined && a.idx !== null;
      const hasIdxB = b.idx !== undefined && b.idx !== null;
      if (hasIdxA && hasIdxB) {
        return a.idx - b.idx;
      }
      // BACKWARDS_COMPAT fallback: sort by score descending (old behavior for sessions without idx)
      const pa = st.prompts[a.promptId];
      const pb = st.prompts[b.promptId];
      return (pb?.score || 0) - (pa?.score || 0);
    });
  
  // Up before any of the rebuilding starts, and held at the bottom-right for the whole restore however
  // little is in the feed (see #feedJumpBtn.loading). The total counts both halves of the work: liked
  // images, which come straight back from their stored thumbnails, and the unliked rows, which cost a
  // pair of IndexedDB reads each and are the entire reason this wait is noticeable.
  const manifestRows = restorableManifestRows(feedManifest, sortedImages);
  restoreProgressStart(sortedImages.length + manifestRows.length);
  // Yield one frame so the pill is on screen BEFORE the synchronous card-building below, which on a big
  // session is itself long enough to look like nothing happened. The setTimeout is the escape hatch, not
  // a belt-and-braces double: rAF does not fire at all in a backgrounded tab, and switching tabs is the
  // natural thing to do when told this will take a while — on rAF alone the whole restore would hang
  // there, pill frozen at 0, until you came back. Whichever fires first settles it; the other is a no-op.
  await new Promise(r => { requestAnimationFrame(r); setTimeout(r, 60); });

  for (const img of sortedImages) {
    const card = createRestoredCard(img);
    feedEl.appendChild(card);
  }
  restoreProgressTick(sortedImages.length);

  await restoreFeedManifest(feedManifest, sortedImages, manifestRows);

  // 🔖 A pending mark that resolves to no image is clutter — a bookmark you can't open — so drop it.
  // But ONLY when the feed we just built is the whole truth. Carry-forward means the opposite: the
  // unliked cards were deliberately not rebuilt ("restore unliked images" off, or the cache couldn't
  // answer), so an unresolvable mark says nothing about whether its image still exists. Prune then and
  // the marks are gone for good, while the manifest rows they point at are being carefully preserved
  // two lines up. Same reasoning, same answer: keep them.
  // COMMITTED records are never pruned either way — they're history, and the tree draws a ghost box
  // from the stored text when the prompt behind one is gone.
  if (!st.feedManifestCarryForward) {
    const idx = infCacheIndex();
    st.markedInfluences = st.markedInfluences.filter(r => infTaskOf(r, idx));
  }
  refreshInfluenceFlags();   // marks loaded before the cards existed → give the tiles their 🔖 now
  updateInfluencesBtn();

  instInput.value = st.instruction;
  if (applyInstBtn) applyInstBtn.classList.remove('show');   // discard any pending Apply from the session we're leaving
  // …then bring back THIS session's own unapplied edit, if it saved one (see pendingDraft in
  // buildSessionData). Only while it still differs from what's applied — otherwise there's nothing pending.
  // infResetWhyDraft above already cleared the old session's 💭; this session's goes back on with its draft.
  // BACKWARDS_COMPAT: sessions saved before drafts were kept have no pendingDraft → nothing pending.
  const pendingDraft = typeof meta.pendingDraft === 'string' ? meta.pendingDraft : '';
  if (pendingDraft.trim() && pendingDraft.trim() !== st.instruction) {
    instInput.value = pendingDraft;
    infWhyDraft = typeof meta.pendingWhy === 'string' ? meta.pendingWhy : '';
    // A collapsed composer would hide the ✓ Apply this lights — same reasoning as infClose.
    if (!st.composerVisible) toggleComposer(true);
  }
  updateInstDirty();   // Apply or this session's "vN · in use" tag
  resolutionSelect.value = st.resolution;
  updateImageSize();
  // (showStartedState already ran, before the rebuild — see the note by st.started above.)
  // Reflect the resumed session's named/unnamed state on the toolbar button:
  // a named session keeps it hidden; the unnamed recovery slot shows 'Save as…'.
  updateSessionButtons();
  // Restored steer queue → chips.
  renderInfluenceChips();

  // Restored cards are already "seen" — observe them so observer fires immediately
  // but do NOT add to unseenCards (user already interacted with these)
  if (window.cardIO) {
    feedEl.querySelectorAll('.card[data-idx]').forEach(c => window.cardIO.observe(c));
  }

  logEvent('session_restored', {
    promptCount: st.order.length,
    imageCount: sortedImages.length,
    instructionLength: st.instruction.length,
    sessionName: st.currentSessionName
  });

  ensureQueue();
  syncPlaceholders();
  schedule();

  requestAnimationFrame(() => {
    st.pendingPool[0]?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    updateFeedJump();
  });
}

// Rebuild the unliked part of the feed from the image cache. A session save only ever stored liked
// images, so restoring one used to drop everything else on the floor even when its full-res blobs were
// still sitting in the cache. These rows carry no thumbnail: a blob that has expired (72h TTL) or been
// evicted (500-entry cap) simply doesn't come back, and the row is dropped from the next save.
//
// The carry-forward guard: if the cache is off or its DB never opened, we can't tell "expired" from
// "couldn't ask". Restoring nothing and then re-deriving the manifest at save time would erase every
// row permanently, so in that case we stash the manifest untouched for saveSession to re-emit verbatim.
// The manifest rows a restore will actually ATTEMPT: nothing at all unless the cache is on, open and
// opted into, and otherwise the rows with a cacheId that a liked image's card doesn't already cover, in
// feed order. Split out because two callers need the same answer — restoreFeedManifest walks it, and
// the restore-progress denominator counts it — and a pill that promised a different number of images
// than the loop tries to load would be worse than no pill. The denominator computes it first and hands
// it down (restoreFeedManifest's `precomputedRows`) rather than each side calling this independently:
// same answer either way, but on a big session rebuilding the Set and re-filtering the whole manifest
// twice is pure latency in front of the very wait the pill exists to make bearable.
function restorableManifestRows(feedManifest, restoredImages) {
  if (!Array.isArray(feedManifest) || !feedManifest.length) return [];
  if (!RESTORE_UNLIKED || !IC_ENABLED || !icDB) return [];
  // Liked images already have cards (with thumbnails and upvote state); don't duplicate them.
  const already = new Set((restoredImages || []).map(im => im.cacheId).filter(c => c != null));
  return feedManifest
    .filter(r => r && r.cacheId != null && !already.has(r.cacheId))
    .sort((a, b) => (a.idx ?? 0) - (b.idx ?? 0));
}

/* The feed position of the NEWEST liked image, which is where 💾 starts being offered again on restore
   (see createUnlikedRestoredCard). Everything below that point in the feed is the tail you generated
   after your last keeper and never triaged, so it's the part still worth saving off; everything above it
   you already walked past and chose not to keep.

   `idx` is the ordering key rather than the cache's createdAt timestamp. The feed is append-only with the
   newest tile last and restorableManifestRows already sorts by idx, so feed position IS generation order —
   and both row kinds carry idx already, whereas createdAt lives in the cache meta store and would cost a
   read per liked image just to compute this one number.

   Two different ways to end up with no cutoff, and they want opposite answers, so they are separated
   rather than sharing one default:

     nothing liked            → -Infinity, every row clears the bar. A session with nothing kept has no
                                point at which you started ignoring things, so nothing is hidden.
     liked, none placeable    → +Infinity, no row clears it. This session demonstrably HAS keepers, so
                                the user did triage it — we just can't say where the line falls. Showing
                                💾 on all of them is the "hundreds of buttons on images you already
                                rejected" this function exists to remove, and it would hit hardest on
                                exactly the long sessions that made it worth removing. Hiding costs less
                                than it looks: ❓ and fullscreen are still on every tile, and the
                                lightbox saves from there. Reachable when every liked image lost its idx
                                (its task was gone by save time) while unliked manifest rows survived —
                                and by construction for any save old enough to predate idx on images. */
function feedSaveCutoffIdx(restoredImages) {
  const liked = (restoredImages || []).filter(im => !!im);
  if (!liked.length) return -Infinity;
  let cutoff = -Infinity;
  for (const im of liked) {
    if (typeof im.idx === 'number' && im.idx > cutoff) cutoff = im.idx;
  }
  return cutoff === -Infinity ? Infinity : cutoff;
}

async function restoreFeedManifest(feedManifest, restoredImages, precomputedRows) {
  st.feedManifest = Array.isArray(feedManifest) ? feedManifest.slice() : [];
  st.feedManifestCarryForward = false;
  if (!st.feedManifest.length) return;

  // Carry-forward, not prune, when we can't safely rebuild: the user opted out of restoring unliked
  // tiles, or the cache can't answer. In both cases the live feed won't hold these images, so letting
  // the next save re-derive from it would orphan every row permanently. Preserve them instead — the
  // manifest is still there if the setting is turned back on or the cache recovers.
  if (!RESTORE_UNLIKED || !IC_ENABLED || !icDB) {
    st.feedManifestCarryForward = true;
    return;
  }
  st.feedManifest = [];               // cache can answer → rows now live or die on their own merit

  const rows = precomputedRows || restorableManifestRows(feedManifest, restoredImages);
  const saveCutoff = feedSaveCutoffIdx(restoredImages);   // once per restore, not once per row

  let recovered = 0;
  for (const row of rows) {
    // Both reads resolve-null on error and never reject, so no per-row try/catch is needed. The meta
    // record carries the exact resolvedText/promptText/seed that produced this blob (see cacheImage).
    const [blob, meta] = await Promise.all([
      getICBlob(row.cacheId),
      icGetFromStore('meta', row.cacheId)
    ]);
    if (!blob) continue;   // expired or evicted — the row dies here and isn't re-saved
    // Only the tail below your newest keeper gets 💾 — see feedSaveCutoffIdx.
    createUnlikedRestoredCard(row, blob, meta, (row.idx ?? 0) > saveCutoff);   // meta may be null → card falls back to the base prompt
    recovered++;
    restoreProgressTick();   // counts images RESTORED, so an expired row leaves the run short of its total
  }
  logEvent('feed_manifest_restored', { rows: rows.length, recovered });
}

// A restored unliked card: full-res blob straight from the cache, normal chrome, starts NOT upvoted.
// A tap toggles the upvote — on upvote it joins st.upvotedTasks (so it saves into session `images` and
// appears in the Export tab), carrying the exact resolved prompt recovered from the cache `meta`. The
// vote math on its prompt is guarded because the row's prompt could (defensively) be absent from st.prompts.
function createUnlikedRestoredCard(row, blob, meta, showSave) {
  const ui = createCard();
  const promptObj = st.prompts[row.promptId];

  // Exact wording that produced THIS image, so an upvote here matches a pre-restoration upvote (and
  // trimmed-away-prompt tiles still export with real text). The base prompt is only a last resort.
  const resolvedText = (meta && meta.resolvedText)
    || (meta && meta.promptText)
    || (promptObj ? promptObj.text : '')
    || '';

  const task = {
    id: uid('t'),
    state: 'done',
    ui,
    promptId: row.promptId,
    resolvedText,
    cacheId: row.cacheId,
    seed: row.seed ?? (meta && meta.seed != null ? meta.seed : null),
    idx: st.nextIdx++,
    influenced: !!row.influenced   // this image spent its prompt's steer → keeps 🧲 (absent on old rows)
  };
  st.tasksById[task.id] = task;

  const url = URL.createObjectURL(blob);
  const img = new Image();
  img.src = url;
  img.className = 'imgEl';
  img.alt = '';
  ui.inner.innerHTML = '';
  ui.inner.appendChild(img);
  ui.imgEl = img;

  setPromptHover(ui, task.resolvedText);
  populateFlags(ui, promptObj, task);

  ui.card.dataset.tid = task.id;
  ui.card.dataset.idx = String(row.idx ?? task.idx);
  ui.fsBtn.style.display = 'block';
  ui.fsBtn.onclick = (e) => { e.stopPropagation(); feedOpenLightbox(task); };

  // 💾 on the tail of the feed only — the images generated after your newest keeper, which are the ones
  // you never got round to triaging. Restoring a long session used to put a save button on every single
  // unliked tile it could rebuild, which is hundreds of buttons on images you already scrolled past and
  // decided against. feedSaveCutoffIdx picks the line; `showSave` is that decision, made once per restore.
  //
  // Reaching this function already proves the original is around: the card exists only because
  // restoreFeedManifest pulled `blob` out of the LIVE cache, which stores originals untouched. That's the
  // same bar the liked path applies (createRestoredCard reveals 💾 only inside its getICBlob hit) — it
  // just gets to skip the lookup, since the bytes were handed in. The archive is deliberately not a
  // fallback here or there: it holds a 25% WebP, and 💾 promises the full-res original.
  // promptObj is guarded like every other access in this function (a manifest row can outlive st.prompts).
  // Reveal and handler are gated together, which is what the liked path does (createRestoredCard reveals
  // and wires inside its getICBlob hit). Wiring a permanently hidden button isn't free here: the closure
  // pins this card's full-res `blob` for the life of the card, and on the restore this cutoff was written
  // for that is hundreds of originals held for buttons that can never be clicked.
  if (showSave) {
    ui.saveBtn.style.display = 'block';
    ui.saveEl = ui.saveBtn;
    ui.save = () => saveTileToGallery(ui.saveBtn, blob, tileSaveInfo(task, promptObj, task.seed), () => {
      const ghost = img.cloneNode(false);
      animateImageIntoTarget({ imgEl: ghost, sourceEl: img, targetEl: showSavedBtn, durationMs: 700, wiggle: true });
    });
    ui.saveBtn.onclick = (e) => { e.stopPropagation(); ui.save(); };
  }

  // Tap-to-upvote — mirrors the live path (attachImageToCard) but starts un-upvoted and guards the
  // (defensively possible) missing-prompt case. The 👍 badge follows the .card.upvoted CSS rule, so
  // toggling the class is enough; no inline thumbBadge writes.
  wireTileTap(ui, () => {

    ui.upvoted = !ui.upvoted;
    ui.card.classList.toggle('upvoted', ui.upvoted);   // 👍 badge follows via .card.upvoted CSS

    const p = promptObj;   // defensive: effectively always set (a manifest row means a used prompt), but never assume
    if (ui.upvoted) {
      if (p) p.votes += 1;
      st.upvotedTasks.push({
        taskId: task.id,
        promptId: task.promptId,
        imgEl: ui.imgEl,
        resolvedText: task.resolvedText,
        cacheId: task.cacheId || null,
        _thumb: null   // no stored thumb; buildSessionData encodes one from the full-res imgEl on save
      });
      // ⭐ variant fork — gated on the session setting, same condition as the live path. addPrompts
      // dedups and logs evo_prompts_added itself, so no extra log here. p is guaranteed non-null here
      // (the `&& p &&` above), so the upvote-parent edge is safe. influenceText rides along: the text
      // being captured IS the steered prompt's resolved wording, so the 🧲 is still literally in it.
      if (st.autoQueueVariant && p && /\{[^{}]+\}/.test(p.text)
          && task.resolvedText && !/\{/.test(task.resolvedText)) {
        addPrompts([task.resolvedText], 'upvoted', { parent: { kind: 'upvote', promptId: p.id, taskId: task.id }, influenceText: p.influenceText });
      }
      if (p) recomputeScore(p);
      updateSessionButtons();
      scheduleAutosave();
      logEvent('upvote', {
        promptId: p ? p.id : null, votes: p ? p.votes : null, used: p ? p.used : null,
        score: p ? p.score : null, promptText: p ? p.text : (task.resolvedText || ''),
        restored: true, restoredUnliked: true
      });
    } else {
      if (p) { p.votes = Math.max(0, p.votes - 1); recomputeScore(p); }
      st.upvotedTasks = st.upvotedTasks.filter(t => t.taskId !== task.id);
      updateSessionButtons();
      scheduleAutosave();
    }
    st.unseenCards.delete(ui.card);   // harmless no-op (restored cards aren't in unseenCards)
  });

  // Restored cards lay out by DOM order (no style.order, unlike live completions), so insert at the
  // idx-sorted position rather than appending — otherwise every unliked card would pile up after the
  // liked ones instead of interleaving back into the original feed order.
  const myIdx = row.idx ?? task.idx;
  const before = Array.from(feedEl.children).find(c => {
    const ci = parseInt(c.dataset.idx, 10);
    return !isNaN(ci) && ci > myIdx;
  });
  feedEl.insertBefore(ui.card, before || null);
  return ui.card;
}

function createRestoredCard(img) {
  const ui = createCard();
  const promptObj = st.prompts[img.promptId];

  const task = {
    id: uid('t'),
    state: 'done',
    ui,
    promptId: img.promptId,
    resolvedText: img.resolvedText || img.promptText,
    cacheId: img.cacheId || null,
    seed: img.seed ?? null,   // BACKWARDS_COMPAT: absent in sessions saved before seeds were persisted
    idx: st.nextIdx++,
    influenced: !!img.influenced   // this image spent its prompt's steer → keeps 🧲 (absent on old rows)
  };

  st.tasksById[task.id] = task;

  const thumbImg = new Image();
  thumbImg.src = img.thumbnail;
  // Only the stored 128px thumbnail, not the original — 🧺 Picked must not zip it as one. The full-res
  // Image swapped in below (cache hit) is a new element without the tag, so the flag clears itself, and it
  // covers both st.upvotedTasks' entry and task.ui.imgEl, which point at this same node.
  thumbImg._ipoThumbOnly = true;
  thumbImg.className = 'imgEl';
  thumbImg.alt = '';
  ui.inner.innerHTML = '';
  ui.inner.appendChild(thumbImg);
  ui.imgEl = thumbImg;

  // Populate the hover prompt overlay + provenance flags — the live path does this in attachImageToCard,
  // but restored cards build their own image and skip it, so do it here too.
  setPromptHover(ui, task.resolvedText || (promptObj ? promptObj.text : ''));
  populateFlags(ui, promptObj, task);

  ui.upvoted = true;
  ui.card.classList.add('upvoted');
  ui.card.dataset.tid = task.id;
  // Tag with the SAVED feed position (img.idx), not the fresh task.idx (= st.nextIdx++). The unliked
  // restore path (createUnlikedRestoredCard) interleaves its cards by comparing dataset.idx, and its
  // rows carry the same save-time idx space; using task.idx here would put liked cards in the unrelated
  // nextIdx-counter space, so every unliked card would sort ahead of them and bury the upvoted ones.
  ui.card.dataset.idx = String(img.idx ?? task.idx);
  ui.fsBtn.style.display = 'block';
  ui.thumbBadge.style.display = 'block';

  let fullResUrl = null;

  st.upvotedTasks.push({
    taskId: task.id,
    promptId: task.promptId,
    imgEl: thumbImg,
    resolvedText: task.resolvedText,
    cacheId: task.cacheId || null,
    // The restored image IS the stored 128px thumbnail — seed the cache so a
    // re-save of this restored session needs no re-encoding until a new upvote.
    _thumb: img.thumbnail || null
  });

  if (task.cacheId != null) {
    getICBlob(task.cacheId).then(blob => {
      if (!blob) return;
      fullResUrl = URL.createObjectURL(blob);
      const fullImg = new Image();
      fullImg.src = fullResUrl;
      fullImg.className = 'imgEl';
      fullImg.alt = '';
      ui.inner.innerHTML = '';
      ui.inner.appendChild(fullImg);
      ui.imgEl = fullImg;
      const entry = st.upvotedTasks.find(t => t.taskId === task.id);
      if (entry) entry.imgEl = fullImg;

      ui.saveBtn.style.display = 'block';
      ui.saveEl = ui.saveBtn;
      ui.save = () => saveTileToGallery(ui.saveBtn, blob, tileSaveInfo(task, promptObj, img.seed), () => {
        const ghost = fullImg.cloneNode(false);
        animateImageIntoTarget({ imgEl: ghost, sourceEl: fullImg, targetEl: showSavedBtn, durationMs: 700, wiggle: true });
      });
      ui.saveBtn.onclick = (e) => { e.stopPropagation(); ui.save(); };
      lbFeedTileChanged(task);
    });
  }

  wireTileTap(ui, () => {

    ui.upvoted = !ui.upvoted;
    ui.card.classList.toggle('upvoted', ui.upvoted);
    ui.thumbBadge.style.display = ui.upvoted ? 'block' : 'none';

    // Defensive: a liked image normally always saved its prompt, but a restored-UNLIKED upvote of a
    // promptless tile (rare st.prompts drift) round-trips into `images` and comes back through here — so
    // guard every p access, matching createUnlikedRestoredCard. See "guarded on both paths" in §18c.
    const p = promptObj;
    if (ui.upvoted) {
      if (p) p.votes += 1;
      st.upvotedTasks.push({
        taskId: task.id,
        promptId: task.promptId,
        imgEl: ui.imgEl,
        resolvedText: task.resolvedText,
        cacheId: task.cacheId || null,
        // Reuse the stored 128px thumbnail so autosave doesn't re-encode (and double-compress) it.
        _thumb: img.thumbnail || null
      });
      // ⭐ variant fork — same gate/condition as the live path and the restored-unliked path. addPrompts
      // dedups and logs evo_prompts_added itself, so no extra log here. p is guaranteed non-null here
      // (the `&& p &&` above), so the upvote-parent edge is safe.
      if (st.autoQueueVariant && p && /\{[^{}]+\}/.test(p.text)
          && task.resolvedText && !/\{/.test(task.resolvedText)) {
        addPrompts([task.resolvedText], 'upvoted', { parent: { kind: 'upvote', promptId: p.id, taskId: task.id }, influenceText: p.influenceText });
      }
      if (p) recomputeScore(p);
      updateSessionButtons();   // so upvoting on a resumed unnamed recovery slot re-surfaces the Save-as button
      scheduleAutosave();
      logEvent('upvote', {
        promptId: p ? p.id : null, votes: p ? p.votes : null, used: p ? p.used : null,
        score: p ? p.score : null, promptText: p ? p.text : (task.resolvedText || ''),
        restored: true
      });
    } else {
      if (p) { p.votes = Math.max(0, p.votes - 1); recomputeScore(p); }
      st.upvotedTasks = st.upvotedTasks.filter(t => t.taskId !== task.id);
      updateSessionButtons();   // and re-surface it again on un-upvote
      scheduleAutosave();
    }
    st.unseenCards.delete(ui.card);
  });

  ui.fsBtn.onclick = (e) => { e.stopPropagation(); feedOpenLightbox(task); };

  if (!task.cacheId) ui.saveBtn.style.display = 'none';

  return ui.card;
}

// The session to offer on the resume panel: the most recently touched of the
// newest named session and the unnamed recovery slot. Returns null if neither exists.
// Shape: { name, data, isAutosave }.
//
// The named half has two possible sources and which one is right depends on whether anything has
// actually scanned the store yet. Boot deliberately doesn't: it reads the ONE record the remembered-
// latest pointer names and parks it in st.resumeCand. The moment a real scan happens — 📂, or any
// save/rename/delete/import — st.savedSessionsList becomes the better answer, st.sessionsListLoaded
// flips, and we switch to it permanently. Before that flip the list is empty because nobody has looked,
// not because there's nothing there, so reading it would silently offer no session to resume.
function resumeCandidate() {
  const newest = st.sessionsListLoaded ? st.savedSessionsList[0] : null;
  const named = newest
    ? { name: newest.name, data: newest.data, isAutosave: false }
    : (st.sessionsListLoaded ? null : st.resumeCand);
  const slot = st.autosaveSlot
    ? { name: AUTOSAVE_SLOT, data: st.autosaveSlot, isAutosave: true }
    : null;
  if (named && slot) {
    return (slot.data.meta?.savedAt || 0) >= (named.data.meta?.savedAt || 0) ? slot : named;
  }
  return slot || named;
}

// Build a horizontal row of saved-image thumbnails for a session, shared by the resume
// panel and the Saved Sessions modal. Picks up to `count` images at random from the
// session's already-compressed thumbnails (no re-encoding). Falls back to a folder icon
// when the session has no usable liked-image thumbnails.
function buildSessionThumbs(images, count = SESSION_THUMB_COUNT) {
  const wrap = document.createElement('div');
  wrap.className = 'sessionThumbs';
  const pool = (images || []).filter(im => im && im.thumbnail);
  if (pool.length === 0) {
    wrap.classList.add('sessionThumbsEmpty');
    wrap.textContent = '📂';
    return wrap;
  }
  // Fisher–Yates shuffle a copy, then take the first `count` for a random sample.
  const picks = pool.slice();
  for (let i = picks.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [picks[i], picks[j]] = [picks[j], picks[i]];
  }
  picks.slice(0, Math.max(1, count)).forEach(im => {
    const img = document.createElement('img');
    img.className = 'sessionThumb';
    img.src = im.thumbnail;
    img.loading = 'lazy';
    img.alt = '';
    wrap.appendChild(img);
  });
  return wrap;
}

function showResumePanel() {
  if (st.savedSessionToastShown && st.started) return;
  if (!resumeCandidate()) return;
  st.savedSessionToastShown = true;
  updateResumePanelContent();
  document.getElementById('resumePanel').style.display = 'flex';
}

function updateResumePanelContent() {
  const cand = resumeCandidate();
  if (!cand) return;
  document.getElementById('resumePanelTitle').textContent =
    cand.isAutosave ? 'Recovered session (unsaved)' : cand.name;
  document.getElementById('resumeSaveBtn').style.display = cand.isAutosave ? '' : 'none';
  const imgCount = cand.data.images?.length || 0;
  const promptCount = cand.data.order?.length || 0;
  const savedAt = cand.data.meta?.savedAt;
  document.getElementById('resumePanelSub').textContent =
    `${plural(imgCount, 'liked image')}, ${plural(promptCount, 'prompt')}` + (savedAt ? ` · last used ${icRelativeTime(savedAt)}` : '');
  const iconEl = document.getElementById('resumePanelIcon');
  iconEl.innerHTML = '';
  iconEl.appendChild(buildSessionThumbs(cand.data.images));
}

function refreshResumePanel() {
  const panel = document.getElementById('resumePanel');
  if (panel.style.display !== 'flex') return;
  if (!resumeCandidate()) {
    panel.style.display = 'none';
    return;
  }
  updateResumePanelContent();
}

function hideResumePanel() {
  document.getElementById('resumePanel').style.display = 'none';
}

// Boot reads at most TWO records: the recovery slot (fixed key) and whichever named session the
// remembered-latest pointer names. It used to read every one of them — every prompt and a base64
// preview thumbnail per liked image, in every saved session — purely to sort by savedAt and take the
// first, which is why the resume bar used to turn up seconds after the page and shove the layout down.
async function checkForSavedSession() {
  try {
    // MIGRATION: convert legacy 'current' key to a named session.
    // Remove this call once no users have the old single-session format.
    await migrateLegacySession();

    // Keys tell us whether anything is saved and whether the remembered name is still real; the slot
    // has to be read in full either way. Neither depends on the other, so don't queue them.
    const [named, slot] = await Promise.all([getNamedSessionKeys(), loadSession(AUTOSAVE_SLOT)]);
    st.autosaveSlot = slot || null;
    st.hasSavedSessions = named.length > 0;

    const ptr = readLatestSessionPointer();
    st.resumeCand = null;
    if (ptr && named.includes(ptr.name)) {
      const data = await loadSession(ptr.name);
      if (data) st.resumeCand = { name: ptr.name, data, isAutosave: false };
    }
    // Fall back whenever the shortcut didn't produce a candidate: no pointer (first boot after this
    // shipped, cleared site data, a private window), a stale one (renamed or deleted in another tab), or
    // a pointer whose key is still listed but whose RECORD won't load. That last one is why this is a
    // second `if` and not an `else` — sessions exist, so showing no resume bar at all would be a worse
    // bug than the slow bar this replaced. refreshSessionsList() writes the pointer on its way out, so
    // the slow path is something you hit once rather than the steady state.
    if (!st.resumeCand && named.length) {
      await refreshSessionsList();
    }

    if (!st.started && resumeCandidate()) {
      showResumePanel();
    }
  } catch (e) {
    st.hasSavedSessions = false;
  }
  updateSessionButtons();
}

function updateSessionButtons() {
  const saveBtn = document.getElementById('saveSessionBtn');
  // Show 'Save as…' only while the session is still unnamed (living in the
  // __autosave__ recovery slot) — that's the one window where the button does real
  // work: naming promotes it to a durable, listed session. Once named, autosave +
  // the 📂 chip carry it, so the button stays hidden.
  // Suppressed during the post-save fade so the animation can finish (see onclick).
  if (saveBtn && !explicitSaveAnimating) {
    saveBtn.style.display = (st.started && !st.currentSessionName) ? 'flex' : 'none';
  }
  renderSaveChip();
}

/* ===================== Diversity boosts ===================== */

const EXTRA_INSTRUCTIONS = [
  "Look closely at the user instruction. What is their underlying intent? Deeply fulfill that intent.",
  "Boldly explore variations that still obey the user instruction exactly; avoid timid small changes.",
  "Prefer highly descriptive, concrete details over generic adjectives when appropriate.",
  "Try a concise, comma-separated Stable Diffusion style for some prompts.",
  "Try a Midjourney-style phrasing for one prompt; others can be plain descriptive.",
  "Include camera language when appropriate (lens, shot type, angle) but only if consistent with the user instruction.",
  "For one prompt, focus on mood/lighting; for another, focus on composition; keep both faithful to the user instruction.",
  "Lean into the user instruction's constraints aggressively; do not add unrelated styles.",
  "Include a simple list-like structure in one prompt (still one line) to pack key details.",
  "Favor variation in specificity: some prompts terse, others richly detailed — all must match the user instruction exactly."
];

// 📏 Every-batch rule, rolled once per batch. Unlike evaluateCurlyFallback (shared with Prefix/Suffix and
// image prompts, so left alone) an EMPTY option counts: {huge heads|} means "a twist on some batches".
// Any brace left after rolling is a typo ("make it {night") — dropped, because the LLM would copy it into
// its prompts, addPrompts rejects unbalanced braces, and an all-rejected batch re-brainstorms at once.
function rollBatchRule(str) {
  if (typeof str !== 'string') return '';
  const rolled = str.replace(/\{([^{}]*)\}/g, (_, inner) => {
    const opts = inner.split('|').map(x => x.trim());
    return opts[Math.floor(Math.random() * opts.length)];
  });
  return rolled.replace(/[{}]/g, '').replace(/[ \t]{2,}/g, ' ').trim();
}

// The block that closes the brainstorm prompt. It goes AFTER the Rules list on purpose: Faithful's rules
// end on "do not conflict with the instruction", and whichever word comes last tends to win. No concrete
// example of a rule's effect — the LLM copies examples into prompts whatever the rule is. The no-stacking
// line covers promoted batches and liked examples that were themselves written under the rule.
function batchRuleBlock(rule, k) {
  if (!rule) return '';
  return `\n\n<every_batch_rule>\n${rule}\n</every_batch_rule>\nThe user wants this rule applied to every one of the ${k} prompts. It overrides anything above, including the instructions to match or not conflict with <user_instruction>. Write its effect into each prompt as concrete visual description the image model can draw, not as a comparison. Some prompts above may already have been written under this rule: apply its effect once, at the strength asked for, rather than stacking it on top of what they already show.`;
}

function maybeCurlyGuidance() {
  if (Math.random() < 0.60){
    return `\nUse curly brace syntax for diversity: You should generally add several curly brace blocks with pipe-separated variants anywhere (colors, lighting, expressions, locations, backgrounds, camera angle, clothing, themes, art/photo styles, etc.) while ensuring that all variants follow the user's instruction exactly. Example: "a {candid|studio|drone|selfie|cute illustrated} {portrait|panorama} of an {Nigerian|Scandinavian|...} ...".`;
  }
  return '';
}

/* ===================== Utils ===================== */

const uid = (()=>{ let i=0; const r=Math.random().toString(36).slice(2,6); return (p='id') => p + r + (++i); })();

function getAllPrompts() { return st.order.map(id => st.prompts[id]).filter(p=>!!p); }
/* effective used counts (used + claimed) */
function effUsed(p) { return p ? ((p.used||0) + (p._claimed||0)) : 0; }
function getUntestedPrompts() { return getAllPrompts().filter(p=>effUsed(p)===0 && !p.stale && p.ver===st.instVersion); }
function recomputeScore(p) { p.score = (p.used>0) ? (p.votes / p.used) : 0; }
function weightedPickByScore(arr) {
  if (!arr.length) return null;
  const weights = arr.map(p=>Math.max(0, p.score));
  const sum = weights.reduce((a,b)=>a+b,0);
  if (sum<=0) return arr[Math.floor(Math.random()*arr.length)];
  let r = Math.random()*sum, c=0;
  for (let i=0;i<arr.length;i++){ c+=weights[i]; if (r<=c) return arr[i]; }
  return arr[arr.length-1];
}
/* Stale-prompt weight: score × recency decay × vote-confidence boost.
   Recent versions and prompts with more absolute upvotes are favoured,
   but old high-scorers can still appear — the bias is soft, not absolute. */
function staleWeight(p) {
  const age = Math.max(0, st.instVersion - (p.ver || 1));
  const recency = Math.pow(st.params.STALE_RECENCY_DECAY, age);
  const confidence = 1 + Math.log1p(p.votes || 0); // log(1+votes): 0→1, 1→1.69, 5→2.79, 10→3.40
  return Math.max(0, p.score) * recency * confidence;
}
function weightedPickStale(arr) {
  if (!arr.length) return null;
  const weights = arr.map(staleWeight);
  const sum = weights.reduce((a,b)=>a+b,0);
  if (sum<=0) return arr[Math.floor(Math.random()*arr.length)];
  let r = Math.random()*sum, c=0;
  for (let i=0;i<arr.length;i++){ c+=weights[i]; if (r<=c) return arr[i]; }
  return arr[arr.length-1];
}
// Prompts you type or paste (sidebar Add, 📜 Prompts Add): one per line. A list marker only counts when a
// space follows it, so "3-D render", "16:9 shot" and "2-headed dragon" stay whole, and one line keeps its
// quotes. The AI's batches go through parseNumberedOrBulletedList, which is looser about its output.
function parseTypedPrompts(s) {
  const lines = String(s || '').split(/\r?\n/).map(x => x.trim()).filter(Boolean);
  const out = lines.map(ln => ln.replace(/^(?:\d+[.):\-]|[•\-–*])\s+(?=\S)/, '').trim());
  return (out.length > 1 ? out.map(t => t.replace(/^"(.*)"$/, '$1').trim()) : out).filter(Boolean);
}
function parseNumberedOrBulletedList(s) {
  if (!s) return [];
  const lines = s.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
  const out=[];
  for (let ln of lines){
    let m = ln.match(/^\s*(\d+[\.\)\-:]|[•\-–])\s*(.+)$/);
    if (m) out.push(m[2].trim());
    else out.push(ln);
  }
  return out.map(t=>t.replace(/^"(.*)"$/,'$1').trim()).filter(Boolean);
}
function escapeHtml(s) { return (s||'').replace(/[&<>"']/g, m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }

/* ===== Curly-block validation & expansion (simple, no nesting/escaping) ===== */

function isValidCurlyBlocks(str) {
  if (typeof str !== 'string') return false;
  if (/[\\][{}]/.test(str)) return false;
  const opens = (str.match(/{/g) || []).length;
  const closes = (str.match(/}/g) || []).length;
  if (opens !== closes) return false;
  const stripped = str.replace(/\{[^{}]+\}/g, '');
  if (/[{}]/.test(stripped)) return false;
  return true;
}

function evaluateCurlyFallback(str) {
  if (typeof str !== 'string') return str;
  return str.replace(/\{([^{}]+)\}/g, (_, inner)=>{
    const opts = inner.split('|').map(x=>x.trim()).filter(Boolean);
    if (!opts.length) return '';
    return opts[Math.floor(Math.random()*opts.length)];
  });
}

/* ===================== UI elements ===================== */

const startBtn = document.getElementById('startBtn');

const topBar = document.getElementById('topBar');
const feedEl = document.getElementById('feed');

const composerDock = document.getElementById('composerDock');
const instInput = document.getElementById('instInput');
const instSpinner = document.getElementById('instSpinner');
const instTick = document.getElementById('instTick');

const helpHint = document.getElementById('helpHint');
const refineHint = document.getElementById('refineHint');

/* Prompts UI */
const showPromptsBtn = document.getElementById('showPromptsBtn');
const showSavedBtn = document.getElementById('showSavedBtn');
// 📷 Image Cache's title, from the live limits: it's every session's images, and only the recent ones.
function cacheBtnTitle(ttlHours, maxCount) {
  const span = ttlHours % 24 === 0 ? plural(ttlHours / 24, 'day') : plural(ttlHours, 'hour');
  return `Every image from the last ${span} (up to ${maxCount}), all sessions; older ones move to the archive`;
}
function updateCacheBtnTitle() {
  const b = document.getElementById('showCacheBtn');
  if (b) b.title = cacheBtnTitle(IC_TTL_HOURS, IC_MAX_COUNT);
}
const showTreeBtn = document.getElementById('showTreeBtn');
const promptsModal = document.getElementById('promptsModal');
const promptsList = document.getElementById('promptsList');
const promptAddInput = document.getElementById('promptAddInput');
const addPromptBtn = document.getElementById('addPromptBtn');
const promptsCloseX = document.getElementById('promptsCloseX');

const commentsBtn = document.getElementById('commentsBtn');
const commentsModal = document.getElementById('commentsModal');
const commentsCloseX = document.getElementById('commentsCloseX');
const commentsContainer = document.getElementById('commentsContainer');

/* Debug Log UI */
const debugBtn = document.getElementById('debugBtn');
const logModal = document.getElementById('logModal');
const logList = document.getElementById('logList');
const logCount = document.getElementById('logCount');
const logClear = document.getElementById('logClear');
const logExport = document.getElementById('logExport');
const logCloseX = document.getElementById('logCloseX');

/* Sidebar UI */
const sidebarList = document.getElementById('sidebarList');
const sidebarStatus = document.getElementById('sidebarStatus');
const sidebarInjectInput = document.getElementById('sidebarInjectInput');
const sidebarInjectBtn = document.getElementById('sidebarInjectBtn');
const pauseBtn = document.getElementById('pauseBtn');
const pauseBtnIcon = document.getElementById('pauseBtnIcon');
const pauseBtnLabel = document.getElementById('pauseBtnLabel');
const pausePromptsItem = document.getElementById('pausePromptsItem');
const pauseImagesItem = document.getElementById('pauseImagesItem');
const pausePromptsState = document.getElementById('pausePromptsState');
const pauseImagesState = document.getElementById('pauseImagesState');

const resolutionSelect = document.getElementById('resolutionSelect');
resolutionSelect.value = st.resolution;
resolutionSelect.onchange = () => {
  st.resolution = resolutionSelect.value;
  Object.values(st.tasksById).forEach(task => {
    if (task.state === 'waiting') {
      task.resolution = st.resolution;
    }
  });
  st.pendingPool.forEach(el => {
    el.style.aspectRatio = ASPECT_RATIOS[st.resolution];
  });
  logEvent('resolution_changed', { resolution: st.resolution });
  scheduleAutosave();
  schedule();
};

const sizeDownBtn = document.getElementById('sizeDownBtn');
const sizeUpBtn = document.getElementById('sizeUpBtn');
const sizeIndicator = document.getElementById('sizeIndicator');

const mixPromptsChk = document.getElementById('mixPromptsChk');
mixPromptsChk.checked = st.allowPromptMixing;
mixPromptsChk.onchange = () => {
  st.allowPromptMixing = mixPromptsChk.checked;
  logEvent('prompt_mixing_toggled', { enabled: st.allowPromptMixing });
  updateStrategyButton();
  scheduleAutosave();
};

const creativitySeg = document.getElementById('creativitySeg');
const creativityBtns = creativitySeg ? Array.from(creativitySeg.querySelectorAll('.segBtn')) : [];
function updateCreativityUI() {
  creativityBtns.forEach(b => b.classList.toggle('active', b._level === st.creativity));
  updateStrategyButton();
}
creativityBtns.forEach(b => {
  b._level = Number(b.dataset.level);  // parse once; reused by click handler + updateCreativityUI
  b.onclick = () => {
    st.creativity = b._level;
    updateCreativityUI();
    logEvent('creativity_changed', { level: st.creativity });
    scheduleAutosave();
  };
});
updateCreativityUI();

const promoteUpvotedChk = document.getElementById('promoteUpvotedChk');
promoteUpvotedChk.checked = st.promoteUpvoted;
promoteUpvotedChk.onchange = () => {
  st.promoteUpvoted = promoteUpvotedChk.checked;
  logEvent('promote_upvoted_toggled', { enabled: st.promoteUpvoted });
  updateStrategyButton();
  scheduleAutosave();
};

const freshOnlyChk = document.getElementById('freshOnlyChk');
freshOnlyChk.checked = st.freshPromptsOnly;
freshOnlyChk.onchange = () => {
  st.freshPromptsOnly = freshOnlyChk.checked;
  logEvent('fresh_only_toggled', { enabled: st.freshPromptsOnly });
  updateStrategyButton();
  updateStaleBridgeUI();
  scheduleAutosave();
  // Turning it off frees tasks that were held back waiting for fresh prompts — don't make them wait for
  // the next event (a batch landing) to notice.
  if (!st.freshPromptsOnly) scheduleDebounced();
};
// Each ? in the ⚗️ popover opens Help at the item explaining that control (data-help). Most sit inside a
// <label>, so a click must not toggle the checkbox.
for (const a of document.querySelectorAll('#strategyPopover .strategyHelpLink[data-help]')) {
  a.onclick = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setStrategyOpen(false);
    openHelp(a.dataset.help);
  };
}

const staleBridgeSeg = document.getElementById('staleBridgeSeg');
const staleBridgeBtns = staleBridgeSeg ? Array.from(staleBridgeSeg.querySelectorAll('.segBtn')) : [];
function updateStaleBridgeUI() {
  staleBridgeBtns.forEach(b => b.classList.toggle('active', b._level === st.staleBridgeMode));
  // ⏳ Fresh prompts only overrides bridging (which IS stale prompts). The chosen mode is kept, not
  // reset, so unticking ⏳ brings it back as it was.
  const off = !!st.freshPromptsOnly;
  if (staleBridgeSeg) staleBridgeSeg.classList.toggle('segOverridden', off);
  // aria-disabled, not `disabled`: browsers disagree on tooltips over disabled buttons, and each mode's
  // tooltip is its only explanation. The click handler refuses while overridden.
  staleBridgeBtns.forEach(b => b.setAttribute('aria-disabled', String(off)));
  const note = document.getElementById('staleBridgeOverride');
  if (note) note.style.display = off ? '' : 'none';
}
staleBridgeBtns.forEach(b => {
  b._level = Number(b.dataset.level);
  b.onclick = () => {
    if (st.freshPromptsOnly) return;   // overridden by ⏳ (see updateStaleBridgeUI)
    st.staleBridgeMode = b._level;
    updateStaleBridgeUI();
    logEvent('stale_bridge_changed', { mode: st.staleBridgeMode });
    scheduleAutosave();
  };
});
updateStaleBridgeUI();

const keepPromptsSeg = document.getElementById('keepPromptsSeg');
const keepPromptsBtns = keepPromptsSeg ? Array.from(keepPromptsSeg.querySelectorAll('.segBtn')) : [];
function updateKeepPromptsUI() {
  keepPromptsBtns.forEach(b => b.classList.toggle('active', b._level === st.keepPromptsMode));
}
keepPromptsBtns.forEach(b => {
  b._level = Number(b.dataset.level);
  b.onclick = () => {
    st.keepPromptsMode = b._level;
    updateKeepPromptsUI();
    logEvent('keep_prompts_mode_changed', { mode: st.keepPromptsMode });
    updateInstDirty();   // Apply's title names the mode
    scheduleAutosave();
  };
});
updateKeepPromptsUI();

const autoQueueVariantChk = document.getElementById('autoQueueVariantChk');
autoQueueVariantChk.checked = st.autoQueueVariant;
autoQueueVariantChk.onchange = () => {
  st.autoQueueVariant = autoQueueVariantChk.checked;
  logEvent('auto_queue_variant_toggled', { enabled: st.autoQueueVariant });
  scheduleAutosave();
};

const prioritizeSteeredChk = document.getElementById('prioritizeSteeredChk');
prioritizeSteeredChk.checked = st.prioritizeSteered;
prioritizeSteeredChk.onchange = () => {
  st.prioritizeSteered = prioritizeSteeredChk.checked;
  logEvent('prioritize_steered_toggled', { enabled: st.prioritizeSteered });
  scheduleAutosave();
};

const promptPrefixInput = document.getElementById('promptPrefixInput');
const promptSuffixInput = document.getElementById('promptSuffixInput');
promptPrefixInput.value = st.promptPrefix;
promptSuffixInput.value = st.promptSuffix;

// Prefix / Suffix work like 📏 below: typing just edits the box, Enter or click-out applies (Shift+Enter is
// a newline), Esc cancels, a hint shows while what's typed isn't in force — and nothing pauses. They used
// to write on every keystroke and pause generation while focused, so an image started mid-typing could
// get half a prefix. Now it gets the old one. Unapplied text is lost on a reload mid-typing (blur isn't
// reliable on unload); accepted, as for 📏.
function psfixHintShown(input, applied) {
  return document.activeElement === input && input.value.trim() !== applied;
}
function wireAppliedBox(input, hint, key) {
  const chrome = () => { hint.style.display = psfixHintShown(input, st[key]) ? '' : 'none'; };
  input.addEventListener('input', chrome);
  input.addEventListener('focus', chrome);
  input.addEventListener('blur', () => {
    const typed = input.value.trim();
    if (typed !== st[key]) { st[key] = typed; scheduleAutosave(); }
    chrome();
  });
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing && e.keyCode !== 229) { e.preventDefault(); input.blur(); }
    else if (e.key === 'Escape') { input.value = st[key]; input.blur(); }
  });
}
wireAppliedBox(promptPrefixInput, document.getElementById('promptPrefixHint'), 'promptPrefix');
wireAppliedBox(promptSuffixInput, document.getElementById('promptSuffixHint'), 'promptSuffix');

// 📏 Every-batch rule. Applies on Enter / click-out, and deliberately does NOT pause anything on focus:
// like the 🧲 Steer box it only feeds the brainstorm, never the image queue. Typing just edits the box;
// st.batchRule changes on blur, so a batch that starts mid-typing gets the rule already in force, never
// half of a new one. Esc is cancel (leaving the box applies, so an Esc that only blurred would apply).
// Unapplied text is lost on a reload mid-typing — blur isn't reliable on unload; accepted.
const batchRuleInput = document.getElementById('batchRuleInput');
const batchRuleClearBtn = document.getElementById('batchRuleClearBtn');
const batchRuleHint = document.getElementById('batchRuleHint');
const batchRuleActive = document.getElementById('batchRuleActive');
// ✕ while there's a rule in force or text in the box; the hint only while you're in the box with text
// that isn't in force yet. A rule in force also gets an accent border and "· active" in its label, so a
// resumed session can't bring one back unnoticed.
function updateBatchRuleChrome() {
  const typed = batchRuleInput.value.trim();
  batchRuleClearBtn.style.display = (st.batchRule || typed) ? '' : 'none';
  batchRuleHint.style.display = (document.activeElement === batchRuleInput && typed !== st.batchRule) ? '' : 'none';
  batchRuleInput.parentElement.classList.toggle('active', !!st.batchRule);
  batchRuleActive.style.display = st.batchRule ? '' : 'none';
}
function syncBatchRuleUI() {
  batchRuleInput.value = st.batchRule;
  updateBatchRuleChrome();
}
syncBatchRuleUI();
batchRuleInput.addEventListener('input', updateBatchRuleChrome);
batchRuleInput.addEventListener('focus', updateBatchRuleChrome);
batchRuleInput.addEventListener('blur', () => {
  const typed = batchRuleInput.value.trim();
  if (typed !== st.batchRule) {
    st.batchRule = typed;
    logEvent('batch_rule_set', { text: typed });
    scheduleAutosave();
  }
  updateBatchRuleChrome();
});
batchRuleInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey && !e.isComposing && e.keyCode !== 229) { e.preventDefault(); batchRuleInput.blur(); }
  else if (e.key === 'Escape') { batchRuleInput.value = st.batchRule; batchRuleInput.blur(); }
});
// mousedown keeps focus in the box, so pressing ✕ mid-typing doesn't first apply the typed text via blur.
batchRuleClearBtn.addEventListener('mousedown', (e) => e.preventDefault());
batchRuleClearBtn.addEventListener('click', () => {
  const was = st.batchRule;
  if (was) {
    logEvent('batch_rule_cleared', { text: was });
    st.batchRule = '';
    scheduleAutosave();
  }
  syncBatchRuleUI();
  if (was) showToast('Cleared the 📏 every-batch rule', { undo: () => {
    if (st.batchRule || batchRuleInput.value.trim()) return;   // a new rule was applied or is being typed; leave it
    st.batchRule = was;
    logEvent('undo', { what: 'batch_rule_cleared' });
    scheduleAutosave();
    syncBatchRuleUI();
  } });
});


// Keep the top-most visible feed card fixed in the viewport across a reflow that changes the grid's
// column width/count (sidebar toggle, image-size change). Without this, scrollTop stays at the same
// pixel value while the content height changes underneath it, so the feed jumps "to the middle of
// nowhere". Capture the anchor card + its exact offset before mutating, then correct scrollTop
// synchronously after — reading layout forces reflow, so the fix lands before paint (no flicker).
function preserveFeedScroll(mutate) {
  const scroll = document.getElementById('feedScroll');
  const feed = document.getElementById('feed');
  if (!scroll || !feed) { mutate(); return; }
  const cTop = scroll.getBoundingClientRect().top;
  let anchor = null, anchorOffset = 0;
  for (const card of feed.children) {
    const r = card.getBoundingClientRect();
    if (r.bottom > cTop + 1) { anchor = card; anchorOffset = r.top - cTop; break; }
  }
  mutate();
  if (!anchor) return; // empty feed / placeholder showing — nothing to hold
  const newTop = anchor.getBoundingClientRect().top - scroll.getBoundingClientRect().top;
  scroll.scrollTop += newTop - anchorOffset;
}

function updateImageSize() {
  preserveFeedScroll(() => {
    document.documentElement.style.setProperty('--image-size', st.imageSizeScale);
  });
  sizeIndicator.textContent = Math.round(st.imageSizeScale * 100) + '%';
  localStorage.setItem('imageSizeScale', String(st.imageSizeScale));
}

updateImageSize();

sizeDownBtn.onclick = () => {
  st.imageSizeScale = Math.max(0.5, st.imageSizeScale - 0.1);
  updateImageSize();
};

sizeUpBtn.onclick = () => {
  st.imageSizeScale = Math.min(2.0, st.imageSizeScale + 0.1);
  updateImageSize();
};

/* Settings modal */
const settingsBtn = document.getElementById('settingsBtn');
const settingsModal = document.getElementById('settingsModal');
const settingsCloseX = document.getElementById('settingsCloseX');
const pluginViewerChk = document.getElementById('pluginViewerChk');

pluginViewerChk.checked = st.pluginViewer;
pluginViewerChk.onchange = () => {
  st.pluginViewer = pluginViewerChk.checked;
  localStorage.setItem('ipo_pluginViewer', String(st.pluginViewer));
  logEvent('plugin_viewer_toggled', { enabled: st.pluginViewer });
};

const minPromptsSlider = document.getElementById('minPromptsSlider');
const minPromptsValue = document.getElementById('minPromptsValue');
const minPromptsReset = document.getElementById('minPromptsReset');
const MIN_PROMPTS_DEFAULT = 6;
st.params.MIN_PROMPTS_READY = parseInt(localStorage.getItem('ipo_minPromptsReady') || MIN_PROMPTS_DEFAULT, 10);
minPromptsSlider.value = st.params.MIN_PROMPTS_READY;
minPromptsValue.textContent = st.params.MIN_PROMPTS_READY;
minPromptsSlider.oninput = () => {
  st.params.MIN_PROMPTS_READY = parseInt(minPromptsSlider.value, 10);
  minPromptsValue.textContent = st.params.MIN_PROMPTS_READY;
  localStorage.setItem('ipo_minPromptsReady', st.params.MIN_PROMPTS_READY);
};
minPromptsReset.onclick = () => {
  st.params.MIN_PROMPTS_READY = MIN_PROMPTS_DEFAULT;
  minPromptsSlider.value = MIN_PROMPTS_DEFAULT;
  minPromptsValue.textContent = MIN_PROMPTS_DEFAULT;
  localStorage.removeItem('ipo_minPromptsReady');
};

function openSettings() { settingsModal.style.display = 'flex'; refreshICStats(); refreshDCStats(); }
function closeSettings() { settingsModal.style.display = 'none'; }
settingsBtn.onclick = openSettings;
settingsCloseX.onclick = closeSettings;
settingsModal.addEventListener('click', (e) => { if (e.target === settingsModal) closeSettings(); });

const saveSessionBtn = document.getElementById('saveSessionBtn');
const forceSaveBtn = document.getElementById('forceSaveBtn');

// Shared explicit-save path for the toolbar 'Save as…' button and the settings
// 'Force save now' button. Prompts for a name if the session is still unnamed
// (promoting it out of the __autosave__ recovery slot), then writes last by
// cancelling any pending autosave and awaiting any in-flight one. Returns the
// resolved name on success, or null if the user cancelled the name prompt;
// throws on save failure (callers render their own error feedback).
async function doExplicitSave() {
  // Cancel any debounced autosave so it can't race this explicit save...
  clearTimeout(autosaveTimer); autosaveTimer = null;
  let name = st.currentSessionName;
  const wasUnnamed = !name;
  if (!name) {
    const defaultName = st.instruction.slice(0, 40).trim()
      || `Session – ${new Date().toLocaleDateString()}`;
    // askSessionName won't accept a name already in use: saving under it would silently overwrite
    // that saved session.
    name = await askSessionName({ title: 'Name this session',
      body: 'It stays in this browser, and you can open it again from 📂 All sessions.', value: defaultName });
    if (!name) return null;
  }
  // ...and let any in-flight autosave finish first so this explicit save writes last.
  while (autosaveInFlight) await new Promise(r => setTimeout(r, 30));
  await saveSession(name);
  // First explicit save of an unnamed session: it now lives under a real name,
  // so retire the rolling recovery slot (no longer the latest unnamed session).
  if (wasUnnamed) await deleteAutosaveSlot();
  // Only worth the scan if something is already leaning on the list — saveSession() has already put
  // the pointer and the resume candidate straight, which is all boot and the resume bar read.
  if (st.sessionsListLoaded) await refreshSessionsList();
  return name;
}

// The label sits in its own .tbtnLabel span so it can collapse to the icon on narrow screens; writing
// textContent on the button would flatten that span away for good.
function setSaveBtnLabel(icon, label) {
  saveSessionBtn.textContent = icon + ' ';
  const span = document.createElement('span');
  span.className = 'tbtnLabel';
  span.textContent = label;
  saveSessionBtn.appendChild(span);
}

// Toolbar button only ever shows while unnamed, so a click here always promotes
// the session to a name, then lingers on '✅ Saved!' and fades out — its job
// (naming) is done; autosave + the 📂 chip take over from here.
saveSessionBtn.onclick = async () => {
  explicitSaveAnimating = true;  // hold off updateSessionButtons() until the fade ends
  setSaveBtnLabel('💾', 'Saving...');
  saveSessionBtn.disabled = true;
  try {
    const name = await doExplicitSave();
    if (!name) {  // user cancelled the name prompt — restore and bail
      explicitSaveAnimating = false;
      setSaveBtnLabel('💾', 'Save as…');
      saveSessionBtn.disabled = false;
      updateSessionButtons();
      return;
    }
    setSaveBtnLabel('✅', 'Saved!');
    setTimeout(() => {
      saveSessionBtn.classList.add('fading');
      let finished = false;
      const finish = () => {
        if (finished) return;
        finished = true;
        saveSessionBtn.removeEventListener('transitionend', finish);
        saveSessionBtn.classList.remove('fading');
        saveSessionBtn.style.display = 'none';
        setSaveBtnLabel('💾', 'Save as…');
        saveSessionBtn.disabled = false;
        explicitSaveAnimating = false;
        updateSessionButtons();  // settle final state (stays hidden — now named)
      };
      saveSessionBtn.addEventListener('transitionend', finish, { once: true });
      setTimeout(finish, 600);  // fallback if transitionend never fires
    }, 1200);
  } catch (e) {
    console.error('Save failed:', e);
    explicitSaveAnimating = false;
    setSaveBtnLabel('❌', 'Error');
    setTimeout(() => {
      setSaveBtnLabel('💾', 'Save as…');
      saveSessionBtn.disabled = false;
      updateSessionButtons();
    }, 1500);
  }
};

// Settings 'Force save now' — break-glass for a named session (autosave handles
// the normal case). Stays put; no fade. If used while still unnamed, it prompts
// and promotes just like the toolbar button.
if (forceSaveBtn) forceSaveBtn.onclick = async () => {
  const orig = '💾 Force save now';
  forceSaveBtn.disabled = true;
  forceSaveBtn.textContent = '💾 Saving...';
  try {
    const name = await doExplicitSave();
    forceSaveBtn.textContent = name ? '✅ Saved!' : orig;
  } catch (e) {
    console.error('Force save failed:', e);
    forceSaveBtn.textContent = '❌ Error';
  }
  setTimeout(() => { forceSaveBtn.textContent = orig; forceSaveBtn.disabled = false; }, 1500);
};

async function renameSession(oldName, newName) {
  const data = await loadSession(oldName);
  if (!data) return;
  data.meta = data.meta || {};
  data.meta.sessionName = newName;
  const db = await openSavedSessionDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('session', 'readwrite');
    const store = tx.objectStore('session');
    store.put(data, newName);
    store.delete(oldName);
    tx.oncomplete = () => {
      if (st.currentSessionName === oldName) st.currentSessionName = newName;
      // The old key is gone, so a pointer naming it is now a lie. Callers re-point via
      // refreshSessionsList(); dropping it here means even a caller that doesn't only costs a scan.
      forgetLatestSession(oldName);
      resolve();
    };
    tx.onerror = () => reject(tx.error);
  });
}

// Boot no longer scans the store, so this is where that cost moved to: the one screen that genuinely
// needs every session listed pays for the list, once, when you ask for it. Show the modal first and say
// what's happening — the click must not look dead while a big store is read.
async function openSessionModal() {
  const modal = document.getElementById('sessionModal');
  modal.style.display = 'flex';
  if (!st.sessionsListLoaded) {
    document.getElementById('sessionModalList').innerHTML =
      '<div class="sessionModalEmpty">Loading saved sessions…</div>';
    await refreshSessionsList();
    // Closed while we were reading — Esc, ✕, or the backdrop, which a slow read invites. Opening is this
    // function's job alone (renderSessionModal only fills the list), so bail rather than resurrect a
    // modal the user has dismissed. The list is loaded now, so the next 📂 opens instantly.
    if (modal.style.display !== 'flex') return;
  }
  renderSessionModal();
}

function renderSessionModal() {
  const modal = document.getElementById('sessionModal');
  const listEl = document.getElementById('sessionModalList');
  listEl.innerHTML = '';

  if (st.savedSessionsList.length === 0) {
    listEl.innerHTML = '<div class="sessionModalEmpty">No saved sessions</div>';
  } else {
    for (const s of st.savedSessionsList) {
      const row = document.createElement('div');
      row.className = 'sessionModalRow';

      const info = document.createElement('div');
      info.className = 'sessionModalInfo';
      const nameEl = document.createElement('div');
      nameEl.className = 'sessionModalName';
      nameEl.textContent = s.name;
      if (s.name === st.currentSessionName) {
        const badge = document.createElement('span');
        badge.className = 'sessionModalCurrent';
        badge.textContent = 'current';
        nameEl.appendChild(badge);
      }
      const detail = document.createElement('div');
      detail.className = 'sessionModalDetail';
      const imgCount = s.data.images?.length || 0;
      const promptCount = s.data.order?.length || 0;
      const date = s.data.meta?.savedAt ? new Date(s.data.meta.savedAt).toLocaleString() : '';
      detail.textContent = `${plural(imgCount, 'liked image')}, ${plural(promptCount, 'prompt')}${date ? ' · ' + date : ''}`;
      info.appendChild(nameEl);
      info.appendChild(detail);

      const actions = document.createElement('div');
      actions.className = 'sessionModalActions';
      const loadBtn = document.createElement('button');
      loadBtn.className = 'sessionModalBtn primary';
      loadBtn.textContent = 'Load';
      loadBtn.onclick = async () => {
        modal.style.display = 'none';
        hideResumePanel();
        await settleAutosave();   // before the rename below points autosave at the incoming session
        st.currentSessionName = s.name;
        await restoreSession(s.data);
      };
      const renameBtn = document.createElement('button');
      renameBtn.className = 'sessionModalBtn';
      renameBtn.textContent = 'Rename';
      renameBtn.onclick = async () => {
        const trimmed = await askSessionName({ title: 'Rename session', value: s.name, okLabel: 'Rename', keep: s.name });
        if (!trimmed || trimmed === s.name) return;
        await renameSession(s.name, trimmed);
        await refreshSessionsList();
        refreshResumePanel();
        renderSessionModal();
      };
      const delBtn = document.createElement('button');
      delBtn.className = 'sessionModalBtn danger';
      delBtn.textContent = 'Delete';
      delBtn.onclick = async () => {
        const nImg = s.data.images?.length || 0, nPr = s.data.order?.length || 0;
        const act = await confirmChoice({
          title: `Delete "${s.name}"?`,
          body: `${plural(nImg, 'liked image')}, ${plural(nPr, 'prompt')}. This can't be undone.`
            + (IC_PIN_SAVED ? ' Its cached images will then expire as usual.' : ''),
          okLabel: 'Delete', danger: true
        });
        if (act !== 'ok') return;
        await deleteSession(s.name);   // refreshes the list itself — it's loaded, or this row wouldn't be here
        refreshResumePanel();
        if (st.savedSessionsList.length === 0) {
          modal.style.display = 'none';
        } else {
          renderSessionModal();
        }
      };
      const exportBtn = document.createElement('button');
      exportBtn.className = 'sessionModalBtn';
      exportBtn.textContent = '🧺 View picks';
      exportBtn.title = 'Browse this saved session’s upvoted and marked images without loading it, and download them';
      exportBtn.onclick = () => {
        modal.style.display = 'none';
        exOpen({ kind: 'saved', name: s.name, data: s.data });
      };
      actions.appendChild(loadBtn);
      actions.appendChild(exportBtn);
      actions.appendChild(renameBtn);
      actions.appendChild(delBtn);

      row.appendChild(buildSessionThumbs(s.data.images));
      row.appendChild(info);
      row.appendChild(actions);
      listEl.appendChild(row);
    }
  }
}

document.getElementById('sessionModalClose').onclick = () => {
  document.getElementById('sessionModal').style.display = 'none';
};
document.getElementById('sessionModal').addEventListener('click', (e) => {
  if (e.target === document.getElementById('sessionModal')) {
    document.getElementById('sessionModal').style.display = 'none';
  }
});
document.addEventListener('keydown', (e) => {
  const modal = document.getElementById('sessionModal');
  if (modal.style.display !== 'flex') return;
  if (e.key === 'Escape') modal.style.display = 'none';
});

/* ===================== Session Backup / Restore ===================== */

function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(blob);
  });
}

async function buildSessionImageExportList(onProgress) {
  if (!icDB) return [];
  const liveMeta = await getICMeta();
  const deepMeta = await getDeepMeta();
  const total = liveMeta.length + deepMeta.length;
  const out = [];
  let done = 0;
  for (const rec of liveMeta) {
    try {
      const blob = await getICBlob(rec.id);
      if (blob) {
        const compressed = await compressToDeepCache(blob, DC_SIZE_PCT);
        out.push({
          promptId: rec.promptId ?? null,
          promptText: rec.promptText || '',
          resolvedText: rec.resolvedText || '',
          sessionName: rec.sessionName || '',
          resolution: rec.resolution || '',
          createdAt: rec.createdAt,
          dataUrl: await blobToDataUrl(compressed),
        });
      }
    } catch (e) { console.warn('Export live image failed:', rec.id, e); }
    done++;
    if (onProgress) onProgress(done, total);
  }
  for (const rec of deepMeta) {
    try {
      const blob = await getDeepBlob(rec.id);
      if (blob) {
        out.push({
          promptId: rec.promptId ?? null,
          promptText: rec.promptText || '',
          resolvedText: rec.resolvedText || '',
          sessionName: rec.sessionName || '',
          resolution: rec.resolution || '',
          createdAt: rec.createdAt,
          dataUrl: await blobToDataUrl(blob),
        });
      }
    } catch (e) { console.warn('Export archived image failed:', rec.id, e); }
    done++;
    if (onProgress) onProgress(done, total);
  }
  return out;
}

async function estimateSessionImageExportInfo() {
  if (!icDB) return { totalCount: 0, estBytes: null };
  const [liveMeta, deepMeta] = await Promise.all([getICMeta(), getDeepMeta()]);
  const liveCount = liveMeta.length;
  const archivedCount = deepMeta.length;
  const totalCount = liveCount + archivedCount;
  let estBytes = null;
  if (totalCount > 0) {
    const [liveBytes, deepBytes] = await Promise.all([getICBlobsTotalSize(), getDeepBlobsTotalSize()]);
    // Live images are re-compressed to archive quality on export. Estimate their exported
    // size from the archived average when we have a sample; otherwise fall back to roughly
    // half their raw bytes. Archived images export at their stored size.
    const liveExportBytes = archivedCount > 0
      ? liveCount * (deepBytes / archivedCount)
      : liveBytes * 0.5;
    estBytes = Math.round((deepBytes + liveExportBytes) * 1.37); // *1.37 ≈ base64 + JSON overhead
  }
  return { totalCount, estBytes };
}

async function importSessionImages(images, onProgress) {
  if (!icDB) return { imported: 0, duplicate: 0, failed: 0 };
  // Prebuild the set of createdAt timestamps already present (live + archive) so dedup
  // is O(1) instead of opening two IndexedDB transactions per candidate image. We check
  // against this pre-import snapshot only (not updated inside the loop): distinct images
  // that happen to share a millisecond all import, while re-importing the same file later
  // dedups against the now-stored copies. Images with no timestamp can't be deduped.
  const [liveMeta, deepMeta] = await Promise.all([getICMeta(), getDeepMeta()]);
  const existingCreatedAt = new Set();
  for (const m of liveMeta) if (m.createdAt != null) existingCreatedAt.add(m.createdAt);
  for (const m of deepMeta) if (m.createdAt != null) existingCreatedAt.add(m.createdAt);

  let imported = 0, duplicate = 0, failed = 0;
  let done = 0;
  for (const img of images) {
    if (img.createdAt != null && existingCreatedAt.has(img.createdAt)) {
      duplicate++;
      done++;
      if (onProgress) onProgress(done, images.length);
      continue;
    }
    try {
      // Exported images are already at archive quality — skip re-compression.
      const blob = await (await fetch(img.dataUrl)).blob();
      const id = await archiveToDeepCache({
        promptId: img.promptId ?? null,
        promptText: img.promptText || '',
        resolvedText: img.resolvedText || '',
        sessionName: img.sessionName || '',
        resolution: img.resolution || '',
        createdAt: img.createdAt != null ? img.createdAt : Date.now(),
      }, blob, { preCompressed: true });
      if (id != null) imported++; else failed++;
    } catch (e) {
      console.warn('Import image failed:', e);
      failed++;
    }
    done++;
    if (onProgress) onProgress(done, images.length);
  }
  return { imported, duplicate, failed };
}

// A session's image.cacheId indexes the ORIGIN machine's image cache (auto-increment
// ints), so it's meaningless after import and would make a restored card load an
// unrelated blob. Strip it here so restored cards fall back to the embedded thumbnail.
function stripImportedImageRefs(images) {
  return (images || []).map(img => ({ ...img, cacheId: null }));
}

// A well-formed session entry from an import file. Guards getAllSessions() (which
// dereferences data.meta) against a truncated/hostile file writing an undefined value.
function isValidImportSession(s) {
  return s && typeof s.name === 'string' && s.name && s.data && typeof s.data === 'object';
}

// Writes many {name, value} sessions in ONE transaction so the import is atomic —
// a failure partway rolls the whole batch back instead of leaving a half-written store.
function putSessionsBatch(db, writes) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction('session', 'readwrite');
    const store = tx.objectStore('session');
    for (const w of writes) store.put(w.value, w.name);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

{
  const exportIncludeImagesChk = document.getElementById('exportIncludeImagesChk');
  const exportImagesEstimate = document.getElementById('exportImagesEstimate');
  const exportBtn = document.getElementById('exportSessionsBtn');
  const importBtn = document.getElementById('importSessionsBtn');
  const importFileInput = document.getElementById('importSessionsFile');
  const importPanel = document.getElementById('importSessionsPanel');
  const importInfo = document.getElementById('importSessionsInfo');
  const importResult = document.getElementById('importSessionsResult');
  const importConfirmBtn = document.getElementById('importSessionsConfirm');
  const importCancelBtn = document.getElementById('importSessionsCancel');

  let pendingImportData = null;

  exportIncludeImagesChk.addEventListener('change', async () => {
    if (!exportIncludeImagesChk.checked) {
      exportImagesEstimate.style.display = 'none';
      return;
    }
    exportImagesEstimate.style.display = 'block';
    exportImagesEstimate.textContent = 'Estimating...';
    try {
      const { totalCount, estBytes } = await estimateSessionImageExportInfo();
      exportImagesEstimate.textContent = estBytes != null
        ? `~${totalCount} image(s), ~${formatBytes(estBytes)}`
        : `~${totalCount} image(s)`;
    } catch (e) {
      exportImagesEstimate.textContent = 'Unable to estimate size';
    }
  });

  exportBtn.addEventListener('click', async () => {
    try {
      exportBtn.textContent = 'Gathering sessions...';
      const sessions = await getAllSessions();
      const data = {
        version: 1,
        exportedAt: new Date().toISOString(),
        sessions: sessions.map(s => ({ name: s.name, data: s.data })),
      };
      if (exportIncludeImagesChk.checked) {
        data.images = await buildSessionImageExportList((done, total) => {
          exportBtn.textContent = `Exporting ${done}/${total}...`;
        });
      }
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `ipo-sessions-${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      showToast("Couldn't export sessions: " + err.message, { kind: 'error' });
    } finally {
      exportBtn.textContent = '📤 Export';
    }
  });

  importBtn.addEventListener('click', () => {
    importFileInput.value = '';
    importFileInput.click();
  });

  // Replace deletes every saved session not in the file, on one click — so choosing it changes the button
  // to say exactly that, in red, before anything can happen.
  let importExisting = 0;
  const importReplaceWarn = document.getElementById('importSessionsReplaceWarn');
  function importUpdateReplaceWarning() {
    const replace = document.querySelector('input[name="importSessionsMode"]:checked')?.value === 'replace';
    const incoming = pendingImportData?.sessions?.length || 0;
    importConfirmBtn.classList.toggle('importDanger', replace);
    importConfirmBtn.textContent = replace
      ? `Replace ${plural(importExisting, 'session')} with ${incoming}`
      : 'Import';
    importReplaceWarn.style.display = replace && importExisting ? 'block' : 'none';
  }
  document.querySelectorAll('input[name="importSessionsMode"]').forEach(r => r.addEventListener('change', importUpdateReplaceWarning));
  document.getElementById('importExportFirstLink').addEventListener('click', (e) => { e.preventDefault(); exportBtn.click(); });

  importCancelBtn.addEventListener('click', () => {
    pendingImportData = null;
    importPanel.style.display = 'none';
    importResult.style.display = 'none';
  });

  importFileInput.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    importResult.style.display = 'none';
    try {
      const text = await file.text();
      const data = JSON.parse(text);
      if (!data.sessions || !Array.isArray(data.sessions)) throw new Error('Invalid format: missing sessions array');
      pendingImportData = data;

      const existingSessions = await getAllSessions();
      let info = `File: <b>${escapeHtml(file.name)}</b><br>`;
      info += `Contains: ${data.sessions.length} session(s)`;
      const totalPrompts = data.sessions.reduce((n, s) => n + (s.data?.order?.length || 0), 0);
      const totalImages = data.sessions.reduce((n, s) => n + (s.data?.images?.length || 0), 0);
      info += `, ${plural(totalPrompts, 'prompt')}, ${plural(totalImages, 'liked image')}`;
      if (data.images && data.images.length > 0) {
        info += `<br>Also includes: ${data.images.length} cached/archived image(s)`;
      }
      if (existingSessions.length > 0) {
        info += `<br>Existing: ${existingSessions.length} session(s)`;
      }
      importInfo.innerHTML = info;
      importExisting = existingSessions.length;
      importUpdateReplaceWarning();
      importPanel.style.display = 'block';
    } catch (err) {
      importInfo.innerHTML = `<span style="color:#ff6b6b">Error reading file: ${escapeHtml(err.message)}</span>`;
      pendingImportData = null;
      importPanel.style.display = 'block';
    }
  });

  importConfirmBtn.addEventListener('click', async () => {
    if (!pendingImportData) return;
    const data = pendingImportData;
    const modeRadio = document.querySelector('input[name="importSessionsMode"]:checked');
    const mode = modeRadio ? modeRadio.value : 'merge';

    // Drop malformed entries up front so a truncated/hostile file can never write an
    // undefined session value (which would poison getAllSessions on every later load).
    const validSessions = data.sessions.filter(isValidImportSession);
    const invalid = data.sessions.length - validSessions.length;
    if (mode === 'replace' && validSessions.length === 0) {
      importResult.innerHTML = 'Nothing valid to import — existing sessions left untouched.';
      importResult.style.display = 'block';
      importResult.style.background = 'rgba(255,107,107,0.12)';
      importResult.style.color = '#ff6b6b';
      return;
    }

    importConfirmBtn.disabled = true;
    importConfirmBtn.textContent = 'Importing...';
    // Suppress autosave for the duration so a debounced save of the active session
    // can't race our writes (resurrect a replaced session / clobber a merge).
    importInProgress = true;

    // Counters are declared here (not inside a branch) so the summary below can read them.
    let imported = 0, skipped = 0, replaced = 0;
    let mergedSessions = 0, newPrompts = 0, newImages = 0, dupImages = 0;

    try {
      const db = await openSavedSessionDB();

      if (mode === 'replace') {
        // Clear existing named sessions and write all imported ones in a SINGLE
        // transaction, so a mid-import failure rolls back cleanly instead of leaving
        // the store half-replaced.
        const writes = validSessions.map(s => ({
          name: s.name,
          value: { ...s.data, images: stripImportedImageRefs(s.data.images) },
        }));
        await new Promise((resolve, reject) => {
          const tx = db.transaction('session', 'readwrite');
          const store = tx.objectStore('session');
          const cursorReq = store.openCursor();
          cursorReq.onsuccess = (e) => {
            const cursor = e.target.result;
            if (cursor) {
              if (cursor.key !== AUTOSAVE_SLOT) cursor.delete();
              cursor.continue();
            } else {
              for (const w of writes) store.put(w.value, w.name);
            }
          };
          tx.oncomplete = () => resolve();
          tx.onerror = () => reject(tx.error);
        });
        replaced = writes.length;
      } else {
        const existing = await getAllSessions();
        const existingByName = new Map(existing.map(s => [s.name, s.data]));
        const writes = [];
        for (const s of validSessions) {
          const prev = existingByName.get(s.name);
          if (prev) {
            const existingThumbs = new Set((prev.images || []).map(img => img.thumbnail));
            const existingIds = new Set(Object.keys(prev.prompts || {}));
            // Map an existing prompt's text -> its id, so a duplicate-text import can point
            // its image at the prompt already here instead of a dangling id.
            const textToExistingId = new Map(Object.values(prev.prompts || {}).map(p => [p.text, p.id]));
            const addedPrompts = {};
            const addedOrder = [];
            // imported prompt id -> the id it resolves to in the merged session (an existing
            // prompt when text already matched, a fresh id on collision, else itself). Used to
            // repoint this session's images so none end up orphaned (restore drops those).
            const idToFinal = {};
            for (const id of (s.data.order || [])) {
              const p = s.data.prompts?.[id];
              if (!p) continue;
              if (textToExistingId.has(p.text)) {
                idToFinal[id] = textToExistingId.get(p.text); // dup text: fold into existing prompt
                continue;
              }
              // A genuinely new prompt whose id already belongs to a different existing prompt:
              // re-key it so the spread below can't overwrite and `order` gets no duplicate.
              let newId = id;
              if (existingIds.has(newId) || addedPrompts[newId]) newId = uid('p');
              idToFinal[id] = newId;
              addedPrompts[newId] = { ...p, id: newId };
              addedOrder.push(newId);
              newPrompts++;
            }
            // Now that idToFinal is complete, remap each new prompt's tree lineage through it (§2). A
            // parent/mix-in pointing at a prompt that didn't come across (absent from idToFinal) is
            // dropped: parent → null (the node becomes a root under its version), drewFrom id → omitted.
            // taskId is always dropped — tasks aren't copied, so the live-highlight hint can't survive.
            for (const nid in addedPrompts) {
              const np = addedPrompts[nid];
              if (np.parent && np.parent.promptId != null) {
                const mapped = idToFinal[np.parent.promptId];
                np.parent = mapped ? { kind: np.parent.kind, promptId: mapped, ver: np.parent.ver } : null;
              }
              if (Array.isArray(np.drewFrom)) {
                const remapped = np.drewFrom.map(fid => idToFinal[fid]).filter(Boolean);
                np.drewFrom = remapped.length ? remapped : null;
              }
            }
            const addedImages = [];
            for (const img of (s.data.images || [])) {
              if (img.thumbnail && existingThumbs.has(img.thumbnail)) {
                dupImages++;
              } else {
                addedImages.push({ ...img, promptId: idToFinal[img.promptId] || img.promptId, cacheId: null });
                newImages++;
              }
            }
            if (addedOrder.length === 0 && addedImages.length === 0) {
              skipped++;
              continue;
            }
            // Spread prev as the base so any session field added by a future saveSession
            // survives the merge instead of being silently dropped.
            writes.push({
              name: s.name,
              value: {
                ...prev,
                meta: { ...prev.meta, savedAt: Math.max(prev.meta?.savedAt || 0, s.data.meta?.savedAt || 0) },
                prompts: { ...prev.prompts, ...addedPrompts },
                order: [...(prev.order || []), ...addedOrder],
                images: [...(prev.images || []), ...addedImages],
              },
            });
            mergedSessions++;
          } else {
            writes.push({
              name: s.name,
              value: { ...s.data, images: stripImportedImageRefs(s.data.images) },
            });
            imported++;
          }
        }
        await putSessionsBatch(db, writes);
      }

      let imageStats = null;
      if (data.images && data.images.length > 0) {
        importConfirmBtn.textContent = 'Importing images...';
        imageStats = await importSessionImages(data.images, (done, total) => {
          importConfirmBtn.textContent = `Images ${done}/${total}...`;
        });
      }

      // An import can add sessions, merge into existing ones, or (replace mode) wipe the lot, so the
      // remembered-latest pointer is re-derived from the fresh list rather than patched — see
      // refreshSessionsList().
      await refreshSessionsList();
      updateSessionButtons();

      let msg = '';
      if (mode === 'replace') {
        msg = `Replaced with ${replaced} session(s).`;
      } else {
        const parts = [];
        if (imported > 0) parts.push(`${imported} new session(s)`);
        if (mergedSessions > 0) parts.push(`${mergedSessions} merged`);
        if (newPrompts > 0) parts.push(`${newPrompts} new prompt(s)`);
        if (newImages > 0) parts.push(`${newImages} new image(s)`);
        if (dupImages > 0) parts.push(`${dupImages} duplicate image(s) skipped`);
        if (skipped > 0) parts.push(`${skipped} unchanged session(s)`);
        msg = parts.length > 0 ? parts.join(', ') + '.' : 'Nothing new to import.';
      }
      if (invalid > 0) msg += ` ${invalid} malformed entr${invalid === 1 ? 'y' : 'ies'} skipped.`;
      if (imageStats) {
        msg += `<br>Cache images: ${imageStats.imported} imported`;
        if (imageStats.duplicate > 0) msg += `, ${imageStats.duplicate} duplicate(s)`;
        if (imageStats.failed > 0) msg += `, ${imageStats.failed} failed`;
        msg += '.';
      }

      importResult.innerHTML = msg;
      importResult.style.display = 'block';
      importResult.style.background = 'rgba(43,210,106,0.12)';
      importResult.style.color = '#2bd26a';
      pendingImportData = null;
      setTimeout(() => { importPanel.style.display = 'none'; importResult.style.display = 'none'; }, 5000);
    } catch (err) {
      importResult.innerHTML = `Error: ${escapeHtml(err.message)}`;
      importResult.style.display = 'block';
      importResult.style.background = 'rgba(255,107,107,0.12)';
      importResult.style.color = '#ff6b6b';
    } finally {
      importInProgress = false;
      importConfirmBtn.disabled = false;
      importConfirmBtn.textContent = 'Import';
    }
  });
}

/* The ⏸️ button has four states, because the two halves pause separately:

     writing  drawing   button
     ───────  ───────   ──────────────────────────────
     running  running   ⏸️ Pause            (plain)
     PAUSED   PAUSED    ▶ Resume            (red)
     PAUSED   running   ▶✍️ Resume writing  (amber)
     running  PAUSED    ▶🖼️ Resume drawing  (amber)

   Amber rather than red for the half-states: something is still being produced, so the toolbar
   shouldn't read as stopped. The label always names what a click would START, never what is paused —
   from any half-state one click puts everything back to running, which is the whole point of leaving
   the main button alone and putting the split in a menu. */
function renderPauseBtn() {
  const p = st.pausedPrompts, i = st.pausedImages;
  const [icon, label] =
    (p && i) ? ['▶', 'Resume'] :
    p        ? ['▶✍️', 'Resume writing'] :
    i        ? ['▶🖼️', 'Resume drawing'] :
               ['⏸️', 'Pause'];
  // Write to the two spans, never to pauseBtn.textContent: that would delete the <span class="tbtnLabel">
  // the narrow-toolbar rule hides, and the button would keep its full-width label from then on.
  pauseBtnIcon.textContent = icon;
  pauseBtnLabel.textContent = label;
  pauseBtn.classList.toggle('active', p && i);
  pauseBtn.classList.toggle('half', (p || i) && !(p && i));
  // The title says what's happening now and what a click does, since the label is the action alone.
  // Stored as the ready title: before Start, updateToolbarState shows why it's greyed instead.
  pauseBtn.dataset.readyTitle =
    (p && i) ? 'Everything is paused. Click to resume both' :
    p        ? 'Writing paused, drawing runs. Click to resume both' :
    i        ? 'Drawing paused, writing runs. Click to resume both' :
               'Pause or resume everything · ▾ to pause just one half';
  if (st.started) pauseBtn.title = pauseBtn.dataset.readyTitle;
  pausePromptsState.textContent = p ? 'Paused' : 'Running';
  pausePromptsState.classList.toggle('off', p);
  pauseImagesState.textContent = i ? 'Paused' : 'Running';
  pauseImagesState.classList.toggle('off', i);
}

// The one writer of both flags. Nothing recomputes here — the guards read st.pausedPrompts /
// st.pausedImages directly — so this is just: record it, redraw the surfaces that show it, and wake
// the scheduler if anything is now allowed to run (it sits idle until something calls it).
function setPauseState(pausedPrompts, pausedImages, source) {
  st.pausedPrompts = !!pausedPrompts;
  st.pausedImages = !!pausedImages;
  renderPauseBtn();
  logEvent('manual_pause_toggle', { pausedPrompts: st.pausedPrompts, pausedImages: st.pausedImages, source });
  if (!st.paused) schedule();
  renderSidebar();
}

pauseBtn.onclick = () => {
  if (!st.started) return;   // greyed before Start; .disabled no longer blocks the click itself
  // Always "make both halves agree": pause everything if anything is running, resume everything if
  // anything is paused. So the menu can never strand you in a half-state you have to go back for.
  const anyPaused = st.pausedPrompts || st.pausedImages;
  setPauseState(!anyPaused, !anyPaused, 'button');
};

// ▾ is its own button, click-only like ⚗️ / 🧰: a hover menu had no way in on a touchscreen, and a click
// on ⏸️ itself has to stay an instant pause. The document click that closes ⚗️ / 🧰 closes this too.
const pauseMenuBtn = document.getElementById('pauseMenuBtn');
const pauseMenu = document.getElementById('pauseMenu');
// Toolbar popovers are absolutely positioned right:0 against their button's wrapper. When the
// toolbar wraps on a narrow screen the button can sit on the LEFT of its row, hanging the
// popover off the viewport's left edge (it reads as a cut-off menu). If the natural position
// overflows, re-anchor with fixed coords clamped to the viewport. Inline styles are reset first
// so a previous fix-up never fights the fresh measurement.
function keepToolbarPopoverOnScreen(pop, btn) {
  pop.style.position = '';
  pop.style.left = '';
  pop.style.right = '';
  pop.style.top = '';
  pop.style.width = '';
  pop.style.maxWidth = '';
  pop.style.boxSizing = '';
  const m = 8;
  const r = pop.getBoundingClientRect();
  if (r.left >= m && r.right <= window.innerWidth - m) return;
  const w = Math.min(r.width || 300, window.innerWidth - m * 2);
  const b = btn.getBoundingClientRect();
  const left = Math.max(m, Math.min(b.right - w, window.innerWidth - w - m));
  pop.style.position = 'fixed';
  pop.style.left = left + 'px';
  pop.style.right = 'auto';
  pop.style.top = (b.bottom + 6) + 'px';
  pop.style.width = w + 'px';
  pop.style.maxWidth = 'none';
  pop.style.boxSizing = 'border-box';
}
function setPauseMenuOpen(open) {
  pauseMenu.style.display = open ? 'block' : 'none';
  pauseMenuBtn.classList.toggle('open', open);
  pauseMenuBtn.setAttribute('aria-expanded', String(open));
  if (open) keepToolbarPopoverOnScreen(pauseMenu, pauseMenuBtn);
}
pauseMenuBtn.onclick = (e) => {
  e.stopPropagation();
  if (!st.started) return;
  const open = pauseMenu.style.display !== 'block';
  if (open) { setStrategyOpen(false); setMiscOpen(false); }   // only one toolbar popover open at a time
  setPauseMenuOpen(open);
};
pauseMenu.addEventListener('click', (e) => e.stopPropagation());

pausePromptsItem.onclick = () => setPauseState(!st.pausedPrompts, st.pausedImages, 'menu');
pauseImagesItem.onclick  = () => setPauseState(st.pausedPrompts, !st.pausedImages, 'menu');
renderPauseBtn();   // the markup already spells out the default state; this is what keeps the two in step

/* Ends an editing pause. `anySidebarFocus` blocks schedule() outright, so every path that ends an edit
   routes through here.

   st.focusTimer is nulled rather than only cleared: the ground-truth check in renderSidebarList() guards
   on `!st.focusTimer`, and timer ids are always truthy, so a cleared-but-still-set handle disables that
   check for the rest of the session. It is the only recovery that does not need a blur event.

   `fromRender` is for the caller that runs inside renderSidebarList() and cannot re-enter it. */
function releaseSidebarFocus({ fromRender = false } = {}) {
  clearTimeout(st.focusTimer);
  st.focusTimer = null;
  st.anySidebarFocus = false;
  st.focusedPromptId = null;
  st.focusStartTime = 0;
  if (fromRender) {
    renderSidebarStatus();
    scheduleDebounced();
  } else {
    schedule();
    renderSidebar();
  }
}

function renderSidebar() {
  // Update the entire sidebar (status message + list of upcoming prompts + inflight)
  renderSidebarStatus();
  renderSidebarList();
  renderSidebarQueueActions();
  renderSidebarInflight();
  renderInfluenceChips();
}

function renderSidebarInflight() {
  const container = document.getElementById('sidebarInflight');
  const running = Object.values(st.tasksById).filter(t => t.state === 'running');
  // Change-guard: this runs on the ~100ms renderSidebar tick. Rebuilding innerHTML every time both
  // wastes work and churns the .sidebarInflightItem nodes that the provenance tooltip tracks by element
  // identity — so only rebuild when the running set (id + text + provenance icons) actually changes.
  const sig = JSON.stringify(running.map(t => {
    const p = st.prompts[t.promptId];
    return [t.promptId, p ? p.text : (t.resolvedText || '...'), provenanceIcons(p)];
  }));
  if (container.dataset.sig === sig) return;
  container.dataset.sig = sig;
  if (!running.length) {
    container.innerHTML = '';
    return;
  }
  container.innerHTML = '<div class="sidebarInflightTitle">Now Generating</div>' +
    running.map(t => {
      const p = st.prompts[t.promptId];
      const text = p ? p.text : (t.resolvedText || '...');
      const icons = provenanceIcons(p);
      const badge = icons ? '<span class="sidebarProv">' + icons + '</span> ' : '';
      const pidAttr = p ? ' data-pid="' + escapeHtml(t.promptId) + '"' : '';
      // Now one line with an ellipsis: the full text goes in a native tooltip, except on a badged row,
      // whose provenance box (showProvTip) already shows the full prompt.
      const tipAttr = icons ? '' : ' title="' + escapeHtml(text) + '"';
      return '<div class="sidebarInflightItem"' + pidAttr + tipAttr + '>' + badge + escapeHtml(text) + '</div>';
    }).join('');
}

function renderSidebarStatus() {
  const readyCount = getUntestedPrompts().filter(p => p && Date.now() >= (p.readyAt||0)).length;
  let stateKey = '';
  let why = null;

  // Order matters and mirrors the guards themselves: a full manual pause stops everything, an editing
  // pause stops everything below that, and a half-pause stops one half — so the first one that applies
  // is also the most complete explanation of why less is happening than you expected.
  if (st.paused) {
    stateKey = 'paused';
  } else if (st.anySidebarFocus) {
    stateKey = 'editing';
  } else if (st.pausedPrompts) {
    stateKey = 'paused:prompts';
  } else if (st.pausedImages) {
    stateKey = 'paused:images';
  } else if (!st.started) {
    stateKey = 'idle';
  } else if (isLeadCapReached()) {
    stateKey = 'leadcap:' + st.unseenCards.size;
  } else {
    // No pause applies, but the scheduler can still be holding back for its own reasons (warming up, all
    // cooling, ⏳, the AI busy) and "✅ N ready" over a stalled feed reads as a bug. pipelineWhy already
    // knows those reasons; the line says the first one that applies.
    // Only while nothing is generating: new prompts cool for a few seconds after each batch, and saying
    // "Waiting" over images that are still arriving (from reused prompts) reads as a stall.
    why = st.inflight > 0 ? null : pipelineWhy();
    stateKey = why && why[2] === 'warn' ? 'why:' + why[0] + ':' + why[1] : 'ready:' + readyCount;
  }

  if (sidebarStatus.dataset.stateKey === stateKey) return;
  const wasLeadCap = (sidebarStatus.dataset.stateKey || '').startsWith('leadcap:');
  sidebarStatus.dataset.stateKey = stateKey;
  // The ↓ button at the bottom of the feed names the lead-cap wait too; repaint it on the way in and out.
  if (wasLeadCap || stateKey.startsWith('leadcap:')) scheduleFeedJumpUpdate();

  if (stateKey === 'paused') {
    sidebarStatus.innerHTML = '<div class="sidebarStatusMessage danger">⏸️ ALL NEW GENERATION PAUSED</div>';
  } else if (stateKey === 'paused:prompts') {
    sidebarStatus.innerHTML = '<div class="sidebarStatusMessage warning"><div>✍️ New prompts paused · images continue</div></div>';
  } else if (stateKey === 'paused:images') {
    sidebarStatus.innerHTML = '<div class="sidebarStatusMessage warning"><div>🖼️ New images paused · prompts continue</div></div>';
  } else if (stateKey === 'editing') {
    sidebarStatus.innerHTML = '<div class="sidebarStatusMessage warning"><div>✍️ Paused while you edit</div></div>';
    const btn = document.createElement('button');
    btn.className = 'sidebarConfirmAllBtn';
    btn.textContent = 'Done editing · resume';
    // blur() runs before the release, which re-renders this banner away.
    btn.onclick = () => {
      btn.blur();
      releaseSidebarFocus();
    };
    sidebarStatus.querySelector('.sidebarStatusMessage').appendChild(btn);
  } else if (stateKey === 'idle') {
    sidebarStatus.innerHTML = '<div class="sidebarStatusMessage idle">Not started yet</div>';
  } else if (stateKey.startsWith('leadcap:')) {
    const n = st.unseenCards.size;
    sidebarStatus.innerHTML = `<div class="sidebarStatusMessage warning"><div>⏸ ${plural(n, 'unseen image')} — scroll down</div></div>`;
  } else if (stateKey.startsWith('why:')) {
    sidebarStatus.innerHTML = `<div class="sidebarStatusMessage warning"><div>⏳ ${escapeHtml(why[0])}: ${escapeHtml(why[1])}</div></div>`;
  } else {
    sidebarStatus.innerHTML = `<div class="sidebarStatusMessage">✅ ${plural(readyCount, 'prompt')} ready</div>`;
  }
}

// Delete a queued (Upcoming) prompt from the pool. Refuses a prompt that's currently claimed/generating
// (`_claimed > 0`) — the delete button is also hidden on generating rows, but re-check here since the
// button lives on a row the incremental render reuses. Removes it from both the id map and the order
// list, persists, re-renders, and nudges the scheduler so a now-thin pool tops itself back up. Returns
// true if it deleted, so the caller can drop the row node directly (renderSidebarList freezes its rebuild
// while a textarea is focused, which would otherwise leave the deleted row on screen as a ghost).
function deleteQueuedPrompt(id){
  const p = st.prompts[id];
  if (!p) return false;
  if ((p._claimed||0) > 0) return false;
  const at = st.order.indexOf(id);
  delete st.prompts[id];
  st.order = st.order.filter(x => x !== id);
  logEvent('prompt_deleted', { promptId: id, text: p.text });
  scheduleAutosave();
  renderSidebar();
  scheduleDebounced();
  showToast('Removed 1 queued prompt', { undo: () => {
    if (st.prompts[id]) return;
    st.prompts[id] = p;
    st.order.splice(Math.min(Math.max(at, 0), st.order.length), 0, id);
    logEvent('undo', { what: 'prompt_deleted', promptId: id });
    scheduleAutosave();
    renderSidebar();
  } });
  return true;
}

// A row's cooldown in whole seconds, rounded up so it never reads 0s while still waiting. It used to show
// tenths on the 100ms tick, which is a number changing ten times a second for no decision anyone makes.
function sidebarTimerText(remaining, editing) {
  if (remaining <= 0) return '✅ Ready';
  const s = Math.ceil(remaining / 1000);
  return editing ? `⏸ ${s}s (paused)` : `⏳ Ready in ${s}s`;
}

// The Upcoming header's count. Run when the set of rows changes, not on every tick.
function renderUpcomingHead(upcoming) {
  document.getElementById('sidebarUpcomingCount').textContent = String(upcoming.length);
}

function renderSidebarList() {
  // Ground-truth focus check: sync anySidebarFocus with what's actually focused. Runs on the 100ms tick
  // and is the only recovery that does not depend on a blur event.
  const activeEl = document.activeElement;
  // A collapsed sidebar counts as not-editing regardless of activeElement. Browsers move focus out of a
  // display:none subtree, but a stale one surviving there would re-arm the pause on the next tick, with
  // neither the reason nor the button that clears it on screen.
  const sidebarShown = st.sidebarVisible !== false;
  const isSidebarTA = sidebarShown && activeEl && activeEl.classList.contains('sidebarTextArea');
  // Only the Upcoming rows pause. The Add, Steer, 📏, Prefix and Suffix boxes never do.
  if (isSidebarTA && !st.anySidebarFocus) {
    st.anySidebarFocus = true;
    st.focusStartTime = Date.now();
    const item = activeEl.closest('.sidebarItem');
    if (item && item.dataset.pid) st.focusedPromptId = item.dataset.pid;
    renderSidebarStatus();
  } else if (st.anySidebarFocus && !isSidebarTA && !st.focusTimer) {
    releaseSidebarFocus({ fromRender: true });
  }

  // Use a stabilized "now" if focus is active to visually freeze timers
  const now = st.anySidebarFocus ? st.focusStartTime : Date.now();
  const untested = getUntestedPrompts();
  const upcoming = untested;

  // Incremental Update / No-flicker sync: If the set of prompt IDs hasn't changed,
  // we just update the existing DOM elements instead of clearing and rebuilding.
  // This prevents the "flash" from the 100ms redraw interval.
  const currentIds = Array.from(sidebarList.children).map(c => c.dataset.pid).join(',');
  const newIds = upcoming.map(p => p.id).join(',');

  if (newIds && currentIds === newIds && sidebarList.children.length > 0) {
    Array.from(sidebarList.children).forEach((item, idx) => {
      const p = upcoming[idx];
      if (!p) return;
      
      const ta = item.querySelector('.sidebarTextArea');
      const timerEl = item.querySelector('.sidebarTimer');
      
      const remaining = Math.max(0, (p.readyAt||0) - now);
      item.classList.toggle('cooling', remaining > 0);

      if (ta && st.focusedPromptId !== p.id) {
        // Sync text only if not currently focused
        if (ta.value !== p.text) ta.value = p.text;
      }

      if (timerEl) {
        timerEl.textContent = sidebarTimerText(remaining, st.anySidebarFocus);
      }
    });
    return;
  }

  renderUpcomingHead(upcoming);

  // If the user has focused a box, we "freeze" the list order to prevent the UI from jumping
  // around while they are typing. We still allow the timer/state updates above if IDs match.
  // _forceListRebuild is a one-shot flag set by injectPromptsFromSidebar so the newly-added
  // prompt appears immediately even though focus is held on the inject input.
  if (st.anySidebarFocus && sidebarList.children.length > 0 && !st._forceListRebuild) return;
  st._forceListRebuild = false;

  sidebarList.innerHTML = '';
  
  if (upcoming.length === 0) {
    const empty = document.createElement('div');
    empty.style.padding = '20px';
    empty.style.opacity = '0.5';
    empty.style.fontSize = '12px';
    empty.style.textAlign = 'center';
    if (!st.started) {
      empty.textContent = 'Prompts appear here after Start ▶';
    } else if (st.textGenBusy) {
      empty.textContent = 'AI is writing prompts…';
    } else if (st.suggestBusy) {
      empty.textContent = 'AI is writing your ✨ suggestion — prompts next…';
    } else {
      empty.textContent = 'Asking the AI for prompts…';
    }
    sidebarList.appendChild(empty);
    return;
  }

  upcoming.forEach(p => {
    const item = document.createElement('div');
    item.className = 'sidebarItem';
    item.dataset.pid = p.id;
    
    const remaining = Math.max(0, p.readyAt - now);
    if (remaining > 0) item.classList.add('cooling');

    const ta = document.createElement('textarea');
    ta.className = 'sidebarTextArea';
    ta.value = p.text;

    const timerEl = document.createElement('div');
    timerEl.className = 'sidebarTimer';
    timerEl.textContent = sidebarTimerText(remaining, st.anySidebarFocus);
    
    // Auto-expand helper
    const autoExpand = (el) => {
      el.style.height = 'auto';
      el.style.height = el.scrollHeight + 'px';
    };
    
    ta.onfocus = () => {
      clearTimeout(st.focusTimer);
      st.focusTimer = null;
      st.anySidebarFocus = true;
      st.focusedPromptId = p.id;
      st.focusStartTime = Date.now();
      renderSidebarStatus(); 
    };
    
    let edited = false;
    ta.onblur = () => {
      p.text = ta.value.trim();
      // Persist hand-typed wording: pool growth is deliberately not autosaved (regenerable churn), but a
      // user's edit isn't regenerable — without this, a reload before the next autosave trigger loses it.
      if (edited) { edited = false; scheduleAutosave(); }
      const focusDuration = Date.now() - st.focusStartTime;
      const BLUR_BUFFER_MS = 3000;

      // Compensate frozen time + add buffer for all prompts so user can tab between them
      getAllPrompts().forEach(pp => {
        if (pp.readyAt > st.focusStartTime) {
          pp.readyAt += focusDuration;
        }
        pp.readyAt = Math.max(pp.readyAt, Date.now() + BLUR_BUFFER_MS);
      });

      setTimeout(scheduleDebounced, BLUR_BUFFER_MS + 50);

      st.focusTimer = setTimeout(() => releaseSidebarFocus(), 50);
    };

    ta.oninput = () => {
      edited = true;
      p.text = ta.value;
      autoExpand(ta);
    };

    const actions = document.createElement('div');
    actions.className = 'sidebarActions';
    const btn = document.createElement('button');
    btn.className = 'sidebarConfirmBtn';
    btn.textContent = 'Done';
    btn.title = 'Finish editing this prompt (or click anywhere else)';
    btn.onclick = () => { ta.blur(); btn.blur(); };

    // Provenance badge (origin + influenced + stale). Absolute top-right sibling so it never sits over
    // the textarea and is untouched by the zero-flicker incremental render (which only rewrites the
    // timer/text). Set once here in the full-rebuild branch — an Upcoming row's provenance is immutable
    // for its lifetime (stale ⇒ filtered out of getUntestedPrompts ⇒ the row is gone, not re-badged).
    const provIcons = provenanceIcons(p);
    if (provIcons) {
      const provEl = document.createElement('span');
      provEl.className = 'sidebarProv';
      provEl.dataset.pid = p.id;
      provEl.textContent = provIcons;
      item.appendChild(provEl);
    }

    // Delete affordance: a hover-revealed ✕ pinned top-right (absolute sibling like the prov badge, so
    // it never sits in the textarea flow). On hover the prov badge shifts left to make room (CSS).
    // deleteQueuedPrompt re-checks the claimed guard, covering a row gone stale during a focus freeze.
    // stopPropagation on mousedown so clicking it never steals focus from / blurs the textarea.
    const delBtn = document.createElement('button');
    delBtn.className = 'sidebarDeleteBtn';
    delBtn.type = 'button';
    delBtn.textContent = '✕';
    delBtn.title = 'Delete this queued prompt';
    delBtn.onmousedown = (e) => { e.stopPropagation(); e.preventDefault(); };
    delBtn.onclick = (e) => { e.stopPropagation(); if (deleteQueuedPrompt(p.id)) item.remove(); };
    item.appendChild(delBtn);

    item.appendChild(timerEl);
    item.appendChild(ta);
    actions.appendChild(btn);
    item.appendChild(actions);
    sidebarList.appendChild(item);
    
    // Initial expand
    setTimeout(() => autoExpand(ta), 0);
  });
}

// Bulk-clear the visible Upcoming queue. `getUntestedPrompts()` is exactly the rows shown in the sidebar
// (effUsed===0 ⇒ excludes claimed/generating and already-used prompts, plus current-version & non-stale),
// so clearing it matches what the user sees. keepSteered spares rows carrying the 🧲 Influenced flag and
// keepManual the ✏️ hand-written ones.
// Mirrors deleteQueuedPrompt's bookkeeping (drop from st.prompts + st.order, persist, re-render, nudge the
// scheduler) but in one batch, and forces a list rebuild so the emptied list repaints even mid-edit-focus.
//
// The two sets a bulk clear can spare, as one predicate. 🧲 and ✏️ are disjoint by construction —
// addPrompts() never inherits p.influenced, and the only writer of it is the steer taint on a generated
// batch — but this is written as "kept if EITHER flag protects it" rather than as an either/or, so if that
// invariant ever breaks the behaviour degrades to keeping the prompt rather than deleting it.
// Pure and DOM-free on purpose: it and queueClearPlan() are what make this whole feature testable in node.
function promptSpared(p, { keepSteered, keepManual } = {}) {
  return !!((keepSteered && p.influenced) || (keepManual && p.origin === 'manual'));
}

// Does this prompt survive an instruction Apply, under "Keep unused prompts on instruction change"?
// 0 = Off (nothing), 1 = Keep all unused, 2 = Keep only the unused ones you put there yourself.
// The modes nest, which is what makes the segmented control explainable: 0 ⊂ 2 ⊂ 1.
//
// effUsed===0 gates every mode, including 2: it excludes an IN-FLIGHT prompt whose running image was
// built against the OLD instruction, so re-versioning it would smear provenance. Lives here beside
// promptSpared() rather than inline in applyInstructionChange() so the two "what counts as yours"
// decisions in this app are one definition and can be tested together.
function keepPromptOnVersionChange(p, mode) {
  if (effUsed(p) !== 0) return false;
  if (mode === 1) return true;
  if (mode === 2) return promptSpared(p, { keepSteered: true, keepManual: true });
  return false;
}
function clearQueuedPrompts({ keepSteered, keepManual } = {}) {
  const targets = getUntestedPrompts().filter(p => !promptSpared(p, { keepSteered, keepManual }));
  if (!targets.length) return 0;
  const ids = new Set(targets.map(p => p.id));
  ids.forEach(id => { delete st.prompts[id]; });
  st.order = st.order.filter(x => !ids.has(x));
  st._forceListRebuild = true;
  logEvent('prompts_cleared', { count: ids.size, keepSteered: !!keepSteered, keepManual: !!keepManual });
  scheduleAutosave();
  renderSidebar();
  scheduleDebounced();
  return ids.size;
}

/* ===================== showToast — the app's one toast =====================
   One message at a time, bottom centre, above every overlay. Used for what happens out of sight: an
   Undo after a single removal (D1 of the usability overhaul), a failure that used to go only to the
   console or an alert(), and the result of an action whose dialog has already closed. Successes the eye
   is already on keep their in-button flashes ("Copied!") instead.

   A new toast replaces the old one. If the old one offered Undo, that offer simply lapses — the removal
   it would have undone stands, the same as letting it time out. Hovering holds it open. */
let _toast = null;

function showToast(msg, { undo, action, kind, ms } = {}) {
  hideToast();
  const el = document.createElement('div');
  el.className = 'ipoToast' + (kind === 'error' ? ' ipoToastErr' : '');
  el.setAttribute('role', kind === 'error' ? 'alert' : 'status');
  const text = document.createElement('span');
  text.className = 'ipoToastText';
  text.textContent = msg;
  el.appendChild(text);
  const t = { el, timer: null };
  const addBtn = (label, fn) => {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'ipoToastBtn';
    b.textContent = label;
    b.onclick = () => { hideToast(); fn(); };
    el.appendChild(b);
  };
  if (undo) addBtn('Undo', undo);
  if (action) addBtn(action.label, action.onClick);
  const x = document.createElement('button');
  x.type = 'button';
  x.className = 'ipoToastX';
  x.textContent = '✕';
  x.title = 'Dismiss';
  x.setAttribute('aria-label', 'Dismiss');
  x.onclick = () => hideToast();
  el.appendChild(x);
  document.body.appendChild(el);
  const dur = ms ?? (undo || action ? 8000 : kind === 'error' ? 7000 : 4000);
  const arm = (d) => { clearTimeout(t.timer); t.timer = setTimeout(() => { if (_toast === t) hideToast(); }, d); };
  el.addEventListener('mouseenter', () => clearTimeout(t.timer));
  el.addEventListener('mouseleave', () => arm(2500));
  arm(dur);
  _toast = t;
}

function hideToast() {
  if (!_toast) return;
  clearTimeout(_toast.timer);
  _toast.el.remove();
  _toast = null;
}

// "1 prompt" / "3 prompts" — the counts in toasts and confirms read as people would say them.
function plural(n, word) { return `${n} ${word}${n === 1 ? '' : 's'}`; }

/* ===================== confirmChoice — the app's one custom dialog =====================
   A confirm() with up to three outcomes: 'cancel' | 'ok' | 'extra'. Built for the queue clear, and now
   every confirmation in the app (the native confirm() is no longer used anywhere); nothing here knows
   about prompts.

   Why a custom one at all: confirm() has exactly two answers, and this needs three. The cost is that
   confirm() also happens to FREEZE the app (it blocks the main thread, so no timer, no scheduler tick,
   no batch lands while it's up) and this doesn't — hence `refresh`, which lets a caller keep the text
   honest while the world moves behind it.

   Only one can be open at a time; opening a second resolves the first as a cancel.

   `input` turns it into a one-field form (the session-name dialogs): { value, placeholder, validate }.
   validate(text) returns an error to show under the field, or ''; the default button stays off while
   there's an error or the field is empty, and Enter in the field presses it. On 'ok' the trimmed text is
   written back to input.value. `danger` paints the default button red, for answers that delete. */
let _cchoice = null;

function confirmChoice({ title, body, okLabel, extraLabel, okDisabled, refresh, input, danger }) {
  return new Promise(resolve => {
    confirmChoiceClose('cancel');   // singleton

    const back = document.createElement('div');
    back.className = 'cchoiceBack';
    back.innerHTML = `<div class="cchoicePanel" role="dialog" aria-modal="true" aria-labelledby="cchoiceTitle" aria-describedby="cchoiceBody">
      <div class="cchoiceTitle" id="cchoiceTitle"></div>
      <div class="cchoiceBody" id="cchoiceBody"></div>
      <div class="cchoiceRow">
        <button type="button" class="cchoiceBtn" data-act="cancel">Cancel</button>
        <button type="button" class="cchoiceBtn cchoiceOk" data-act="ok"></button>
      </div>
    </div>`;
    back.querySelector('.cchoiceTitle').textContent = title;
    back.querySelector('.cchoiceBody').textContent = body || '';
    back.querySelector('[data-act="ok"]').textContent = okLabel;
    if (danger) back.querySelector('[data-act="ok"]').classList.add('cchoiceDanger');
    let field = null, errEl = null;
    if (input) {
      field = document.createElement('input');
      field.type = 'text';
      field.className = 'cchoiceInput';
      field.value = input.value || '';
      if (input.placeholder) field.placeholder = input.placeholder;
      errEl = document.createElement('div');
      errEl.className = 'cchoiceErr';
      const row = back.querySelector('.cchoiceRow');
      row.parentNode.insertBefore(field, row);
      row.parentNode.insertBefore(errEl, row);
    }
    document.body.appendChild(back);

    const state = {
      back, resolve, refresh,
      row: back.querySelector('.cchoiceRow'),
      bodyEl: back.querySelector('.cchoiceBody'),
      okBtn: back.querySelector('[data-act="ok"]'),
      extraBtn: null,
      prevFocus: document.activeElement,
      sig: '',
      input, field
    };
    _cchoice = state;
    confirmChoiceSetExtra(extraLabel);
    confirmChoiceSetOkDisabled(okDisabled);
    if (field) {
      const check = () => {
        const err = input.validate ? input.validate(field.value.trim()) : '';
        errEl.textContent = err;
        confirmChoiceSetOkDisabled(!!err || !field.value.trim());
      };
      field.addEventListener('input', check);
      field.addEventListener('keydown', e => {
        if (e.key === 'Enter' && !e.isComposing && e.keyCode !== 229) { e.preventDefault(); if (!state.okBtn.disabled) confirmChoiceClose('ok'); }
      });
      check();
    }
    // Seed the refresh change-guard with what was just rendered, so the first tick after opening is a
    // no-op instead of rewriting the same three strings.
    state.sig = confirmChoiceSig({ body, okLabel, extraLabel, okDisabled });

    back.addEventListener('click', e => {
      const b = e.target.closest && e.target.closest('.cchoiceBtn');
      if (b) { confirmChoiceClose(b.dataset.act); return; }
      if (e.target === back) confirmChoiceClose('cancel');   // backdrop, not the panel
    });

    // Capture phase + stopImmediatePropagation so Esc means "cancel this dialog" and only that, rather
    // than also reaching the global Escape chain further down the file. Nothing that chain handles can
    // currently be open at the same time (the pointerdown that opened this dialog dismissed the ❓ panel
    // and the toolbar popovers on its way), so this is insurance — but it makes the guarantee structural
    // instead of a standing survey of what else happens to be closed.
    state.onKey = e => {
      if (e.key === 'Escape') { e.stopImmediatePropagation(); e.preventDefault(); confirmChoiceClose('cancel'); return; }
      if (e.key !== 'Tab') return;
      // :not(:disabled) — a dead default button must drop out of the ring rather than being a stop that
      // does nothing when you press Enter on it.
      const f = Array.from(back.querySelectorAll('.cchoiceInput, .cchoiceBtn:not(:disabled)'));
      if (!f.length) return;
      const i = f.indexOf(document.activeElement);
      const next = e.shiftKey ? (i <= 0 ? f.length - 1 : i - 1) : (i === f.length - 1 || i === -1 ? 0 : i + 1);
      e.preventDefault();
      f[next].focus();
    };
    document.addEventListener('keydown', state.onKey, true);

    // Focus the default (not Cancel, not the escalation): Enter then means the ordinary clear. A form
    // focuses its field instead, with the text selected so typing replaces the suggestion.
    if (field) { field.focus(); field.select(); }
    else confirmChoiceFocusDefault();
  });
}

// Where focus belongs right now: the default action, or the next live button along if it has gone dead.
// Never a disabled one — Enter on it would resolve nothing and close the dialog on a press that read as
// an instruction.
function confirmChoiceFocusDefault() {
  const s = _cchoice;
  if (!s) return;
  const btn = !s.okBtn.disabled ? s.okBtn
    : (s.extraBtn || s.back.querySelector('[data-act="cancel"]'));
  if (btn) btn.focus();
}

// The default action can lose its target while the dialog is open — this one doesn't block the main
// thread, so the scheduler can claim the very prompts it offered to remove. Disabled rather than closed:
// the escalation below it may still have work to do, and the caller's refresh returning null is the
// "nothing left for either button" exit.
function confirmChoiceSetOkDisabled(disabled) {
  const s = _cchoice;
  if (!s) return;
  const hadFocus = document.activeElement === s.okBtn;
  s.okBtn.disabled = !!disabled;
  if (disabled && hadFocus) confirmChoiceFocusDefault();
}

function confirmChoiceSig({ body, okLabel, extraLabel, okDisabled }) {
  return body + '\u0000' + okLabel + '\u0000' + (extraLabel || '') + '\u0000' + (okDisabled ? '1' : '0');
}

// Add, relabel or remove the third button. Rebuilt rather than hidden so a removed one can't be tabbed
// to, and so the row's spacing is right with two buttons or three. It goes in the middle, between Cancel
// and the default, so the default action always sits rightmost.
function confirmChoiceSetExtra(label) {
  const s = _cchoice;
  if (!s) return;
  if (!label) {
    if (s.extraBtn) {
      // Don't strand focus on a button that's about to vanish.
      if (document.activeElement === s.extraBtn) s.okBtn.focus();
      s.extraBtn.remove();
      s.extraBtn = null;
    }
    return;
  }
  if (!s.extraBtn) {
    s.extraBtn = document.createElement('button');
    s.extraBtn.type = 'button';
    s.extraBtn.className = 'cchoiceBtn cchoiceExtra';
    s.extraBtn.dataset.act = 'extra';
    s.row.insertBefore(s.extraBtn, s.okBtn);
  }
  s.extraBtn.textContent = label;
}

// Called from the sidebar tick. Re-asks the caller what the dialog should say now, and rewrites it if
// anything moved. A null answer means there is nothing left for either button to do, so the dialog
// closes as a cancel rather than sitting there offering an empty action.
//
// `ctx` is passed straight through to the caller's refresh, opaque to this dialog like everything else
// here. It lets the tick hand over work it has already done rather than making the callback recompute it.
//
// okDisabled travels with the labels, because the two go out of date together: a refresh that relabels
// the default button without re-answering whether it can still act leaves a live, focused button reading
// "Clear (-0)".
function confirmChoiceRefresh(ctx) {
  const s = _cchoice;
  if (!s || !s.refresh) return;
  const next = s.refresh(ctx);
  if (!next) { confirmChoiceClose('cancel'); return; }
  const sig = confirmChoiceSig(next);
  if (sig === s.sig) return;
  s.sig = sig;
  s.bodyEl.textContent = next.body;
  s.okBtn.textContent = next.okLabel;
  confirmChoiceSetExtra(next.extraLabel);   // before the disable, so focus can land on a live escalation
  confirmChoiceSetOkDisabled(next.okDisabled);
}

function confirmChoiceClose(act) {
  const s = _cchoice;
  if (!s) return;
  _cchoice = null;
  if (s.input && s.field && act === 'ok') s.input.value = s.field.value.trim();
  document.removeEventListener('keydown', s.onKey, true);
  s.back.remove();
  if (s.prevFocus && s.prevFocus.isConnected && !s.prevFocus.disabled) {
    try { s.prevFocus.focus(); } catch (e) {}
  }
  s.resolve(act || 'cancel');
}

// The one way to name a session: Save as…, Force save, Rename, naming the recovery slot. The clash is
// shown under the field as you type rather than after an OK, and a taken name can't be confirmed at all —
// saving under one would silently overwrite that session. `keep` is the session's own current name
// (Rename), which isn't a clash with itself. Resolves to the name, or null if cancelled.
async function askSessionName({ title, body, value, okLabel = 'Save', keep = null }) {
  const taken = new Set(await getSessionKeys());
  taken.add(AUTOSAVE_SLOT);
  taken.add('current');
  if (keep) taken.delete(keep);
  const input = {
    value,
    placeholder: 'Session name',
    validate: v => taken.has(v) ? `A saved session is already called "${v}" — pick another name.` : ''
  };
  const act = await confirmChoice({ title, body, okLabel, input });
  return act === 'ok' ? input.value : null;
}

// Every string and every enable/disable decision for the "Keep 🧲 steered + ✏️ yours" button and its dialog, as
// one pure function of three counts. Pure and DOM-free so the whole wording matrix is testable in node —
// this is the only way to check it without a browser, and there are more cases here than read at a glance.
//
//   rest    prompts that are neither 🧲 steered nor ✏️ hand-written (plain AI generations, ⭐ captures)
//   steered p.influenced
//   manual  p.origin === 'manual'
//
// The default action removes `rest`; the escalation additionally removes `manual`, so its count is
// rest+manual — the true total it takes. Counting only `manual` there would badly understate it.
function queueClearPlan({ rest, steered, manual }) {
  const s = n => n === 1 ? '' : 's';
  const rTxt = `${rest} queued prompt${s(rest)}`;
  // Disabled only when the default action has nothing to remove. That's the one honest disable and it
  // can't go stale on the user: a 🧲 or ✏️ prompt appearing never changes `rest`. The consequence is
  // accepted — with a queue of nothing but 🧲 and ✏️ the escalation is unreachable from here, and the
  // per-row ✕ or "Clear all" is the way. A live button whose label reads (0) would be the worse trade.
  const disabled = rest === 0;

  let title;
  if (disabled)      title = 'Nothing but 🧲 and ✏️ prompts to remove';
  else {
    const keeps = [steered ? `${steered} 🧲 steered` : null, manual ? `${manual} ✏️ hand-written` : null]
      .filter(Boolean).join(' and ');
    title = (keeps
      ? `Remove ${rTxt}, keeping the ${keeps}`
      : `Remove ${rTxt} — nothing is 🧲 steered or ✏️ hand-written right now`)
      + '. ⭐ prompts captured from a like go too.';
  }

  // The body always says what SURVIVES, because that's the half the old confirm never mentioned for ✏️.
  // When a set is empty it's named as empty rather than omitted: "nothing is steered right now" is the
  // fact that turns this click into Clear-all-by-another-name, and the user has to know before agreeing.
  let body;
  if (disabled) {
    // Only the live refresh gets here: the dialog opened on a real `rest` that the scheduler then claimed
    // while it sat there (this dialog doesn't block the main thread, unlike the confirm() it replaced).
    // The default button is dead in this state, so the body stops describing that action and says what
    // happened instead — otherwise it reads "Clear 0 queued prompts, keeping the 2 ✏️ hand-written?".
    const keeps = [steered ? `${steered} 🧲 steered` : null, manual ? `${manual} ✏️ hand-written` : null]
      .filter(Boolean).join(' and ');
    body = keeps
      ? `Those prompts are gone already — only the ${keeps} ${steered + manual === 1 ? 'is' : 'are'} left.`
      : 'The queue is already empty.';
    if (manual) body += ` Clearing the ✏️ hand-written ones too would ${steered ? `leave just the ${steered} 🧲 steered` : 'empty the queue'}.`;
  }
  else if (steered && manual)  body = `Clear ${rTxt}, keeping the ${steered} 🧲 steered and ${manual} ✏️ hand-written?`;
  else if (steered)            body = `Clear ${rTxt}, keeping the ${steered} 🧲 steered? Nothing is ✏️ hand-written right now.`;
  else if (manual)             body = `Clear ${rTxt}, keeping the ${manual} ✏️ hand-written? Nothing is 🧲 steered right now, so clearing the hand-written ones too would empty the queue.`;
  else                         body = `Clear ${rTxt}? Nothing is 🧲 steered or ✏️ hand-written right now, so this clears the whole queue.`;
  // Only where a button can still act on it. A dead dialog warning that something can't be undone is
  // describing nothing.
  if (!disabled || manual) body += " This can't be undone.";

  return {
    disabled, title,
    // Counts carry a minus: they're what the click takes away from the queue.
    label: `Keep 🧲 steered + ✏️ yours (−${rest})`,
    dialog: {
      title: 'Clear the queue?',
      body,
      okLabel: `Clear (−${rest})`,
      // `disabled` rides into the dialog as well as onto the sidebar button: an open dialog can reach
      // rest === 0 while the escalation still has ✏️ prompts to take, and a live "Clear (-0)" sitting
      // focused under Enter is a button that answers a keypress by doing nothing.
      okDisabled: disabled,
      // Omitted, not disabled, when there is nothing to escalate to.
      extraLabel: manual ? `Clear ✏️ too (−${rest + manual})` : null
    }
  };
}

// Footer action bar under the Upcoming list: two bulk-clear buttons whose labels/counts refresh on each
// sidebar tick. Handlers are wired once (dataset guard) since the buttons are static HTML. The whole bar
// hides when the queue is empty.
//
// Both go through confirmChoice(), which — unlike the native confirm() "Clear all" used to use — doesn't
// block the main thread, so prompts can arrive or be claimed while it is open. That's why the tick below
// re-renders an open dialog rather than leaving it quoting stale numbers. The action itself is always
// correct either way: clearQueuedPrompts() re-filters the live queue.
function renderSidebarQueueActions() {
  const wrap = document.getElementById('sidebarQueueActions');
  if (!wrap) return;
  const clearAllBtn = document.getElementById('clearQueueBtn');
  const clearNonBtn = document.getElementById('clearNonSteeredBtn');

  if (!wrap.dataset.wired) {
    wrap.dataset.wired = '1';
    clearAllBtn.onclick = async () => {
      const ask = () => {
        const n = getUntestedPrompts().length;
        return n ? { body: `All ${plural(n, 'queued prompt')} go, including your ✏️ and 🧲 ones. This can't be undone.`,
                     okLabel: `Clear all (−${n})` } : null;
      };
      const first = ask();
      if (!first) return;
      const act = await confirmChoice({ title: 'Clear the whole queue?', ...first, danger: true, refresh: ask });
      if (act === 'ok') clearQueuedPrompts({ keepSteered: false, keepManual: false });
    };
    clearNonBtn.onclick = async () => {
      // Recomputed at click time (not read off the last tick) so a 🧲 or ✏️ prompt that landed a
      // split-second before the press is already spared by the numbers the dialog quotes.
      const plan = queueClearPlan(queueClearCounts());
      if (plan.disabled) return;
      const choice = await confirmChoice({
        title: plan.dialog.title, body: plan.dialog.body,
        okLabel: plan.dialog.okLabel, extraLabel: plan.dialog.extraLabel,
        okDisabled: plan.dialog.okDisabled,
        // Live-refresh: called on each sidebar tick while the dialog is open. Returning null closes it
        // as a cancel — that's the "everything it could have removed is gone already" case. `c` is the
        // tick's own counts handed down rather than a fourth walk of the queue; the fallback covers a
        // caller that refreshes outside the tick.
        refresh: (c) => {
          c = c || queueClearCounts();
          if (c.rest === 0 && c.manual === 0) return null;
          const p = queueClearPlan(c);
          return { body: p.dialog.body, okLabel: p.dialog.okLabel,
                   extraLabel: p.dialog.extraLabel, okDisabled: p.dialog.okDisabled };
        }
      });
      if (choice === 'ok')         clearQueuedPrompts({ keepSteered: true, keepManual: true });
      else if (choice === 'extra') clearQueuedPrompts({ keepSteered: true, keepManual: false });
    };
  }

  // Counted ONCE per tick and handed to everything that needs the numbers. This runs ten times a second
  // and an open dialog asks for the same answer again, so a queue of a few thousand prompts was being
  // walked four or five times per tick to label two buttons.
  const counts = queueClearCounts();
  const { total, rest, steered, manual } = counts;

  // Change-guard: this runs on the ~100ms sidebar tick, so skip the DOM writes unless the counts moved
  // (also avoids toggling `disabled` out from under a keyboard-focused button every frame). An open
  // dialog is refreshed OUTSIDE the guard's early return, since its text tracks counts the guard may
  // consider unchanged for the buttons (rest steady while manual moves, say).
  confirmChoiceRefresh(counts);

  const sig = total + '/' + steered + '/' + manual;
  if (wrap.dataset.sig === sig) return;
  wrap.dataset.sig = sig;

  if (total === 0) { wrap.style.display = 'none'; return; }
  wrap.style.display = 'flex';

  clearAllBtn.textContent = `Clear all (−${total})`;
  clearAllBtn.title = `Remove all ${total} queued prompt${total === 1 ? '' : 's'}`;

  const plan = queueClearPlan({ rest, steered, manual });
  clearNonBtn.textContent = plan.label;
  clearNonBtn.disabled = plan.disabled;
  clearNonBtn.title = plan.title;
}

// The three counts queueClearPlan() takes, off the live queue. 🧲 and ✏️ are disjoint (see promptSpared),
// so rest = total - steered - manual holds without a third pass.
//
// One walk, not three. Called from the ~100ms sidebar tick, where two .filter() passes over a
// few-thousand-prompt session on top of getUntestedPrompts()'s own map+filter is tens of thousands of
// predicate calls a second to produce two button labels.
function queueClearCounts() {
  let total = 0, steered = 0, manual = 0;
  for (const p of getUntestedPrompts()) {
    total++;
    if (p.influenced) steered++;
    else if (p.origin === 'manual') manual++;
  }
  return { total, steered, manual, rest: total - steered - manual };
}

/* Gallery + save animation */
let gallery = null;
function ensureGallery() { if (!gallery && typeof createMediaGallery === 'function') gallery = createMediaGallery(); return gallery; }
function animateImageIntoTarget({imgEl, sourceEl, targetEl, durationMs, wiggle}={}) {
  const srcRect = sourceEl.getBoundingClientRect()
  let tgtRect = targetEl.getBoundingClientRect();
  imgEl.style.cssText = `position:fixed;top:${srcRect.top}px;left:${srcRect.left}px;width:${srcRect.width}px;height:${srcRect.height}px;margin:0;pointer-events:none;z-index:9999;transition:top ${durationMs}ms cubic-bezier(.4,0,.2,1),left ${durationMs}ms cubic-bezier(.4,0,.2,1),width ${durationMs}ms cubic-bezier(.4,0,.2,1),height ${durationMs}ms cubic-bezier(.4,0,.2,1)`;
  if (!imgEl.parentNode) document.body.appendChild(imgEl);
  imgEl.getBoundingClientRect();
  imgEl.style.top = tgtRect.top + tgtRect.height / 2 + 'px';
  imgEl.style.left = tgtRect.left + tgtRect.width / 2 + 'px';
  imgEl.style.width = imgEl.style.height = '0px';
  
  imgEl.addEventListener('transitionend', () => {
    imgEl.remove();
    if (!wiggle) return;
    const anim = 'wiggle' + Math.random().toString(36).slice(2);
    const styleEl = Object.assign(document.createElement('style'), {
      id: anim,
      textContent: `@keyframes ${anim}{0%,100%{transform:rotate(0deg)}20%{transform:rotate(-5deg)}40%{transform:rotate(5deg)}60%{transform:rotate(-3deg)}80%{transform:rotate(3deg)}}`
    });
    document.head.appendChild(styleEl);
    targetEl.style.animation = `${anim} 400ms ease-in-out`;
    targetEl.addEventListener('animationend', () => { targetEl.style.animation = ''; styleEl.remove(); }, { once: true });
  }, { once: true });
}

/* ===================== Show/hide main views ===================== */

// 🌳 Tree joins the pre-Start disabled set rather than hiding: it stays discoverable, but there is no
// instruction history until Start writes v1, so opening it early would center on an empty version
// reading "(instruction text not recorded)".
// Greyed before Start, but still hoverable so the title can say why — .tbtn.disabled no longer sets
// pointer-events:none, so each of these onclicks checks st.started itself (Tab+Enter got through anyway).
// A button's own title is kept in data-ready-title and put back once started.
const TOOLBAR_NEEDS_START = 'Available after you press Start ▶';
function updateToolbarState() {
  const btns = [showPromptsBtn, showTreeBtn, pauseBtn, pauseMenuBtn];
  btns.forEach(btn => {
    if (!btn) return;
    if (btn.dataset.readyTitle === undefined) btn.dataset.readyTitle = btn.title;
    btn.classList.toggle('disabled', !st.started);
    btn.setAttribute('aria-disabled', String(!st.started));
    btn.title = st.started ? btn.dataset.readyTitle : TOOLBAR_NEEDS_START;
  });
  renderSaveChip();
}

function showReadyState() {
  const feedPlaceholder = document.getElementById('feedPlaceholder');
  const resumePanel = document.getElementById('resumePanel');
  const instWrap = document.getElementById('instWrap');
  if (feedPlaceholder) feedPlaceholder.style.display = 'flex';
  if (resumePanel) resumePanel.style.display = 'none';
  if (instWrap) instWrap.classList.remove('started');
  updateToolbarState();
}

function showStartedState() {
  const feedPlaceholder = document.getElementById('feedPlaceholder');
  const resumePanel = document.getElementById('resumePanel');
  const instWrap = document.getElementById('instWrap');
  if (feedPlaceholder) feedPlaceholder.style.display = 'none';
  if (resumePanel) resumePanel.style.display = 'none';
  if (instWrap) instWrap.classList.add('started');
  updateToolbarState();
  updateInfluencesBtn();   // the button is disabled until Start, so Start has to repaint it
  updateInstDirty();       // the "vN · in use" tag appears with Start
}

/* ===================== Start button ===================== */

// An empty instruction would start a run that never writes a prompt (ensureQueue waits on one), with
// nothing on screen saying why — so Start refuses and says what's missing.
const instEmptyMsg = document.getElementById('instEmptyMsg');
instInput.addEventListener('input', () => { instEmptyMsg.style.display = 'none'; });

// The recovery slot holds the last run that was never named. Nothing lists it in 📂, and the new run's
// first autosave would overwrite it two seconds after Start — so if it holds anything, ask first. The
// safe answer (keep it, under a name) is the default button.
async function settleAutosaveSlotBeforeStart() {
  const slot = st.autosaveSlot;
  const nImg = slot?.images?.length || 0, nPr = slot?.order?.length || 0;
  if (!nImg && !nPr) return true;
  const act = await confirmChoice({
    title: 'Keep your unsaved run?',
    body: `Your last run was never named (${plural(nImg, 'liked image')}, ${plural(nPr, 'prompt')}). Starting a new one replaces it.`,
    okLabel: 'Name & keep it…', extraLabel: 'Discard it'
  });
  if (act === 'cancel') return false;
  if (act === 'extra') {
    await deleteAutosaveSlot();
    logEvent('autosave_slot_discarded', { images: nImg, prompts: nPr });
    return true;
  }
  const meta = slot.meta || {};
  const name = await askSessionName({ title: 'Name your last run',
    value: (meta.instruction || '').slice(0, 40).trim() || `Session – ${new Date(meta.savedAt || Date.now()).toLocaleDateString()}` });
  if (!name) return false;
  await renameSession(AUTOSAVE_SLOT, name);
  st.autosaveSlot = null;
  st.hasSavedSessions = true;
  noteLatestSession(name);
  logEvent('autosave_slot_named', { images: nImg, prompts: nPr });
  showToast(`Kept your last run as "${name}" — in 📂 All sessions`);
  return true;
}

startBtn.onclick = async ()=>{
  if (!instInput.value.trim()) {
    instEmptyMsg.style.display = 'block';
    instInput.focus();
    return;
  }
  if (startBtn.dataset.busy) return;
  startBtn.dataset.busy = '1';
  try { if (!(await settleAutosaveSlotBeforeStart())) return; }
  finally { delete startBtn.dataset.busy; }
  st.instruction = instInput.value.trim();
  localStorage.setItem('instruction', st.instruction);
  st.instHistory[st.instVersion] = st.instruction;   // v1 baseline, so the first generation is traceable too
  st.started = true; /* gate lifted only after Start */
  // The pipeline averages span "since the buffers started collecting", and nothing collects before Start.
  // Stamped at page load, that span counted the time you spent reading the help overlay or picking a
  // session: press Start after twenty-five minutes of that and the first image reported "1 image in the
  // last 20m" eight seconds into the run. Restore re-stamps for the same reason (restoreSessionBody).
  st.timingsSince = Date.now();
  logEvent('start', { instructionLength: st.instruction.length });
  showStartedState();
  updateSessionButtons();
  ensureQueue();
  schedule();
};

/* ===================== Save indicator ===================== */

function setSaved() { instSpinner.style.display='none'; instTick.style.display='flex'; }

/* ===================== 🔖 Marked influences =====================
   Images you bookmark while browsing, to reread side by side while you rewrite your instruction. When
   the edit lands, the marked set is recorded permanently as EXTRA PARENTS of the version it created,
   and the 🌳 tree draws them above that version alongside the previous one.

   Strictly an authoring aid: marking sends nothing to the LLM, prioritises no prompt, changes no
   selection. That is the whole difference from the 🧲 theme steer (st.influenceQueue / p.influenced),
   which shares the word "influence" but genuinely reshapes the next brainstorm batch. The one place the
   marked wording reaches the AI is the panel's ✨ AI help column, and only when you press Ask — it drafts an
   instruction for you to copy or ignore, and generation stays untouched until you apply something.

   Identity is the IMAGE, not the prompt. Two images of one prompt keep two records — their {a|b} picks
   usually differ and that difference is exactly what you're comparing. Each record carries both handles:
   taskId is the live one, cacheId the durable one, because a restored card mints a fresh task id and
   only cacheId is written into the save. Every lookup therefore tries both.

   🚫 ANTI-INFLUENCES are the same records with `anti: true` — an image that shows you what you DON'T
   want. Same page, same count, same commit, and just as inert: "anti" is your reaction to the image, not
   something the app does with it. They share the lists rather than having their own so that an image can
   only be pending as ONE kind — marking the other kind flips the record in place — which two lists could
   only enforce with a cross-check at every write. Across versions the kinds are independent: an image can
   be a 🔖 for v3 and a 🚫 for v5. Every reader that means one kind filters on !!rec.anti. */

// The live task behind a record, or null once that image has left the feed. Committed records are
// allowed to outlive their image — the panel and the tree fall back to the stored text.
function infTaskOf(rec, index) {
  if (!rec) return null;
  if (rec.taskId && st.tasksById[rec.taskId]) return st.tasksById[rec.taskId];
  if (rec.cacheId == null) return null;
  if (index) {
    const hit = index.get(rec.cacheId) || null;
    if (hit) rec.taskId = hit.id;
    return hit;
  }
  for (const tid in st.tasksById) {
    const t = st.tasksById[tid];
    if (t && t.cacheId === rec.cacheId) { rec.taskId = tid; return t; }   // rebind so the next call is O(1)
  }
  return null;
}

// Pass this to infTaskOf whenever you're resolving a WHOLE LIST of records. The rebind above only makes
// the next call cheap for records that HIT; a record whose image is gone (trimmed, or an unliked tile
// this load didn't restore) has nothing to cache and pays the full scan every single time. Without an
// index that makes list-wide resolution O(records × tasks) — and infSerialize does exactly that on every
// autosave, over every committed version, which is the hottest periodic path in the app.
function infCacheIndex() {
  const m = new Map();
  for (const tid in st.tasksById) {
    const t = st.tasksById[tid];
    if (t && t.cacheId != null && !m.has(t.cacheId)) m.set(t.cacheId, t);
  }
  return m;
}

// Every mark record, flat: the pending list then each committed version's list. Takes the two lists
// rather than reading st, so a saved session's meta walks the same way. Skips null holes.
function infAllRecords(pending, committed) {
  const out = [];
  if (Array.isArray(pending)) for (const r of pending) if (r) out.push(r);
  if (committed && typeof committed === 'object') {
    for (const v in committed) if (Array.isArray(committed[v])) for (const r of committed[v]) if (r) out.push(r);
  }
  return out;
}

// The same two-key test from the other end: does this record name this image?
function infMatches(rec, task) {
  if (!rec || !task) return false;
  if (rec.taskId && rec.taskId === task.id) return true;
  return rec.cacheId != null && rec.cacheId === task.cacheId;
}

// The image's one pending record, of either kind (the lists hold at most one per image — see above).
function infPendingIndex(task) { return st.markedInfluences.findIndex(r => infMatches(r, task)); }
// Pending as THIS kind — false for the other one, which is what lets the two ❓ buttons light separately.
function infIsMarked(task, anti) {
  const i = infPendingIndex(task);
  return i >= 0 && !!st.markedInfluences[i].anti === !!anti;
}

// Instruction versions this image was committed to as this kind, ascending. Permanent — "this image
// influenced v3" stays true forever — so it's reported as history rather than a state you can toggle off.
function infCommittedVersions(task, anti) {
  const out = [];
  for (const v in st.instInfluences) {
    if ((st.instInfluences[v] || []).some(r => !!r.anti === !!anti && infMatches(r, task))) out.push(Number(v));
  }
  return out.sort((a, b) => a - b);
}

// Either state earns the tile the kind's glyph: pending because you're about to use it, committed because
// you did. Asked per kind, because an image committed as a 🔖 can later be marked 🚫 and carries both.
function infFlagged(task, anti) {
  return !!task && (infIsMarked(task, anti) || infCommittedVersions(task, anti).length > 0);
}

// Three outcomes, because the image's pending record can already exist as either kind: none → add this
// kind; this kind → remove it; the OTHER kind → flip it in place, keeping its position in the list.
function infToggleMark(task, anti) {
  if (!task) return false;
  anti = !!anti;
  const i = infPendingIndex(task);
  const markedEvent = anti ? 'anti_influence_marked' : 'influence_marked';
  if (i >= 0 && !!st.markedInfluences[i].anti === anti) {
    st.markedInfluences.splice(i, 1);
    logEvent(anti ? 'anti_influence_unmarked' : 'influence_unmarked', { count: st.markedInfluences.length });
  } else if (i >= 0) {
    const rec = st.markedInfluences[i];
    if (anti) rec.anti = true; else delete rec.anti;
    logEvent(markedEvent, { count: st.markedInfluences.length, switched: true });
  } else {
    const p = st.prompts[task.promptId];
    const rec = {
      taskId: task.id,
      cacheId: task.cacheId != null ? task.cacheId : null,   // may still be null; refreshed on save
      promptId: task.promptId || null,
      // Snapshot the wording now. The prompt can be edited, deleted or trimmed away later, and its exact
      // resolved wording is the only reason this image was worth marking.
      text: task.resolvedText || (p ? p.text : '')
    };
    if (anti) rec.anti = true;
    st.markedInfluences.push(rec);
    logEvent(markedEvent, { count: st.markedInfluences.length });
  }
  infRefreshTile(task);
  updateInfluencesBtn();
  scheduleAutosave();
  return true;
}

// Repaint one tile's flag row after its 🔖 / 🚫 changed. populateFlags rebuilds the row wholesale and is its
// only writer, so re-running it is both the simplest update and the correct one.
function infRefreshTile(task) {
  if (!task || !task.ui) return;
  populateFlags(task.ui, st.prompts[task.promptId], task);
}

// Repaint every tile any record names. Walks the records (a handful) rather than the feed (thousands of
// cards), and is needed where records change hands without a tile being touched: a commit, or a restore
// that has just rebuilt the feed under a set of marks loaded before the cards existed.
function refreshInfluenceFlags() {
  const seen = new Set();
  const idx = infCacheIndex();   // resolving every record at once — index it rather than rescan per record
  for (const r of infAllRecords(st.markedInfluences, st.instInfluences)) {
    const t = infTaskOf(r, idx);
    if (t && !seen.has(t.id)) { seen.add(t.id); infRefreshTile(t); }
  }
}

// Persisted form. taskId is dropped deliberately (a restored card gets a new one) and cacheId is re-read
// from the live task, because cacheImage fills it in asynchronously — an image marked the instant it
// appeared would otherwise be saved with a null id and come back unmatchable.
// `anti` is written only when true. BACKWARDS_COMPAT: every save from before 🚫 existed has no such field,
// and absent reads as 🔖 — which is exactly what those marks were.
function infSerialize(list, index) {
  const idx = index || infCacheIndex();
  return (list || []).map(r => {
    const t = infTaskOf(r, idx);
    const out = {
      cacheId: (t && t.cacheId != null) ? t.cacheId : (r.cacheId != null ? r.cacheId : null),
      promptId: r.promptId || null,
      text: r.text || ''
    };
    if (r.anti) out.anti = true;
    return out;
  });
}
function infDeserialize(v) {
  if (!Array.isArray(v)) return [];
  return v.filter(Boolean).map(r => {
    const rec = {
      taskId: null,
      cacheId: r.cacheId != null ? r.cacheId : null,
      promptId: r.promptId || null,
      text: r.text || ''
    };
    if (r.anti) rec.anti = true;
    return rec;
  });
}

// Committed records for a version, deduped to one per prompt PER KIND: the tree draws PROMPT boxes, so two
// marks of one kind on the same prompt are one parent edge. The panel keeps both rows — it's about images,
// not prompts. Kind is part of the key because two images of one {a|b} prompt CAN go opposite ways for the
// same version, and collapsing them would silently erase one of the two things that happened.
// 🔖 first, then 🚫, each in commit order — the order the parent row draws them in.
function infParentsForVersion(ver) {
  const seen = new Set(), infs = [], antis = [];
  for (const r of (st.instInfluences[ver] || [])) {
    const key = (r.anti ? 'a:' : 'i:') + (r.promptId || ('text:' + (r.text || '')));
    if (seen.has(key)) continue;
    seen.add(key);
    (r.anti ? antis : infs).push(r);
  }
  return infs.concat(antis);
}

// Reverse edge (§7.5): the instruction versions this PROMPT fed as this kind, ascending.
function infVersionsForPrompt(pid, anti) {
  const out = [];
  for (const v in st.instInfluences) {
    if ((st.instInfluences[v] || []).some(r => !!r.anti === !!anti && r.promptId === pid)) out.push(Number(v));
  }
  return out.sort((a, b) => a - b);
}

// Two buttons, one state: the composer's control column and the collapsed composer's thin bar. Whichever
// one is on screen is the only one you can see, so they must never disagree.
const influencesBtns = ['influencesBtn', 'influencesBtnMini']
  .map(id => document.getElementById(id)).filter(Boolean);
const infApplyBtn = document.getElementById('infApplyBtn');

// The count IS the state indicator — "Influences" vs "Influences 3" — so the button never needs a
// separate badge. The count is the TOTAL: 🚫 anti-influences live on the same page, so they're part of
// what the button opens.
//
// It opens with NOTHING marked, too. The panel is the only full-size instruction box in the app, and it
// now carries the in-use wording beside it — so gating it behind "have you bookmarked an image yet"
// hid the best writing surface here behind a feature you may not use. The one state that stays disabled
// is before Start, where there is no in-use version to sit beside and no applied instruction to
// change: the Start button is the commit until then.
//
// .hasMarks still tracks the COUNT, not enabledness — the amber treatment means "you have marks", which
// is the thing worth noticing from across the screen.
function updateInfluencesBtn() {
  const n = st.markedInfluences.length;
  const title = !st.started
    ? 'Press Start first'
    : n
      ? `Rewrite your instruction beside your ${n} marked image${n === 1 ? '' : 's'}`
      : 'Rewrite your instruction · nothing marked yet';
  for (const btn of influencesBtns) {
    btn.textContent = n ? 'Influences ' + n : 'Influences';
    btn.disabled = !st.started;
    btn.classList.toggle('hasMarks', n > 0);
    btn.title = title;
  }
}

/* ===================== Instruction confirm (explicit apply) =====================
   After Start, editing the instruction no longer auto-applies on a 700 ms debounce —
   a mid-edit pause used to bump instVersion, stale every prompt, and kick generation
   before the user was done. Now the edit only lands on an explicit "✓ Apply change"
   (or Ctrl/Cmd+Enter). st.instruction stays the last APPLIED value; the unapplied edit lives in the
   textbox and is saved with the session as pendingDraft, so a reload brings it back still pending. */

const applyInstBtn = document.getElementById('applyInstBtn');

// The version bump + stale sweep, factored out of the old debounce so the Apply button
// and the keyboard shortcut share one commit path.
function applyInstructionChange() {
  st.instruction = instInput.value.trim();
  localStorage.setItem('instruction', st.instruction);

  // What was queued under the old version, read before the bump (getUntestedPrompts matches the current one).
  const queuedBefore = new Set(getUntestedPrompts().map(p => p.id));
  // Mark existing prompts stale and bump instruction version
  st.instVersion++;
  st.instHistory[st.instVersion] = st.instruction;   // so prompts stamped with this version stay traceable
  let keptQueued = 0, setAside = 0;
  const marksCommitted = st.markedInfluences.length;
  for (const id of st.order){
    const p = st.prompts[id];
    if (!p) continue;
    // Mode 2 used to spare 🧲 alone, which quietly dropped hand-written prompts on every Apply; it now
    // spares whatever you put there yourself, the same predicate the sidebar's bulk clear spares, so the
    // glyph pair means one thing everywhere. The widening only ever KEEPS more, so a session saved under
    // the old meaning loses nothing on its next Apply. Rules in keepPromptOnVersionChange().
    //
    // Keeping = re-stamp p.ver to the new version so it re-passes choosePromptForTask; p.influenced /
    // p.influenceText / p.origin ride through untouched (badge + "steered by" survive the change).
    const keep = keepPromptOnVersionChange(p, st.keepPromptsMode);
    if (keep) p.ver = st.instVersion;
    else      p.stale = true;
    if (queuedBefore.has(id)) { if (keep) keptQueued++; else setAside++; }
  }

  // Commit the marked set (🔖 and 🚫 together) to the version this edit just created, then clear it — the
  // next instruction starts with none. This is the single commit path (the composer's ✓ Apply,
  // Ctrl/Cmd+Enter and the Influences panel's Apply all route here), so it's the only place the handover
  // can happen. Marks commit whether or not you visibly used them: you marked them, that was the intent, and
  // there is no way to detect "used" — you retyped the instruction by hand.
  if (st.markedInfluences.length) {
    st.instInfluences[st.instVersion] = st.markedInfluences;
    logEvent('influences_committed', { count: st.markedInfluences.length,
      anti: st.markedInfluences.filter(r => r.anti).length, instVersion: st.instVersion });
    st.markedInfluences = [];
    infClearDiffs();           // those records are history now; nothing in the panel can toggle them again
    updateInfluencesBtn();
    refreshInfluenceFlags();   // pending 🔖 → committed 🔖; the tiles look the same but now say a version
  }

  // 💭 The note lands on the version this edit just created, beside that version's marks. A why on its
  // own is NOT a change — instIsDirty stays text-only, so there is no path that bumps the version and
  // stales the queue for a note. Empty notes are not stored: an absent key means "no note", and a version
  // carrying '' would render an empty 💭 line everywhere the note is shown.
  const infWhyText = (infWhyDraft || '').trim();
  if (infWhyText) st.instWhy[st.instVersion] = infWhyText;
  infResetWhyDraft();
  infSugAfterApply();   // ✨ a suggestion written against the version just replaced is out of date

  logEvent('instruction_updated', { length: st.instruction.length, instVersion: st.instVersion,
    whyLength: infWhyText.length });
  scheduleAutosave();
  ensureQueue();   // harmless before Start due to guard
  schedule();      // harmless before Start due to guard
  // The 100ms sidebar tick and schedule() both sit out a full pause, so without this the 📌 just set on
  // Now Generating rows (and the swept Upcoming list) wouldn't show until an in-flight image finished.
  renderSidebar();
  updateInstDirty();
  // What the Apply did with the queue and the marks happens out of sight, so say it once.
  const parts = [`Applied v${st.instVersion}`];
  if (setAside) parts.push(`${plural(setAside, 'queued prompt')} set aside`);
  else if (keptQueued) parts.push(`kept ${plural(keptQueued, 'queued prompt')}`);
  if (marksCommitted) parts.push(`${plural(marksCommitted, 'mark')} recorded`);
  if (parts.length > 1) showToast(parts.join(' · '));
}

// A pending, unapplied manual edit only exists after Start (before Start the Start button
// is the commit). Programmatic writers (restore / Start / boot) always set
// st.instruction and the textbox together, so they never read as dirty.
function instIsDirty() { return st.started && instInput.value.trim() !== st.instruction; }

// ↺ Discard: back to the instruction in use. Written through the editing command so the thrown-away text
// is one Ctrl/Cmd+Z away — the draft can be long and survives reloads, so losing it outright would sting.
const discardInstBtn = document.getElementById('discardInstBtn');
if (discardInstBtn) discardInstBtn.onclick = () => {
  if (!instIsDirty()) return;
  logEvent('instruction_draft_discarded', { length: instInput.value.length });
  replaceTextUndoably(instInput, st.instruction);
  updateInstDirty();
  scheduleAutosave();
};

// What Apply will do with the queue, named in its title — the keep mode decides, and it lives in Settings.
function applyTitleText(nextVer, mode) {
  const what = mode === 0 ? 'unused prompts set aside'
    : mode === 2 ? 'keeps 🧲 steered + ✏️ yours, sets the rest aside'
    : 'unused prompts kept';
  return `Apply as v${nextVer} · ${what} (Ctrl/Cmd+Enter)`;
}

const instVerTag = document.getElementById('instVerTag');
const instHint = document.getElementById('instHint');

function updateInstDirty() {
  const dirty = instIsDirty();
  // Class, not style.display — the button holds a fixed slot in the control column (see #applyInstBtn).
  if (applyInstBtn) {
    applyInstBtn.classList.toggle('show', dirty);
    applyInstBtn.title = applyTitleText(st.instVersion + 1, st.keepPromptsMode);
  }
  // The version tag takes Apply's slot whenever there's no edit pending, so "which version am I on" is
  // answered without opening Influences or a ❓.
  if (instVerTag) {
    instVerTag.style.display = (st.started && !dirty) ? '' : 'none';
    instVerTag.textContent = `v${st.instVersion} · in use`;
    instVerTag.title = `Edit the box and ✓ Apply to make v${st.instVersion + 1}`;
  }
  if (instTick) instTick.title = `Applied — v${st.instVersion} is the instruction in use`;
  if (discardInstBtn) discardInstBtn.classList.toggle('show', dirty);
  if (infApplyBtn) {
    infApplyBtn.disabled = !dirty;   // the panel's Apply is the same commit, same test
    infApplyBtn.title = applyTitleText(st.instVersion + 1, st.keepPromptsMode);
  }
  // Follows the edit, NOT focus. This line sits in the dock's flow, so hiding it on blur shrank the dock
  // between mousedown and mouseup: the buttons moved out from under the pointer and the click was lost,
  // which is why ✓ Apply took two presses. Nothing here may change the dock's height on blur.
  if (instHint) instHint.style.display = dirty ? '' : 'none';
  if (dirty) {
    // While an edit is pending, hide the ✓/spinner so the amber Apply button is the one
    // clear call to action.
    instSpinner.style.display = 'none';
    instTick.style.display = 'none';
  } else if (st.started) {
    setSaved();
  }
}

instInput.value = st.instruction;
instInput.addEventListener('input', () => {
  hideRefineHint(true);
  if (st.started) {
    updateInstDirty();
    scheduleAutosave();   // the unapplied edit is saved with the session (pendingDraft)
  } else {
    // Before Start: persist the draft (survives reload); Start commits it as v1.
    st.instruction = instInput.value.trim();
    localStorage.setItem('instruction', st.instruction);
  }
});
instInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
    e.preventDefault();
    if (!st.started) { startBtn.click(); return; }   // before Start, commit via Start
    if (instIsDirty()) applyInstructionChange();
  }
});
if (applyInstBtn) applyInstBtn.onclick = () => { if (instIsDirty()) applyInstructionChange(); };

/* ===================== 🔖 Influences panel =====================
   Two panes: the images you marked on the left, a second view of the instruction on the right, so you
   rewrite it while reading them.

   ONE VALUE, TWO VIEWS. The right pane edits the same string as the composer's textarea — opening copies
   it in, typing mirrors it back live, and every close path copies it out. That's why there is no Cancel:
   closing after typing leaves your text in the composer unapplied, which is precisely the existing
   contract for an unapplied edit. No path can lose an edit, and the two boxes can never disagree.

   PENDING ONLY — no history section. Once you Apply, that set belongs to a version: it's in the 🌳 tree
   and in each image's ❓ details, and this panel is empty again. */

const infOverlay = document.getElementById('infOverlay');
const infInput = document.getElementById('infInput');
const infList = document.getElementById('infList');
const infListHead = document.getElementById('infListHeadText');
const infDiffAllBtn = document.getElementById('infDiffAllBtn');
const infWhy = document.getElementById('infWhy');
const infRootBox = document.getElementById('infRootBox');
const infRootText = document.getElementById('infRootText');
const infRootWhyEl = document.getElementById('infRootWhy');
const infRootHeadText = document.getElementById('infRootHeadText');
const infRootDiffBtn = document.getElementById('infRootDiffBtn');
const infRootLegend = infRootBox ? infRootBox.querySelector('.infDiffLegend') : null;

/* ---------- 💭 The pending "why" note ----------
   Lives on the PENDING EDIT, not on the panel. The field is only visible here, but the note is committed
   by whichever control commits the edit — this panel's Apply, the composer's ✓ Apply, or Ctrl/Cmd+Enter
   from either box. If it committed only from inside the panel, typing a note, closing, and applying from
   the composer would drop it silently, and "no path can lose an edit" is the whole reason this panel has
   no Cancel. It lives and dies with the draft it annotates: saved with the session beside it
   (pendingWhy), and discarded whenever the draft is — a note explaining an edit that's gone has nothing
   left to explain. */
let infWhyDraft = '';

/* ---------- ⇄ Inline diff ----------
   Ported from the prompt-history userscript's compare view, integrated form only — ONE box, deletions
   struck through in place. The two-column form is wrong here: this pane is 55% of a modal and a marked
   prompt already wraps to several lines, so splitting it would halve the reading width of the very thing
   you opened the panel to read.

   DIRECTION: on every box but one, `a` is the live draft and `b` is the box's own text — green = this
   box has it, your draft doesn't; struck red = your draft has it, this box doesn't. On a marked prompt
   that makes green a to-absorb list which drains to plain text as you type those words in, which is
   exactly the job this panel exists for. The in-use box is the exception (infPaintBox's `flip`): there
   the question is "what is my edit changing?", and the same rule read back-to-front from every commit
   diff people know (green = wording you're dropping), so it swaps sides — green is what your draft
   adds, struck is what it drops. The legend above each diff says which reading a box uses, and
   strikethrough already carries "not in the other text" without leaning on colour at all. */

/* Split once into three parallel arrays: the matching key, the word as written, and the whitespace that
   FOLLOWED it. The LCS runs on the key; the render prints the raw word and re-emits the gap.

   key — prompt text is comma-delimited, so matching raw tokens would call "lighting," and "lighting"
   different words and report nearly every line as rewritten. This is the pairing the userscript's own
   pill-label path settled on for the same reason; its compare view never got the fix. The class is
   \p{L}\p{N}_ rather than \w because \w is ASCII-only: "café" keyed as "caf" and 日本語 keyed as nothing
   at all. A token that is ALL punctuation or emoji still has no letters to key on, so it keys on its own
   lowercased text — two identical "🌸" then match each other instead of reading as a rewrite.

   raw — every token is kept, with no exceptions. This list is what gets printed, so a token missing here
   is a word silently deleted from the wording on screen. Under the old empty-key skip, turning ⇄ on
   quietly dropped every dash, emoji and non-Latin word from the box, and the text you were comparing
   against was not the text the image came from. Keying and printing are now separate decisions.

   gap — the render rebuilds the text from tokens, so the line structure has to be carried or it is lost.
   Joining with a single space collapsed the in-use instruction (routinely several paragraphs) into one
   run-on wall inside a 132px scroller, which is harder to read than the plain text it replaced. Runs are
   normalised to one of three shapes — a space, a line break, a paragraph break — because the exact
   whitespace is not worth preserving but the difference between those three is. */
function infWordsOf(text) {
  const raw = [], key = [], gap = [];
  const re = /(\S+)(\s*)/g;
  let m;
  while ((m = re.exec(String(text == null ? '' : text)))) {
    const w = m[1];
    const c = w.toLowerCase().replace(/[^\p{L}\p{N}_]/gu, '');
    raw.push(w);
    key.push(c || w.toLowerCase());
    const nl = (m[2].match(/\n/g) || []).length;
    gap.push(nl > 1 ? '\n\n' : nl === 1 ? '\n' : ' ');
  }
  return { raw, key, gap };
}

// Above this, skip the diff. dp is (m+1) × Uint16Array(n+1), so a 2000-word instruction against a
// 500-word prompt is ~2 MB per box — and this runs on every box that's open, on a debounce, while you
// type. Below it the whole pass is well under a millisecond.
const INF_DIFF_CELL_CAP = 250000;

// Classic LCS backtrack, carrying INDICES rather than words so the caller can print raw text for an
// equal/insert and the draft's own wording for a delete.
// On a substitution this emits the INSERT before the DELETE ("blue ~~red~~ sky"), which is the userscript's
// order and the right one here: the box is showing its own wording, and the struck draft word is an
// annotation dropped in beside it rather than the "before" half of a before/after pair.
function infLcsOps(aKey, bKey) {
  const m = aKey.length, n = bKey.length;
  const dp = Array.from({ length: m + 1 }, () => new Uint16Array(n + 1));
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      dp[i][j] = aKey[i - 1] === bKey[j - 1]
        ? dp[i - 1][j - 1] + 1
        : Math.max(dp[i - 1][j], dp[i][j - 1]);
    }
  }
  const out = [];
  let i = m, j = n;
  while (i > 0 && j > 0) {
    if (aKey[i - 1] === bKey[j - 1]) out.unshift({ t: 'eq', i: --i, j: --j });
    else if (dp[i - 1][j] >= dp[i][j - 1]) out.unshift({ t: 'del', i: --i });
    else out.unshift({ t: 'ins', j: --j });
  }
  while (i > 0) out.unshift({ t: 'del', i: --i });
  while (j > 0) out.unshift({ t: 'ins', j: --j });
  return out;
}

function infDiffNote(host, text) {
  const n = document.createElement('span');
  n.className = 'infDiffNote';
  n.textContent = text;
  host.appendChild(n);
}

// Renders into `host` as DOM nodes rather than an HTML string — everything else in this panel is built
// with createElement, and prompt text is user content that has no business going near innerHTML.
//
// Returns whether a comparison actually happened, which is the one thing the caller can't see from the
// outside: over the cell cap this prints the plain text and no comparison is made, and the box must not
// go on advertising one. "no changes" is a real result and reports true.
function infRenderDiff(host, draftText, boxText) {
  const A = infWordsOf(draftText), B = infWordsOf(boxText);
  host.textContent = '';
  if (A.key.length * B.key.length > INF_DIFF_CELL_CAP) {
    host.appendChild(document.createTextNode(boxText + ' '));
    infDiffNote(host, '(too long to diff)');
    return false;
  }
  const ops = infLcsOps(A.key, B.key);
  if (!ops.some(o => o.t !== 'eq')) { infDiffNote(host, 'no changes'); return true; }
  for (const op of ops) {
    const span = document.createElement('span');
    // The gap comes from whichever text the printed word came from, so B's line structure survives. A
    // deletion is your draft's word dropped in beside B's wording as an annotation, not part of B's
    // layout, so it always takes a plain space — otherwise a struck word could introduce a paragraph
    // break that exists in neither text.
    let gap;
    if (op.t === 'eq')       { span.textContent = B.raw[op.j]; gap = B.gap[op.j]; }
    else if (op.t === 'ins') { span.className = 'infDiffIns'; span.textContent = B.raw[op.j]; gap = B.gap[op.j]; }
    else                     { span.className = 'infDiffDel'; span.textContent = A.raw[op.i]; gap = ' '; }
    host.appendChild(span);
    host.appendChild(document.createTextNode(gap));
  }
  return true;
}

function infFillLegend(el, flip) {
  el.textContent = '⇄  ';
  const ins = document.createElement('span');
  ins.className = 'lgIns'; ins.textContent = flip ? '+ your draft' : '+ here';
  const del = document.createElement('span');
  del.className = 'lgDel'; del.textContent = flip ? '− dropping' : '− your draft';
  el.appendChild(ins);
  el.appendChild(document.createTextNode('   '));
  el.appendChild(del);
}

// One painter for every box, so the in-use box and a marked row can never drift apart in how they
// render or how they read.
//
// The legend and the diff surface follow the RESULT, not the request: over the cell cap infRenderDiff
// prints plain text, and dressing that up with a "+ here / − your draft" key above it would leave the
// user unable to tell "nothing changed" from "no comparison was made" — the one-line note saying so is
// easy to miss at the end of two hundred words. The ⇄ button keeps aria-pressed either way; you did
// press it, it just couldn't answer.
//
// `flip` is for the in-use box alone: there the question is "what does my draft change?", so it reads like
// an ordinary before → after — green is what your draft adds, struck is what it drops. Every other box keeps
// "draft → this box" (green = this box has it), which is what you want from a marked image or an old version.
function infPaintBox(host, legend, plainText, on, flip) {
  if (!host) return;
  if (!on) {
    host.classList.remove('infDiffBody');
    if (legend) { legend.classList.remove('on'); legend.textContent = ''; }
    host.textContent = plainText;
    return;
  }
  const draft = infInput ? infInput.value : '';
  const diffed = flip ? infRenderDiff(host, plainText, draft) : infRenderDiff(host, draft, plainText);
  // Over the cell cap infRenderDiff prints its second text plainly, which flipped would be the DRAFT.
  if (!diffed && flip) { host.textContent = plainText + ' '; infDiffNote(host, '(too long to diff)'); }
  host.classList.toggle('infDiffBody', diffed);
  if (legend) {
    legend.classList.toggle('on', diffed);
    if (diffed) infFillLegend(legend, flip); else legend.textContent = '';
  }
}

// Which boxes are currently showing a diff. Keyed by RECORD IDENTITY, not index: infRenderList partitions
// 🔖 before 🚫 for display, so a record's position moves when its kind flips while the record itself does
// not. View state — it survives closing and reopening the panel within a session, and is deliberately not
// written to a save file.
const infDiffOn = new Set();
let infRootDiffOn = false;

/* Holding records by identity means an entry outlives the record's removal from st.markedInfluences, and
   there are four ways out — the panel's ✕, a tile's ❓ toggle, an Apply committing the whole set, and a
   session restore replacing it wholesale — of which only the first is in this file's line of sight.
   Rather than a delete at each (a list that a fifth exit would silently not join), reconcile against the
   live list. Entries can only ever be ADDED by the panel's own ⇄ button, so pruning wherever the panel
   renders bounds the Set at "what you diffed while it was open"; infClearDiffs covers the two wholesale
   replacements, which would otherwise pin a whole committed generation of records until the next open. */
function infPruneDiffOn() {
  if (!infDiffOn.size) return;
  const live = new Set(st.markedInfluences || []);
  for (const rec of infDiffOn) if (!live.has(rec)) infDiffOn.delete(rec);
}
function infClearDiffs() { infDiffOn.clear(); infHistDiffOn.clear(); }

// The 💭 draft lives and dies with the edit it annotates, so every path that discards the pending edit has
// to discard the note with it (restore puts a session's saved pair back after this). Both writers in one place: the field and the variable behind it must move
// together or a cleared box would still commit its old text on the next Apply.
function infResetWhyDraft() {
  infWhyDraft = '';
  if (infWhy) infWhy.value = '';
}

// The in-use wording: the instruction actually in force, which is what you're writing over. Falls back
// to st.instruction for the sliver where a restored session has a version with no recorded text.
function infRootPlain() {
  const t = (st.instHistory && st.instHistory[st.instVersion] != null) ? String(st.instHistory[st.instVersion]) : '';
  return t.trim() ? t : (st.instruction || '');
}

function infRootRender() {
  if (!infRootBox) return;
  if (infRootHeadText) infRootHeadText.textContent = 'In use now · v' + st.instVersion;
  const why = (st.instWhy && st.instWhy[st.instVersion]) || '';
  if (infRootWhyEl) infRootWhyEl.textContent = why ? '💭 ' + why : '';
  // Started with an empty instruction, or a restored version whose text was never recorded: there is
  // nothing to compare against, so the ⇄ is greyed out for the same reason a bookmark with no recorded
  // wording is. Same rule, same treatment, one fewer special case to explain.
  const plain = infRootPlain();
  const diffable = !!plain.trim();
  if (!diffable) infRootDiffOn = false;
  const on = diffable && infRootDiffOn;
  if (infRootDiffBtn) {
    infRootDiffBtn.disabled = !diffable;
    infRootDiffBtn.setAttribute('aria-pressed', on ? 'true' : 'false');
    infRootDiffBtn.title = !diffable ? 'No instruction wording recorded for this version'
      : on ? 'Show the wording in use plainly' : 'Compare it with what you are typing';
  }
  infPaintBox(infRootText, infRootLegend, plain || '(instruction text not recorded)', on, true);
}

/* ---------- 🕘 History ----------
   Every earlier version of the instruction, newest first, in place of the marked list — so an older
   wording that turned out better can be read, compared and reused from the box you're writing in, instead
   of walked to one version at a time in the 🌳 tree. The version in force is the in-use box above, so it
   isn't repeated here; versions with no recorded wording (a spin-off drops older ones) are skipped.

   "Use as draft" puts the wording in your instruction box UNAPPLIED, through the same undo-safe insert as
   ✨ Copy, so Ctrl/Cmd+Z brings back what you'd typed. Applying it then makes a NEW version with that text —
   never a rewind of the counter, which everything from prompt stamps to committed marks is keyed on. */
const infHistBtn = document.getElementById('infHistBtn');
const infHistFilterRow = document.getElementById('infHistFilterRow');
const infHistFilter = document.getElementById('infHistFilter');
let infHistoryOn = false;          // view state, like the ⇄ toggles: survives close/reopen, not a reload
const infHistDiffOn = new Set();   // version numbers showing a diff

function infHistoryVersions() {
  const out = [];
  for (let v = st.instVersion - 1; v >= 1; v--) {
    const t = st.instHistory ? st.instHistory[v] : null;
    if (t == null || !String(t).trim()) continue;
    out.push({ ver: v, text: String(t), why: (st.instWhy && st.instWhy[v]) || '' });
  }
  return out;
}

// Every word must match: "neon dusk" narrows by both, looking in the wording and the 💭 note. A word
// shaped like "v12" means that version exactly — as a substring, "v1" would also catch v10 to v19.
function infHistMatches(h, words) {
  if (!words.length) return true;
  const hay = (h.text + ' ' + h.why).toLowerCase();
  return words.every(w => /^v\d+$/.test(w) ? Number(w.slice(1)) === h.ver : hay.includes(w));
}

function infRenderHistory() {
  const all = infHistoryVersions();
  const words = (infHistFilter ? infHistFilter.value : '').toLowerCase().split(/\s+/).filter(Boolean);
  const shown = all.filter(h => infHistMatches(h, words));
  const noun = n => n + ' earlier version' + (n === 1 ? '' : 's');
  infListHead.textContent = words.length ? `History (${shown.length} of ${noun(all.length)})` : `History (${noun(all.length)})`;
  if (!shown.length) {
    const empty = document.createElement('div');
    empty.className = 'infEmpty';
    empty.textContent = all.length ? 'No earlier version matches that filter.'
      : 'No earlier versions yet — each Apply adds one here.';
    infList.appendChild(empty);
    return;
  }
  for (const h of shown) {
    const row = document.createElement('div');
    row.className = 'infRow infHistRow';
    const col = document.createElement('div');
    col.className = 'infTextCol';
    const label = document.createElement('div');
    label.className = 'infHistLabel';
    label.textContent = 'v' + h.ver;
    col.appendChild(label);
    const legend = document.createElement('div');
    legend.className = 'infDiffLegend';
    col.appendChild(legend);
    const txt = document.createElement('div');
    txt.className = 'infText';
    col.appendChild(txt);
    if (h.why) {
      const why = document.createElement('div');
      why.className = 'infHistWhy';
      why.textContent = '💭 ' + h.why;
      col.appendChild(why);
    }
    row.appendChild(col);
    row._infTextEl = txt;
    row._infLegendEl = legend;

    const dbtn = document.createElement('button');
    dbtn.className = 'infDiffBtn';
    dbtn.type = 'button';
    dbtn.textContent = '⇄ Compare';
    row._infDiffable = true;
    row._infDiffIsOn = () => infHistDiffOn.has(h.ver);
    row._infSetDiff = (o) => { if (o) infHistDiffOn.add(h.ver); else infHistDiffOn.delete(h.ver); };
    row._infRepaintDiff = () => {
      const o = infHistDiffOn.has(h.ver);
      dbtn.setAttribute('aria-pressed', o ? 'true' : 'false');
      dbtn.title = o ? 'Show this version plainly' : 'Compare it with what you are typing';
      infPaintBox(txt, legend, h.text, o);
    };
    dbtn.onclick = () => {
      row._infSetDiff(!row._infDiffIsOn());
      row._infRepaintDiff();
      infUpdateDiffAllBtn();
    };
    row.appendChild(dbtn);
    row._infRepaintDiff();

    const use = document.createElement('button');
    use.className = 'infHistUse';
    use.type = 'button';
    use.textContent = 'Use as draft';
    use.title = 'Replace your draft with this, unapplied · Ctrl/Cmd+Z in the box brings yours back';
    use.onclick = () => {
      infReplaceDraft(h.text);
      logEvent('instruction_history_used', { fromVersion: h.ver, instVersion: st.instVersion });
    };
    row.appendChild(use);
    infList.appendChild(row);
  }
}

function infSetHistory(on) {
  infHistLabel(on);
  infRenderList();
  if (infHistoryOn && infHistFilter) infHistFilter.focus();
}

// Called on session restore: like the ⇄ toggles, the History view and its filter describe the session
// being left (a "v12" typed there may not even exist here). No render — the restore repaints the panel.
function infHistReset() {
  if (infHistFilter) infHistFilter.value = '';
  infHistLabel(false);
}

function infHistLabel(on) {
  infHistoryOn = !!on;
  if (infHistBtn) {
    infHistBtn.setAttribute('aria-pressed', infHistoryOn ? 'true' : 'false');
    // A fixed label with the pressed highlight as the state: a label that flips to "where a click goes"
    // reads as the name of the view you're in, and the button seemed to change identity.
    infHistBtn.title = infHistoryOn ? 'Back to your marked images' : 'Earlier versions of your instruction';
  }
  if (infHistFilterRow) infHistFilterRow.style.display = infHistoryOn ? '' : 'none';
}

/* Replaces the draft through the browser's own editing command rather than .value, so it lands on the
   textarea's undo stack: Ctrl/Cmd+Z brings back the draft it replaced. A plain .value write wipes that
   history, and the draft would be gone for good. .value stays as the fallback for a browser that refuses
   the command. Shared by ✨ Copy and 🕘 Use as draft. */
function infReplaceDraft(text) {
  if (!infInput) return;
  replaceTextUndoably(infInput, text);
  infMirrorOut();   // the input event already mirrored it when the command ran; this covers the fallback
}

// The undo-stack-friendly write itself, shared with the composer's ↺ Discard.
function replaceTextUndoably(el, text) {
  el.focus();
  el.select();
  let ok = false;
  try { ok = document.execCommand('insertText', false, text); } catch (_) {}
  if (!ok || el.value !== text) el.value = text;
}

/* ---------- ⇄ Compare all ----------
   One button in the Marked heading for every box on the page: the in-use box, each marked row with
   recorded wording, and the ✨ AI help suggestion while its column is showing one. Pressed means EVERY one
   of them is comparing — turn a single box off afterwards and the button goes back up, so it never claims
   more than is true. Pressing it from any other state turns them all on; pressing it pressed turns them
   all off. The per-box toggles stay the default for reading one prompt at a time (see the row ⇄). */
function infDiffAllTargets() {
  const rows = infList ? Array.from(infList.querySelectorAll('.infRow')).filter(r => r._infDiffable) : [];
  return {
    root: !!infRootPlain().trim(),
    rows,
    sug: infSugShown && infSugCopyable(),
  };
}

function infAllDiffing(t) {
  const n = (t.root ? 1 : 0) + t.rows.length + (t.sug ? 1 : 0);
  if (!n) return false;
  return (!t.root || infRootDiffOn) && t.rows.every(r => r._infDiffIsOn()) && (!t.sug || infSugDiffOn);
}

function infUpdateDiffAllBtn() {
  if (!infDiffAllBtn) return;
  const t = infDiffAllTargets();
  const any = t.root || t.rows.length > 0 || t.sug;
  const all = infAllDiffing(t);
  infDiffAllBtn.disabled = !any;
  infDiffAllBtn.setAttribute('aria-pressed', all ? 'true' : 'false');
  infDiffAllBtn.title = !any ? 'Nothing to compare yet'
    : all ? 'Show every box plainly again' : 'Compare every box with what you are typing';
}

function infToggleDiffAll() {
  const t = infDiffAllTargets();
  const on = !infAllDiffing(t);
  if (t.root) infRootDiffOn = on;
  for (const r of t.rows) {
    r._infSetDiff(on);
    r._infRepaintDiff();
  }
  if (t.sug) infSugDiffOn = on;
  infRootRender();
  infSugRender();   // repaints the suggestion box and, at its end, this button
  infUpdateDiffAllBtn();
}

/* Repaints ONLY the boxes actually showing a diff. Deliberately not infRenderList: that one revokes every
   object URL and refetches every thumbnail blob, which on a per-keystroke path would mean re-downloading
   the marked set on every character. Rows with their toggle off cost nothing here, so the common case
   (none or one open) does almost no work however many marks there are. */
function infRefreshDiffs() {
  if (!infIsOpen()) return;
  if (infRootDiffOn) infPaintBox(infRootText, infRootLegend, infRootPlain(), true, true);
  // ✨ its ⇄ diffs against the draft too, and its "Sends … your draft" line depends on the draft
  if (infSugShown) infSugRender();
  if (!infList) return;
  // Marked rows and 🕘 history rows alike: each carries its own hooks, so this loop needn't know which.
  for (const row of infList.querySelectorAll('.infRow')) {
    if (row._infDiffIsOn && row._infDiffIsOn()) row._infRepaintDiff();
  }
}

// Trailing debounce. The diff itself is sub-millisecond at these sizes; this is mostly so the box doesn't
// flicker through half-words under fast typing.
let infDiffTimer = 0;
function infScheduleDiffs() {
  if (!infIsOpen()) return;
  clearTimeout(infDiffTimer);
  infDiffTimer = setTimeout(infRefreshDiffs, 120);
}

let infObjectUrls = [];      // thumbnail object URLs, revoked on close/re-render
let infGen = 0;              // bumped to strand in-flight thumb loads, mirroring pgtGen

function infRevokeUrls() {
  for (const u of infObjectUrls) { try { URL.revokeObjectURL(u); } catch (e) {} }
  infObjectUrls = [];
}

async function infLoadThumb(cell, task, gen) {
  const blob = await pgtResolveBlob(task);   // same cache → live <img> → nothing ladder the tree uses,
  if (gen !== infGen) return;                // so cached and restored images both resolve
  if (!blob) {
    cell.classList.add('infThumbNA');
    cell.title = 'Original no longer available';
    // A row can have a live task and still have no image: the record survives, the bytes expired. Drop
    // the open affordance, which is also what takes this row out of the lightbox's paging order — see
    // infOpenableRows, which reads the class rather than a list captured before these loads resolved.
    cell.classList.remove('infThumbOpen');
    return;
  }
  const url = URL.createObjectURL(blob);
  infObjectUrls.push(url);
  const img = new Image();
  img.src = url; img.alt = '';
  cell.appendChild(img);
}

/* Clicking a marked thumbnail goes STRAIGHT into the shared lightbox — the one 📷 Image Cache, 🧺 Picked and
   the 🌳 tree's galleries already use — landing on that image, ←/→ walking the rest of the marked set
   in the order this panel lists them. No intermediate grid the way the tree's "+N" does it: the panel
   IS the list, so making you pick from a second one would be a wasted click. This is the panel you sit
   in while writing your next instruction, so being able to actually LOOK at what you marked is the
   point of it.

   Stacking needs nothing: #icLightbox is z-index 400 over #infOverlay's 330, and its own keydown
   listener is registered earlier than the global Escape chain, so one Esc closes the lightbox and
   leaves the panel — with its thumbnails and their object URLs — exactly as it was. */

// The rows that can actually be opened, in the order the panel lists them. Read from the LIVE DOM
// rather than captured at render time, because a thumbnail resolves asynchronously: a row can look
// openable when it is built and turn out to have nothing behind it a moment later. Rows showing "n/a"
// are left out, so arrowing through the set never lands on a blank frame.
function infOpenableRows() {
  return Array.from(infList.querySelectorAll('.infRow'))
    .filter(r => r._infTask && r.querySelector('.infThumb.infThumbOpen'));
}

// Mirrors pgtOpenLightbox: same per-item hook contract, and the same blob ladder infLoadThumb draws the
// thumbnails with, so anything this panel can show is something the lightbox can open. The record's own
// stored text is the last fallback — a mark outlives the prompt behind it by design.
function infOpenLightbox(row) {
  const rows = infOpenableRows();
  const at = rows.indexOf(row);
  if (at < 0) return;
  const items = rows.map(r => {
    const task = r._infTask;
    const p = st.prompts[task.promptId];
    return {
      resolvedText: task.resolvedText || (r._infRec && r._infRec.text) || (p ? p.text : ''),
      promptText:   p ? p.text : '',
      // Paging runs straight across both kinds, and a full-size image carries no red row around it — the
      // note is the only thing that stops a rejected image passing for one you wanted more of.
      _note:        (r._infRec && r._infRec.anti) ? '🚫 Anti-influence' : null,
      _resolveBlob: () => pgtResolveBlob(task).catch(() => null),
    };
  });
  icOpenLightbox(items, at);
}

function infRenderList() {
  if (!infList) return;
  infPruneDiffOn();   // the one place every removal route is guaranteed to pass through — see infPruneDiffOn
  const gen = ++infGen;
  infRevokeUrls();
  infList.innerHTML = '';
  if (infHistoryOn) { infRenderHistory(); infUpdateDiffAllBtn(); return; }
  // 🔖 rows first, then 🚫, each in the order you marked them. A render-order partition only: the array
  // keeps mark order, so flipping a record's kind never moves it in the saved list.
  const marks = st.markedInfluences.filter(r => !r.anti).concat(st.markedInfluences.filter(r => r.anti));
  const nAnti = marks.filter(r => r.anti).length;
  infListHead.textContent = !marks.length ? 'Marked'
    : nAnti ? `Marked (${marks.length - nAnti} 🔖 · ${nAnti} 🚫)`
    : 'Marked (' + marks.length + ')';
  if (!marks.length) {
    // Now a first-class state, not a leftover: the panel opens with nothing marked, so this is where a
    // first-timer meets 🔖 at all. It carries the explainer that used to live only in the disabled
    // button's tooltip — which is why the tooltip no longer repeats it.
    const empty = document.createElement('div');
    empty.className = 'infEmpty';
    infUpdateDiffAllBtn();
    empty.textContent = 'Nothing marked yet — hover an image\'s ❓ and choose "Mark as influence" or "Mark as anti-influence".';
    infList.appendChild(empty);
    return;
  }
  const idx = infCacheIndex();
  marks.forEach(rec => {
    const row = document.createElement('div');
    row.className = 'infRow' + (rec.anti ? ' infAnti' : '');

    const thumb = document.createElement('div');
    thumb.className = 'infThumb';
    row.appendChild(thumb);
    const task = infTaskOf(rec, idx);
    // Both handles live on the row, because infOpenLightbox rebuilds its set from the DOM at click time
    // (a thumbnail that fails to load has to be able to drop out after this loop has finished).
    row._infTask = task || null;
    row._infRec = rec;
    if (task) {
      thumb.classList.add('infThumbOpen');
      thumb.title = 'Open full size';
      thumb.onclick = () => infOpenLightbox(row);
      infLoadThumb(thumb, task, gen);
    }
    else thumb.classList.add('infThumbNA');

    // Wraps to as many lines as it needs instead of truncating: rereading the exact wording is the whole
    // point. It's selectable, which is all the "easy access" needed — there's no coherent way to merge a
    // full image prompt into an instruction automatically, so you read it and write your own.
    // EVERY row gets the column wrapper now, 🚫 or not, because the ⇄ legend has to sit above the text.
    const plain = rec.text || '(wording not recorded)';
    const col = document.createElement('div');
    col.className = 'infTextCol';
    if (rec.anti) {
      // Red alone would leave the kind to colour vision; the label says it in words, the same line the
      // tree's 🚫 boxes carry.
      const label = document.createElement('div');
      label.className = 'infAntiLabel';
      label.textContent = '🚫 Anti-influence';
      col.appendChild(label);
    }
    const legend = document.createElement('div');
    legend.className = 'infDiffLegend';
    col.appendChild(legend);
    const txt = document.createElement('div');
    txt.className = 'infText';
    col.appendChild(txt);
    row.appendChild(col);
    row._infTextEl = txt;
    row._infLegendEl = legend;

    // ⇄ per row, each with its own state: you diff the one prompt you're working from, not all six at
    // once — six diffs open at the same time is six things to read instead of six prompts to read.
    const dbtn = document.createElement('button');
    dbtn.className = 'infDiffBtn';
    dbtn.type = 'button';
    dbtn.textContent = '⇄ Compare';
    // A record whose wording was never captured has nothing to compare: diffing your draft against the
    // "(wording not recorded)" placeholder would be noise dressed up as a comparison.
    const diffable = !!(rec.text && rec.text.trim());
    const on = diffable && infDiffOn.has(rec);
    dbtn.disabled = !diffable;
    if (!diffable) infDiffOn.delete(rec);
    const setTitle = (o) => {
      dbtn.setAttribute('aria-pressed', o ? 'true' : 'false');
      dbtn.title = !diffable ? 'No wording recorded for this image'
        : o ? 'Show this prompt plainly' : 'Compare it with what you are typing';
    };
    setTitle(on);
    // Repaints this row from infDiffOn — its own ⇄ and ⇄ Compare all both go through it, so the button
    // state and the box can't drift apart. Diffable rows only: Compare all skips the rest.
    row._infDiffable = diffable;
    row._infDiffIsOn = () => infDiffOn.has(rec);
    row._infSetDiff = (o) => { if (o) infDiffOn.add(rec); else infDiffOn.delete(rec); };
    row._infRepaintDiff = () => {
      const nowOn = diffable && infDiffOn.has(rec);
      setTitle(nowOn);
      infPaintBox(txt, legend, plain, nowOn);
    };
    dbtn.onclick = () => {
      if (infDiffOn.has(rec)) infDiffOn.delete(rec); else infDiffOn.add(rec);
      row._infRepaintDiff();
      infUpdateDiffAllBtn();
    };
    row.appendChild(dbtn);
    infPaintBox(txt, legend, plain, on);

    const x = document.createElement('button');
    x.className = 'infUnmark';
    x.type = 'button';
    x.textContent = '✕';
    x.title = rec.anti ? 'Remove this image from the anti-influences' : 'Remove this image from the influences';
    // Same state transition as un-marking from the tile, so it goes through the same function rather
    // than reimplementing splice + log + repaint here and drifting from it later. Passing the record's own
    // kind makes the toggle a removal, never a flip. The tile path can't be reused wholesale, though: a
    // record whose image has left the feed has no task to toggle, so fall back to dropping this exact
    // record by identity.
    x.onclick = () => {
      const at = st.markedInfluences.indexOf(rec);
      // Drop the ⇄ state with the record. The infRenderList below would prune it anyway, but doing it
      // here keeps the removal and its view state in one statement rather than relying on a later pass.
      infDiffOn.delete(rec);
      if (task) infToggleMark(task, !!rec.anti);
      else {
        const i = st.markedInfluences.indexOf(rec);
        if (i >= 0) st.markedInfluences.splice(i, 1);
        logEvent(rec.anti ? 'anti_influence_unmarked' : 'influence_unmarked', { count: st.markedInfluences.length });
        updateInfluencesBtn();
        scheduleAutosave();
      }
      infRenderList();
      infSugRender();   // ✨ the "Sends …" count, and whether Ask is allowed at all, follow the marks
      // Undo matters most for a record whose image has left the feed: there's no tile to mark it again from.
      // Puts back the very record (its wording snapshot), at its old place, unless it's been re-marked since.
      if (at >= 0) showToast(rec.anti ? 'Removed 1 🚫 anti-influence' : 'Removed 1 🔖 influence', { undo: () => {
        if (st.markedInfluences.includes(rec)) return;
        if (rec.taskId && st.markedInfluences.some(r => r.taskId === rec.taskId)) return;
        st.markedInfluences.splice(Math.min(at, st.markedInfluences.length), 0, rec);
        logEvent('undo', { what: rec.anti ? 'anti_influence_unmarked' : 'influence_unmarked' });
        if (task) infRefreshTile(task);
        updateInfluencesBtn();
        scheduleAutosave();
        if (infIsOpen()) infRenderList();
        infSugRender();
      } });
    };
    row.appendChild(x);
    infList.appendChild(row);
  });
  infUpdateDiffAllBtn();
}

function infIsOpen() { return !!infOverlay && infOverlay.classList.contains('infOpen'); }

function infOpen() {
  if (!infOverlay) return;
  // Before Start there is no in-use version to sit beside and no applied instruction to change — the
  // Start button is the commit until then. The button is already disabled for this, but the invariant
  // belongs with the panel rather than only with the two controls that open it.
  if (!st.started) return;
  infInput.value = instInput.value;                 // the live draft, dirty or not
  if (infWhy) infWhy.value = infWhyDraft;           // a note typed, closed and reopened is still here
  if (infApplyBtn) infApplyBtn.disabled = !instIsDirty();
  infOverlay.classList.add('infOpen');
  infRootRender();                                  // before the list: both read infInput, now set
  infRenderList();
  infSugRender();                                   // ✨ column, if you left it showing
  infInput.focus();
}

// Text typed in the panel is text typed in the composer, so it has to do everything the composer's own
// input listener does. A programmatic .value write fires no input event, so nothing downstream runs by
// itself — hideRefineHint in particular, or the hint telling you to refine your instruction is still
// sitting there after you've refined it in the panel.
function infMirrorOut() {
  instInput.value = infInput.value;
  hideRefineHint(true);
  updateInstDirty();
  scheduleAutosave();   // same as typing in the composer: the unapplied edit is saved with the session
  // Every open diff is measured against this text, so they move with it. Debounced, and only the boxes
  // actually showing a diff are touched — nothing here goes near a thumbnail.
  infScheduleDiffs();
}

// Unconditional, and first on every close path — the panel must never take text away with it.
function infSyncOut() {
  if (!infIsOpen()) return;
  infMirrorOut();
}

function infClose() {
  infSyncOut();
  infOverlay.classList.remove('infOpen');
  infGen++;
  infRevokeUrls();
  infList.innerHTML = '';
  // The panel can be opened from the collapsed composer's thin bar, and closing it without applying
  // leaves the edited text sitting in an instInput that is display:none — ✓ Apply hidden with it, and
  // Ctrl/Cmd+Enter unreachable because the textarea can't take focus. Generation would keep running on
  // the old instruction with nothing on screen saying otherwise, so bring the composer back to show it.
  if (instIsDirty() && !st.composerVisible) toggleComposer(true);
}

// Same commit path and same guard as the composer's button: applying an unchanged instruction would bump
// instVersion and stale the entire queue for a no-op. On success the marks have just become the new
// version's parents, so there is nothing left here to show.
function infApply() {
  infSyncOut();
  if (!instIsDirty()) return;
  applyInstructionChange();
  infClose();
}

for (const btn of influencesBtns) btn.onclick = infOpen;
if (infApplyBtn) infApplyBtn.onclick = infApply;
if (infRootDiffBtn) infRootDiffBtn.onclick = () => { infRootDiffOn = !infRootDiffOn; infRootRender(); infUpdateDiffAllBtn(); };
if (infDiffAllBtn) infDiffAllBtn.onclick = infToggleDiffAll;
if (infHistBtn) infHistBtn.onclick = () => infSetHistory(!infHistoryOn);
if (infHistFilter) infHistFilter.addEventListener('input', () => { if (infHistoryOn) infRenderList(); });
if (infWhy) {
  // Mirrored into the module-level draft on every keystroke, because the field is destroyed and rebuilt
  // with nothing — it is the draft that has to outlive the panel, not the input.
  infWhy.addEventListener('input', () => { infWhyDraft = infWhy.value; if (instIsDirty()) scheduleAutosave(); });
  infWhy.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) { e.preventDefault(); infApply(); }
  });
}
if (infOverlay) infOverlay.addEventListener('click', (e) => { if (e.target === infOverlay) infClose(); });
const infCloseX = document.getElementById('infCloseX');
if (infCloseX) infCloseX.onclick = infClose;
if (infInput) {
  // Mirror as you type, so the two boxes are never even momentarily out of step and both Apply buttons
  // agree about whether there is anything to apply.
  infInput.addEventListener('input', infMirrorOut);
  infInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) { e.preventDefault(); infApply(); }
  });
}

/* ===================== ✨ Suggest an instruction =====================
   A third column in the Influences panel. Sends the in-use instruction, your draft (when it differs),
   the 🔖 / 🚫 marked prompts and an optional note to the same LLM that writes image prompts, and shows the
   instruction it suggests. This is the ONE place marked wording reaches the AI, and only when you press
   Ask — marks on their own still change nothing about generation.

   The suggestion lands in its own box, never in the instruction box: Copy is the only way across. That
   keeps the panel's "no path can lose an edit" contract without an undo stack.

   It TAKES a brainstorm turn rather than running beside one. st.suggestBusy stops ensureUntestedStock
   starting a batch from the moment you ask, a batch already in flight is waited out, and the scheduler is
   woken when the ask ends. It runs even with prompt writing paused — you asked for it directly.

   Unsaved, like the draft it helps with: a restore stops the ask and clears the column (infSugReset), and
   any Apply clears the suggestion, which was written against the version just replaced (infSugAfterApply).

   A long reply can run out of room mid-sentence. The reply closes with an end tag, so one that stops
   without it is known to be cut (infSugParseReply / infSugLooksCutOff), and ▶ Continue resends the same
   request primed with the reply so far (infSugContinue). */

// Until we know how much text the LLM accepts. The most recently marked are the ones kept.
const INF_SUG_MAX_MARKS = 12;

/* "How to rewrite" presets: hidden guidance that rides along in the request's rules. `hint` is the line
   shown under the note, so what's being asked is never invisible. Your note outranks all of them.
   Worded as leanings, not hard limits — a rigid rule ("must be shorter", "never add") makes the model
   contort a good rewrite to satisfy the letter of it, and the user can always ask again.
   `variety` is how each one treats alternatives the liked marks disagree on (golden hour in some, blue
   hour in others): keep them as an {a|b} block rather than picking one. Tighten's version only allows it
   where a block is the SHORTER way to say it, since its whole point is to trim. */
const INF_SUG_VARIETY = 'Where the liked prompts show the user is happy with several alternatives for the same thing (lighting, setting, palette and so on), you can keep them as an {option a|option b} choice block rather than picking one, if that suits the instruction.';
const INF_SUG_MODES = {
  keep: {
    label: 'Keep its form',
    hint: 'Keeps the form and length of your instruction.',
    rule: "Broadly keep the current instruction's form, style and length, changing what the marked images and the user's request call for; small reshuffles are fine where they make it read better.",
    variety: INF_SUG_VARIETY,
  },
  free: {
    label: 'Free to restructure',
    hint: 'May reorganise it freely, still asking for the same kind of image.',
    rule: 'Feel free to restructure the instruction (reorder, merge, split or reorganise it) if that makes it clearer or stronger, as long as it still asks for the same kind of image and keeps what the user explicitly asked for.',
    variety: INF_SUG_VARIETY,
  },
  tighten: {
    label: 'Tighten',
    hint: 'Shorter and punchier, keeping what it asks for.',
    rule: 'Lean towards a shorter, punchier instruction than the current one: trim repetition and filler while keeping what it actually asks for.',
    variety: 'If the liked prompts vary on something, a short {option a|option b} choice block is fine where it is more compact than spelling the alternatives out.',
  },
  expand: {
    label: 'Expand',
    hint: 'Spells out what your 🔖 marked images have in common.',
    rule: 'Lean towards a more detailed instruction: spell out concretely what the liked prompts have in common (subject, setting, lighting, composition, palette, style, whatever stands out) so the prompt writer picks it up.',
    variety: INF_SUG_VARIETY,
  },
};
const INF_SUG_MODE_KEY = 'ipo_infSugMode';

// The {a|b} syntax, spelled out for an instruction that has no block to learn it from. Matches what the
// app accepts (isValidCurlyBlocks): plain braces and pipes, no nesting.
const INF_SUG_CHOICE_RE = /\{[^{}]*\|[^{}]*\}/;
const INF_SUG_CHOICE_SYNTAX = 'About choice blocks: an instruction can contain choice blocks like {golden hour|blue hour|overcast} — curly braces around two or more alternatives separated by |, meaning any one of them is fine. The prompt writer spreads the alternatives across the many prompts it writes, so a block is how to keep several options open instead of picking one. Write them with plain braces and pipes only: no nested blocks, and every { closed by a }.';

// Pure, so it can be tested without a DOM. marks are the panel's records ({ text, anti }); records with
// no recorded wording are skipped. Returns the request text plus what went into it, which is also what
// the column's "Sends …" line reports — one count, so the line can't disagree with the request.
function infSugBuildRequest(opts) {
  let { locked, draft, marks, note, cap, mode } = opts || {};
  if (!INF_SUG_MODES[mode]) mode = 'keep';
  const preset = INF_SUG_MODES[mode];
  locked = String(locked == null ? '' : locked).trim();
  draft = String(draft == null ? '' : draft).trim();
  note = String(note == null ? '' : note).trim();
  const usable = (Array.isArray(marks) ? marks : []).filter(r => r && r.text && String(r.text).trim());
  const picked = cap == null ? usable : usable.slice(Math.max(0, usable.length - Math.max(0, cap)));
  const liked = picked.filter(r => !r.anti), disliked = picked.filter(r => r.anti);
  // One line per prompt: the list is bulleted, and a prompt's own line breaks would read as new items.
  const bullets = rs => rs.map(r => '- ' + String(r.text).trim().replace(/\s*\n\s*/g, ' ')).join('\n');
  const hasDraft = !!draft && draft !== locked;

  const parts = [
    `You are helping a user rewrite the instruction they give to an AI image-prompt writer. The instruction describes the kind of images they want; another AI turns it into many different image prompts, the user looks at the resulting images, and they have marked some of those images as ones they liked or didn't like. Below is the exact prompt wording behind each marked image.`,
    `<current_instruction>\n${locked || '(none yet)'}\n</current_instruction>`,
  ];
  if (hasDraft) parts.push(`<draft_in_progress>\n${draft}\n</draft_in_progress>\nThe user has already started rewriting it. Build on this draft rather than starting over from the current instruction.`);
  if (liked.length) parts.push(`<liked_image_prompts>\n${bullets(liked)}\n</liked_image_prompts>\nThe user liked the images these prompts produced. Work out what they have in common that the current instruction doesn't already ask for, and work it into the instruction. Don't paste them in wholesale.`);
  if (disliked.length) parts.push(`<disliked_image_prompts>\n${bullets(disliked)}\n</disliked_image_prompts>\nThe user did NOT want what these prompts produced. Work out what made them unwanted and steer the instruction away from it, preferring to say what to do instead over listing things to avoid.`);
  if (note) parts.push(`<user_request>\n${note}\n</user_request>\nThis is what the user wants changed. Follow it above everything else.`);
  // With no block of its own to copy, the model doesn't know what {a|b} means here and writes them badly.
  const hasChoices = INF_SUG_CHOICE_RE.test(locked) || INF_SUG_CHOICE_RE.test(draft);
  if (!hasChoices) parts.push(INF_SUG_CHOICE_SYNTAX);
  parts.push([
    'Rules:',
    '- Write a new version of the instruction itself (a description of the images the user wants), not an image prompt.',
    '- ' + preset.rule + " If the user's request asks for something different (shorter, longer, rewritten from scratch, a different format), go with the request.",
    preset.variety ? '- ' + preset.variety : '',
    '- Keep any {option a|option b} choice blocks well-formed.',
    `- Reply with the new instruction only, between ${INF_SUG_OPEN} and ${INF_SUG_CLOSE}: nothing before or after it — no preamble, no explanation, no quotes, no headings.`,
  ].filter(Boolean).join('\n'));

  return { text: parts.join('\n\n'), used: picked.length, liked: liked.length, disliked: disliked.length,
    total: usable.length, hasDraft, hasNote: !!note, noteLength: note.length, mode, explainsChoices: !hasChoices };
}

// Pure. Peels the wrapping the model adds despite being asked not to: a chatty lead-in line, an
// "Instruction:" label, a code fence, matching quotes. Conservative on purpose — each strip only fires on
// the exact shape, because anything it gets wrong is your next instruction.
function infSugCleanOutput(raw) {
  let t = String(raw == null ? '' : raw).replace(/\r\n?/g, '\n').trim();
  // "Sure! Here's the revised instruction:" — a whole lead-in line ending in a colon. Requiring the colon
  // keeps a real first line that merely starts with "Here's" ("Here's a cozy cabin at dusk…").
  // It must also name what it's handing over (instruction, version, rewrite…), and it never reaches past
  // the FIRST colon — "Here's the instruction: Cats. Style: film" keeps "Cats. Style: film", and "Here's a
  // cozy cabin at dusk: warm light" isn't a lead-in at all.
  t = t.replace(/^(?:(?:sure|certainly|okay|ok|absolutely)\b[^\n:]*?)?(?:here(?:'|’)?s|here is)\b[^\n:]*?\b(?:instruction|version|rewrite|suggestion|prompt|take)\b[^\n:]*:[ \t]*(?:\n+|(?=\S))/i, '').trim();
  t = t.replace(/^(?:sure|certainly|okay|ok|absolutely)[!.,]?[ \t]*\n+/i, '').trim();
  const fence = /^```[^\n]*\n([\s\S]*?)\n?```$/.exec(t);
  if (fence) t = fence[1].trim();
  // "New instruction: …", "**Revised instruction:**"
  t = t.replace(/^\**[ \t]*(?:(?:new|revised|updated|suggested|improved)[ \t]+)?instruction[ \t]*\**[ \t]*:[ \t]*\**[ \t]*\n*/i, '').trim();
  const pairs = { '"': '"', '“': '”', "'": "'", '`': '`' };
  const open = t.charAt(0);
  if (t.length > 1 && pairs[open] && t.endsWith(pairs[open])) {
    const inner = t.slice(1, -1);
    // Only a quote that wraps the WHOLE text: one more of the same mark inside means these two are a
    // quoted phrase at each end, not a wrapper.
    if (!inner.includes(open) && !inner.includes(pairs[open])) t = inner.trim();
  }
  return t;
}

/* Cut-off replies. The plugin caps how much it writes per call and says nothing about why it stopped, so
   the reply carries its own end marker: the instruction comes between INF_SUG_OPEN and INF_SUG_CLOSE, and
   a reply that finishes without the closing tag ran out of room. Not a stopSequence — the plugin leaves
   those out of the text, which would make every finished reply look cut. */
const INF_SUG_OPEN = '<new_instruction>';
const INF_SUG_CLOSE = '</new_instruction>';

// Pure. The raw reply → the instruction in it, and whether the closing tag arrived.
// streaming: the reply is still coming in, so a tag half-written at the very end is hidden rather than
// flashed on screen. Not on a finished reply — there a trailing "<" is the reply's own text.
function infSugParseReply(raw, streaming) {
  let t = String(raw == null ? '' : raw).replace(/\r\n?/g, '\n');
  // Searched on t itself, not a lower-cased copy: lower-casing İ adds a character, which would shift
  // every cut after it.
  const close = new RegExp(INF_SUG_CLOSE, 'i').exec(t);
  const closed = !!close;
  if (close) t = t.slice(0, close.index);
  // From the LAST opening tag: the one it was primed with, or its own after some chatter, or a fresh one
  // a Continue started over with.
  let from = -1;
  for (const m of t.matchAll(new RegExp(INF_SUG_OPEN, 'gi'))) from = m.index + m[0].length;
  if (from >= 0) t = t.slice(from);
  if (!closed && streaming) t = t.replace(/<\/?[a-z_]*$/i, m => (INF_SUG_OPEN.startsWith(m.toLowerCase()) || INF_SUG_CLOSE.startsWith(m.toLowerCase())) ? '' : m);
  return { text: infSugCleanOutput(t), closed };
}

// Pure. No closing tag AND an unfinished look: a { still open at the end (the usual place a cut lands — a
// choice block is a long run of text), or no closing punctuation. Both, so a model that forgot the tag but
// ended cleanly isn't nagged to continue.
function infSugLooksCutOff(text, closed) {
  if (closed) return false;
  const t = String(text == null ? '' : text).trim();
  if (!t) return false;
  let depth = 0;
  for (const ch of t) { if (ch === '{') depth++; else if (ch === '}' && depth > 0) depth--; }
  if (depth > 0) return true;
  // An opening brace can't be last by now (depth caught it); it's in the class only to keep the braces
  // paired for the tests, which find a function's end by counting them.
  return !/[.!?…)\]{}"'”’*]$/.test(t);
}

// Pure. The whole raw reply after a call primed with startWith. The finish data's .text is preferred, as
// it always was (it's the plugin's own final word): as-is when it already holds the prefix (whitespace
// aside), else prefix + it — never the prefix twice, which would duplicate everything a Continue was
// given. What streamed in (prefix chunks are skipped as they arrive) only when there's no finish text.
function infSugJoinReply(startWith, finished, streamed) {
  const sw = String(startWith == null ? '' : startWith);
  const f = typeof finished === 'string' ? finished : '';
  const s = typeof streamed === 'string' ? streamed : '';
  if (f.trim()) return (f.startsWith(sw) || (sw.trim() && f.trimStart().startsWith(sw.trim()))) ? f : sw + f;
  return sw + s;
}

const infModal = document.getElementById('infModal');
const infSugToggle = document.getElementById('infSugToggle');
const infSugHide = document.getElementById('infSugHide');
const infSugNote = document.getElementById('infSugNote');
const infSugAskBtn = document.getElementById('infSugAskBtn');
const infSugStopBtn = document.getElementById('infSugStopBtn');
const infSugContinueBtn = document.getElementById('infSugContinueBtn');
const infSugSends = document.getElementById('infSugSends');
const infSugStatus = document.getElementById('infSugStatus');
const infSugDiffBtn = document.getElementById('infSugDiffBtn');
const infSugBox = document.getElementById('infSugBox');
const infSugTextEl = document.getElementById('infSugText');
const infSugLegend = infSugBox ? infSugBox.querySelector('.infDiffLegend') : null;
const infSugWarn = document.getElementById('infSugWarn');
const infSugCopyBtn = document.getElementById('infSugCopyBtn');
const infSugCopyApplyBtn = document.getElementById('infSugCopyApplyBtn');
const infSugModeSel = document.getElementById('infSugMode');
const infSugModeHint = document.getElementById('infSugModeHint');

let infSugShown = false;      // view state: is the column showing (survives close/reopen, not a reload)
let infSugText = '';          // the suggestion: the instruction parsed out of infSugRaw (infSugParseReply)
let infSugState = 'idle';     // idle | waiting | writing | done | stopped | error
let infSugDiffOn = false;
let infSugNotice = '';        // status-line note when a new ask failed and the previous suggestion is back
let infSugAskToken = null;    // the ask in flight: { cancelled, stopped, pendingObj, releaseStop, prev, continuation }
// The result beside infSugText, all cleared and restored together (infSugClearResult / infSugSnapshot):
let infSugRaw = '';           // the whole reply as written, tags and all — what ▶ Continue hands back as startWith
let infSugClosed = false;     // the closing tag arrived
let infSugCutOff = false;     // ended on its own, unfinished (infSugLooksCutOff)
let infSugStuck = false;      // a ▶ Continue added nothing — no more Continue for this one
let infSugLastReq = null;     // the request the reply was written against; ▶ Continue resends this one
let infSugContinues = 0;      // ▶ Continues so far on this reply
const INF_SUG_STOP_GRACE_MS = 1500;   // after ■ Stop, how long to wait for the plugin's own finish

function infSugBusy() { return infSugState === 'waiting' || infSugState === 'writing'; }

function infSugRequest() {
  return infSugBuildRequest({ locked: infRootPlain(), draft: infInput ? infInput.value : '',
    marks: st.markedInfluences, note: infSugNote ? infSugNote.value : '', cap: INF_SUG_MAX_MARKS,
    mode: infSugModeSel ? infSugModeSel.value : 'keep' });
}

// A mark with wording, or a note — with neither, all the AI can do is pad the instruction out.
function infSugCanAsk(req) { return st.started && (req.used > 0 || req.hasNote); }

// Finished text that can go across. A partial one from ■ Stop counts: you stopped it because you'd seen
// enough.
function infSugCopyable() {
  return (infSugState === 'done' || infSugState === 'stopped') && !!infSugText.trim();
}

// ▶ Continue: a reply that ran out of room, or one you stopped before it closed. Not after a Continue that
// got nowhere — each one resends everything so far, so the room can be gone for good.
function infSugCanContinue() {
  return st.started && infSugCopyable() && !!infSugLastReq && !infSugClosed && !infSugStuck
    && (infSugCutOff || infSugState === 'stopped');
}

function infSugClearResult() {
  infSugText = ''; infSugRaw = '';
  infSugClosed = false; infSugCutOff = false; infSugStuck = false;
  infSugLastReq = null; infSugContinues = 0;
}

function infSugSnapshot() {
  return { text: infSugText, raw: infSugRaw, state: infSugState, closed: infSugClosed, cutOff: infSugCutOff,
    stuck: infSugStuck, req: infSugLastReq, continues: infSugContinues };
}

function infSugSendsLine(req) {
  const bits = ['your instruction'];
  if (req.hasDraft) bits.push('your draft');
  if (req.used) {
    const kinds = [req.liked ? req.liked + ' 🔖' : '', req.disliked ? req.disliked + ' 🚫' : ''].filter(Boolean).join(' + ');
    bits.push(req.used < req.total
      ? `the ${req.used} most recent of ${req.total} marked prompts (${kinds})`
      : `${kinds} marked prompt${req.used === 1 ? '' : 's'}`);
  }
  if (req.hasNote) bits.push('your note');
  const list = bits.length > 1 ? bits.slice(0, -1).join(', ') + ' and ' + bits[bits.length - 1] : bits[0];
  return `Sends ${list} · prompt writing waits for it`;
}

function infSugMessage(text) {
  infSugTextEl.classList.remove('infDiffBody');
  infSugTextEl.classList.add('infSugEmpty');
  if (infSugLegend) { infSugLegend.classList.remove('on'); infSugLegend.textContent = ''; }
  infSugTextEl.textContent = text;
}

// The box alone, so a streamed chunk doesn't rebuild the request just to repaint text.
function infSugPaintBox(req) {
  if (!infSugTextEl) return;
  if (infSugState === 'waiting') {
    // A ▶ Continue keeps the partial in view while it waits its turn; the status line says it's waiting.
    if (infSugAskToken && infSugAskToken.continuation && infSugText) {
      infSugMessage(infSugText);
      infSugTextEl.classList.remove('infSugEmpty');
      return;
    }
    return infSugMessage('Waiting for the current brainstorm to finish…');
  }
  if (infSugState === 'writing') {
    if (!infSugText) return infSugMessage('Writing…');
    infSugMessage(infSugText);
    infSugTextEl.classList.remove('infSugEmpty');
    return;
  }
  if (infSugState === 'error') return infSugMessage("The AI didn't answer — try again.");
  if (infSugState === 'idle') {
    return infSugMessage(infSugCanAsk(req || infSugRequest())
      ? "The AI's draft appears here. Nothing changes until you use it."
      : 'Needs a 🔖 / 🚫 marked image (hover its ❓) or a note above.');
  }
  if (!infSugText.trim()) return infSugMessage('The AI sent back nothing usable — try again.');
  infSugTextEl.classList.remove('infSugEmpty');
  infPaintBox(infSugTextEl, infSugLegend, infSugText, infSugDiffOn);
}

function infSugRender() {
  if (!infModal) return;
  infModal.classList.toggle('infSugOn', infSugShown);
  if (infSugToggle) {
    infSugToggle.setAttribute('aria-pressed', infSugShown ? 'true' : 'false');
    // Fixed label, pressed highlight while the column is open (same rule as 🕘 History).
    infSugToggle.title = infSugShown ? 'Hide the AI help column' : 'The AI drafts an instruction from your marks and a note — nothing is sent until you ask';
  }
  if (!infSugShown || !infSugAskBtn) { infUpdateDiffAllBtn(); return; }
  const req = infSugRequest();
  const busy = infSugBusy();
  const can = infSugCanAsk(req);
  infSugAskBtn.disabled = busy || !can;
  infSugAskBtn.textContent = (infSugText && !busy) ? '✨ Ask again' : '✨ Ask for suggestion';
  if (infSugContinueBtn) infSugContinueBtn.style.display = (!busy && infSugCanContinue()) ? '' : 'none';
  infSugStopBtn.style.display = busy ? '' : 'none';
  infSugStopBtn.textContent = infSugState === 'waiting' ? 'Cancel' : '■ Stop';
  infSugStopBtn.title = infSugState === 'waiting' ? "Don't ask after all" : 'Stop and keep what it has written';
  infSugSends.textContent = can ? infSugSendsLine(req) : '';
  if (infSugModeHint) infSugModeHint.textContent = INF_SUG_MODES[req.mode].hint;
  const continuing = !!(infSugAskToken && infSugAskToken.continuation);
  infSugStatus.textContent = infSugState === 'writing' ? (continuing ? 'Continuing…' : 'Writing…')
    : infSugState === 'waiting' ? (continuing ? 'Waiting to continue…' : 'Waiting…')
    : infSugNotice ? infSugNotice
    : infSugState === 'stopped' ? 'Stopped early'
    : infSugCutOff ? 'Looks cut off'
    : 'Suggestion';

  const copyable = infSugCopyable();
  if (!copyable) infSugDiffOn = false;
  infSugDiffBtn.disabled = !copyable;
  infSugDiffBtn.setAttribute('aria-pressed', infSugDiffOn ? 'true' : 'false');
  infSugDiffBtn.title = !copyable ? 'Nothing to compare yet'
    : infSugDiffOn ? 'Show the suggestion plainly' : 'Compare it with what you are typing';
  infSugPaintBox(req);

  const text = infSugText.trim();
  const curlyOk = !copyable || isValidCurlyBlocks(text);
  const same = copyable && text === st.instruction;
  const cut = copyable && infSugCutOff;
  // A cut inside a choice block would also read as unbalanced { }: say the real reason instead.
  // Worded as a guess: a finished reply that forgot its end marker and ends on a word looks just the same.
  infSugWarn.textContent = (cut && infSugStuck) ? "⚠ Still unfinished — the AI couldn't write more. Finish it by hand, or ✨ Ask again."
    : cut ? '⚠ May have run out of room — ▶ Continue picks up where it stopped'
    : !curlyOk ? '⚠ Unbalanced { } — fix it in your draft before applying'
    : same ? 'Same as the instruction in use.' : '';
  infSugCopyBtn.disabled = !copyable;
  infSugCopyApplyBtn.disabled = !copyable || !curlyOk || same || cut;
  infUpdateDiffAllBtn();   // the suggestion is one of the boxes Compare all covers
}

function infSugSetShown(on) {
  infSugShown = !!on;
  infSugRender();
  if (infSugShown && infSugNote && infIsOpen()) infSugNote.focus();
}

// Ends the ask in flight without a result: Cancel while waiting, an Apply, a restore. Hands the
// brainstorm turn straight back.
// quiet: from a restore — the restore owns the scheduler from here, and the ask belongs to the session
// being left, so it's neither logged nor followed by a schedule() against a half-restored state.
function infSugCancel(quiet) {
  const t = infSugAskToken;
  if (!t) return;
  t.cancelled = true;
  if (quiet) t.quiet = true;
  try { if (t.pendingObj && t.pendingObj.stop) t.pendingObj.stop(); } catch (_) {}
  // Settles the ask's race now rather than trusting the plugin to finish after a stop — otherwise an
  // ask cancelled mid-write could hang for good, and its finally (the log line) would never run.
  if (t.releaseStop) t.releaseStop();
  infSugAskToken = null;
  st.suggestBusy = false;
  st.suggestStartedAt = 0;
  infSugBackToPrev(t);   // a cancelled ask produced no replacement (Apply and restore clear it after this)
  if (!quiet) scheduleDebounced();
}

// "Ask again" only replaces the old suggestion once there's a new one. An ask that's cancelled, fails or
// brings back nothing puts the previous one back (still copyable), with a word on why in the status line.
// The same for ▶ Continue: its "previous one" is the partial it was continuing.
function infSugBackToPrev(t, why) {
  const p = t.prev;
  if (p) {
    infSugText = p.text; infSugRaw = p.raw; infSugState = p.state;
    infSugClosed = p.closed; infSugCutOff = p.cutOff; infSugStuck = p.stuck;
    infSugLastReq = p.req; infSugContinues = p.continues;
    infSugNotice = why || '';
  } else {
    infSugClearResult();
    infSugState = 'idle';
  }
}

function infSugStop() {
  const t = infSugAskToken;
  if (!t) return;
  if (infSugState === 'waiting') { infSugCancel(); infSugRender(); return; }
  t.stopped = true;
  try { if (t.pendingObj && t.pendingObj.stop) t.pendingObj.stop(); } catch (_) {}
  // The plugin's finish normally follows a stop, but nothing guarantees it — and an ask that never ends
  // would hold the brainstorm turn forever. Settle on what has streamed if it hasn't finished by then.
  setTimeout(() => { if (t.releaseStop) t.releaseStop(); }, INF_SUG_STOP_GRACE_MS);
}

async function infSugAsk() {
  if (infSugBusy()) return;
  const req = infSugRequest();   // snapshotted now: edits while it waits or writes count for the next ask
  if (!infSugCanAsk(req)) return;
  // Primed with the opening tag, so the reply starts inside it rather than with a chatty lead-in.
  return infSugRun(req, INF_SUG_OPEN + '\n', 0);
}

// ▶ Continue: the SAME request the partial was written against (not today's marks and note), primed with
// the whole reply so far, so the AI carries on mid-sentence. The plugin's own continue works this way.
function infSugContinue() {
  if (infSugBusy() || !infSugCanContinue()) return;
  return infSugRun(infSugLastReq, infSugRaw, infSugContinues + 1);
}

// One ask or one Continue: takes the brainstorm turn, streams, then parses the reply for its closing tag.
// continuation: 0 for an ask, n for the nth Continue of the same reply.
async function infSugRun(req, startWith, continuation) {
  const STOPPED = {};
  const token = { cancelled: false, stopped: false, pendingObj: null, releaseStop: null, continuation,
    prev: infSugCopyable() ? infSugSnapshot() : null };
  const stopGate = new Promise(r => { token.releaseStop = () => r(STOPPED); });
  infSugAskToken = token;
  if (!continuation) infSugText = '';   // a Continue keeps the partial on screen while it waits
  infSugNotice = '';
  infSugDiffOn = false;
  infSugState = 'waiting';
  st.suggestBusy = true;          // from here ensureUntestedStock won't start a batch — this ask is next
  st.suggestStartedAt = 0;
  infSugRender();
  renderSidebar();

  const startedAt = Date.now();
  let outcome = 'cancelled';
  let resultLength = 0;
  let acc = '';
  // This call's own result for the log — null when it produced none (cancelled, failed), rather than
  // whatever earlier suggestion was put back.
  let logCutOff = null, logClosed = null;
  // The finished reply → the result. A Continue that added nothing and still didn't close puts the partial
  // back and retires Continue for it.
  const settle = (raw, state) => {
    const parsed = infSugParseReply(raw);
    infSugRaw = raw;
    infSugText = parsed.text;
    infSugClosed = parsed.closed;
    infSugState = state;
    // A ■ Stop isn't "cut off" by itself — you chose to stop — but stopping a Continue of a cut reply
    // leaves it as unfinished as it was.
    infSugCutOff = !parsed.closed && (state === 'done'
      ? infSugLooksCutOff(parsed.text, parsed.closed)
      : !!(continuation && token.prev && token.prev.cutOff));
    infSugStuck = false;
    infSugLastReq = req;
    infSugContinues = continuation;
    outcome = state;
    resultLength = infSugText.length;
    logCutOff = infSugCutOff;
    logClosed = infSugClosed;
    // Progress is judged on the raw reply, not the cleaned text: cleanup can shorten the text as the
    // reply grows (a wrapping quote that just closed).
    const grew = raw.trimEnd().length > String(startWith).trimEnd().length;
    if (!infSugText.trim() && token.prev) infSugBackToPrev(token, 'Nothing usable came back — previous one kept');
    else if (continuation && state === 'done' && !parsed.closed && !grew && token.prev) {
      infSugBackToPrev(token, "Still looks unfinished — the AI couldn't write any more");
      infSugStuck = true;
      outcome = 'no_progress';
    }
  };
  try {
    // One await per batch. If the promise is still the live one after it settles, its batch can't clear it
    // (see restoreSessionBody), and awaiting a settled promise again resolves in a microtask — the loop
    // would spin without ever yielding, freezing the page with Cancel unreachable.
    while (st.textGenPromise && !token.cancelled) {
      const batch = st.textGenPromise;
      try { await batch; } catch (_) {}
      if (st.textGenPromise === batch) break;
    }
    if (token.cancelled) return;

    infSugState = 'writing';
    st.suggestStartedAt = Date.now();
    infSugRender();
    const po = generateText({
      instruction: req.text,
      startWith,
      hideStartWith: true,
      onChunk: (d) => {
        if (token !== infSugAskToken || !d || d.isFromStartWith || typeof d.textChunk !== 'string') return;
        acc += d.textChunk;
        infSugText = infSugParseReply(startWith + acc, true).text;
        infSugPaintBox();
      },
    });
    token.pendingObj = po;
    const finished = (po && po.onFinishPromise) ? po.onFinishPromise : po;
    const res = await Promise.race([finished, stopGate]);
    if (token.cancelled) return;
    // The finish data's .text when there is one (the whole reply), else what streamed in.
    let full = '';
    if (res !== STOPPED && res != null) {
      if (typeof res.text === 'string') full = res.text;
      else if (typeof res.valueOf() === 'string') full = String(res);
    }
    settle(infSugJoinReply(startWith, full, acc), token.stopped ? 'stopped' : 'done');
  } catch (e) {
    if (token.cancelled) return;
    // A stop can surface as a rejection; what streamed before it is still yours.
    if (token.stopped && infSugParseReply(startWith + acc).text.trim()) {
      settle(startWith + acc, 'stopped');
    } else {
      outcome = 'error';
      infSugBackToPrev(token, "The AI didn't answer — previous one kept");
      if (!token.prev) infSugState = 'error';
    }
  } finally {
    if (!token.quiet) logEvent('instruction_suggested', { outcome, continuation, cutOff: logCutOff,
      closed: logClosed, marksUsed: req.used, marksTotal: req.total,
      liked: req.liked, disliked: req.disliked, draft: req.hasDraft, mode: req.mode, noteLength: req.noteLength,
      resultLength, ms: Date.now() - startedAt });
    // Only the ask still in charge may hand the turn back; a cancelled one already did.
    if (infSugAskToken === token) {
      infSugAskToken = null;
      st.suggestBusy = false;
      st.suggestStartedAt = 0;
      scheduleDebounced();
    }
    infSugRender();
    renderSidebar();
  }
}

// Undo-safe (infReplaceDraft): Ctrl/Cmd+Z after a Copy brings back the draft it replaced.
function infSugCopy() {
  if (!infSugCopyable() || !infInput) return false;
  infReplaceDraft(infSugText.trim());
  infSugRender();
  return true;
}

// Copy, then the panel's own Apply — the same commit path, so marks become the new version's parents and
// the 💭 note is saved exactly as if you'd typed the text yourself.
function infSugCopyApply() {
  if (infSugCopyApplyBtn && infSugCopyApplyBtn.disabled) return;
  if (infSugCopy()) infApply();
}

// Called by applyInstructionChange. The suggestion was written against the version just replaced, so it
// goes; the note stays, in case you want to ask again with the same words.
function infSugAfterApply() {
  if (infSugAskToken) infSugCancel();
  infSugClearResult();
  infSugNotice = '';
  infSugState = 'idle';
  infSugDiffOn = false;
  infSugRender();
}

// Called on session restore: everything here describes the session being left.
function infSugReset() {
  if (infSugAskToken) infSugCancel(true);
  infSugClearResult();
  infSugNotice = '';
  infSugState = 'idle';
  infSugDiffOn = false;
  if (infSugNote) infSugNote.value = '';
  infSugRender();
}

if (infSugModeSel) {
  // Built from the table so the labels can't drift from the rules they send. A preference, not part of a
  // session: it's how you like to be helped, not something about this run.
  for (const [key, m] of Object.entries(INF_SUG_MODES)) {
    const o = document.createElement('option');
    o.value = key; o.textContent = m.label;
    infSugModeSel.appendChild(o);
  }
  const saved = localStorage.getItem(INF_SUG_MODE_KEY);
  infSugModeSel.value = INF_SUG_MODES[saved] ? saved : 'keep';
  infSugModeSel.addEventListener('change', () => {
    localStorage.setItem(INF_SUG_MODE_KEY, infSugModeSel.value);
    infSugRender();
  });
}
if (infSugToggle) infSugToggle.onclick = () => infSugSetShown(!infSugShown);
if (infSugHide) infSugHide.onclick = () => infSugSetShown(false);
if (infSugAskBtn) infSugAskBtn.onclick = infSugAsk;
if (infSugContinueBtn) infSugContinueBtn.onclick = infSugContinue;
if (infSugStopBtn) infSugStopBtn.onclick = infSugStop;
if (infSugCopyBtn) infSugCopyBtn.onclick = infSugCopy;
if (infSugCopyApplyBtn) infSugCopyApplyBtn.onclick = infSugCopyApply;
if (infSugDiffBtn) infSugDiffBtn.onclick = () => { infSugDiffOn = !infSugDiffOn; infSugRender(); };
if (infSugNote) {
  infSugNote.addEventListener('input', infSugRender);
  infSugNote.addEventListener('keydown', (e) => {
    // keyCode 229 too: Safari reports the Enter that commits an IME composition with isComposing false.
    if (e.key === 'Enter' && !e.metaKey && !e.ctrlKey && !e.isComposing && e.keyCode !== 229) { e.preventDefault(); infSugAsk(); }
  });
}

/* ===================== Prompts modal ===================== */

// Search + "This instruction / All" scope: view state for this dialog only, kept while the page is open.
let promptsScope = 'current';
function promptsFilter(arr, query, scope, curVer) {
  const q = (query || '').trim().toLowerCase();
  return arr.filter(p => (scope === 'all' || p.ver === curVer) && (!q || String(p.text).toLowerCase().includes(q)));
}

function openPromptsModal() {
  renderPromptsList();
  promptsModal.style.display='flex';
}
function renderPromptsList() {
  promptsList.innerHTML='';

  // Sort by score (highest first). Treat fresh (used==0) as score 0.
  const all = getAllPrompts();
  const arr = promptsFilter(all, promptsSearch.value, promptsScope, st.instVersion).sort((a,b)=>{
    if (b.score !== a.score) return b.score - a.score;
    if (b.votes !== a.votes) return b.votes - a.votes;
    return a.createdAt - b.createdAt;
  });

  if (!arr.length){
    const row = document.createElement('div'); row.className='promptRow';
    row.textContent = !all.length ? 'No prompts yet.'
      : promptsSearch.value.trim() ? 'No prompts match that search.'
      : 'None for this instruction yet — choose All for earlier ones.';
    promptsList.appendChild(row);
  } else {
    for (let p of arr){
      const row = document.createElement('div'); row.className='promptRow';
      const title = document.createElement('div');
      const badgeText = (effUsed(p) === 0) ? 'Fresh' : Math.round(p.score * 100) + '%'; /* Fresh considers claimed */
      title.innerHTML = `<span class="scoreBadge" title="Share of this prompt's images you liked">${badgeText}</span>${escapeHtml(p.text)}`;
      const meta = document.createElement('div'); meta.className='promptMeta';
      const provLabel = promptProvenance(p).map(f => `${f.icon} ${f.label.toLowerCase()}`).join(' • ');
      meta.textContent = promptLikeStats(p) + (p.ver !== st.instVersion ? ` • v${p.ver}` : '') + (provLabel ? ' • ' + provLabel : '');
      const btns = document.createElement('div'); btns.className = 'promptRowBtns';
      // ✏️ Draw next: the same path as the sidebar's Add box — a hand-written copy at the front of the queue.
      const drawBtn = document.createElement('button'); drawBtn.type = 'button'; drawBtn.className = 'promptRowBtn';
      drawBtn.textContent = '✏️ Draw next';
      drawBtn.title = 'Put this prompt at the front of the queue, as one of yours';
      drawBtn.onclick = (e) => {
        e.stopPropagation();
        const added = addPrompts([p.text], 'manual', { allowDuplicates: true });
        if (added.length) {
          logEvent('manual_prompts_added', { count: added.length, prompts: added.map(a => a.text) });
          st._forceListRebuild = true;
          renderSidebar();
        }
        drawBtn.textContent = 'Added ✓';
        setTimeout(() => { drawBtn.textContent = '✏️ Draw next'; }, 1200);
      };
      const copyBtn = document.createElement('button'); copyBtn.type = 'button'; copyBtn.textContent = "📋 Copy"; copyBtn.className='promptRowBtn';
      copyBtn.onclick = async (e)=>{
        e.stopPropagation();
        await navigator.clipboard.writeText(p.text).then(_ => { copyBtn.textContent='✅ Copied!'; }).catch(console.error);
        setTimeout(()=> copyBtn.textContent = '📋 Copy', 1200);
      };
      btns.appendChild(drawBtn); btns.appendChild(copyBtn);
      row.appendChild(title); row.appendChild(meta); row.appendChild(btns);
      promptsList.appendChild(row);
    };
  }
}
function closePromptsModal() { promptsModal.style.display='none'; }

showPromptsBtn.onclick = () => { if (st.started) openPromptsModal(); };
promptsCloseX.onclick = closePromptsModal;
const promptsSearch = document.getElementById('promptsSearch');
promptsSearch.addEventListener('input', renderPromptsList);
const promptsScopeBtns = Array.from(document.querySelectorAll('#promptsScopeSeg .segBtn'));
promptsScopeBtns.forEach(b => b.onclick = () => {
  promptsScope = b.dataset.scope;
  promptsScopeBtns.forEach(x => x.classList.toggle('active', x === b));
  renderPromptsList();
});
promptsModal.addEventListener('click', (e)=>{ if (e.target===promptsModal) closePromptsModal(); });

/* Manual add */
function addManualPrompts(text){
  const lines = parseTypedPrompts(text);
  const before = getAllPrompts().length;
  const added = addPrompts(lines, 'manual', { allowDuplicates: true });
  const after = getAllPrompts().length;
  const count = after - before;
  if (count > 0) {
    logEvent('manual_prompts_added', { count, prompts: added.map(p=>p.text) });
  }
  renderPromptsList();
}
addPromptBtn.onclick = () => {
  const t = (promptAddInput.value || '').trim();
  if (!t) return;
  addManualPrompts(t);
  promptAddInput.value = '';
  autoExpandTextarea(promptAddInput);
};
promptAddInput.addEventListener('input', () => autoExpandTextarea(promptAddInput));
promptAddInput.addEventListener('keydown',(e)=> {
  if (e.key === 'Enter' && !e.shiftKey && !e.isComposing && e.keyCode !== 229){ e.preventDefault(); addPromptBtn.click(); }
});

/* Sidebar prompt injection: drop hand-written prompts straight into the upcoming list.
   Goes through the normal 10s cooldown. Deliberately does NOT pause the scheduler on focus
   (unlike editing an existing sidebar prompt): queuing something new shouldn't halt work in flight. */
// Grow a rows="1" textarea to fit its content. Shared by the inject and theme-steer fields.
function autoExpandTextarea(el){
  el.style.height = 'auto';
  el.style.height = el.scrollHeight + 'px';
}
function autoExpandInject(){ autoExpandTextarea(sidebarInjectInput); }
function injectPromptsFromSidebar(){
  const t = (sidebarInjectInput.value || '').trim();
  if (!t) return;

  // A pasted list adds one prompt per line, the same parser the Prompts dialog's Add uses. Manual injects
  // are allowed to duplicate an existing prompt on purpose.
  const lines = parseTypedPrompts(t);
  const added = addPrompts(lines, 'manual', { allowDuplicates: true });
  if (added.length){
    // addPrompts() already moved these to the head of st.order (every 'manual' origin does), so the
    // Upcoming list shows them at the top — matching the fact that they're picked next.
    logEvent('manual_prompts_injected', { count: added.length, prompts: added.map(p => p.text) });
    sidebarInjectInput.value = '';
    autoExpandInject();
    st._forceListRebuild = true;
    renderSidebar();
  }
}
// Pressing the button would blur the textarea, whose blur handler re-renders the sidebar
// ~50ms later (see below). For a normal click (mousedown→mouseup often >50ms) that reflow
// shifts the button out from under the cursor before mouseup, so the first click misses
// and you have to click "Add" twice. Suppress the blur by keeping focus on the textarea;
// the click still fires, the prompt is added, and focus() below is a harmless no-op.
sidebarInjectBtn.addEventListener('mousedown', (e) => e.preventDefault());
sidebarInjectBtn.onclick = () => { injectPromptsFromSidebar(); sidebarInjectInput.focus(); };
sidebarInjectInput.addEventListener('input', autoExpandInject);
sidebarInjectInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey && !e.isComposing && e.keyCode !== 229){ e.preventDefault(); injectPromptsFromSidebar(); }
  else if (e.key === 'Escape'){ sidebarInjectInput.blur(); }
});
// Deliberately NON-pausing (like the Theme Steer field below): queuing your own prompt must not freeze
// ongoing image generation or the countdown timers — only editing an EXISTING prompt textarea does
// that. So there is no focus/blur `anySidebarFocus` wiring here, and `sidebarInjectInput` is left out
// of the ground-truth focus check in `renderSidebarList`. The injected prompt still gets the normal 10s
// cooldown via addPrompts, and this input lives outside `#sidebarList`, so list rebuilds never blur it.

/* Theme steer: a second sidebar field that queues "influence" prompts. Unlike the inject field
   above, these never go straight to image generation — each is consumed by the next LLM brainstorm
   batch as a <theme_steer> block that taints all of that batch's prompts. Deliberately does NOT
   pause the scheduler on focus (no anySidebarFocus wiring): it doesn't feed the image queue, so
   there's nothing to protect mid-edit. Always available — no upvote threshold. */
const sidebarInfluenceInput = document.getElementById('sidebarInfluenceInput');
const sidebarInfluenceBtn = document.getElementById('sidebarInfluenceBtn');
const sidebarInfluenceChips = document.getElementById('sidebarInfluenceChips');
let steerDrag = null;   // the press/drag in progress on a chip — see onSteerChipPointerDown

function renderInfluenceChips(){
  if (!sidebarInfluenceChips) return;
  const sig = JSON.stringify(st.influenceQueue);   // collision-free (unlike a raw-char join)
  if (sidebarInfluenceChips.dataset.sig === sig) return;  // no-op if unchanged (avoids 100ms-interval flicker)
  sidebarInfluenceChips.dataset.sig = sig;
  sidebarInfluenceChips.innerHTML = '';
  const draggable = st.influenceQueue.length > 1;
  st.influenceQueue.forEach((text) => {
    const chip = document.createElement('div');
    chip.className = 'influenceChip' + (draggable ? ' draggable' : '')
      + (steerDrag && steerDrag.moved && steerDrag.text === text ? ' dragging' : '');
    chip.dataset.text = text;
    chip.title = draggable ? text + '\n\nDrag to reorder — the leftmost steer is used next.' : text;
    if (draggable) chip.addEventListener('pointerdown', onSteerChipPointerDown);
    const label = document.createElement('span');
    label.className = 'influenceChipText';
    label.textContent = '🧲 ' + text;
    const del = document.createElement('button');
    del.className = 'influenceChipDel';
    del.textContent = '✕';
    del.title = 'Remove';
    del.onclick = () => {
      // Looked up by text, not a render-time index: a batch may have consumed the front steer since.
      const i = st.influenceQueue.indexOf(text);
      if (i < 0) return;
      st.influenceQueue.splice(i, 1);
      logEvent('influence_removed', { count: st.influenceQueue.length, text });
      renderInfluenceChips();
      scheduleAutosave();
      showToast('Removed 1 steer', { undo: () => {
        st.influenceQueue.splice(Math.min(i, st.influenceQueue.length), 0, text);
        logEvent('undo', { what: 'influence_removed' });
        renderInfluenceChips();
        scheduleAutosave();
      } });
    };
    chip.appendChild(label);
    chip.appendChild(del);
    sidebarInfluenceChips.appendChild(chip);
  });
}

// Drag a chip to reorder the queue; the leftmost is consumed next. Pointer events rather than HTML5
// drag-and-drop so it works on touch too, and a 4px threshold keeps a plain click (✕, tooltip) a click.
// The drag holds steer TEXT, never a chip element, and the chips don't move while dragging — a bar on
// the target chip's left or right edge shows where it will land. So a batch consuming or handing back a
// steer mid-drag can re-render the chips freely, and the drop is one splice moving one entry.
function onSteerChipPointerDown(e){
  if (steerDrag || e.button !== 0 || e.target.closest('.influenceChipDel')) return;
  steerDrag = {
    pointerId: e.pointerId, text: e.currentTarget.dataset.text, x: e.clientX, y: e.clientY,
    moved: false, target: null,   // target: { text, after } — the chip it would land next to
    queue: st.influenceQueue,     // a session restore swaps the array; the drop is void if it did
  };
  window.addEventListener('pointermove', onSteerDragMove);
  window.addEventListener('pointerup', onSteerDragUp);
  window.addEventListener('pointercancel', endSteerDrag);
}
function onSteerDragMove(e){
  const d = steerDrag;
  if (!d || e.pointerId !== d.pointerId) return;
  if (e.buttons === 0) { endSteerDrag(); return; }   // the release went missing (context menu, window switch)
  if (!d.moved) {
    if (Math.hypot(e.clientX - d.x, e.clientY - d.y) < 4) return;
    d.moved = true;
    window.getSelection()?.removeAllRanges();   // the press may have started a text selection
    sidebarInfluenceChips.classList.add('steerDragActive');
    document.body.classList.add('steerChipDragging');
    sidebarInfluenceChips.querySelector(`.influenceChip[data-text="${CSS.escape(d.text)}"]`)?.classList.add('dragging');
  }
  e.preventDefault();
  const over = document.elementFromPoint(e.clientX, e.clientY)?.closest('.influenceChip');
  let target = null;
  if (over && over.parentNode === sidebarInfluenceChips && over.dataset.text !== d.text) {
    const r = over.getBoundingClientRect();
    target = { text: over.dataset.text, after: e.clientX > r.left + r.width / 2 };
  }
  d.target = target;
  showSteerDropMarker(target);
}
function showSteerDropMarker(target){
  for (const c of sidebarInfluenceChips.children) {
    const on = !!target && c.dataset.text === target.text;
    c.classList.toggle('dropBefore', on && !target.after);
    c.classList.toggle('dropAfter', on && target.after);
  }
}
function onSteerDragUp(e){
  const d = steerDrag;
  if (!d || e.pointerId !== d.pointerId) return;
  endSteerDrag();
  if (!d.moved || !d.target || st.influenceQueue !== d.queue) return;
  if (moveSteer(d.text, d.target.text, d.target.after)) {
    logEvent('influence_reordered', { text: d.text, order: st.influenceQueue.slice() });
    renderInfluenceChips();
    scheduleAutosave();
  }
}
// Tears the drag down without applying it — also the whole of a pointercancel, which reverts.
function endSteerDrag(){
  steerDrag = null;
  window.removeEventListener('pointermove', onSteerDragMove);
  window.removeEventListener('pointerup', onSteerDragUp);
  window.removeEventListener('pointercancel', endSteerDrag);
  sidebarInfluenceChips.classList.remove('steerDragActive');
  document.body.classList.remove('steerChipDragging');
  showSteerDropMarker(null);
  sidebarInfluenceChips.querySelector('.influenceChip.dragging')?.classList.remove('dragging');
}
// Move `text` to just before/after `targetText` in st.influenceQueue, IN PLACE (an in-flight batch holds
// the array as an identity anchor). Either may have left the queue mid-drag (a batch consumed it); then
// nothing happens. Every other steer keeps its position, including one a failed batch handed back to the
// front. Returns whether the order changed.
function moveSteer(text, targetText, after){
  const q = st.influenceQueue;
  const from = q.indexOf(text);
  if (from < 0 || !q.includes(targetText) || text === targetText) return false;
  q.splice(from, 1);
  const to = q.indexOf(targetText) + (after ? 1 : 0);
  if (to === from) { q.splice(from, 0, text); return false; }
  q.splice(to, 0, text);
  return true;
}

function autoExpandInfluence(){ autoExpandTextarea(sidebarInfluenceInput); }

// Queueing a steer, independent of which field it was typed into — the sidebar has one, and the tree's
// hover card has a second. There is only ONE queue: st.influenceQueue is global, FIFO, one entry consumed
// per brainstorm batch, and it never attaches to a prompt. So a steer typed at a node in the tree is not
// "steer this branch" and must not behave like one; it goes to exactly the same place as the sidebar's,
// which is why this is shared code and not a second implementation.
// Returns what happened so a caller can say so in its own surface: the sidebar flashes the existing chip,
// the tree card has no chips to flash.
function queueSteer(text) {
  const t = (text || '').trim();
  if (!t) return 'empty';
  const lower = t.toLowerCase();
  const dupIdx = st.influenceQueue.findIndex(x => x.toLowerCase() === lower);
  if (dupIdx >= 0) return 'duplicate';
  st.influenceQueue.push(t);
  logEvent('influence_queued', { count: st.influenceQueue.length, text: t });
  renderInfluenceChips();
  scheduleAutosave();
  return 'queued';
}

function queueInfluenceFromSidebar(){
  const t = (sidebarInfluenceInput.value || '').trim();
  const res = queueSteer(t);
  if (res === 'duplicate') {
    // Point at the entry that already says this rather than silently doing nothing — the field keeps its
    // text so the wording can be edited into something new.
    const dupIdx = st.influenceQueue.findIndex(x => x.toLowerCase() === t.toLowerCase());
    const chip = sidebarInfluenceChips.children[dupIdx];
    if (chip) {
      chip.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      chip.classList.add('flash-duplicate');
      setTimeout(() => chip.classList.remove('flash-duplicate'), 1200);
    }
    return;
  }
  if (res !== 'queued') return;
  sidebarInfluenceInput.value = '';
  autoExpandInfluence();
}

// Same double-click guard as the inject button (see comment there).
sidebarInfluenceBtn.addEventListener('mousedown', (e) => e.preventDefault());
sidebarInfluenceBtn.onclick = () => { queueInfluenceFromSidebar(); sidebarInfluenceInput.focus(); };
sidebarInfluenceInput.addEventListener('input', autoExpandInfluence);
sidebarInfluenceInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey && !e.isComposing && e.keyCode !== 229){ e.preventDefault(); queueInfluenceFromSidebar(); }
  else if (e.key === 'Escape'){ sidebarInfluenceInput.blur(); }
});
// NOTE: intentionally no focus/blur handlers — theme steering must not pause generation.
renderInfluenceChips();

/* ===================== Debug Log modal ===================== */

function renderLogModal() {
  logList.innerHTML='';
  const evs = st.events.slice().reverse(); // newest first
  logCount.textContent = `(${st.events.length} events)`;
  for (const ev of evs) {
    const row = document.createElement('div'); row.className='logRow';
    const meta = document.createElement('div'); meta.className='logMeta';
    const time = new Date(ev.t).toLocaleTimeString();
    const desc = EVENT_DESCRIPTIONS[ev.type] || '';
    meta.textContent = `${time} — ${desc} (${ev.type})`;
    const pre = document.createElement('div');
    const data = Object.assign({}, ev); delete data.t; delete data.type;
    pre.textContent = JSON.stringify(data, null, 2);
    row.appendChild(meta); row.appendChild(pre);
    logList.appendChild(row);
  }
}

function openLogModal(){ renderLogModal(); logModal.style.display='flex'; }
function closeLogModal(){ logModal.style.display='none'; }
function clearLog(){ st.events = []; renderLogModal(); }

// Lives in Settings → Display now (troubleshooting, not a daily control), so Settings closes first and
// Esc on the log doesn't find Settings still open underneath.
debugBtn.onclick = () => { closeSettings(); openLogModal(); };
logCloseX.onclick = closeLogModal;
logModal.addEventListener('click', (e)=>{ if (e.target===logModal) closeLogModal(); });
logClear.onclick = clearLog;
logExport.onclick = ()=>{
  const blob = new Blob([JSON.stringify(st.events, null, 2)], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = `events-${Date.now()}.json`;
  a.click();
  URL.revokeObjectURL(url);
};

/* ===================== Comments modal ===================== */
let commentsEl = null;
function openComments() {
  commentsModal.style.display='flex';
  if(!commentsEl) {
    commentsEl = root.tabbedCommentsPlugin({ channels:root.commentChannels, defaultCommentOptions:root.defaultCommentOptions, allowBots:false, fillHeight:false });
    if(commentsEl) commentsContainer.appendChild(commentsEl);
  }
}
function closeComments(){ commentsModal.style.display='none'; }
commentsBtn.onclick = openComments;
commentsCloseX.onclick = closeComments;
commentsModal.addEventListener('click', (e)=>{ if (e.target===commentsModal) closeComments(); });

/* ===================== Feed viewer =====================
   🔍 on a tile (live, restored or plugin-viewer) opens the shared lightbox (#icLightbox) on this session's finished
   tiles, in feed order. The feed adds its own buttons after the core ones: 👍 Like, 🖼️ Save and 🌳 Prompt
   tree, each acting through the tile itself (ui.like / ui.save), so the four card paths keep their own
   vote and save rules. */

function gatherDoneTasksSorted(){
  const out = [];
  for (const c of feedEl.children) {
    const t = st.tasksById[c.dataset?.tid];
    if (t && t.state === 'done' && t.ui && t.ui.imgEl) out.push(t);
  }
  // In screen order: plugin-viewer cards are appended when they start but laid out by CSS `order` when
  // they finish, so DOM order isn't what you see. Restored cards have no order (0) and keep DOM order,
  // which is what the layout does too (the sort is stable).
  const at = t => parseInt(t.ui.card.style.order, 10) || 0;
  return out.sort((a, b) => at(a) - at(b));
}

// ❓'s read-only facts about a tile's prompt, for the lightbox's info panel.
function feedLbFacts(p) {
  if (!p) return '';
  const lines = [promptLikeStats(p), `Version v${p.ver}` + (p.ver !== st.instVersion ? ` (current is v${st.instVersion})` : '')];
  if (p.origin === 'upvoted') lines.push('⭐ Captured from a like');
  else if (p.origin === 'manual') lines.push('✏️ Added by hand');
  if (p.influenceText) lines.push(`🧲 Steered by "${p.influenceText}"`);
  return lines.join('\n');
}

function feedLbItem(t) {
  const p = st.prompts[t.promptId];
  return {
    resolvedText: t.resolvedText || (p ? p.text : ''),
    promptText: p ? p.text : '',
    seed: t.seed,
    resolution: t.resolution ? (RESOLUTIONS[t.resolution] || t.resolution) : null,
    genMs: t.genMs,
    // A function, so a 👍 in the lightbox can redraw "Liked N of M" with the new count.
    _facts: () => feedLbFacts(st.prompts[t.promptId]),
    _cell: t.ui.card,
    _task: t,
    ...lbTaskSource(t),
  };
}

function feedOpenLightbox(task) {
  const tasks = gatherDoneTasksSorted();
  const at = tasks.indexOf(task);
  if (at < 0) return;
  icOpenLightbox(tasks.map(feedLbItem), at, { extras: 'feed' });
}

/* ===================== Help & refine hints ===================== */

function helpDismissCount(){
  const n = parseInt(localStorage.getItem('HELP_HINT_DISMISS_COUNT')||'0',10);
  return isNaN(n) ? 0 : n;
}
function incrementHelpDismiss(){
  const n = helpDismissCount() + 1;
  localStorage.setItem('HELP_HINT_DISMISS_COUNT', String(n));
}
function shouldShowHelp(){ return helpDismissCount() < 5; }

function likeCount(){
  return parseInt(localStorage.getItem('LIKE_COUNT')||'0',10) || 0;
}
function incrementLikeCount(){
  const n = likeCount() + 1;
  localStorage.setItem('LIKE_COUNT', String(n));
  maybeShowFirstLikeTip();
  if (n >= 10) maybeShowRefineHint();
}

// Once ever (until "Show tips again"): a like is easy to mistake for "saved", and the two live in different places.
function maybeShowFirstLikeTip() {
  if (localStorage.getItem('FIRST_LIKE_TIP_SHOWN') === '1') return;
  localStorage.setItem('FIRST_LIKE_TIP_SHOWN', '1');
  showToast('Likes stay with this session. 🖼️ Save keeps an image across sessions.', { ms: 10000 });
}

function hideRefineHint(permanent=false){
  refineHint.style.display='none';
  if (permanent) localStorage.setItem('REFINE_HINT_DISMISSED','1');
}
function maybeShowRefineHint(){
  if (localStorage.getItem('REFINE_HINT_DISMISSED') === '1') return;
  if (refineHint.style.display!=='block'){ refineHint.style.display='block'; }
}
refineHint.addEventListener('click', ()=> hideRefineHint(true));

// Settings → Display "Show tips again": forgets both dismissals, so each hint returns at its usual moment.
document.getElementById('showTipsAgainBtn').onclick = () => {
  localStorage.removeItem('HELP_HINT_DISMISS_COUNT');
  localStorage.removeItem('REFINE_HINT_DISMISSED');
  localStorage.removeItem('FIRST_LIKE_TIP_SHOWN');
  showToast('Tips will show again as you go');
};

/* ===================== Cards ===================== */

function createCard(){
  const card = document.createElement('div'); card.className='card';
  const inner = document.createElement('div'); inner.className='cardInner';

  const loading = document.createElement('div'); loading.className='loadingWrap';
  const spin = document.createElement('div'); spin.className='miniSpinner';
  const ph = document.createElement('div'); ph.className='ph'; ph.textContent='Loading...';
  loading.appendChild(spin); loading.appendChild(ph);

  const fsBtn = document.createElement('button'); fsBtn.className='fsBtn'; fsBtn.textContent='🔍';
  const saveBtn = document.createElement('button'); saveBtn.className='saveBtn'; saveBtn.textContent='🖼️ Save'; saveBtn.title='Save this image to 🖼️ Saved';
  const thumbBadge = document.createElement('div'); thumbBadge.className='thumbBadge'; thumbBadge.textContent='👍';

  /* hover prompt bar placeholder */
  const promptHover = document.createElement('div'); promptHover.className='promptHover'; promptHover.style.display='none';

  /* Provenance flags row — hover-only, bottom-centered, one emoji box per flag (populateFlags). */
  const flagsRow = document.createElement('div'); flagsRow.className='promptFlags'; flagsRow.style.display='none';   // populateFlags reveals it (every tile gets at least ❓)

  inner.appendChild(loading);
  card.appendChild(inner); card.appendChild(fsBtn); card.appendChild(saveBtn); card.appendChild(thumbBadge);
  card.appendChild(flagsRow); card.appendChild(promptHover);

  return { card, inner, ph, fsBtn, saveBtn, thumbBadge, flagsRow, promptHover, imgEl:null, upvoted:false, setLoading(msg){ this.ph.textContent = msg; } };
}

// Provenance = where a prompt actually came from, limited to genuinely *attributable* sources: you
// typed it (manual), a theme-steer you queued shaped it (influenced), or it carried over from an older
// instruction version (stale). Generation knobs (creative / mix / promoted) are deliberately NOT
// provenance — each can produce a prompt identical to a plain generation round, so they aren't a
// distinct source. Returns an ordered array of {icon, label, desc}; empty for a plain AI-generated
// prompt (no badge). Single source of truth for every provenance surface.
//
// `task` is optional and only image-carrying surfaces (the tile flag row) pass it: it answers the 🧲
// question per IMAGE rather than per prompt — see the influenced branch below. Prompt-only surfaces (the
// sidebar, the Prompts modal) pass nothing and read the prompt's live state.
function promptProvenance(p, task) {
  const flags = [];
  // The ✏️ badge itself is permanent — "you wrote this" stays true for the life of the prompt — but the
  // queue jump it buys is not, so the wording splits on the same effUsed()===0 test choosePromptForTask()
  // uses. Otherwise a manual prompt that had its turn an hour ago would still be promising priority it no
  // longer has, which is exactly the trap the ⭐/🧲 badges retire to avoid. Stale / older-version prompts
  // never reach the priority branch at all (it only sees the current instruction version), so they read
  // as spent too.
  if (p && p.origin === 'manual')  flags.push({ icon: '✏️', label: 'Manual',
                                     desc: (effUsed(p) === 0 && !p.stale && p.ver === st.instVersion)
                                       ? 'You added this prompt by hand — it jumps the queue and is generated before any AI-written prompt.'
                                       : 'You added this prompt by hand. It has had its turn at the front of the queue, and now takes its normal turn.' });
  // "Recently" is load-bearing: the ⭐ marks a prompt that exists as the direct consequence of a click
  // you just made, sitting in Upcoming waiting to be tried. Once it has produced an image (or gone
  // stale under a newer instruction) it's just another prompt in the pool, so the badge retires —
  // otherwise it rides that prompt forever and eventually pairs with 📌, claiming the prompt is both
  // freshly upvoted and inherited from an older instruction. p.origin is left untouched (it's saved
  // and exported); only the badge is conditional, and the ❓ panel still reports the capture.
  // 🧲 below reaches the same end-state (badge retires on use, knowledge kept) by the opposite lever: it
  // CLEARS p.influenced at the used-increment site rather than filtering the badge on read, because that
  // field is also the selection filter ("Send steered prompts first") — retiring only the badge would
  // leave a used steered prompt permanently prioritized. Its durable half is p.influenceText, which is
  // never cleared on use. ✏️ drives selection too (manual prompts jump the queue in
  // choosePromptForTask), but takes neither route: p.origin is immutable, and the priority branch spends
  // itself by re-testing effUsed() rather than by clearing anything — nothing to retire.
  if (p && p.origin === 'upvoted' && effUsed(p) === 0 && !p.stale)
                                   flags.push({ icon: '⭐', label: 'Recently upvoted',  desc: 'Captured from an image you upvoted — its randomized prompt pinned to this exact wording.' });
  // Per-image when a task is supplied, per-prompt otherwise. p.influenced is cleared the instant a
  // steered prompt lands its first image, so a tile reading it would ALWAYS miss — including on the very
  // image that spent the steer, the one image that should carry the badge. task.influenced is that
  // image's own answer, stamped at the used-increment site and persisted with the image, so image #1 of
  // a steered prompt keeps 🧲 for good while #2 and #3 correctly show nothing. Absent on a task that
  // predates this (older saved session) → falls back to the prompt, which reads false for a used prompt
  // exactly as before.
  const influenced = (task && task.influenced != null) ? task.influenced : (p && p.influenced);
  if (p && influenced)             flags.push({ icon: '🧲', label: 'Steered',           desc: 'Shaped by a theme-steer you queued.' });
  if (p && p.stale)                flags.push({ icon: '📌', label: 'Stale',             desc: 'Created under an older instruction version.' });
  return flags;
}
function provenanceIcons(p) { return promptProvenance(p).map(f => f.icon).join(''); }

// Whether this device has a real hover — decides whether tapping the ❓ flag has to open the panel, since
// there is no hover to do it. It no longer affects any WORDING: the panel's rows expand via an explicit
// button, which reads the same either way. Evaluated once: it can't change mid-session.
const STATS_NO_HOVER = window.matchMedia('(hover: none)').matches;

// Render provenance as a hover-only row of individual emoji boxes at the bottom of the tile: one box per
// flag (with a label/desc tooltip). Visibility is driven by CSS (`.card:hover .promptFlags`); we only set
// the inline display — '' to defer to CSS when the prompt has flags, 'none' to force-hide when it has none
// (so a flagless card shows nothing even on hover).
function populateFlags(ui, promptObj, task) {
  if (!ui.flagsRow) return;
  const flags = promptProvenance(promptObj, task);   // task → 🧲 answers for THIS image, not the prompt

  // 🔖 is appended HERE rather than added to promptProvenance, which is the single source of truth for
  // PROVENANCE — where a prompt came from. A bookmark points the other way: where this image went. Tiles
  // only, and that's not a limitation — the sidebar and Prompts modal list unused prompts, which by
  // definition have no image to mark. Shown while pending AND after committing: once an image has
  // influenced v3 that stays true forever, the same resolution 🧲 reached (§7c) — transient on a prompt,
  // permanent on an image, knowledge kept either way.
  // 🚫 follows the same rules and is asked SEPARATELY, not as an either/or: pending marks are exclusive, but
  // an image committed as a 🔖 to v3 can be marked 🚫 for v5, and then both are true and both are shown.
  if (infFlagged(task, false)) {
    const vers = infCommittedVersions(task, false);
    flags.push({
      icon: '🔖', label: 'Marked as influence',
      desc: vers.length
        ? 'Recorded as an influence on instruction ' + vers.map(v => 'v' + v).join(', ') + '.'
        : 'Bookmarked to reread while you rewrite your instruction.'
    });
  }
  if (infFlagged(task, true)) {
    const vers = infCommittedVersions(task, true);
    flags.push({
      icon: '🚫', label: 'Marked as anti-influence',
      desc: vers.length
        ? 'Recorded as an anti-influence on instruction ' + vers.map(v => 'v' + v).join(', ') + '.'
        : 'Marked as something you don\'t want, to reread while you rewrite your instruction.'
    });
  }

  ui.flagsRow.innerHTML = '';

  // ❓ is present on every tile — it's the entry point to the details panel, so a flagless image still
  // needs one. Spliced at the middle index so it reads as the centre box rather than drifting to one
  // end: [❓] · [✏️ ❓] · [✏️ ❓ 📌] · [✏️ 🧲 ❓ 📌].
  const info = document.createElement('button');
  info.type = 'button';
  info.className = 'promptFlag promptFlagInfo';
  info.textContent = '❓';
  info.title = 'Image details';
  info.setAttribute('aria-label', 'Image details');
  if (task) info.dataset.tid = task.id;
  // The upvote only counts presses on the card or its image (isUpvoteTapTarget), so no box in this row
  // likes the image. They still swallow their pointer events, so a press here never reaches the card.
  // ❓: on touch a tap opens the panel and a second tap closes it. With a mouse, hover opens it and a
  // click PINS it (it stays when the pointer leaves, like ▾ Show all), a second click closes it — so the
  // click does something even after Esc or an outside click closed the panel under a resting pointer.
  info.addEventListener('pointerdown', e => e.stopPropagation());
  info.addEventListener('pointerup', e => e.stopPropagation());
  info.addEventListener('click', e => {
    e.stopPropagation();
    const upHere = _statsMode === 'tile' && _statsBox && _statsBox.style.display !== 'none' && _statsBox.dataset.tid === info.dataset.tid;
    if (STATS_NO_HOVER) { if (upHere) hideStats(); else showTileStats(info); return; }
    if (upHere && _statsBox.dataset.pinned) { hideStats(); return; }
    if (!upHere) showTileStats(info);
    if (_statsBox && _statsMode === 'tile') _statsBox.dataset.pinned = _statsBox.dataset.clickPin = '1';
  });

  const boxes = flags.map(f => {
    const box = document.createElement('span');
    box.className = 'promptFlag';
    box.textContent = f.icon;
    // Flag tooltips stay: they explain what the icon MEANS. The panel shows the values instead, so the
    // two never state the same thing. A tap or click on a flag opens the same details panel as ❓ — it
    // used to like the image, which is not what anyone reaching for ✏️ or 📌 means.
    box.title = `${f.label} — ${f.desc}`;
    box.addEventListener('pointerdown', e => e.stopPropagation());
    box.addEventListener('pointerup', e => e.stopPropagation());
    box.addEventListener('click', e => { e.stopPropagation(); info.click(); });
    return box;
  });
  boxes.splice(Math.floor(boxes.length / 2), 0, info);
  boxes.forEach(b => ui.flagsRow.appendChild(b));

  ui.flagsRow.style.display = '';
}

// Populate the tile hover caption with just the prompt text. Provenance is shown separately as the
// hover-only emoji-box row along the bottom (populateFlags), not appended to the caption.
function setPromptHover(ui, text) {
  ui.promptHover.textContent = text || '';
  ui.promptHover.style.display = 'block';
}

// --- Provenance info box (sidebar) ---
// A singleton floating tip, lazily created, showing the full prompt + a plain-language legend of each
// active flag. pointer-events:none (CSS) means it never blocks the textarea underneath. Delegation is
// used because the Now Generating list is rebuilt via innerHTML each tick, so per-element listeners
// wouldn't survive. Trigger differs per list: the read-only "Now Generating" row triggers on the WHOLE
// row (`.sidebarInflightItem`, carries data-pid) for a big easy target; the editable "Upcoming" row
// triggers only on its `.sidebarProv` emoji, so a box never pops while you're aiming for the textarea.
let _provTipBox = null, _provTipFor = null;
function provTarget(e) {
  if (!e.target || !e.target.closest) return null;
  return e.target.closest('.sidebarInflightItem') || e.target.closest('.sidebarProv');
}
function showProvTip(el) {
  const pid = el.dataset.pid;
  const p = pid ? st.prompts[pid] : null;
  const flags = p ? promptProvenance(p) : [];
  if (!flags.length) return;
  if (_provTipFor === el && _provTipBox && _provTipBox.style.display === 'block') return; // already up for this row
  if (!_provTipBox) { _provTipBox = document.createElement('div'); _provTipBox.id = 'provTip'; document.body.appendChild(_provTipBox); }
  const tip = _provTipBox;
  _provTipFor = el;
  tip.innerHTML = '';
  const promptLine = document.createElement('div');
  promptLine.className = 'provTipPrompt';
  promptLine.textContent = p.text;
  tip.appendChild(promptLine);
  const legend = document.createElement('div');
  legend.className = 'provTipLegend';
  flags.forEach(f => {
    const line = document.createElement('div');
    line.className = 'provTipLine';
    line.textContent = `${f.icon} ${f.label} — ${f.desc}`;
    legend.appendChild(line);
  });
  tip.appendChild(legend);
  tip.style.display = 'block';
  // Always render just LEFT of the whole sidebar (over the feed), never over the sidebar itself. An
  // Upcoming badge sits at the sidebar's right edge, so a box drawn left-of-badge would overlap other
  // rows' badges and — since a pass-through re-triggers it — turn into a hover trap. Anchor to the
  // sidebar's left edge instead; align vertically to the hovered row.
  const sidebar = document.getElementById('sidebar');
  const sbLeft = sidebar ? sidebar.getBoundingClientRect().left : el.getBoundingClientRect().left;
  const r = el.getBoundingClientRect();
  const tr = tip.getBoundingClientRect();
  let top = r.top;
  if (top + tr.height > window.innerHeight - 8) top = window.innerHeight - tr.height - 8;
  tip.style.left = Math.max(8, sbLeft - tr.width - 10) + 'px';
  tip.style.top = Math.max(8, top) + 'px';
}
function hideProvTip() { if (_provTipBox) _provTipBox.style.display = 'none'; _provTipFor = null; }
document.addEventListener('mouseover', (e) => {
  const el = provTarget(e);
  if (el) showProvTip(el);
});
document.addEventListener('mouseout', (e) => {
  const el = provTarget(e);
  if (!el) return;
  if (e.relatedTarget && el.contains(e.relatedTarget)) return; // moving within the same row — don't flicker
  hideProvTip();
});

/* ===================== Stats panel (shared: pipeline + per-tile) ===================== */
// One floating singleton on document.body serving two content builders — the sidebar pipeline panel
// and the per-tile ❓ panel. It lives on the body rather than inside either host because the sidebar
// status line replaces its own innerHTML whenever the ready count changes (renderSidebarStatus), which
// would otherwise destroy a child panel mid-read — driven by the very numbers the panel exists to show.
// The pipeline panel is pointer-events:none (CSS) so it never blocks what's underneath; the tile panel
// flips to auto (renderTileStats) because it scrolls and its long rows expand on hover.
let _statsBox = null;
let _statsMode = null;   // 'pipeline' | 'tile' | null — open-state is a flag, never element identity
let _statsTick = null;
let _statsCloseTimer = null;   // tile-mode hover-intent close delay (bridges ❓ → panel so it stays readable)
// ⓘ explainer singleton (see "ⓘ explainers" below). Declared up here beside _statsBox rather than with its
// functions because hideStats reads it: a `let` further down would put hideStats in its temporal dead zone
// for any call made while the script is still evaluating.
let _infoTipPop = null, _infoTipFor = null;

// Give the pointer a beat to cross the gap from the ❓ down into the panel instead of closing the
// instant it leaves the ❓ — cancelled when the panel is reached (or the pointer returns to the ❓).
// Tile mode only; the read-only pipeline panel never schedules.
function statsScheduleClose() {
  // A pinned panel (one where you pressed ▾ Show all) ignores the pointer leaving — see the expand handler.
  if (_statsBox && _statsBox.dataset.pinned) return;
  clearTimeout(_statsCloseTimer);
  _statsCloseTimer = setTimeout(() => { if (_statsMode === 'tile') hideStats(); }, 180);
}
function statsCancelClose() { clearTimeout(_statsCloseTimer); _statsCloseTimer = null; }

function statsBox() {
  if (!_statsBox) {
    _statsBox = document.createElement('div');
    _statsBox.id = 'statsPanel';
    // The tile panel is interactive (scrollable body, hover-expanding rows, 🌳 button), so a pointer
    // resting anywhere inside it counts as "still reading" — otherwise the ❓'s mouseout closes it the
    // moment you reach for the scrollbar. Pipeline mode never fires these: it stays pointer-events:none.
    _statsBox.addEventListener('mouseenter', statsCancelClose);
    _statsBox.addEventListener('mouseleave', () => { if (_statsMode === 'tile') statsScheduleClose(); });
    document.body.appendChild(_statsBox);
  }
  return _statsBox;
}

// A hard cap on any value this panel renders — EXCEPT the expandable free-text rows, which are exempt.
// Applying it to those was a mistake: they carry the prompt, and a button that says "▾ Show all" has to
// mean all, so a 700-character prompt that unfolded to "… [omitted 200 chars]" left the app with no route
// at all to its own full text. What justified a cap there was panel height, and height is already handled
// properly — the panel is capped to the room beside the tile and the overflow scrolls inside .statsBody —
// so the character cut was solving a solved problem by destroying content. It still guards the ordinary
// rows, which have no expand button and so genuinely cannot be unbounded. 500 characters is far past any
// value that reaches one of those; when it fires, the value is pathological.
// The cut is announced, never silent, reusing the "[omitted N chars]" wording sanitizeForLog already uses
// so the app has one form of truncation rather than two.
const STATS_MAX_CHARS = 500;

// How far back the pipeline panel's two averages look. A display window only — nothing in the scheduler
// reads it, which is why it isn't in st.params beside the tunables that do change behaviour.
const TIMING_WINDOW_MS = 20 * 60 * 1000;
// Memory backstop only. At five parallel images it would take a sustained sub-second image to reach this
// inside the window, which this backend cannot do — the realistic way to hit it is a system clock that
// jumped backwards, and every clock-derived figure in the app is wrong in that case. Sized so it can
// never trim a sample the window still wants.
const TIMING_MAX_SAMPLES = 4000;
function statsCap(value) {
  const s = String(value);
  if (s.length <= STATS_MAX_CHARS) return s;
  return s.slice(0, STATS_MAX_CHARS) + `… [omitted ${(s.length - STATS_MAX_CHARS).toLocaleString()} chars]`;
}

// Rows are [label, value] pairs; a null/'' value drops the row entirely, which is how the panels stay
// terse without every builder repeating an if. A row tagged `statsClampable` holds free text that can be
// arbitrarily long (a prompt, an instruction, a steer, a template): it clamps to a few lines (three here,
// eight in the tree's hover card) and unfolds IN FULL only when its explicit button is pressed — those
// rows skip statsCap, because that is the one place the app has to show you the whole prompt. Every other
// value goes through it. Rows go in their own scroll container so one huge value
// scrolls INSIDE the panel instead of pushing everything below it — including the 🌳 button, which
// callers append to the box after this — off the bottom of the screen.
function statsRows(box, rows, titleText) {
  box.innerHTML = '';
  // A rebuild is a new subject, so it drops any pin the last subject's ▾ Show all left behind.
  delete box.dataset.pinned;
  delete box.dataset.clickPin;
  if (titleText) {
    const t = document.createElement('div');
    t.className = 'statsTitle';
    t.textContent = titleText;
    box.appendChild(t);
  }
  const body = document.createElement('div');
  body.className = 'statsBody';
  rows.forEach(r => {
    if (!r) return;
    const [label, value, cls, tip] = r;   // tip: the label's tooltip, for a name that needs explaining
    if (value == null || value === '') return;
    const line = document.createElement('div');
    line.className = 'statsRow' + (cls ? ' ' + cls : '');
    if (label) {
      const k = document.createElement('span');
      k.className = 'statsK';
      k.textContent = label;
      if (tip) k.title = tip;
      line.appendChild(k);
    }
    const v = document.createElement('span');
    v.className = 'statsV';
    const clampable = line.classList.contains('statsClampable');
    v.textContent = clampable ? String(value) : statsCap(value);
    line.appendChild(v);
    if (clampable) {
      // The ONE way to unfold a row. Nothing in this panel expands merely because the pointer is over it,
      // so expansion is always an explicit, labelled control — and because there is no hover path left,
      // there is nothing for STATS_NO_HOVER to word differently: desktop and touch read the same label.
      // Shown only once markClamped() confirms the text really is cut (CSS keys it off .isClamped), so a
      // one-line instruction never advertises an expansion that would do nothing.
      const hint = document.createElement('button');
      hint.type = 'button';
      hint.className = 'statsHint';
      // The character count is in the label deliberately: it's an honest warning about how much is about
      // to unfold, readable BEFORE you commit rather than after — and it is now the WHOLE value, since
      // nothing truncates these rows any more.
      const shut = `▾ Show all (${v.textContent.length.toLocaleString()} chars)`;
      hint.textContent = shut;
      line.appendChild(hint);
      // stopPropagation keeps the press off the card's upvote.
      hint.addEventListener('click', e => {
        e.stopPropagation();
        const open = line.classList.toggle('statsExpanded');
        hint.textContent = open ? '▴ Show less' : shut;
        // Re-place, because the panel's height was decided when it opened — capped to the room on one side
        // of the tile and positioned by its COLLAPSED height. Unfolding a row then grew it straight off the
        // bottom of the window, where it was clipped by the viewport rather than scrolling: the promised
        // text was rendered and unreachable. Re-running the placer measures the panel as it now is, so it
        // flips to the roomier side (anchored by its bottom edge, which is what that branch is for) and the
        // remainder scrolls inside .statsBody.
        const host = line.closest('#statsPanel, #pgtCard');
        const anchor = host && host._statsAnchor;
        if (host && anchor && anchor.isConnected) placeStats(host, anchor);
        // Re-placing can move the panel out from under the pointer, and a panel that vanishes 180ms after
        // you asked to read it is worse than one that never expanded. So while anything is unfolded the
        // panel is PINNED: it closes on Esc, a click outside, or moving to another ❓ instead of on the
        // pointer wandering off. Keyed on "is any row still open", not on this press — a panel can hold
        // several expandable rows, so collapsing one must not release a pin the others still need, and
        // collapsing the last one must release it, or ▾ then ▴ would leave a normal-sized panel that had
        // quietly stopped closing by itself.
        if (host) {
          if (host.querySelector('.statsExpanded')) {
            host.dataset.pinned = '1';
            statsCancelClose();
            if (typeof pgtCardCancelClose === 'function') pgtCardCancelClose();
          } else if (!host.dataset.clickPin) {   // a pin from clicking ❓ / tapping a box outlives the rows
            delete host.dataset.pinned;
          }
        }
      });
    }
    body.appendChild(line);
  });
  box.appendChild(body);
}

// Clamped-ness is measured, not assumed — and only once the panel is visible, since a display:none box
// reports zero heights. Re-run whenever the rows change. Rows are always in their collapsed state here:
// statsRows rebuilds them from scratch, and nothing expands them but the button.
function markClamped(box) {
  box.querySelectorAll('.statsClampable').forEach(row => {
    const v = row.querySelector('.statsV');
    row.classList.toggle('isClamped', !!v && v.scrollHeight > v.clientHeight + 1);
  });
}

/* One elapsed-time formatter behind both of the pipeline panel's duration words, so 'Last image — 3m 12s
   ago' and '… in the last 3m' — adjacent rows of the same panel — can't round differently. They were two
   functions ten lines apart doing the same arithmetic, which is one edit away from disagreeing.

   `coarse` is what makes a SPAN different from a stopwatch: it drops the seconds once there's a whole
   minute and floors rather than rounds, so a buffer 119 seconds old says 1m rather than claiming a
   2-minute window it cannot cover. `min` keeps a sub-second span off zero for the same reason. */
function fmtElapsed(ms, { coarse = false, min = 0 } = {}) {
  const raw = Math.max(0, ms) / 1000;
  const s = coarse ? Math.floor(raw) : Math.round(raw);
  if (s < 60) return Math.max(min, s) + 's';
  const m = Math.floor(s / 60);
  return coarse ? m + 'm' : m + 'm ' + (s % 60) + 's';
}
function fmtAgo(ts) {
  if (!ts) return '';
  return fmtElapsed(Date.now() - ts) + ' ago';
}
function fmtDur(ms) {
  if (!ms) return '';
  const s = ms / 1000;
  return (s < 10 ? s.toFixed(1) : Math.round(s)) + 's';
}

/* ---- Rolling timings (the pipeline panel's two averages) ----
   Nothing here measures anything new: both durations were already computed and thrown away, one at the
   end of a brainstorm batch and one at the end of a successful image. These keep the last
   TIMING_WINDOW_MS of them so the panel can say how fast the run has been going, not just what the last
   one did. Split into small pure functions on purpose — the panel itself can't be tested without a DOM,
   and this is the half worth testing. */

// Append a duration sample, dropping whatever has aged out. Bounded on write for memory and filtered
// again on read for truth: pruning only here would leave a pipeline that stopped 40 minutes ago still
// reporting its last average under a label that says "the last 20m".
function recordTiming(buf, ms) {
  const now = Date.now();
  buf.push({ t: now, ms });
  while (buf.length && (now - buf[0].t > TIMING_WINDOW_MS || buf.length > TIMING_MAX_SAMPLES)) buf.shift();
}

// Mean of the samples inside the window, and the mean gap between them. Walks backwards and stops at
// the first one that has aged out, which is sound because the buffer is only ever appended to in real
// time.
//
// gapMs is how often one LANDED, against avgMs's how long one TOOK — two different numbers whenever
// work runs in parallel, and the interesting pair: at five at once a steady pipeline lands one every
// fifth of a generation time, and anything slower than that is queue starvation or an endpoint
// throttling, which avgMs alone cannot show. It is measured from the arrival stamps rather than derived
// as avgMs/PARALLEL precisely so it can disagree with that ideal.
//
// (newest − oldest) / (n − 1): the mean of the n−1 gaps actually observed BETWEEN two images. The two
// open-ended edges — window start to the first arrival, last arrival to now — are deliberately not
// gaps; neither is bounded by two samples, and the trailing one is already on screen one row up as
// 'Last image — 42s ago'. Needs two samples to have a gap at all; below that it reports zero, which the
// caller must tell apart from a real zero by checking n rather than the value.
//
// staleMs is that trailing edge, reported rather than folded in. It exists because leaving it out is
// right for an ordinary hiccup and badly wrong for a stall: 40 images arriving in a two-minute burst at
// the far end of the window, then an endpoint that dies, still measures a 3.1s mean gap eighteen minutes
// later. Clamping the newest edge to `now` would bury the stall inside a number that is then neither the
// observed rate nor the silence — so the caller gets both and suppresses the rate instead (timingValue).
function windowStat(buf, now, windowMs) {
  let n = 0, total = 0, newest = 0, oldest = 0;
  for (let i = buf.length - 1; i >= 0; i--) {
    if (now - buf[i].t > windowMs) break;
    if (!n) newest = buf[i].t;
    oldest = buf[i].t;
    n++; total += buf[i].ms;
  }
  return { n, avgMs: n ? total / n : 0, gapMs: n > 1 ? (newest - oldest) / (n - 1) : 0,
           staleMs: n ? Math.max(0, now - newest) : 0 };
}

// How quiet it has to have gone before "one lands every 1.6s" stops describing the present. Both halves
// are load-bearing: the multiple is what adapts to a slow pipeline (a 30s gap earns two minutes of
// grace), and the floor is what stops a fast one being called stalled over a perfectly ordinary pause
// while the scheduler brainstorms. A minute of nothing is not a hiccup at any rate this panel reports.
const TIMING_GAP_STALE_MULT = 4;
const TIMING_GAP_STALE_FLOOR_MS = 60 * 1000;
function timingGapIsStale(stat) {
  return stat.n > 1 && stat.staleMs > Math.max(TIMING_GAP_STALE_FLOOR_MS, TIMING_GAP_STALE_MULT * stat.gapMs);
}

// "20m" once there is twenty minutes of history, the real span before that.
function fmtSpan(ms) { return fmtElapsed(ms, { coarse: true, min: 1 }); }

// Reads in the order you ask the questions: how long each one takes, how often one arrives, how many
// there were, over what span. It has to stand alone — the pipeline panel is pointer-events:none, so
// there is no tooltip and no ⓘ to lean on. Two different empty states, because "nothing has happened
// yet" and "nothing has happened lately" are different answers: the first matches the wording
// 'Last image' already uses.
//
// opts.each and opts.gap are the words that keep two durations on one line from reading as one number
// restated. A row with a single duration passes neither and is left exactly as it was — the bare
// number is unambiguous when it is the only one there, and naming it would be noise.
//
// The Math.max(1, …) is load-bearing on BOTH durations: fmtDur returns '' for a falsy argument and
// statsRows drops any row whose value is '', so a figure rounding to zero would delete its own row
// instead of showing it. Reachable on the gap as well as the average — five parallel images can finish
// inside the same millisecond.
function timingValue(stat, spanMs, everHappened, one, many, opts) {
  const span = fmtSpan(spanMs);
  if (!stat.n) return everHappened ? `none in the last ${span}` : 'none yet';
  const each = fmtDur(Math.max(1, Math.round(stat.avgMs))) + (opts && opts.each ? ` ${opts.each}` : '');
  // Gated on n, not on gapMs being truthy: five parallel images can land inside the same millisecond,
  // and a real gap of zero is a measurement, not a missing one. Testing the value would print the same
  // thing for "they arrived together" as for "there is only one of them", which are opposite readings.
  // Dropped entirely once the pipeline has gone quiet for long enough (timingGapIsStale): "one lands
  // every 3.1s" is present tense and would sit one row under "Last image — 18m 0s ago" contradicting it.
  // Only the RATE goes — the average beside it is a labelled fact about those samples ("8.1s to generate
  // … in the last 20m") and stays true whether or not more are coming. Nothing replaces it: the row above
  // already says how long the silence has been, in the words that row has always used.
  const gap = opts && opts.gap && stat.n > 1 && !timingGapIsStale(stat)
    ? ` · ${opts.gap} ${fmtDur(Math.max(1, Math.round(stat.gapMs)))}`
    : '';
  return `${each}${gap} · ${stat.n} ${stat.n === 1 ? one : many} in the last ${span}`;
}

// Position a panel next to an anchor, clamped to the viewport. Mirrors showProvTip's approach: draw to
// the LEFT of the sidebar so a pass-through box never lands back on its own trigger and hover-traps.
function placeStats(box, anchorEl) {
  // Remembered so ▾ Show all can re-place against the same anchor. On the box rather than in a module
  // variable because two boxes share this placer — the ❓ panel and the tree's hover card.
  box._statsAnchor = anchorEl;
  const sidebar = document.getElementById('sidebar');
  const inSidebar = !!(sidebar && sidebar.contains(anchorEl));
  const M = 8;
  const r = anchorEl.getBoundingClientRect();
  const roomBelow = window.innerHeight - r.bottom - M * 2;
  const roomAbove = r.top - M * 2;

  // Cap the height BEFORE measuring. Uncapped, a panel carrying a long value (the whole instruction
  // behind "📌 Born under" is the usual offender) grows past the bottom of the screen and takes the rows
  // under it — and the 🌳 button — with it. Capped to the room actually available on the side it's drawn
  // on, the overflow scrolls inside .statsBody instead. The box is a singleton shared with the pipeline
  // panel, so both edges are reset first: a stale `bottom` from the last placement would fight the new
  // `top` and stretch the panel.
  box.style.top = 'auto';
  box.style.bottom = 'auto';
  box.style.maxHeight = Math.max(160, inSidebar ? window.innerHeight - M * 2 : Math.max(roomBelow, roomAbove)) + 'px';
  const br = box.getBoundingClientRect();

  let left;
  if (inSidebar) {
    left = sidebar.getBoundingClientRect().left - br.width - 10;
    box.style.top = Math.round(Math.max(M, Math.min(r.top, window.innerHeight - br.height - M))) + 'px';
  } else {
    left = r.left + r.width / 2 - br.width / 2;   // tile: centred under the flag row
    if (br.height <= roomBelow || roomBelow >= roomAbove) {
      box.style.top = Math.round(Math.max(M, Math.min(r.bottom + M, window.innerHeight - br.height - M))) + 'px';
    } else {
      // Flipped above the tile, anchored by its BOTTOM edge rather than its top: expanding a clamped row
      // grows the panel, and a top-anchored flipped panel would grow back down over the ❓ that opened it.
      box.style.bottom = Math.round(Math.max(M, Math.min(window.innerHeight - r.top + M, window.innerHeight - br.height - M))) + 'px';
    }
  }
  box.style.left = Math.round(Math.min(Math.max(M, left), window.innerWidth - br.width - M)) + 'px';
}

function hideStats() {
  if (_statsBox) { _statsBox.style.display = 'none'; delete _statsBox.dataset.pinned; delete _statsBox.dataset.clickPin; }
  infoTipHide();   // an ⓘ explainer lives on the body, not in this box, so it has to be told the box went
  _statsMode = null;
  clearTimeout(_statsCloseTimer);   // drop any pending tile-mode close so it can't fire after a reopen
  if (_statsTick) { clearInterval(_statsTick); _statsTick = null; }
}

/* ---- Feature A: pipeline panel ---- */

// The single most useful line in the panel: the scheduler bails out for six different reasons and all
// of them look identical from outside (the sidebar just sits there). First match wins, mirroring the
// order of the guards in schedule() and ensureUntestedStock().
function pipelineWhy() {
  if (st.paused) return ['Paused', 'manually', 'warn'];
  if (st.anySidebarFocus) return ['Paused', "you're editing a prompt", 'warn'];
  if (!st.started) return ['Idle', 'not started yet', 'warn'];
  // Only the images half gets a line here — this whole row is about image throughput. A prompts-only
  // pause shows up on the brainstorming row instead (see bsV below), which is what it actually stops.
  if (st.pausedImages) return ['Paused', 'new images — prompts still being written', 'warn'];
  if (isLeadCapReached()) return ['Paused', `unseen images — scroll down to resume`, 'warn'];
  const now = Date.now();
  const untested = getUntestedPrompts();
  const ready = untested.filter(p => now >= (p.readyAt || 0));
  if (!st.firstImageShown && st.inflight === 0 && ready.length < st.params.MIN_PROMPTS_READY) {
    return ['Warming up', `${ready.length}/${st.params.MIN_PROMPTS_READY} prompts ready`, 'warn'];
  }
  if (!ready.length && untested.length) {
    const soonest = Math.min(...untested.map(p => (p.readyAt || 0) - now).filter(d => d > 0));
    return ['Waiting', `all ${untested.length} prompts cooling, next in ${Math.ceil(soonest / 1000)}s`, 'warn'];
  }
  // Without ⏳ this state would be reusing used or 📌 stale prompts; with it, held-back tasks wait for the
  // AI — reported even while a few images are still finishing, since the rest are what's stuck. (No
  // untested prompts at all; cooling ones were reported just above.)
  if (st.freshPromptsOnly && !untested.length && st.waiting.length) {
    const busy = st.inflight ? `${st.inflight} generating, the rest ` : '';
    // ensureUntestedStock writes nothing while prompt writing is paused, so don't promise prompts
    if (st.pausedPrompts) return ['Paused', `${busy}waiting — ⏳ on, prompt writing paused`, 'warn'];
    return ['Waiting', `${busy}for fresh prompts (⏳)`, 'warn'];
  }
  if (!ready.length && st.textGenBusy) return ['Brainstorming', 'no prompts ready yet', 'warn'];
  if (!ready.length && st.suggestBusy) return ['Waiting', 'for your ✨ suggestion, then new prompts', 'warn'];
  return ['Running', `${st.inflight} image${st.inflight === 1 ? '' : 's'} generating`, 'ok'];
}

function renderPipelineStats() {
  const box = statsBox();
  const now = Date.now();
  const untested = getUntestedPrompts();
  const ready = untested.filter(p => now >= (p.readyAt || 0));
  const cooling = untested.length - ready.length;
  let coolingStr = '';
  if (cooling > 0) {
    const soonest = Math.min(...untested.map(p => (p.readyAt || 0) - now).filter(d => d > 0));
    coolingStr = `, ${cooling} cooling (next in ${Math.ceil(soonest / 1000)}s)`;
  }

  // Both averages cover the same window, and the label says which — TIMING_WINDOW_MS once the buffers
  // have existed that long, the real span before that, so a panel opened two minutes into a run reports
  // two minutes rather than claiming twenty it cannot cover.
  const bsStat  = windowStat(st.textGenTimes, now, TIMING_WINDOW_MS);
  const imgStat = windowStat(st.imageTimes,   now, TIMING_WINDOW_MS);
  const spanMs  = Math.min(TIMING_WINDOW_MS, Math.max(0, now - st.timingsSince));

  const [whyK, whyV, whyCls] = pipelineWhy();
  const strategy = [
    st.creativity === 2 ? 'creative' : st.creativity === 1 ? 'balanced' : 'faithful',
    st.allowPromptMixing ? 'mixed' : null,
    st.promoteUpvoted ? 'promote' : null,
    st.freshPromptsOnly ? 'fresh only' : null
  ].filter(Boolean).join(' + ');

  // Text-gen status, always shown. The scheduler stops brainstorming the moment untested stock reaches
  // the target (targetUntestedStock) — so an idle pipeline that still has plenty of prompts is
  // *satisfied*, not stuck. Spell that out, otherwise the quiet panel reads as a stall.
  const bsTarget = targetUntestedStock();
  const bsLabel = 'Prompt brainstorming';
  let bsV;
  if (st.textGenBusy)                   { bsV = fmtDur(now - st.textGenStartedAt) + ' elapsed'; }
  else if (!st.started)                 bsV = 'not started';
  else if (st.suggestBusy)              bsV = 'on hold for ✨ suggestion' + (st.suggestStartedAt ? ` (${fmtDur(now - st.suggestStartedAt)})` : '');
  else if (st.pausedPrompts)            bsV = 'paused manually';
  else if (st.anySidebarFocus)          bsV = 'paused — editing a prompt';
  else if (untested.length >= bsTarget) bsV = `idle — stock full (${untested.length}/${bsTarget})`;
  else                                  bsV = `topping up (${untested.length}/${bsTarget})`;

  statsRows(box, [
    [whyK + ':', whyV, 'statsWhy ' + whyCls],
    [bsLabel, bsV],
    st.textGenBusy && st.textGenSteer ? ['🧲 steered by', `"${st.textGenSteer}"`, 'statsClip'] : null,
    st.textGenBusy && st.textGenBatchRule ? ['📏 batch rule', `"${st.textGenBatchRule}"`, 'statsClip'] : null,
    st.textGenBusy && st.suggestBusy ? ['✨ Suggestion', 'next, after this brainstorm'] : null,
    !st.textGenBusy && st.lastTextGenMs ? ['Last batch', `${st.lastTextGenCount} prompts in ${fmtDur(st.lastTextGenMs)}`] : null,
    // Each average sits directly under the single-event row it generalises. One sample from an LLM
    // endpoint whose latency swings by 5× says nothing about whether the run is slow; the average does.
    // "brainstorm" rather than "batch" because the panel already uses that word for writing prompts, and
    // "batch" alone is a coin flip between a batch of prompts and a batch of images on first read.
    // lastTextGenMs/lastImageAt double as the "has anything happened yet" test — both are reset on
    // restore alongside the buffers, so they answer for THIS run, not the one being resumed.
    // No "one lands every" here, unlike the image row: brainstorms run one at a time, so their gap is
    // just this duration plus however long the scheduler chose to sit idle — and why it is idle is the
    // 'Prompt brainstorming' row at the top, in words, rather than inferred from a number.
    ['Avg brainstorm', timingValue(bsStat, spanMs, !!st.lastTextGenMs, 'batch', 'batches')],
    ['Last image', st.lastImageAt ? fmtAgo(st.lastImageAt) : 'none yet'],
    // Two numbers, because with PARALLEL images in flight they are different questions and only the
    // second one is the rate you actually feel: "8.1s to generate" is one image's own latency, "one
    // lands every 1.6s" is how often the feed grows. The words are in the value rather than implied,
    // because a bare "8.1s · 1.6s" would read as one number restated — and because the gap between the
    // two IS the parallelism working, which is worth being able to see. The row below says how many run
    // at once, so a gap far above avg ÷ that number is a starved queue or a throttling endpoint.
    ['Avg image', timingValue(imgStat, spanMs, !!st.lastImageAt, 'image', 'images',
      { each: 'to generate', gap: 'one lands every' })],
    ['Images', `${st.inflight}/${st.params.PARALLEL} generating`],
    ['Prompt stock', `${ready.length} ready${coolingStr}`],
    ['Instruction', `v${st.instVersion}` + (st.staleBridgeMode > 0 && !st.freshPromptsOnly && isBridgeActive() ? ' · stale-bridge active' : '')],
    ['Strategy', strategy],
    ['Batches', String(st.numPromptBatchesGenerated)]
  ], '⚙️ Pipeline');

  // Read-only and never hovered (it closes on sidebarStatus mouseleave), so nothing here can be scrolled
  // or expanded. That cuts both ways for the steer row: a hover-to-expand clamp would be a dead control,
  // but the statsClip it gets instead is a hard truncation with no way to see the rest. Clipping still
  // wins — the steer is the one unbounded string here, and left alone it pushes the rows under it past a
  // panel that can't be scrolled to reach them. Six lines is the budget: enough for any steer worth
  // typing, short enough that Images/Prompt stock/Instruction stay on screen behind it.
  box.style.pointerEvents = 'none';
  box.style.display = 'flex';
  placeStats(box, sidebarStatus);
}

function showPipelineStats() {
  if (_statsMode === 'pipeline') return;
  hideStats();
  _statsMode = 'pipeline';
  renderPipelineStats();
  // Re-render on our own interval so elapsed timers actually count up. Deliberately not driven by
  // renderSidebar's tick: this panel outlives the status line's innerHTML churn.
  _statsTick = setInterval(() => { if (_statsMode === 'pipeline') renderPipelineStats(); }, 500);
}

// mouseenter/mouseleave on the stable #sidebarStatus element, NOT delegation on its children:
// renderSidebarStatus replaces the children wholesale, and mouseleave only fires when the pointer
// actually crosses the element's own boundary, so an inner rebuild can't close the panel.
sidebarStatus.addEventListener('mouseenter', () => { if (!STATS_NO_HOVER) showPipelineStats(); });
sidebarStatus.addEventListener('mouseleave', () => { if (_statsMode === 'pipeline') hideStats(); });
// No hover on a touchscreen, so a tap toggles it; a press anywhere else closes it (the pointerdown below).
// The banner's own buttons (Done editing · resume) keep their job.
sidebarStatus.addEventListener('click', (e) => {
  if (!STATS_NO_HOVER || e.target.closest('button')) return;
  if (_statsMode === 'pipeline') hideStats(); else showPipelineStats();
});

/* ---- ⓘ explainers ----
   A small ⓘ beside a control that opens a plain-language note about what the control does — for the
   things a first-time user will misread from the label alone and won't open Help to check. Today that's
   the two mark buttons in the ❓ card: "influence" sounds like it changes generation, and it doesn't.

   The note is ONE body-level singleton, pointer-events:none. Both halves are load-bearing. The ❓ card
   closes 180 ms after the pointer leaves it, so a note that could take the pointer would close the card
   it's explaining; and the card's body scrolls, so a note inside it could be clipped. The ⓘ itself stays
   inside the card, which is what keeps the card open while you read.

   Desktop: hover, or keyboard focus. Touch has no hover, so a tap toggles it instead — and the hover and
   focus paths stand down there, because a tap also fires emulated mouseenter and (on most browsers) focus,
   which would open the note a moment before the tap's click closed it again. */
function infoTipHide() {
  if (_infoTipPop) _infoTipPop.style.display = 'none';
  _infoTipFor = null;
}

function infoTipShow(btn) {
  if (!_infoTipPop) {
    _infoTipPop = document.createElement('div');
    _infoTipPop.id = 'infoTipPop';
    _infoTipPop.setAttribute('role', 'tooltip');
    document.body.appendChild(_infoTipPop);
  }
  const pop = _infoTipPop;
  _infoTipFor = btn;
  pop.textContent = btn._infoText;
  pop.style.display = 'block';
  // Beside the ⓘ, right side first; flipped left when the right edge has no room (a card near the right of
  // the feed), then clamped so a narrow screen still gets the whole note.
  const M = 8;
  const r = btn.getBoundingClientRect(), pr = pop.getBoundingClientRect();
  let left = r.right + M;
  if (left + pr.width > window.innerWidth - M) left = r.left - pr.width - M;
  left = Math.max(M, Math.min(left, window.innerWidth - pr.width - M));
  const top = Math.max(M, Math.min(r.top + r.height / 2 - pr.height / 2, window.innerHeight - pr.height - M));
  pop.style.left = Math.round(left) + 'px';
  pop.style.top = Math.round(top) + 'px';
}

function infoTipButton(text) {
  const b = document.createElement('button');
  b.type = 'button';
  b.className = 'infoTip';
  b.textContent = 'ⓘ';
  b.setAttribute('aria-label', text);   // a screen reader gets the note without the popover
  b._infoText = text;
  b.addEventListener('mouseenter', () => { if (!STATS_NO_HOVER) infoTipShow(b); });
  b.addEventListener('mouseleave', () => { if (!STATS_NO_HOVER) infoTipHide(); });
  // Keyboard focus only: a mouse click also focuses the button, and the hover path already has that covered.
  b.addEventListener('focus', () => {
    let kb = false;
    try { kb = b.matches(':focus-visible'); } catch (e) {}
    if (kb && !STATS_NO_HOVER) infoTipShow(b);
  });
  b.addEventListener('blur', () => { if (_infoTipFor === b) infoTipHide(); });
  b.addEventListener('click', (e) => {
    e.stopPropagation();
    if (!STATS_NO_HOVER) return;
    if (_infoTipFor === b) infoTipHide(); else infoTipShow(b);
  });
  return b;
}

// Wording agreed for the two mark buttons. Each leads with what the control does NOT do, because that's
// the misreading; the rest is what it's for.
const INF_MARK_EXPLAIN = "Records this image as an influence on your next instruction — shown in 🔖 Influences while you rewrite, and in the 🌳 tree after. It doesn't change what's being generated.";
const INF_ANTI_EXPLAIN = "Records this image as a look to move away from — shown in red in 🔖 Influences while you rewrite, and in the 🌳 tree after. It doesn't change what's being generated; nothing is avoided automatically.";

/* ---- Feature B: per-tile panel ---- */

function renderTileStats(el) {
  const task = st.tasksById[el.dataset.tid];
  const p = task ? st.prompts[task.promptId] : null;
  if (!task && !p) return false;
  const box = statsBox();
  infoTipHide();   // a re-render replaces the ⓘ an open note was anchored to

  const flags = p ? promptProvenance(p, task) : [];   // same per-image view the tile's flag row shows
  const has = ic => flags.some(f => f.icon === ic);

  // The Prompt row is the resolved string actually sent. This panel used to omit it on the grounds that
  // the tile's own hover caption already showed it — but that caption is now a pointer-inert one-line
  // label (it no longer un-clamps under the cursor), so this panel is the only place the full text can
  // be read and it MUST carry it. The reversal is the point: the caption stopped being the interactive
  // one, so what was duplication is now the only path to the prompt.
  // Template stays separate and stays conditional — it's the braced source behind a randomized pick, and
  // with no {a|b} and no prefix/suffix it is character-for-character the Prompt row above it.
  const resolved = (task && task.resolvedText) || (p ? p.text : '');
  const template = (p && resolved && resolved !== p.text) ? p.text : '';

  const knobs = (() => {
    const o = p && p.origin || '';
    const parts = [];
    if (o.includes('promoted')) parts.push('promoted');
    if (o.includes('creative')) parts.push('creative');
    if (o.includes('mixed')) parts.push('mixed');
    return parts.join(' + ');
  })();

  // Flag-linked rows are emitted whenever their flag is visible, falling back to "not recorded" —
  // a tile claiming 🧲/📌 whose panel says nothing about it reads as broken. Rows with no
  // corresponding flag simply vanish when their data is absent. The REVERSE is intended for 🧲 and ⭐:
  // the panel can name a steer/capture the tile no longer badges, because those badges mark a
  // current state (an active, unused prompt) while the panel reports durable knowledge that outlives it.
  // So key this row on the raw fields, not has('🧲') — the badge retires on the first image (see the
  // p.used += 1 site), but influenceText is kept, and the disjunction covers all three states: unused
  // steered → badge + row; used steered → no badge, row still names the steer; steer-history cleared
  // while unused → badge + "not recorded". Mirrors the ⭐ Captured row below, which reads p.origin
  // directly for the same reason.
  // "(inherited)" separates a prompt captured from a steered image from one born in the steer's own
  // batch. Without it both read as first-hand, and the ⭐ Captured row two below doesn't disambiguate
  // them — it says this prompt came from an upvote, not that its steer did.
  const steerSuffix = (p && p.influenceInherited) ? ' (inherited)' : '';
  const steerRow = (p && (p.influenced || p.influenceText))
    ? ['🧲 Steered by', (p.influenceText ? `"${p.influenceText}"` : 'not recorded') + steerSuffix, 'statsClampable']
    : null;
  // 📏 The every-batch rule this prompt's batch was written under — the rolled variant, not the {a|b}
  // source. No badge backs it (every prompt would carry one), so no "not recorded" fallback either.
  const batchRuleRow = (p && p.batchRule) ? ['📏 Batch rule', `"${p.batchRule}"`, 'statsClampable'] : null;
  const staleRow = has('📌')
    ? ['📌 Born under', (st.instHistory && st.instHistory[p.ver])
        ? `v${p.ver}: "${st.instHistory[p.ver]}"`
        : `v${p.ver} — instruction not recorded`, 'statsClampable']
    : null;
  // 💭 What that version was FOR, directly under what it said — it turns "born under v5" from a serial
  // number into a reason. Its own row rather than appended to the quote above, which is already the row
  // most likely to overflow this panel (see placeStats), and clampable for the same reason.
  const bornWhyRow = (staleRow && st.instWhy && st.instWhy[p.ver])
    ? ['💭 Why', st.instWhy[p.ver], 'statsClampable']
    : null;
  // Committed 🔖 history is a ROW, never the button's state. The button below asks "is this image in the
  // set I'm collecting for my NEXT instruction?", which an image already recorded against v3 can perfectly
  // well rejoin — it's still a good image. Two different questions, so two different controls.
  // 🚫 history gets its own row by the same rule; an image can carry both (🔖 for v3, 🚫 for v5).
  const infVers = task ? infCommittedVersions(task, false) : [];
  const infRow = infVers.length ? ['🔖 Influenced', infVers.map(v => 'v' + v).join(', ')] : null;
  const antiVers = task ? infCommittedVersions(task, true) : [];
  const antiRow = antiVers.length ? ['🚫 Anti-influence', antiVers.map(v => 'v' + v).join(', ')] : null;

  // The free-text rows are `statsClampable`: their values are user/LLM text with no length bound — an
  // instruction is routinely several paragraphs — and an unclamped one used to make this panel taller
  // than the screen, burying the rows below it and the 🌳 button. Clamped to three lines, unfolded only
  // by the row's own "▾ Show all" button, and capped at statsCap's ceiling so even unfolded they are
  // bounded. The panel is bounded on every other axis too: max-width 360px, a max-height placeStats sets
  // from the room actually beside the tile, and a body that scrolls rather than grows.
  // "Prompt stats" below is deliberately not called "Prompt" any more — that label now belongs to the
  // text, and two rows named the same thing would be a coin flip for a first-time reader.
  statsRows(box, [
    resolved ? ['Prompt', resolved, 'statsPrompt statsClampable'] : null,
    template ? ['Template', template, 'statsPrompt statsClampable', 'The prompt before its {a|b} choices were drawn and the prefix/suffix added'] : null,
    steerRow,
    batchRuleRow,
    staleRow,
    bornWhyRow,
    infRow,
    antiRow,
    p && p.origin === 'upvoted' ? ['⭐ Captured', 'from a like'] : null,
    p && p.origin === 'manual' ? ['✏️ Added', 'by hand'] : null,
    knobs ? ['Written with', knobs] : null,
    task && task.seed != null ? ['Seed', String(task.seed)] : null,
    task && task.resolution ? ['Size', RESOLUTIONS[task.resolution] || task.resolution] : null,
    task && task.genMs ? ['Took', fmtDur(task.genMs)] : null,
    p ? ['Prompt stats', promptLikeStats(p)] : null,
    p ? ['Version', `v${p.ver}` + (p.ver !== st.instVersion ? ` — current is v${st.instVersion}` : '')] : null
  ], '❓ Image details');

  // Unlike the pipeline panel this one takes the pointer: the body scrolls and the clampable rows expand
  // on hover, neither of which works through pointer-events:none. The trade is that it covers whatever
  // tile it overlaps while open — acceptable for a hover card that closes 180ms after the pointer leaves
  // (statsBox's mouseenter/mouseleave keep it up for as long as the pointer is inside it).
  // The 🌳 button opens the prompt generation tree centered on this image's prompt; omitted when no
  // prompt resolves (error card / restored image with promptId null) — nothing to root a tree on (Gap #5).
  // It deliberately has no hover listeners of its own: the box already handles hover-intent, and a
  // mouseleave here would schedule a close while the pointer is still inside the panel (the box's
  // mouseenter can't re-fire to cancel it, because the pointer never left the box).
  box.style.pointerEvents = 'auto';
  if (p) {
    const treeBtn = document.createElement('button');
    treeBtn.className = 'pgtOpenBtn';
    treeBtn.textContent = '🌳 Prompt tree';
    treeBtn.onclick = (ev) => {
      ev.stopPropagation();
      statsCancelClose();
      hideStats();
      pgtOpen(p.id, { taskId: task ? task.id : null });
    };
    box.appendChild(treeBtn);
  }
  if (resolved) {
    const copyBtn = document.createElement('button');
    copyBtn.className = 'pgtOpenBtn';
    copyBtn.textContent = '📋 Copy prompt';
    copyBtn.title = 'Copy the prompt exactly as this image was drawn from it';
    copyBtn.onclick = async (ev) => {
      ev.stopPropagation();
      statsCancelClose();
      try { await navigator.clipboard.writeText(resolved); copyBtn.textContent = '✓ Copied'; }
      catch (err) { copyBtn.textContent = "Couldn't copy"; }
      setTimeout(() => { copyBtn.textContent = '📋 Copy prompt'; }, 1200);
    };
    box.appendChild(copyBtn);
  }

  // 🔖 Mark as influence. Keyed on the TASK, not the prompt: an image with no resolvable prompt (an error
  // card, a restored image whose prompt was trimmed) is still an image you can bookmark, because the
  // record snapshots its resolved wording rather than pointing at the prompt for it.
  // Re-renders IN PLACE — statsCancelClose() then rebuild, never hideStats() — the same trick the 🌳
  // button uses to survive its own click. Marking several images from one open card is the normal way to
  // use this, and a card that shut itself on every click would make that a chore.
  // 🚫 Mark as anti-influence sits under it, same mechanics. At most one of the two is lit: pending marks
  // are exclusive, so clicking the unlit one while the other is lit FLIPS the mark, and the in-place
  // re-render updates both buttons at once.
  // Neither button has a title= any more: its ⓘ says what it does, and saying it twice is noise.
  if (task) {
    const markRow = (anti) => {
      const marked = infIsMarked(task, anti);
      const noun = anti ? 'anti-influence' : 'influence';
      const markBtn = document.createElement('button');
      markBtn.className = 'pgtOpenBtn infMarkBtn' + (marked ? (anti ? ' infMarkedAnti' : ' infMarked') : '');
      markBtn.textContent = marked ? '✓ Marked as ' + noun : 'Mark as ' + noun;
      markBtn.onclick = (ev) => {
        ev.stopPropagation();
        statsCancelClose();
        infToggleMark(task, anti);
        // The mark rebuilt this tile's flag row wholesale, which DESTROYED the ❓ we're anchored to. Re-find
        // the fresh one before re-rendering: placeStats measures its anchor, and a detached node reports
        // all-zeros, so the card would jump to the top-left corner and stay there — showTileStats returns
        // early while the tid matches, so even re-hovering the tile wouldn't put it back.
        const anchor = (task.ui && task.ui.flagsRow && task.ui.flagsRow.querySelector('.promptFlagInfo')) || el;
        renderTileStats(anchor);   // labels, the 🔖/🚫 rows and the composer's count all move together
      };
      const row = document.createElement('div');
      row.className = 'infMarkRow';
      row.appendChild(markBtn);
      row.appendChild(infoTipButton(anti ? INF_ANTI_EXPLAIN : INF_MARK_EXPLAIN));
      return row;
    };
    box.appendChild(markRow(false));
    box.appendChild(markRow(true));
  }

  box.style.display = 'flex';
  markClamped(box);            // needs the panel visible to measure, and runs before placeStats so the
  placeStats(box, el);         // "▾ Show all" buttons are part of the height it's positioned by
  return true;
}

function showTileStats(el) {
  statsCancelClose();   // pointer came back to the ❓ before a pending close fired
  // Already up for THIS tile → leave it exactly as it is. Rebuilding would reset the body's scroll
  // position and drop any row the reader pinned open, which is easy to trigger: the pointer only has to
  // graze the ❓ again on its way back out of the panel. (Tested against 'none', not a specific display
  // value — the box is a flex column, and a literal was silently wrong once already.)
  if (_statsMode === 'tile' && _statsBox && _statsBox.dataset.tid === el.dataset.tid && _statsBox.style.display !== 'none') return;
  hideStats();
  _statsMode = 'tile';
  statsBox().dataset.tid = el.dataset.tid || '';
  if (!renderTileStats(el)) hideStats();
}

document.addEventListener('mouseover', (e) => {
  if (!e.target || !e.target.closest) return;
  const el = e.target.closest('.promptFlagInfo');
  if (el) showTileStats(el);
});
document.addEventListener('mouseout', (e) => {
  if (!e.target || !e.target.closest) return;
  const el = e.target.closest('.promptFlagInfo');
  if (!el) return;
  if (e.relatedTarget && el.contains(e.relatedTarget)) return;
  if (e.relatedTarget && _statsBox && _statsBox.contains(e.relatedTarget)) return;   // drifting straight onto the 🌳 button — keep it
  if (_statsMode === 'tile') statsScheduleClose();   // delayed, so the pointer can bridge ❓ → 🌳 button
});

// The tile panel takes the pointer, so while it is up it swallows clicks on whatever tile it overlaps.
// Hover closes it on the way out, but touch has no "on the way out": without this the only dismissal is
// finding the ❓ again, and every tap that lands on the panel does nothing. Capture phase so the tap that
// closes it isn't first consumed by something inside the covered tile.
document.addEventListener('pointerdown', (e) => {
  const t = e.target;
  if (!t || !t.closest) return;
  if (_statsMode === 'pipeline' && STATS_NO_HOVER) { if (!sidebarStatus.contains(t)) hideStats(); return; }
  if (_statsMode !== 'tile' || !_statsBox) return;
  if (_statsBox.contains(t) || t.closest('.promptFlagInfo, .promptFlag')) return;   // inside the panel, or a ❓ / mark that toggles it
  hideStats();
}, true);

/* Which presses on a tile count as a tap-to-upvote: the card itself and its <img>; the mark flags open
   the ❓ panel instead. Shared by all three card-building paths (live, restored-liked, restored-unliked)
   — it lived as six copies of one expression and drifted in intent, which is how the caption ended up
   voting.

   .promptHover is deliberately NOT in here. The caption is the one part of a tile people drag across and
   double-click to copy a prompt out of, and every one of those gestures landed as a vote — worst while it
   is expanded, since it then covers most of the tile. Reading and selecting the prompt must never move the
   score, so the caption takes no votes at all; the image around it still votes on a tap. */
// "Liked 2 of 5 images (40%)" — the score is that rate, so it's said as one rather than "2 votes / 5 uses · 0.40".
function promptLikeStats(p) {
  if (!p.used) return 'Not used for an image yet';
  return `Liked ${p.votes} of ${plural(p.used, 'image')} (${Math.round(100 * p.votes / p.used)}%)`;
}

function isUpvoteTapTarget(e, ui){
  return e.target === ui.card || e.target === ui.imgEl;
}

/* A tap, not a drag or a long press: released within TAP_MAX_MS and TAP_MAX_MOVE px of where it went down.
   The old test was time-only (≤200ms), so a quick flick to scroll liked the image under it, and a slower
   deliberate tap didn't count. One test for all three card paths, which used to carry a copy each. */
const TAP_MAX_MS = 500, TAP_MAX_MOVE = 8;
function isQuickTap(down, up) {
  return !!down && up.t - down.t <= TAP_MAX_MS && Math.hypot(up.x - down.x, up.y - down.y) <= TAP_MAX_MOVE;
}
function wireTileTap(ui, onTap) {
  let down = null;
  // Keyboard: the tile is focusable and Enter / Space likes it, the same as a tap. aria-pressed carries
  // the liked state for screen readers, which have no 👍 badge to see.
  ui.card.tabIndex = 0;
  ui.card.setAttribute('role', 'button');
  ui.card.setAttribute('aria-label', 'Image — Enter to like');
  ui.card.setAttribute('aria-pressed', String(!!ui.upvoted));
  // The like itself, also what the lightbox's 👍 calls, so every trigger goes through this card's own rules.
  ui.like = () => {
    onTap();
    ui.card.setAttribute('aria-pressed', String(!!ui.upvoted));
  };
  ui.card.onkeydown = (e) => {
    if (e.target !== ui.card || (e.key !== 'Enter' && e.key !== ' ')) return;
    e.preventDefault();
    ui.like();
  };
  ui.card.onpointerdown = (e) => {
    down = isUpvoteTapTarget(e, ui) ? { t: Date.now(), x: e.clientX, y: e.clientY } : null;
  };
  ui.card.onpointerup = (e) => {
    const d = down; down = null;
    if (!isUpvoteTapTarget(e, ui)) return;
    if (!isQuickTap(d, { t: Date.now(), x: e.clientX, y: e.clientY })) return;
    ui.like();
  };
}

/* 🖼️ Save, shared by the four tile save buttons (live, plugin-viewer, restored liked, restored unliked).
   A second press used to add a second copy and a failure only reached the console: the button now says
   "✓ Saved" and stays off once it worked, and a failure says so in a toast. `blobOrUrl` is the original
   (a Blob) or a URL to fetch it from. Anything not a Blob is a URL: the image plugin hands back its URL as
   a String OBJECT carrying .inputs (the seed), which a typeof 'string' test missed — the URL itself then
   went to the gallery as if it were the image. */
async function saveTileToGallery(btn, blobOrUrl, info, animate) {
  if (!btn || btn.disabled) return;
  btn.disabled = true;
  // `_saving` / `_saved` let the lightbox tell a save in flight from a finished one (both disable the button).
  let settle;
  btn._saving = new Promise(r => { settle = r; });
  try {
    const g = ensureGallery();
    const blob = blobOrUrl instanceof Blob ? blobOrUrl : await fetch(String(blobOrUrl)).then(r => r.blob());
    await g.add(blob, { info });
    btn._saved = true;
    btn.textContent = '✓ Saved';
    btn.title = 'Saved to 🖼️ Saved';
    if (animate) animate();
  } catch (err) {
    btn.disabled = false;
    console.warn('Save failed:', err);
    showToast("Couldn't save this image to 🖼️ Saved" + (err && err.message ? ' — ' + err.message : ''), { kind: 'error' });
  } finally {
    btn._saving = null;
    settle();
  }
}
function tileSaveInfo(task, promptObj, seed) {
  return { prompt: String(task.resolvedText || (promptObj && promptObj.text) || ''), seed: seed != null ? String(seed) : '' };
}

/* The upvote toggle itself, shared by the two LIVE card paths: the thumbnail card's tap handler and the
   plugin-viewer overlay's 👍 button. Only the trigger differs — the vote, the ⭐ variant fork, the
   upvotedTasks bookkeeping and the logging all have to agree between them, and as two copies they only
   stayed in agreement by being edited twice. Callers own their own chrome and read the new state back off
   ui.upvoted afterwards.

   The two RESTORED-card paths deliberately don't come through here: they have to survive a null promptObj
   (a promptless tile round-tripping through `images`), reuse the stored 128px thumbnail rather than
   re-encoding, drive their own thumbBadge, and log `restored: true`. Folding those differences in as flags
   would cost more than the duplication saves. */
function toggleUpvote(task, ui, promptObj, resolvedText){
  ui.upvoted = !ui.upvoted;
  ui.card.classList.toggle('upvoted', ui.upvoted);
  const p = promptObj;
  if (ui.upvoted){
    p.votes += 1;
    incrementLikeCount();
    if (helpHint.style.display==='block'){ helpHint.style.display='none'; incrementHelpDismiss(); }

    st.upvotedTasks.push({
      taskId: task.id,
      promptId: task.promptId,
      imgEl: ui.imgEl,
      resolvedText: resolvedText,
      cacheId: task.cacheId || null
    });
    updateSessionButtons();
    scheduleAutosave();

    if (st.autoQueueVariant && /\{[^{}]+\}/.test(p.text) && resolvedText && !/\{/.test(resolvedText)){
      // Pin the resolved variant of an upvoted braced prompt under its own 'upvoted' origin (⭐
      // "Recently upvoted") — captured from an image you upvoted, so NOT 'manual' (not hand-typed).
      // Gated by st.autoQueueVariant (Settings → Prompt Queue, session setting) — off means the like counts but doesn't fork a prompt.
      // influenceText carries over so a capture from a 🧲-steered prompt keeps saying where its
      // wording came from; the transient p.influenced flag deliberately does not.
      // addPrompts dedups and logs evo_prompts_added itself, so no extra log here.
      addPrompts([resolvedText], 'upvoted', { parent: { kind: 'upvote', promptId: p.id, taskId: task.id }, influenceText: p.influenceText });
    }

    recomputeScore(p);
    logEvent('upvote', { promptId: p.id, votes: p.votes, used: p.used, score: p.score, promptText: p.text });
  } else {
    p.votes = Math.max(0, p.votes - 1);
    st.upvotedTasks = st.upvotedTasks.filter(t => t.taskId !== task.id);
    updateSessionButtons();
    scheduleAutosave();
    recomputeScore(p);
  }
  st.unseenCards.delete(ui.card);
}

function attachImageToCard(task, url, promptObj, resolvedText){
  cacheImage(url, promptObj, resolvedText, task.seed, task.resolution).then(id => { if (id != null) task.cacheId = id; });

  if (!st.firstImageShown){
    st.firstImageShown = true;
    if (shouldShowHelp()){ helpHint.style.display='block'; }
  }

  const ui = task.ui;
  const img = new Image(); img.src = url; img.alt = ''; img.className='imgEl';
  ui.inner.innerHTML=''; ui.inner.appendChild(img); ui.imgEl = img;

  /* promptHover is populated in onTaskComplete via attachImageToCard */
  setPromptHover(ui, resolvedText || (promptObj ? promptObj.text : ''));
  populateFlags(ui, promptObj, task);

  // Upvote on card click (only when an image exists)
  wireTileTap(ui, () => {
    toggleUpvote(task, ui, promptObj, resolvedText);
  });

  // Show fullscreen button
  ui.fsBtn.style.display='block';
  ui.fsBtn.onclick = (e)=>{ e.stopPropagation(); feedOpenLightbox(task); };

  // Save button
  ui.saveBtn.style.display='block';
  ui.saveEl = ui.saveBtn;
  ui.save = () => saveTileToGallery(ui.saveBtn, url, tileSaveInfo(task, promptObj, task.seed), () => {
    const ghost = img.cloneNode(false);   // animate into the 🖼️ Saved button
    ghost.src = img.src;
    animateImageIntoTarget({ imgEl: ghost, sourceEl: img, targetEl: showSavedBtn, durationMs:700, wiggle:true });
  });
  ui.saveBtn.onclick = (e)=>{ e.stopPropagation(); ui.save(); };
}

/* ===================== Plugin viewer card (iframe mode) ===================== */

function attachIframeOverlay(task, url, promptObj, resolvedText) {
  cacheImage(url, promptObj, resolvedText, task.seed, task.resolution).then(id => { if (id != null) task.cacheId = id; });

  if (!st.firstImageShown) {
    st.firstImageShown = true;
    if (shouldShowHelp()) helpHint.style.display = 'block';
  }

  const ui = task.ui;

  // Hidden <img> for the thumbnail/session-save path (compressImage reads this).
  const hiddenImg = new Image();
  hiddenImg.src = url;
  ui.imgEl = hiddenImg;

  setPromptHover(ui, resolvedText || (promptObj ? promptObj.text : ''));
  populateFlags(ui, promptObj, task);

  // Build the overlay bar: upvote, fullscreen, save — outside the iframe so clicks work.
  const bar = document.createElement('div');
  bar.className = 'ipoOverlayBar';

  const upBtn = document.createElement('button');
  upBtn.className = 'ovUpvoteBtn';
  upBtn.textContent = '👍';
  upBtn.title = 'Upvote';

  const fsb = document.createElement('button');
  fsb.textContent = '🔍';
  fsb.title = 'View full size';

  const svb = document.createElement('button');
  svb.textContent = '🖼️';
  svb.title = 'Save this image to 🖼️ Saved';

  bar.appendChild(upBtn);
  bar.appendChild(fsb);
  bar.appendChild(svb);
  ui.card.appendChild(bar);

  // Upvote via overlay button — same toggle as thumbnail mode, different trigger. The button's own
  // pressed state is this path's alone, so it's synced from ui.upvoted after the shared work.
  ui.like = () => {
    toggleUpvote(task, ui, promptObj, resolvedText);
    upBtn.classList.toggle('upvoted', ui.upvoted);
  };
  upBtn.onclick = (e) => { e.stopPropagation(); ui.like(); };

  fsb.onclick = (e) => { e.stopPropagation(); feedOpenLightbox(task); };

  ui.saveEl = svb;
  ui.save = () => saveTileToGallery(svb, url, tileSaveInfo(task, promptObj, task.seed), () => {
    const ghost = new Image();
    ghost.src = url;
    animateImageIntoTarget({ imgEl: ghost, sourceEl: ui.card, targetEl: showSavedBtn, durationMs: 700, wiggle: true });
  });
  svb.onclick = (e) => { e.stopPropagation(); ui.save(); };

  ui.fsBtn.style.display = 'none';
  ui.saveBtn.style.display = 'none';
}

/* ===================== Prompt list management ===================== */

// opts.allowDuplicates lets a manual add (typed prompt / sidebar inject / lightbox "Add to queue")
// create a second copy of an existing prompt on purpose. Auto-generation and upvote-capture leave it
// off so the LLM/pin paths still dedupe.
function addPrompts(texts, origin, opts){
  const allowDuplicates = !!(opts && opts.allowDuplicates);
  // Lineage for the prompt generation tree (§2). Both are set once at creation and never mutated,
  // just like provenance. Default parent = the instruction version this prompt was born under (it
  // becomes a trunk root); a caller that knows a stronger causal edge — upvote-capture, promote, a
  // generated batch — passes opts.parent instead. drewFrom (≤3 example mix-in ids) is supplied only
  // by generated batches; every other origin leaves it null.
  const parentOpt = (opts && opts.parent) || null;
  const drewFromOpt = (opts && Array.isArray(opts.drewFrom) && opts.drewFrom.length) ? opts.drewFrom : null;
  // 🧲 lineage inherited from a source prompt (upvote capture passes it; see the capture sites). This is
  // influenceText ONLY — permanent "this wording came from that steer". The transient p.influenced flag
  // is deliberately never inherited: it buys queue priority from the scheduler and re-arms Keep-🧲-only,
  // neither of which a captured copy has earned.
  //
  // Arriving through opts is exactly what makes a steer second-hand, so that's where the "(inherited)"
  // marker comes from — no separate flag for a caller to forget or set inconsistently. A prompt born in
  // the steer's own batch gets its influenceText assigned directly after addPrompts returns (see the
  // consumedSteer taint), never through here, so it stays unmarked and reads as first-hand.
  const influenceTextOpt = (opts && opts.influenceText) || null;
  const added=[];
  for (let t of texts){
    t = (''+t).trim();
    if (!t) continue;
    if (!isValidCurlyBlocks(t)){ continue; }
    if (!allowDuplicates){
      const exists = st.order.some(id => st.prompts[id] && st.prompts[id].text.toLowerCase()===t.toLowerCase());
      if (exists){ continue; }
    }
    const id = uid('p');
    st.prompts[id] = {
      id, text:t, used:0, votes:0, score:0, createdAt:Date.now(),
      ver: st.instVersion, stale:false, _claimed:0,
      readyAt: Date.now() + st.params.PROMPT_WAIT_MS,
      origin: origin || 'generated',
      parent: parentOpt || { kind: origin === 'manual' ? 'manual' : 'instruction', ver: st.instVersion },
      drewFrom: drewFromOpt ? drewFromOpt.slice(0, 3) : null,  // fresh copy per prompt (never shared)
      influenceText: influenceTextOpt,  // lineage only — p.influenced is transient and never inherited
      influenceInherited: influenceTextOpt ? true : null
    };
    st.order.push(id);
    added.push(st.prompts[id]);
  }
  if (added.length){
    // Hand-written prompts jump the queue at the image generator (see choosePromptForTask), so move them
    // to the head of st.order too — that's the order the sidebar's Upcoming list renders in, and a prompt
    // that's about to generate while sitting at the bottom of that list reads as a bug, not a priority.
    // Order within the batch is preserved, so a multi-line paste appears top-to-bottom as you typed it.
    // Every other origin keeps the plain append the loop above did. The sidebar Inject box and the
    // lightbox "Add to queue" each hand-rolled this line for their single prompt; centralizing it here
    // drops that duplication and extends the same placement to the Prompts modal, which never had it.
    if (origin === 'manual'){
      const addedIds = new Set(added.map(p => p.id));
      st.order = [...added.map(p => p.id), ...st.order.filter(id => !addedIds.has(id))];
    }
    logEvent('evo_prompts_added', { count: added.length, prompts: added.map(p=>p.text) });
    // Wake the scheduler once all new prompts have finished their cooling period
    setTimeout(scheduleDebounced, st.params.PROMPT_WAIT_MS + 50);
  }
  return added;
}

/* ===================== LLM prompt generation (single-flight) ===================== */

function parseList(s){ return parseNumberedOrBulletedList(s); }

/* Target: keep enough *fresh* prompts based on current pending */
function targetUntestedStock(){
  const pending = st.waiting.length + st.inflight;
  const buffer = Math.max(5, st.params.GEN_PROMPTS_BATCH * 2);
  return Math.max(st.params.UNT_MIN_STOCK, pending + buffer);
}

async function ensureUntestedStock(target=st.params.UNT_MIN_STOCK){
  if (!st.started) return; /* do not pre-generate text on landing */
  if (st.pausedPrompts || st.anySidebarFocus) return; // respect the writing half of the manual pause, and the editing pause
  if (st.textGenBusy) return;
  if (st.suggestBusy) return;   // ✨ a suggestion has this turn; infSugAsk calls schedule() when it's done
  if (getUntestedPrompts().length >= target) return;
  const inst = st.instruction || '';
  if (!inst.trim()) return;

  st.textGenBusy = true;
  st.textGenStartedAt = Date.now();
  st.textGenSteer = null;   // set below if this batch consumes a steer
  const textGenEpoch = st.epoch;   // capture epoch so a session restore during the await discards this batch
  st.textGenPromise = (async ()=>{
    try {
      if (getUntestedPrompts().length >= target) return;
      const snapshotVersion = st.instVersion;

      const k = st.params.GEN_PROMPTS_BATCH; // 5
      const longMode = st.numPromptBatchesGenerated > 0 && Math.random() < 0.5; // only have a chance of long mode after the first batch, to prevent longer delay in getting the first prompts generated (while user is waiting)
      // Promote Upvoted: sometimes swap the instruction with a high-scoring upvoted prompt
      const good = getAllPrompts().filter(p=>p.votes>0 && p.score>0 && (st.allowPromptMixing || (!p.stale && p.ver===st.instVersion)));
      let promotedPrompt = null;
      let effectiveInst = inst;
      if (st.promoteUpvoted && good.length && Math.random() < 0.6) {
        promotedPrompt = weightedPickByScore(good);
        if (promotedPrompt) effectiveInst = promotedPrompt.text;
      }

      logEvent('evo_generate_begin', { wantStock: target, batch: k, longMode, instVersion: st.instVersion, creativity: st.creativity, promoted: !!promotedPrompt, promotedPromptId: promotedPrompt?.id, promotedPromptText: promotedPrompt?.text });

      // sample best prompts for optional guidance (current instruction only, unless mixing enabled)
      let exampleText = '';
      let drewFromIds = [];   // ids of the sampled examples → each child's p.drewFrom (prompt generation tree)
      if (good.length && Math.random() < 0.7) {
        const pool = good.filter(p => !promotedPrompt || p.id !== promotedPrompt.id);
        const picks=[];
        const want = Math.min(3, pool.length);
        for (let i=0;i<want;i++){
          const pick = weightedPickByScore(pool) || pool[Math.floor(Math.random()*pool.length)];
          if (!pick) break;
          picks.push(pick);
          const idx = pool.indexOf(pick); if (idx>=0) pool.splice(idx,1);
        }
        if (picks.length){
          drewFromIds = picks.map(pp => pp.id);   // record which examples shaped this batch (score-ordered)
          let intro;
          if (st.creativity === 2 && st.allowPromptMixing) {
            // creative + mix
            intro = `These prompts reveal the user's aesthetic taste from earlier sessions, possibly under very different instructions. Treat them as loose creative fuel — remix ideas freely, mash up elements in unexpected ways, or use them as jumping-off points for entirely new directions. You don't need to preserve specific elements; channel the *vibe* and *energy* that made these appealing.\n\nAcross your ${k} outputs: some should be wild reinterpretations; some should borrow only a mood or color palette; at least one should be a genuine surprise that only loosely connects back.`;
          } else if (st.creativity === 2) {
            // creative + no mix
            intro = `The user liked these prompts. Use them as creative inspiration — you're free to wildly reinterpret them, borrow just a mood or texture, or only take the part you find most visually interesting. Don't feel bound to replicate their structure or content. The goal is to spark new ideas the user hasn't seen yet, not to iterate on what already worked.`;
          } else if (st.creativity === 1 && st.allowPromptMixing) {
            // balanced + mix
            intro = `These prompts were rated highly by the user across earlier sessions, possibly under different instructions. Carry forward the recurring subjects and elements the user clearly likes, keeping them recognizably intact — but give each new prompt a fresh angle in mood, lighting, color palette, and composition under the current instruction.\n\nAcross your ${k} outputs, vary the styling and atmosphere widely, but keep the subject the user asked for steady: these should read as fresh takes on what works, not departures from it.`;
          } else if (st.creativity === 1) {
            // balanced + no mix
            intro = `Below are some prompts that the user previously rated highly. Notice the subjects and elements they keep responding to, and keep delivering those — but give each new prompt a fresh angle in mood, lighting, styling, and composition so the user sees fresh takes rather than repeats. Stay recognizably faithful to the request: vary the rendering, not the subject.`;
          } else if (st.allowPromptMixing) {
            // no creative + mix
            intro = `These prompts were rated highly by the user in earlier sessions, possibly under different instructions. The user liked something about each — actively look for what that might be, and find ways to carry it forward into your new prompts.\n\nVary the intensity across your ${k} outputs: some should be bigger blends that heavily reinterpret an idea from these under the current instruction; some should be lighter touches that lift only a small element; one or two should be normal generations with nothing borrowed.`;
          } else {
            // no creative + no mix (default)
            intro = `Below are some prompts that the user previously rated highly. Look for patterns in these prompts which might indicate the specific things that the user likes. You should try to breed/combine their best parts into NEW prompts that the user will love even more. You must ensure that you exactly match the user instruction; do not copy verbatim; do not conflict with user instruction; include ALL details specified in the instruction. Try to break new ground while staying true to what the user likes and wants, to ensure your prompts get a high rating from the user.`;
          }
          exampleText = `\n\n${intro}\n<highly_rated_prompts>\n${picks.map(p=>`- ${p.text}`).join('\n')}\n</highly_rated_prompts>`;
        }
      }

      const extra = EXTRA_INSTRUCTIONS[Math.floor(Math.random()*EXTRA_INSTRUCTIONS.length)];
      const curly = maybeCurlyGuidance();
      const lengthGuide = longMode ? `\n\nLength: Make each prompt about twice as long as usual—a short paragraph (~${40 + Math.round(Math.random()*10)*10} words).` : "";

      const rules = st.creativity === 2 ? [
        `- One prompt per line (no commentary or numbering).`,
        `- Use the instruction as a creative springboard, not a checklist. Reinterpret or expand on specific details freely, but keep the core subject and key elements recognizable. Prioritize producing something visually striking and unexpected over literal compliance.`,
        `- Vary prompt length across the ${k} outputs (mix concise and richly detailed).`,
        `- If there are multiple possible interpretations of the user instruction, then feel free to try a different interpretation for each prompt.`,
        `- Push for genuine variety: different subjects, moods, compositions, art styles, color palettes, time periods, levels of abstraction. Each prompt should feel like it came from a different creative mind.`,
        `- Spread your ${k} outputs across a creative spectrum: some should stay faithful to the instruction with just a fresh angle or unexpected detail; some should take bigger creative leaps; at least one should be an unexpected interpretation or remix that the user might not have thought to ask for.`,
        `- Avoid near-duplicates. Aim for maximum creative range.`,
        `- Lean into the *spirit* and *emotional core* of what the user is asking for, even if you diverge from the literal details. Use vivid, specific, concrete imagery — not vague abstractions.`,
      ].filter(a => a).join('\n') : st.creativity === 1 ? [
        `- One prompt per line (no commentary or numbering).`,
        `- Use the instruction as a springboard you build on, not a strict checklist — but keep the core subject and the user's explicit asks clearly intact in every prompt. Don't reinterpret it into a different subject.`,
        `- Vary prompt length across the ${k} outputs (mix concise and richly detailed).`,
        `- If there are genuinely multiple readings of the user instruction, you may try different ones — but each prompt must still clearly be the thing the user asked for.`,
        `- Push for real variety in mood, lighting, composition, art style, color palette, and framing — while keeping the subject itself steady.`,
        `- Across your ${k} outputs, vary how far you push: let one or two stay close to a straightforward rendering of the request, while the rest explore more varied moods, lighting, and styling. None should be a wild departure.`,
        `- Keep every prompt recognizably faithful to the request. A fresh angle or an unexpected detail is good, but no wild departures or remixes the user didn't ask for.`,
        `- Avoid near-duplicates: two prompts with the same subject should still differ clearly in atmosphere or styling.`,
        `- Lean into the *spirit* of what the user wants. Use vivid, specific, concrete imagery — not vague abstractions.`,
      ].filter(a => a).join('\n') : [
        `- One prompt per line (no commentary or numbering).`,
        `- Keep the user's style/constraints; do not add unrelated styles; do not conflict with the instruction.`,
        `- Include *ALL* details specified in the user instruction in each prompt. Make the prompt longer if needed to include *everything* that the user instruction specifies, creatively rephrased and creatively expanded into an image generation prompt.`,
        `- Vary prompt length across the ${k} outputs (mix concise and richly detailed).`,
        `- If there are multiple possible interpretations of the user instruction, then feel free to try a different interpretation for each prompt.`,
        `- Avoid near-duplicates. Aim for full exploratory diversity within the constraints of the user instruction.`,
        `- Strongly and eagerly lean into the *exact* type of image the user is asking for - pay ultra close attention to exactly what the user instructions ask for, and the deep intent behind the instruction. Within each prompt, use strong and repeated emphasis on the *key* aspects that the user wants, so you force the image generation model to generate exactly the type of image that the user is asking for. Sometimes the image generation model is dumb and needs to hear the same thing repeated in multiple different ways, with synonyms and rephrasing, so it gets the right idea about exactly what the prompt is asking for.`,
      ].filter(a => a).join('\n');

      const generationDirective =
        st.creativity === 2
        ? `Generate ${k} NEW image prompts inspired by the user_instruction. You have creative license — reinterpret, remix, or take the instruction in unexpected directions. Keep the general theme, characters, or spirit, but explore surprising angles, unconventional compositions, or striking stylistic choices that the user might not have thought of. Surprise and delight.`
        : st.creativity === 1
        ? `Generate ${k} NEW image prompts that build on the user_instruction with a creative touch. Keep the core subject and what the user actually asked for clearly intact — don't swap it for something else — but explore fresh angles, varied moods, lighting, compositions, color palettes, and stylistic choices. Give each prompt its own distinct feel while staying recognizably on-topic.`
        : `Generate ${k} NEW image prompts that EXACTLY satisfy the user_instruction; do not copy verbatim; do not conflict with user instruction; include ALL details specified in the user instruction.`;

      // Theme steer: consume one queued influence prompt (FIFO), if any. A fixed, creativity-
      // independent overlay that rides on top of whatever creativity level is active. Not gated by
      // the highly_rated_prompts 70%/needs-upvotes roll — when one is queued, it always applies.
      let consumedSteer = null;
      let steerText = '';
      const queueAtSteer = st.influenceQueue;   // identity anchor: a session restore reassigns this array
      if (st.influenceQueue.length) {
        consumedSteer = st.influenceQueue.shift();
        st.textGenSteer = consumedSteer;   // sidebar panel reports the live batch as steered
        st.consumedSteer = consumedSteer;  // in-flight & unresolved — saveSession re-queues it until it's baked into a prompt or handed back
        renderInfluenceChips();
        steerText = `\n\n<theme_steer>\n${consumedSteer}\n</theme_steer>\nBlend this theme heavily into every one of the ${k} prompts, while keeping the user's core subject and explicit asks from <user_instruction> recognizable.`;
      }
      // Return an unused steer to the queue — but only if this batch's queue is still the live one
      // (a restore during the await reassigns st.influenceQueue, so a stale steer must not
      // resurrect into a fresh/other session) and it isn't already re-queued (the user may have
      // re-typed it during the await). Covers both the throw path and the parsed-nothing path.
      const restoreSteer = () => {
        if (consumedSteer == null || st.influenceQueue !== queueAtSteer) return;
        const lower = consumedSteer.toLowerCase();
        if (st.influenceQueue.some(x => x.toLowerCase() === lower)) return;
        st.influenceQueue.unshift(consumedSteer);
        st.consumedSteer = null;   // now durable in the live queue — save must not double-count it
        renderInfluenceChips();
      };

      // 📏 Every-batch rule: rolled fresh per batch, so {a|b} gives each batch its own twist. Applies to
      // every batch — promoted and steered ones included.
      const batchRuleSource = st.batchRule || '';   // captured now: ✕ may clear the box during the await
      const batchRule = rollBatchRule(batchRuleSource);
      const batchRuleText = batchRuleBlock(batchRule, k);
      st.textGenBatchRule = batchRule || null;   // sidebar panel names the rule the live batch was sent

      const sys =
`<user_instruction>
${effectiveInst}
</user_instruction>

${generationDirective}${lengthGuide}
${exampleText}${steerText}

Extra guide: ${extra}${curly}

Rules:
${rules}${batchRuleText}`;

      let text;
      try {
        text = await generateText(sys);
        // clean up random stuff:
        text = text.replaceAll("[", "(").replaceAll("]", ")");
        text = text.replaceAll("Midjourney prompt: ", "").replaceAll("Midjourney: ", "");
      } catch(e) {
        restoreSteer();   // transient failure — hand the theme back for a later batch
        return;
      }
      if (textGenEpoch !== st.epoch) return;   // session changed while awaiting — discard stale prompts
      const lines = parseList(text);
      const genOrigin = (() => {
        const creative = st.creativity === 2;  // Balanced (1) intentionally shows no badge
        const suffix = (creative && st.allowPromptMixing) ? 'creative+mixed'
                     : creative ? 'creative'
                     : st.allowPromptMixing ? 'mixed'
                     : '';
        if (promotedPrompt) return suffix ? `promoted+${suffix}` : 'promoted';
        return suffix || 'generated';
      })();
      // Lineage: a promoted batch hangs under the prompt it was generated from (causal edge that
      // supersedes the version root, §1.11); otherwise it branches off the version snapshot it was
      // born under. drewFromIds carries the ≤3 example mix-ins onto every child in the batch.
      const batchParent = promotedPrompt
        ? { kind: 'promote', promptId: promotedPrompt.id }
        : { kind: 'instruction', ver: snapshotVersion };
      const added = addPrompts(lines, genOrigin, { parent: batchParent, drewFrom: drewFromIds });
      if (batchRule && added.length) {
        added.forEach(p => { p.batchRule = batchRule; });   // the rolled variant, for the ❓ panel
        logEvent('batch_rule_applied', { text: batchRule, source: batchRuleSource, count: added.length });
      }
      if (snapshotVersion !== st.instVersion) {
        added.forEach(p => { p.ver = snapshotVersion; p.stale = true; });
      } else if (added.length) {
        st.freshBatchVersion = st.instVersion;
      }
      if (consumedSteer != null) {
        // Only now do we know the steer produced usable prompts. On success, log it and persist the
        // post-consume queue so the used steer isn't re-applied after a crash — a steer-batch is
        // infrequent (needs both low stock AND a queued steer) and the 2s autosave debounce coalesces,
        // so this doesn't reintroduce the pool-growth churn autosave deliberately avoids. On an empty
        // batch — or one that landed stale because the instruction changed mid-flight (stale unused
        // prompts are unreachable, so the steer would burn with zero visible effect) — hand the steer
        // back unburnt (its queued state was already saved, so no autosave).
        if (added.length && snapshotVersion === st.instVersion) {
          // Must stay synchronous with addPrompts above: the sidebar's next render has to see
          // influenced already set, or an Upcoming row builds badge-less and the zero-flicker
          // incremental branch (which never adds the badge) keeps it that way. An await between the
          // two would reopen that gap.
          // influenceText records *which* steer, so the ❓ panel and the 🌳 tree can name it long after
          // the queue has moved on. Stored alongside the flag rather than derived, because the queue is
          // consumed destructively and the event log isn't readable from the UI. The two have different
          // lifetimes from here on: `influenced` is transient (cleared on the prompt's first successful
          // image — it marks an ACTIVE steered prompt), `influenceText` is permanent lineage.
          added.forEach(p => { p.influenced = true; p.influenceText = consumedSteer; });   // taint every prompt born from this steer-batch
          st.consumedSteer = null;   // now durable in the prompts (influenceText) — save must not re-queue it
          logEvent('influence_applied', { text: consumedSteer, remaining: st.influenceQueue.length });
          scheduleAutosave();
        } else {
          restoreSteer();
        }
      }
      const avgLen = added.length ? Math.round(added.reduce((a,p)=>a+p.text.length,0)/added.length) : 0;
      if(added.length) st.numPromptBatchesGenerated++;
      logEvent('evo_generate_done', { count: added.length, avgLen, freshAfter: getUntestedPrompts().length, prompts: added.map(p=>p.text) });

      st.lastTextGenMs = Date.now() - st.textGenStartedAt;
      st.lastTextGenCount = added.length;
      // Rolling sample for the panel's average. This site already earns every guard it needs: it is past
      // the epoch check above (a batch whose session was restored out from under it never lands in the
      // new session's buffer) and past the catch around generateText (a failed call is not a duration).
      // A batch that parsed to zero new prompts still counts — it spent the time, and the 'Last batch'
      // row directly above it says "0 prompts in 14.2s", so the two agree.
      recordTiming(st.textGenTimes, st.lastTextGenMs);

      schedule();
    } finally {
      if (textGenEpoch !== st.epoch) return;   // zombie from a prior session — don't touch current state
      st.textGenBusy = false;
      st.textGenPromise = null;
      // Cleared unconditionally: restoreSteer() may have handed the steer back for a later batch, and
      // a panel still claiming "steered by X" would be describing work that never happened.
      st.textGenStartedAt = 0;
      st.textGenSteer = null;
      st.textGenBatchRule = null;
      st.consumedSteer = null;   // backstop: whatever path we took, the steer is resolved once the batch ends
      freshRetryIfStalled();
    }
  })();

  await st.textGenPromise;
  renderSidebar();
}

/* ===================== Prompt choice (5/8) ===================== */

function pickBestWeighted(pool) {
  if (!pool.length) return null;
  const sorted = pool.slice().sort((a,b)=>{
    if (b.score !== a.score) return b.score - a.score;
    if (effUsed(a) !== effUsed(b)) return effUsed(a) - effUsed(b);
    return a.createdAt - b.createdAt;
  });
  return weightedPickByScore(sorted.slice(0,12)) || sorted[0];
}

function choosePromptForTask(){
  // Main selector: picks the next prompt to be used for an image generation task.
  
  // Only prompts for the current instruction version — and under ⏳ Fresh prompts only, only ones that have
  // never made an image (nor are making one), so the exploit branch and the re-use fallback below find
  // nothing and the untested pick answers.
  const all = getAllPrompts().filter(isDrawablePrompt);

  // CRITICAL: Filter by timer and focus immediately. 
  // Generation worker MUST NOT pick prompts that are still in "cooling down" (<10s) 
  // or currently being edited by the user.
  const now = Date.now();
  let available = all.filter(p => now >= (p.readyAt||0) && p.id !== st.focusedPromptId);

  // If we have literally nothing ready yet, stop here and wait for countdowns
  if (!available.length) return null;

  // ✏️ Prompts you wrote by hand — the Prompts modal, the sidebar Inject box, a lightbox "Add to queue"
  // — always go first, ahead of the 🧲 branch below. You typed them because you wanted to see them, and
  // a hand-written prompt taking a random turn behind 20+ AI ones reads as the tool ignoring you. Same
  // narrowing shape as the steer branch (scope `available` rather than return early) so the exploit /
  // explore / fallback branches stay intact, just scoped to the manual subset.
  //
  // effUsed()===0 is what makes this a one-time queue jump rather than a standing preference: it means
  // the prompt has never produced an image AND isn't already in flight. Once it lands its first image it
  // leaves this pool for good and competes on score like every other prompt, so a batch of manual adds
  // can't hold the feed forever. A generation that FAILS releases its claim without incrementing used,
  // so a failed manual prompt keeps its place at the front for the retry — same deal 🧲 gets.
  //
  // Unconditional, with no setting behind it (unlike "Send 🧲 steered prompts first"): p.origin is
  // assigned once at creation and never mutated, so unlike the transient p.influenced flag there's no
  // state here that can strand a prompt at the head of the queue. Manual and steered pools are disjoint
  // by construction — addPrompts() never inherits p.influenced — so narrowing to manual here simply
  // makes the steer branch below a no-op for this tick, never a second filter that empties the pool.
  const manual = available.filter(p => p.origin === 'manual' && effUsed(p) === 0);
  if (manual.length) available = manual;

  // Session setting: when on, divert the whole pick to ready+unclaimed 🧲 steer-born prompts so a
  // queued theme-steer surfaces in the feed sooner. Narrowing `available` (vs an early return) keeps
  // the exploit/explore/fallback branches below intact, just scoped to the steered subset. Unclaimed-
  // only: if every steered prompt is already in flight we fall through to normal selection rather than
  // force a duplicate or stall. p.influenced is TRANSIENT — cleared on a prompt's first successful
  // image — so this is a one-time queue-jump per steered prompt, not a standing preference: a prompt
  // that failed or is still in flight keeps its place here, but one that has produced an image leaves
  // this pool for good and competes normally. Nothing to filter here; the field does it.
  if (st.prioritizeSteered) {
    const steered = available.filter(p => p.influenced && (p._claimed||0) === 0);
    if (steered.length) available = steered;
  }

  // avoid picking prompts already claimed by other inflight tasks
  const scoredAvailable = available.filter(p=>p.score>0 && p.used>0 && (p._claimed||0)===0);
  const untestedZeroClaim = available.filter(p=>effUsed(p)===0);

  // Option 1: Prefer exploitation (re-using good prompts) some of the time
  if (scoredAvailable.length && Math.random() < (1-st.params.EXPLORATION_RATE)){
    const pool = scoredAvailable.slice().sort((a,b)=>b.score-a.score).slice(0,12);
    const pick = weightedPickByScore(pool) || pool[0];
    if (pick) return pick;
  }

  // Option 2: Exploration - pick from the batch of untested, ready prompts
  if (untestedZeroClaim.length){
    // randomize among untested zero-claim to mix the first batch
    return untestedZeroClaim[Math.floor(Math.random()*untestedZeroClaim.length)];
  }

  // Fallback: prefer unclaimed prompts to prevent duplicates in a batch; last resort allows re-use
  const unclaimed = available.filter(p => (p._claimed||0) === 0);
  return pickBestWeighted(unclaimed.length ? unclaimed : available);
}

// Is there a usable prompt for the CURRENT instruction version, ready or still cooling? This is what
// separates "the pool is empty, fall back to stale prompts" from "the pool is fine, it just isn't warm
// yet" in schedule() — the two states choosePromptForTask() flattens into a single null.
// Independent of ⏳ on purpose: restore uses it to derive st.freshBatchVersion, a fact about the pool.
function currentVersionPromptsExist() {
  return getAllPrompts().some(p => !p.stale && p.ver === st.instVersion);
}
// Could choosePromptForTask ever pick this, given time? Current-version and not stale — and under ⏳ Fresh
// prompts only, also unused and unclaimed. The one eligibility rule: the picker filters by it, and the
// re-arm in schedule() asks it — without the ⏳ part a fully-used pool would count as "cooling" and the
// re-arm would spin every 100ms on cooldowns that ended long ago.
function isDrawablePrompt(p) {
  return !p.stale && p.ver === st.instVersion && (!st.freshPromptsOnly || effUsed(p) === 0);
}
function drawablePromptsExist() {
  return getAllPrompts().some(isDrawablePrompt);
}
// When the coolest drawable prompt comes up, so the scheduler can re-arm for exactly that moment.
// Infinity if there are none — callers only reach it behind drawablePromptsExist().
function soonestReadyAt() {
  return getAllPrompts().reduce((min, p) =>
    isDrawablePrompt(p) ? Math.min(min, p.readyAt || 0) : min, Infinity);
}

// ⏳ Fresh prompts only leaves tasks waiting on the AI's next batch, but a batch that fails or parses to
// nothing new wakes nobody — before ⏳, reused prompts kept images (and so schedule() calls) coming.
// Called as a batch ends: if tasks are still stranded, try again shortly rather than hammer a failing AI.
const FRESH_RETRY_MS = 5000;
function freshRetryIfStalled() {
  if (!st.freshPromptsOnly || !st.waiting.length || drawablePromptsExist()) return false;
  setTimeout(scheduleDebounced, FRESH_RETRY_MS);
  return true;
}

/* Fallback chooser: if no current-version prompts, allow high-score *stale* prompts
   weighted by score × recency × vote-confidence so recent / well-voted prompts dominate. */
function choosePromptIncludingStaleIfNeeded(){
  // try normal selection first
  let p = choosePromptForTask();
  if (p) return p;

  // fallback #1: scored stale prompts — biased towards recent & upvoted
  const staleScored = getAllPrompts().filter(pp => (pp.stale || pp.ver!==st.instVersion) && pp.used>0 && pp.score>0 && (pp._claimed||0)===0);
  if (staleScored.length){
    const pool = staleScored.slice().sort((a,b)=> staleWeight(b) - staleWeight(a)).slice(0,12);
    return weightedPickStale(pool) || pool[0];
  }

  // fallback #2: any scored prompts (regardless of version)
  const anyScored = getAllPrompts().filter(pp => pp.used>0 && pp.score>0 && (pp._claimed||0)===0);
  if (anyScored.length){
    const pool = anyScored.slice().sort((a,b)=> staleWeight(b) - staleWeight(a)).slice(0,12);
    return weightedPickStale(pool) || pool[0];
  }

  // No ready prompts found
  return null;
}

function isBridgeActive() {
  if (st.staleBridgeMode === 1) return st.freshBatchVersion !== st.instVersion;
  if (st.staleBridgeMode === 2) return !getAllPrompts().some(p => !p.stale && p.ver === st.instVersion && p.votes > 0);
  return false;
}

function chooseBridgePrompt() {
  const pool = getAllPrompts().filter(p =>
    (p.stale || p.ver !== st.instVersion) && p.votes > 0 && p.score > 0 && (p._claimed || 0) === 0
  );
  if (!pool.length) return null;
  const top = pool.slice().sort((a, b) => staleWeight(b) - staleWeight(a)).slice(0, 12);
  return weightedPickStale(top) || top[0];
}

/* ===================== Queue / Scheduler (headless tasks) ===================== */

function isLeadCapReached(){
  return st.unseenCards.size >= st.params.LEAD_CAP;
}

function createHeadlessTask(){
  const task = {
    id: uid('t'),
    state: 'waiting',
    promptId: null,
    resolvedText: null,
    idx: st.nextIdx++,
    resolution: st.resolution
  };
  st.tasksById[task.id] = task;
  st.waiting.push(task);
  return task;
}

function syncPlaceholders() {
  const want = st.inflight + st.waiting.length;
  const have = st.pendingPool.length;
  for (let i = have; i < want; i++) {
    const el = document.createElement('div');
    el.className = 'card placeholder';
    el.style.aspectRatio = ASPECT_RATIOS[st.resolution];
    el.style.order = '99999';
    el.innerHTML = '<div class="cardInner"><div class="loadingWrap"><div class="miniSpinner"></div><div class="ph">Loading...</div></div></div>';
    feedEl.appendChild(el);
    st.pendingPool.push(el);
  }
  while (st.pendingPool.length > want) {
    const el = st.pendingPool.pop();
    el.remove();
  }
}

function onTaskComplete(task, url, promptObj, resolvedText) {
  const ui = createCard();
  task.ui = ui;
  ui.card.dataset.tid = task.id;
  ui.card.dataset.idx = String(task.idx);
  ui.card.style.aspectRatio = ASPECT_RATIOS[task.resolution || st.resolution];
  ui.card.style.order = String(st._iframeCompletionOrder = (st._iframeCompletionOrder || 0) + 1);

  const firstPlaceholder = st.pendingPool[0];
  if (firstPlaceholder) {
    feedEl.insertBefore(ui.card, firstPlaceholder);
  } else {
    feedEl.appendChild(ui.card);
  }
  if (st.pendingPool.length > 0) {
    st.pendingPool.shift().remove();
  }

  st.unseenCards.add(ui.card);
  if (window.cardIO) window.cardIO.observe(ui.card);
  attachImageToCard(task, url, promptObj, resolvedText);

  // A new image landed below the fold while scrolled up → surface the jump button + "new" dot.
  updateFeedJump();
  if (feedJumpBtn.classList.contains('show')) feedJumpBtn.classList.add('hasNew');
}

// A failed card says what failed, keeps the prompt it was for (hover, like any tile), and can be dismissed.
// No Retry: the prompt keeps its place in the pool and comes round again on its own.
function dressFailedCard(task, ui, err) {
  ui.setLoading('⚠ Generation failed');
  ui.ph.style.color = '#d66';
  const reason = err ? String(err && err.message || err).slice(0, 200) : '';
  ui.card.title = reason ? 'Reason: ' + reason : "The image service didn't answer";
  const p = st.prompts[task.promptId];
  const text = task.resolvedText || (p ? p.text : '');
  if (text && ui.promptHover) setPromptHover(ui, text);
  if (ui.card.querySelector('.failedCardX')) return;
  const x = document.createElement('button');
  x.type = 'button';
  x.className = 'failedCardX';
  x.textContent = '✕';
  x.title = 'Remove this failed card';
  x.onclick = (e) => {
    e.stopPropagation();
    st.unseenCards.delete(ui.card);
    if (window.cardIO) window.cardIO.unobserve(ui.card);
    ui.card.remove();
    scheduleFeedJumpUpdate();
  };
  ui.card.appendChild(x);
}

function onTaskError(task, err) {
  // In plugin viewer mode, the card (with iframe) was already created at task start.
  // Replace its contents with the error message and pull it to the top.
  if (task.ui) {
    const ui = task.ui;
    ui.inner.innerHTML = '';
    ui.card.classList.remove('plugin-viewer-card');
    dressFailedCard(task, ui, err);
    ui.card.style.order = String(st._iframeCompletionOrder = (st._iframeCompletionOrder || 0) + 1);
    st.unseenCards.add(ui.card);
    if (window.cardIO) window.cardIO.observe(ui.card);
    return;
  }

  const ui = createCard();
  task.ui = ui;
  ui.card.dataset.tid = task.id;
  ui.card.dataset.idx = String(task.idx);
  dressFailedCard(task, ui, err);
  ui.card.style.order = String(st._iframeCompletionOrder = (st._iframeCompletionOrder || 0) + 1);

  const firstPlaceholder = st.pendingPool[0];
  if (firstPlaceholder) {
    feedEl.insertBefore(ui.card, firstPlaceholder);
  } else {
    feedEl.appendChild(ui.card);
  }
  if (st.pendingPool.length > 0) {
    st.pendingPool.shift().remove();
  }

  st.unseenCards.add(ui.card);
  if (window.cardIO) window.cardIO.observe(ui.card);
}

/* ensure we have enough headless tasks; stop if user hasn't scrolled past LEAD_CAP cards */
function ensureQueue(){
  if (!st.started) return;
  if (!(st.instruction || '').trim()) return;
  if (isLeadCapReached()) return;

  const totalActive = st.waiting.length + st.inflight;
  const need = Math.max(0, st.params.MAX_QUEUE - totalActive);

  for (let i = 0; i < need; i++) createHeadlessTask();
  logEvent('queue_fill', { totalActive, need, waiting: st.waiting.length, inflight: st.inflight, unseenCount: st.unseenCards.size });
}

/* Debounced schedule: collapses rapid ready-fires into a single schedule() call.
   Use this from timer callbacks; call schedule() directly for immediate triggers.
   Silently skips if focus is still held so box-to-box navigation stays fully paused. */
let _schedDebounce = null;
function scheduleDebounced() {
  clearTimeout(_schedDebounce);
  _schedDebounce = setTimeout(() => {
    if (!st.anySidebarFocus) schedule();
  }, 250);
}

async function schedule(){
  // st.paused is both halves — with only one paused there is still work to do below.
  if (!st.started || st.startBusy || st.paused || st.anySidebarFocus) return;
  st.startBusy = true;
  logEvent('scheduler_tick', { waiting: st.waiting.length, inflight: st.inflight });

  try {
    /* Kick off prompt generation in the background */
    ensureUntestedStock(targetUntestedStock());
    ensureQueue();

    // The drawing half of the manual pause. Deliberately below the two calls above: with images paused
    // the AI carries on writing prompts and the queue carries on filling, so that everything is stocked
    // and ready the moment you resume — it just stops handing any of it to the image generator. (The
    // writing half is enforced inside ensureUntestedStock, which is the only thing it stops.) The
    // finally below still clears st.startBusy, so this early return leaves nothing wedged.
    if (st.pausedImages) return;

    // Before first image: wait until we have enough ready prompts from (ideally) multiple LLM batches
    if (!st.firstImageShown && st.inflight === 0) {
      const now = Date.now();
      const readyCount = getAllPrompts().filter(p => !p.stale && p.ver === st.instVersion && now >= (p.readyAt||0)).length;
      if (readyCount < st.params.MIN_PROMPTS_READY) {
        ensureUntestedStock(st.params.MIN_PROMPTS_READY);
        syncPlaceholders();
        scheduleDebounced();
        st.startBusy = false;
        return;
      }
    }

    for (let i = 0; i < st.waiting.length; i++) {
      if (st.inflight >= st.params.PARALLEL) break;
      const task = st.waiting[i];

      let p = choosePromptForTask();

      if (!p) {
        ensureUntestedStock(targetUntestedStock());
        // ⏳ Fresh prompts only takes neither the bridge nor the stale fallback (choosePromptForTask has
        // already refused reuse). The task stays waiting; the next batch landing wakes the scheduler, and
        // freshRetryIfStalled covers a batch that brings nothing.
        if (!st.freshPromptsOnly && st.staleBridgeMode > 0) {
          // Opted-in stale generation: the user asked for proven old prompts to fill exactly this gap, and
          // isBridgeActive() already encodes when that stops (mode 1: a batch exists for this version;
          // mode 2: a prompt for it has been upvoted). So the bridge is consulted ahead of the cooldown
          // guard below, and gets to answer on its own terms.
          if (isBridgeActive()) p = chooseBridgePrompt();
        } else if (!st.freshPromptsOnly && !currentVersionPromptsExist()) {
          // Unasked-for stale generation, and only justified when there is genuinely nothing else. A null
          // pick has two very different causes: no current-version prompts exist at all (this branch), or
          // they exist and are merely inside their PROMPT_WAIT_MS cooldown — the only filter
          // choosePromptForTask applies that simply waiting undoes. (It never returns null over *claimed*
          // prompts; its last fallback re-uses them. A focused prompt can't arise here either — schedule()
          // bails while a sidebar box has focus.) Restoring a session re-stamps every prompt with a fresh
          // cooldown, so a restored full queue sits in the second case for ~10s, and its first round used
          // to be generated entirely from stale prompts while the queue it had just restored waited its
          // turn. Falling through with p null leaves those tasks waiting for the fresh prompts instead.
          p = choosePromptIncludingStaleIfNeeded();
        }

        if (!p && getAllPrompts().length === 0) {
          try { await ensureUntestedStock(5); } catch(_) {}
          // the stale chooser tries choosePromptForTask first, so it needs no second call after it
          p = st.freshPromptsOnly ? choosePromptForTask() : choosePromptIncludingStaleIfNeeded();
        }

        // Nothing to run this tick and prompts are only cooling → re-arm for the soonest one. Without
        // this the run stalls: the scheduler is event-driven (a finished image, a new batch, a blur), and
        // a queue that is merely waiting out its cooldown fires none of those.
        if (!p && drawablePromptsExist()) {
          setTimeout(scheduleDebounced, Math.max(100, soonestReadyAt() - Date.now() + 50));
          break;   // every other waiting task would hit the same wall this tick
        }
        // Under ⏳ nothing else can answer within this tick either — no stale path — so don't repeat the
        // same full-pool passes for every waiting task. (Waiting between batches is ⏳'s normal state.)
        if (!p && st.freshPromptsOnly) break;
      }
      if (!p) continue;

      task.promptId = p.id;
      const resolved = evaluateCurlyFallback(p.text);
      const resolvedPrefix = evaluateCurlyFallback(st.promptPrefix);
      const resolvedSuffix = evaluateCurlyFallback(st.promptSuffix);
      const prefix = resolvedPrefix && !resolved.startsWith(resolvedPrefix) ? resolvedPrefix + ' ' : '';
      const suffix = resolvedSuffix && !resolved.endsWith(resolvedSuffix) ? ' ' + resolvedSuffix : '';
      task.resolvedText = prefix + resolved + suffix;
      p._claimed = (p._claimed || 0) + 1;
      task.state = 'running';
      task.startedAt = Date.now();
      task.epoch = st.epoch;
      st.inflight++;
      st.waiting.splice(i, 1);
      i--;

      logEvent('generation_started', { tid: task.id, promptId: p.id, promptText: p.text });

      (async () => {
        try {
          const promise = generateImage(task.resolvedText, { resolution: RESOLUTIONS[task.resolution] || '768x768' });
          // In plugin viewer mode, read iframeHtml synchronously BEFORE yielding.
          // This sets outputStringHasBeenRead=true inside the plugin, which prevents
          // the plugin's setTimeout from setting shouldRemoveIframeOnFinish=true.
          // The iframe stays alive after generation, preserving the heart button.
          const iframeHtml = st.pluginViewer ? promise.iframeHtml : null;
          // In plugin viewer mode, create the card NOW and insert the iframe directly.
          // We cannot move iframes later — browsers reload them on DOM reparenting,
          // which loses the generated image and restarts generation from scratch.
          // The card starts with CSS order:99999 so it sits at the bottom (with placeholders).
          // When generation completes, order is set to a completion index so it rises to the top.
          if (iframeHtml) {
            const ui = createCard();
            task.ui = ui;
            ui.card.classList.add('plugin-viewer-card');
            ui.card.dataset.tid = task.id;
            ui.card.dataset.idx = String(task.idx);
            ui.card.style.aspectRatio = ASPECT_RATIOS[task.resolution || st.resolution];
            ui.card.style.order = '99999';
            ui.inner.innerHTML = iframeHtml;
            const iframe = ui.inner.querySelector('iframe');
            if (iframe) {
              iframe.style.cssText = 'width:100%;height:100%;border:0;display:block;';
              iframe.dataset.alreadyAddedIntersectionObserver = 'yes';
            }
            feedEl.appendChild(ui.card);
            if (iframe && iframe.dataset.src) {
              iframe.removeAttribute('srcdoc');
              iframe.src = iframe.dataset.src;
            }
          }
          const url = await promise;
          if (task.epoch !== st.epoch) return;    // session changed while we were generating — discard silently
          if (!url || String(url).length < 10) {
            throw new Error('Invalid or empty image URL');
          }
          task.seed = url.inputs?.seed ?? null;
          p.used += 1;
          // 🧲 marks an ACTIVE (unused) steered prompt. The moment it produces its first image it's just
          // another prompt in the pool, so retire the flag here — at the single used-increment site, on
          // the success path only. Every reader of p.influenced turns unused-only for free: the badge in
          // promptProvenance(), "Send steered prompts first" in choosePromptForTask(), the Keep-🧲✏️ sweep
          // in applyInstructionChange(), and the "Keep 🧲 steered + ✏️ yours" tally. A generation that FAILS never
          // reaches here, so a failed steer keeps its badge and its priority for the retry — only a
          // produced image spends the steer. p.influenceText is deliberately KEPT: the ❓ details panel
          // and the 🌳 generation tree still name which steer shaped this prompt, long after the badge
          // is gone. Keep the knowledge, retire the flag.
          //
          // The tile is the one surface that asks a per-IMAGE question — "was THIS image the one the
          // steer shaped?" — and the answer is yes for exactly the image being finished here. It can't
          // read it off the prompt: the card is built a few lines below, by which time the flag is gone,
          // which is why the first steered image was rendering badge-less. So record the answer on the
          // task before clearing, and let populateFlags prefer it (promptProvenance's second arg).
          task.influenced = p.influenced === true;
          if (p.influenced) p.influenced = false;
          recomputeScore(p);
          // In plugin viewer mode the card already exists with the iframe;
          // set order to pull it to the top, then add the overlay bar and upvote logic.
          if (task.ui) {
            task.ui.card.style.order = String(st._iframeCompletionOrder = (st._iframeCompletionOrder || 0) + 1);
            if (st.pendingPool.length > 0) {
              st.pendingPool.shift().remove();
            }
            st.unseenCards.add(task.ui.card);
            if (window.cardIO) window.cardIO.observe(task.ui.card);
            attachIframeOverlay(task, url, p, task.resolvedText);
          } else {
            onTaskComplete(task, url, p, task.resolvedText);
          }
          task.state = 'done';
          st.lastImageAt = Date.now();
          if (task.startedAt) task.genMs = st.lastImageAt - task.startedAt;
          // Success path only, past the epoch guard — a failure is a timeout, not a generation time, and
          // a run that is failing shows up as a small sample count beside a normal average, which is the
          // honest signal. genMs excludes queue wait (startedAt is stamped at dispatch), so the figure
          // stays comparable across sessions with very different queue depths.
          if (task.genMs) recordTiming(st.imageTimes, task.genMs);
          logEvent('generation_succeeded', { tid: task.id, promptId: p.id, score: p.score });
        } catch (e) {
          if (task.epoch !== st.epoch) return;    // zombie — swallow; the finally guard below also bails
          // A failure releases the claim without counting a use, so under ⏳ the same fresh prompt is the
          // first pick again the instant the finally below calls schedule(). Make it wait out the normal
          // cooldown, so a prompt the image generator keeps rejecting can't fill the feed with failures.
          if (st.freshPromptsOnly) p.readyAt = Date.now() + st.params.PROMPT_WAIT_MS;
          onTaskError(task, e);
          task.state = 'error';
          logEvent('generation_failed', { tid: task.id, error: String(e).slice(0, 160) });
        } finally {
          if (task.epoch !== st.epoch) return;  // zombie from a prior session — don't touch current counters
          p._claimed = Math.max(0, (p._claimed || 1) - 1);
          st.inflight--;
          syncPlaceholders();
          renderSidebar();
          schedule();
        }
      })();
    }

    syncPlaceholders();
    renderSidebar();
  } finally {
    st.startBusy = false;
  }
}

/* ===================== Sentinel & Card observers ===================== */

const sentinel = document.getElementById('sentinel');
let io;
function setupSentinelObserver(){
  if (io) io.disconnect();
  io = new IntersectionObserver((entries)=>{
    for (const e of entries){
      if (e.isIntersecting){
        ensureQueue();
        schedule();
      }
    }
  }, { root:null, rootMargin:'1200px', threshold:0 });
  io.observe(sentinel);
}

// A fast jump (dragging the scrollbar, End, ↓ Newest over a long feed) can carry a card past the
// observer's margin between two frames, so it never reports intersecting and would stay "unseen" for
// good — and 30 of those stop generation until the user scrolls back UP to them. Cards sit in `order`
// sequence, so reaching one means every unseen card ordered before it was passed: count those as seen.
// Spinner-held cards (order 99999) are skipped; they say nothing about position.
function markSkippedCardsSeen(card) {
  const o = parseInt(card.style.order, 10) || 0;
  if (o >= 99999) return;
  for (const c of st.unseenCards) {
    if ((parseInt(c.style.order, 10) || 0) < o) st.unseenCards.delete(c);
  }
}

window.cardIO = null;
function setupCardObserver(){
  if (window.cardIO) window.cardIO.disconnect();
  window.cardIO = new IntersectionObserver((entries)=>{
    for (const e of entries){
      if (e.isIntersecting){
        st.unseenCards.delete(e.target);
        markSkippedCardsSeen(e.target);
        if (!isLeadCapReached()) {
          ensureQueue();
          schedule();
        }
      }
    }
  }, { root:null, rootMargin:'1000px', threshold:0.01 });
}

/* ===================== Feed "jump to newest" button ===================== */

// Newest finished card = the non-placeholder card with the highest CSS `order`. Cards are ordered by
// `order`, not DOM position: finished cards get an incrementing value (onTaskComplete), spinners get
// 99999, restored cards default to 0. `>=` breaks ties to the last DOM node (matches grid render order
// for the order:0 restored cards). parseInt('' )→NaN, so `|| 0` treats an unset order as 0.
function newestFeedCard() {
  let best = null, bestOrder = -Infinity;
  for (const c of feedEl.children) {
    if (c.classList.contains('placeholder')) continue;
    const o = parseInt(c.style.order, 10) || 0;
    if (o === 99999) continue;   // an in-flight plugin-viewer card holds the spinner order — generating, not finished
    if (o >= bestOrder) { bestOrder = o; best = c; }
  }
  return best;
}

const feedJumpBtn = document.getElementById('feedJumpBtn');
const feedJumpLabel = document.getElementById('feedJumpLabel');

/* ---- Restore progress, shown in the ↓ Newest slot ----
   Resuming a session used to sit at the top of an empty feed with no spinner, no counter, nothing, for
   as long as it took to pull every image back out of storage — it looked broken, and on a big session
   people pressed Resume twice. The progress goes where the eye already is: the pill takes the ↓ Newest
   button's own place, then BECOMES that button when the restore ends, so nothing moves at the handover.

   The count is what separates "working" from "hung", so the denominator is worth carrying even though a
   run can legitimately end short of it: images whose originals have expired from the cache are skipped,
   so finishing at 91/120 is normal, not a failure. */
let _restoreTotal = 0;
let _restoreDone = 0;

function restoreProgressRender() {
  feedJumpLabel.textContent = _restoreTotal
    ? `Loading ${_restoreDone}/${_restoreTotal}…`
    : 'Loading…';
}

function restoreProgressStart(total) {
  _restoreTotal = total || 0;
  _restoreDone = 0;
  feedJumpBtn.classList.remove('show', 'hasNew');   // the two states must never both be visible
  feedJumpBtn.classList.add('loading');
  restoreProgressRender();
}

function restoreProgressTick(n = 1) {
  if (!feedJumpBtn.classList.contains('loading')) return;
  _restoreDone += n;
  restoreProgressRender();
}

// Idempotent, and called from a finally: a restore that throws part-way must not leave the button stuck
// saying Loading… forever, which would be worse than the silence this replaces.
function restoreProgressEnd() {
  feedJumpBtn.classList.remove('loading');
  feedJumpLabel.textContent = '↓ Newest';
  _restoreTotal = _restoreDone = 0;
}

function updateFeedJump() {
  if (feedJumpBtn.classList.contains('loading')) return;   // a scroll mustn't take the pill away mid-restore
  const scroll = document.getElementById('feedScroll');
  const target = newestFeedCard();
  if (!target || !scroll) { feedJumpBtn.classList.remove('show', 'hasNew'); return; }
  const sr = scroll.getBoundingClientRect();
  const tr = target.getBoundingClientRect();
  const belowBy = tr.top - sr.bottom;                 // px the newest card sits below the fold
  const show = belowBy > Math.max(320, sr.height * 0.6);   // "more than a few images"
  // While the lead cap holds generation back, this button is the way to end the wait, so it says so.
  feedJumpLabel.textContent = isLeadCapReached() ? `↓ ${st.unseenCards.size} new · paused` : '↓ Newest';
  feedJumpBtn.classList.toggle('show', show);
  if (!show) feedJumpBtn.classList.remove('hasNew');  // reaching the newest clears the "new" dot
}

let feedJumpRaf = 0;
function scheduleFeedJumpUpdate() {
  if (feedJumpRaf) return;
  feedJumpRaf = requestAnimationFrame(() => { feedJumpRaf = 0; updateFeedJump(); });
}
document.getElementById('feedScroll').addEventListener('scroll', scheduleFeedJumpUpdate, { passive: true });
window.addEventListener('resize', scheduleFeedJumpUpdate);
feedJumpBtn.onclick = () => {
  const t = newestFeedCard();
  if (t) t.scrollIntoView({ behavior: 'smooth', block: 'end' });   // land on the image, above the spinners
  feedJumpBtn.classList.remove('hasNew');
};

function toggleSidebar(visible) {
  st.sidebarVisible = visible;
  // Collapsing releases the editing pause. Everything that could otherwise end it sits inside the panel
  // about to be display:none'd: the "✍️ Paused while you edit" banner with its Done editing ·
  // Resume button, and the ⚙️ pipeline panel (hover on sidebarStatus), the only surface naming the
  // reason. The toolbar's ⏸️ Pause does not reach it either — resuming from it calls schedule(), which
  // bails on anySidebarFocus. Blur first: for a prompt box that is what commits its text and settles the
  // cooldown bookkeeping. The release then cancels the redundant 50ms timer and resumes.
  if (!visible) {
    const active = document.activeElement;
    if (active && document.getElementById('sidebar').contains(active)) active.blur();
    releaseSidebarFocus();
  }
  preserveFeedScroll(() => {
    document.getElementById('root').classList.toggle('sidebar-collapsed', !visible);
  });
  logEvent('sidebar_toggle', { visible });
  if (visible) {
    // Re-expand textareas: scrollHeight is 0 while hidden so they may have been set to height:0
    requestAnimationFrame(() => {
      sidebarList.querySelectorAll('.sidebarTextArea').forEach(ta => {
        ta.style.height = 'auto';
        ta.style.height = ta.scrollHeight + 'px';
      });
    });
  }
}

function toggleComposer(visible) {
  st.composerVisible = visible;
  document.getElementById('root').classList.toggle('composer-collapsed', !visible);
  logEvent('composer_toggle', { visible });
}

/* ===================== Image Cache ===================== */

const IC_DB_NAME = 'ipo-image-cache';
const IC_DB_VER = 3;
const IC_TTL_DEFAULT = 72;
const IC_MAX_DEFAULT = 500;

const DC_TTL_DAYS_DEFAULT = 91;   // 13 weeks: on the slider's 7-day grid, so the thumb sits where the value says
const DC_TTL_DAYS_NEVER = 371;    // the slider's last stop (7 + 52×7) = "never expire"; 366 was off-grid and unreachable
const DC_MAX_DEFAULT = 5000;
const DC_MAX_UNLIMITED = 10500;   // one step past the slider max = "unlimited"
const DC_SIZE_PCT_DEFAULT = 25;
const DC_MIN_PX = 100;
const DC_BASE_RES = 768;

let icDB = null;
let IC_ENABLED = localStorage.getItem('ipo_imageCacheEnabled') !== 'false';
let IC_TTL_HOURS = parseInt(localStorage.getItem('ipo_imageCacheTtlHours') || IC_TTL_DEFAULT, 10);
let IC_MAX_COUNT = parseInt(localStorage.getItem('ipo_imageCacheMaxCount') || IC_MAX_DEFAULT, 10);
updateCacheBtnTitle();
// When on, cache entries referenced by any saved set (named session + autosave slot + live upvotes)
// are never archived/evicted and don't count toward IC_MAX_COUNT. Pinning is computed live from
// current references — nothing is stamped on the image. Default off.
let IC_PIN_SAVED = localStorage.getItem('ipo_pinSavedImages') === 'true';
// Restore the whole feed (not just liked images) from the cache when reopening a session. Defaults on;
// a device setting, not saved per session. Only gates the restore side — the manifest is still recorded
// at save time regardless, so toggling this on later can bring earlier images back.
let RESTORE_UNLIKED = localStorage.getItem('ipo_restoreUnlikedFromCache') !== 'false';

let DC_ENABLED = localStorage.getItem('ipo_deepCacheEnabled') !== 'false';
let DC_TTL_DAYS = parseInt(localStorage.getItem('ipo_deepCacheTtlDays') || DC_TTL_DAYS_DEFAULT, 10);
let DC_MAX_COUNT = parseInt(localStorage.getItem('ipo_deepCacheMaxCount') || DC_MAX_DEFAULT, 10);
let DC_SIZE_PCT = parseInt(localStorage.getItem('ipo_deepCacheSizePct') || DC_SIZE_PCT_DEFAULT, 10);

function openICDB() {
  return openDB(IC_DB_NAME, IC_DB_VER, (db) => {
    // v1 had a single 'images' store with blobs inline — drop it
    if (db.objectStoreNames.contains('images')) db.deleteObjectStore('images');
    if (!db.objectStoreNames.contains('meta')) {
      const store = db.createObjectStore('meta', { keyPath: 'id', autoIncrement: true });
      store.createIndex('createdAt', 'createdAt', { unique: false });
    }
    if (!db.objectStoreNames.contains('blobs')) {
      db.createObjectStore('blobs');
    }
    if (!db.objectStoreNames.contains('deep-meta')) {
      const ds = db.createObjectStore('deep-meta', { keyPath: 'id', autoIncrement: true });
      ds.createIndex('createdAt', 'createdAt', { unique: false });
      ds.createIndex('archivedAt', 'archivedAt', { unique: false });
    }
    if (!db.objectStoreNames.contains('deep-blobs')) {
      db.createObjectStore('deep-blobs');
    }
  });
}

async function initICDB() {
  try { icDB = await openICDB(); } catch(e) { console.warn('Image cache DB failed:', e); }
}

let _lastDeepCleanTime = 0;

async function evictOldestCacheEntry() {
  if (!icDB) return;
  const pinned = IC_PIN_SAVED ? await getPinnedCacheIds() : null;
  const pk = await new Promise((resolve) => {
    const cur = icDB.transaction('meta', 'readonly').objectStore('meta').index('createdAt').openCursor();
    cur.onsuccess = (e) => {
      const c = e.target.result;
      if (!c) { resolve(null); return; }
      // Skip pinned (saved-set) entries and evict the oldest unpinned one instead.
      if (pinned && pinned.has(c.primaryKey)) { c.continue(); return; }
      resolve(c.primaryKey);
    };
    cur.onerror = () => resolve(null);
  });
  if (pk == null) return;
  if (DC_ENABLED) {
    try {
      const [metaRec, blob] = await Promise.all([icGetFromStore('meta', pk), getICBlob(pk)]);
      if (metaRec && blob) {
        await archiveToDeepCache(metaRec, blob);
        if (Date.now() - _lastDeepCleanTime > 60000) {
          _lastDeepCleanTime = Date.now();
          await cleanExpiredDeepImages();
        }
      }
    } catch(e) { console.warn('Evict archive error:', e); }
  }
  const dtx = icDB.transaction(['meta', 'blobs'], 'readwrite');
  dtx.objectStore('meta').delete(pk);
  dtx.objectStore('blobs').delete(pk);
  await new Promise((resolve) => { dtx.oncomplete = resolve; dtx.onerror = (e) => { console.warn('Evict delete error:', e); resolve(); }; });
}

async function cacheImage(url, promptObj, resolvedText, seed, resolution) {
  if (!IC_ENABLED || !icDB) return null;
  try {
    const pinned = IC_PIN_SAVED ? await getPinnedCacheIds() : null;
    const count = await new Promise((res) => {
      const store = icDB.transaction('meta', 'readonly').objectStore('meta');
      if (!pinned) {
        const r = store.count();
        r.onsuccess = () => res(r.result);
        r.onerror = () => res(Infinity);
      } else {
        // Pinned (saved-set) entries are "free" — exclude them from the limit count.
        const r = store.getAllKeys();
        r.onsuccess = () => res(r.result.filter(k => !pinned.has(k)).length);
        r.onerror = () => res(Infinity);
      }
    });
    if (count >= IC_MAX_COUNT) await evictOldestCacheEntry();
    const blob = await fetch(url).then(r => r.blob());
    const tx = icDB.transaction(['meta', 'blobs'], 'readwrite');
    const metaStore = tx.objectStore('meta');
    const addReq = metaStore.add({
      promptId: promptObj?.id || null,
      promptText: promptObj?.text || '',
      resolvedText: resolvedText || '',
      seed: seed != null ? String(seed) : null,
      sessionName: st.currentSessionName || '',
      resolution: RESOLUTIONS[resolution ?? st.resolution] || '768x768',
      createdAt: Date.now()
    });
    return new Promise((resolve) => {
      addReq.onsuccess = () => {
        const id = addReq.result;
        tx.objectStore('blobs').put(blob, id);
        resolve(id);
      };
      addReq.onerror = () => resolve(null);
    });
  } catch(e) { console.warn('Cache image failed:', e); return null; }
}

async function cleanExpiredImages() {
  if (!icDB) return;
  const cutoff = Date.now() - IC_TTL_HOURS * 3600000;
  const pinned = IC_PIN_SAVED ? await getPinnedCacheIds() : null;
  const tx = icDB.transaction('meta', 'readonly');
  const idx = tx.objectStore('meta').index('createdAt');
  const expiredIds = [];
  const surviving = [];
  await new Promise((resolve) => {
    const cur = idx.openKeyCursor();
    cur.onsuccess = (e) => {
      const c = e.target.result;
      if (c) {
        // Pinned (saved-set) entries are skipped entirely: never expired, never in the overflow pool.
        if (pinned && pinned.has(c.primaryKey)) { c.continue(); return; }
        if (c.key < cutoff) expiredIds.push(c.primaryKey);
        else surviving.push({ pk: c.primaryKey, ts: c.key });
        c.continue();
      } else resolve();
    };
    cur.onerror = () => resolve();
  });
  const overflowIds = [];
  if (surviving.length > IC_MAX_COUNT) {
    surviving.sort((a, b) => a.ts - b.ts);
    const excess = surviving.splice(0, surviving.length - IC_MAX_COUNT);
    excess.forEach(x => overflowIds.push(x.pk));
  }
  const idsToArchive = DC_ENABLED ? [...expiredIds, ...overflowIds] : [];
  const idsToDelete = DC_ENABLED ? [] : [...expiredIds, ...overflowIds];
  for (const pk of idsToArchive) {
    try {
      const metaRec = await new Promise((res) => {
        const r = icDB.transaction('meta', 'readonly').objectStore('meta').get(pk);
        r.onsuccess = () => res(r.result); r.onerror = () => res(null);
      });
      const blob = await getICBlob(pk);
      if (metaRec && blob) await archiveToDeepCache(metaRec, blob);
    } catch(e) { console.warn('Deep cache archive error for id', pk, e); }
    idsToDelete.push(pk);
  }
  if (idsToDelete.length) {
    const dtx = icDB.transaction(['meta', 'blobs'], 'readwrite');
    const ms = dtx.objectStore('meta');
    const bs = dtx.objectStore('blobs');
    idsToDelete.forEach(pk => { ms.delete(pk); bs.delete(pk); });
    await new Promise((resolve) => { dtx.oncomplete = resolve; dtx.onerror = resolve; });
  }
  await cleanExpiredDeepImages();
}

function icGetAllFromStore(storeName) {
  if (!icDB) return Promise.resolve([]);
  return new Promise((resolve) => {
    const out = [];
    const cur = icDB.transaction(storeName, 'readonly').objectStore(storeName).openCursor();
    cur.onsuccess = (e) => {
      const c = e.target.result;
      if (c) { out.push(c.value); c.continue(); }
      else resolve(out);
    };
    cur.onerror = () => resolve([]);
  });
}

function icGetFromStore(storeName, id) {
  if (!icDB) return Promise.resolve(null);
  return new Promise((resolve) => {
    const req = icDB.transaction(storeName, 'readonly').objectStore(storeName).get(id);
    req.onsuccess = () => resolve(req.result || null);
    req.onerror = () => resolve(null);
  });
}

function icClearStores(metaStore, blobStore) {
  if (!icDB) return Promise.resolve();
  return new Promise((resolve, reject) => {
    const tx = icDB.transaction([metaStore, blobStore], 'readwrite');
    tx.objectStore(metaStore).clear();
    tx.objectStore(blobStore).clear();
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

function icSumBlobSizes(storeName) {
  return new Promise((resolve) => {
    let total = 0;
    const cur = icDB.transaction(storeName, 'readonly').objectStore(storeName).openCursor();
    cur.onsuccess = (e) => {
      const c = e.target.result;
      if (c) { total += c.value?.size || 0; c.continue(); }
      else resolve(total);
    };
    cur.onerror = () => resolve(0);
  });
}

async function getICMeta() { return icGetAllFromStore('meta'); }
async function getICBlob(id) { return icGetFromStore('blobs', id); }
// Every cached original's key, as strings, in one read-only transaction — for "is it cached?" over a whole
// set without a blob read per item. null when the DB is unavailable (callers fall back to getICBlob).
function icBlobKeySet() {
  return new Promise((resolve) => {
    if (!icDB) return resolve(null);
    try {
      const req = icDB.transaction('blobs', 'readonly').objectStore('blobs').getAllKeys();
      req.onsuccess = () => resolve(new Set((req.result || []).map(String)));
      req.onerror = () => resolve(null);
    } catch (e) { resolve(null); }
  });
}
async function clearICStore() { return icClearStores('meta', 'blobs'); }

/* --- Deep Cache (Archive) --- */

async function getDeepMeta() { return icGetAllFromStore('deep-meta'); }
async function getDeepBlob(id) { return icGetFromStore('deep-blobs', id); }
async function clearDeepStore() { return icClearStores('deep-meta', 'deep-blobs'); }

function compressToDeepCache(blob, sizePct) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(blob);
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(url);
      const longest = Math.max(img.naturalWidth, img.naturalHeight);
      const targetLongest = Math.max(Math.round(longest * sizePct / 100), DC_MIN_PX);
      const scale = targetLongest / longest;
      const w = Math.round(img.naturalWidth * scale);
      const h = Math.round(img.naturalHeight * scale);
      const canvas = document.createElement('canvas');
      canvas.width = w;
      canvas.height = h;
      canvas.getContext('2d').drawImage(img, 0, 0, w, h);
      canvas.toBlob((result) => {
        if (result) resolve(result);
        else reject(new Error('toBlob failed'));
      }, 'image/webp', 0.7);
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('Image load failed')); };
    img.src = url;
  });
}

// Archives a blob into the deep (archive) cache. Pass opts.preCompressed when the
// blob is already at archive quality (e.g. images restored from a backup export),
// so we don't re-encode and degrade it a second time. Returns the new deep-meta id,
// or null on failure. Callers that don't care about the id ignore the return value.
async function archiveToDeepCache(metaRecord, blob, opts = {}) {
  try {
    const compressed = opts.preCompressed ? blob : await compressToDeepCache(blob, DC_SIZE_PCT);
    const tx = icDB.transaction(['deep-meta', 'deep-blobs'], 'readwrite');
    const ms = tx.objectStore('deep-meta');
    const addReq = ms.add({
      promptId: metaRecord.promptId || null,
      promptText: metaRecord.promptText || '',
      resolvedText: metaRecord.resolvedText || '',
      sessionName: metaRecord.sessionName || '',
      resolution: metaRecord.resolution || '',
      createdAt: metaRecord.createdAt,
      archivedAt: Date.now(),
      originalId: metaRecord.id ?? null,
    });
    return await new Promise((resolve) => {
      addReq.onsuccess = () => {
        tx.objectStore('deep-blobs').put(compressed, addReq.result);
        resolve(addReq.result);
      };
      addReq.onerror = () => resolve(null);
    });
  } catch (e) { console.warn('Deep cache archive failed:', e); return null; }
}

async function cleanExpiredDeepImages() {
  if (!icDB) return;
  const neverExpire = DC_TTL_DAYS >= DC_TTL_DAYS_NEVER;
  const unlimitedCount = DC_MAX_COUNT >= DC_MAX_UNLIMITED;
  if (neverExpire && unlimitedCount) return;

  const cutoffMs = neverExpire ? 0 : Date.now() - DC_TTL_DAYS * 86400000;
  const tx = icDB.transaction('deep-meta', 'readonly');
  const idx = tx.objectStore('deep-meta').index('archivedAt');
  const toDelete = [];
  const surviving = [];
  await new Promise((resolve) => {
    const cur = idx.openKeyCursor();
    cur.onsuccess = (e) => {
      const c = e.target.result;
      if (c) {
        if (!neverExpire && c.key < cutoffMs) toDelete.push(c.primaryKey);
        else surviving.push({ pk: c.primaryKey, ts: c.key });
        c.continue();
      } else resolve();
    };
    cur.onerror = () => resolve();
  });
  if (!unlimitedCount && surviving.length > DC_MAX_COUNT) {
    surviving.sort((a, b) => a.ts - b.ts);
    const excess = surviving.splice(0, surviving.length - DC_MAX_COUNT);
    excess.forEach(x => toDelete.push(x.pk));
  }
  if (toDelete.length) {
    const dtx = icDB.transaction(['deep-meta', 'deep-blobs'], 'readwrite');
    const ms = dtx.objectStore('deep-meta');
    const bs = dtx.objectStore('deep-blobs');
    toDelete.forEach(pk => { ms.delete(pk); bs.delete(pk); });
    await new Promise((resolve) => { dtx.oncomplete = resolve; dtx.onerror = resolve; });
  }
}

async function getDeepBlobsTotalSize() { return icSumBlobSizes('deep-blobs'); }

/* --- Image Cache Grid UI --- */

const icOverlay = document.getElementById('icOverlay');
const icSearch = document.getElementById('icSearch');
const icGridInner = document.getElementById('icGridInner');
const icGridCtn = document.getElementById('icGrid');
const icEmpty = document.getElementById('icEmpty');
const IC_EMPTY_DEFAULT = icEmpty.textContent;   // the markup's "no cached images yet" line, restored after an error
const icLoadingEl = document.getElementById('icLoading');
const icCount = document.getElementById('icCount');

let icOpenGen = 0;
let icMeta = [];
let icFilterGroup = null;
let icSortNewest = true;
let icShowDeep = localStorage.getItem('ipo_showDeepCache') === '1';
let icCellSizeIdx = parseInt(localStorage.getItem('ipo_icCellSize') || '2', 10);
const IC_CELL_SIZES = [100, 140, 180, 240, 320];

function icSetCellSize() {
  icCellSizeIdx = Math.max(0, Math.min(IC_CELL_SIZES.length - 1, icCellSizeIdx));
  document.documentElement.style.setProperty('--ipo-cache-cell-size', IC_CELL_SIZES[icCellSizeIdx] + 'px');
  localStorage.setItem('ipo_icCellSize', String(icCellSizeIdx));
}

function icRelativeTime(ts) {
  const d = Date.now() - ts;
  if (d < 60000) return 'just now';
  if (d < 3600000) return Math.floor(d / 60000) + 'm ago';
  if (d < 86400000) return Math.floor(d / 3600000) + 'h ago';
  return Math.floor(d / 86400000) + 'd ago';
}

function icTruncate(s, n) {
  return s && s.length > n ? s.slice(0, n) + '…' : (s || '');
}

function icGroupLabel(m) {
  if (m.sessionName) return m.sessionName;
  const d = new Date(m.createdAt);
  const month = d.toLocaleString('default', { month: 'short' });
  const day = d.getDate();
  const half = d.getHours() < 12 ? 'AM' : 'PM';
  return `${month} ${day} ${half}`;
}

// Search scope. "Title" is a row's _group — the session name, or its 12-hour bucket — which is what's
// written across the top of each tile. The choice is remembered; the search text is cleared on open.
const IC_SEARCH_PLACEHOLDERS = { all: 'Search titles & prompts...', title: 'Search titles...', prompt: 'Search prompts...' };
const icSearchIn = document.getElementById('icSearchIn');

// Anything stored that isn't one of the three is 'all'.
function icSearchScopeFrom(value) {
  return value === 'title' || value === 'prompt' ? value : 'all';
}

// `term` arrives lowercased and trimmed. Prompt text is the template plus the rolled text, the pair the
// search covered before scopes existed.
function icSearchMatches(scope, term, title, promptText, resolvedText) {
  const t = (title || '').toLowerCase();
  const p = ((promptText || '') + ' ' + (resolvedText || '')).toLowerCase();
  if (scope === 'title') return t.includes(term);
  if (scope === 'prompt') return p.includes(term);
  return t.includes(term) || p.includes(term);
}

icSearchIn.value = icSearchScopeFrom(localStorage.getItem('ipo_icSearchIn'));
icSearch.placeholder = IC_SEARCH_PLACEHOLDERS[icSearchIn.value];

function icFilteredMeta() {
  let arr = icMeta;
  if (icFilterGroup !== null) {
    arr = arr.filter(m => m._group === icFilterGroup);
  }
  const q = icSearch.value.trim().toLowerCase();
  if (q) {
    const scope = icSearchScopeFrom(icSearchIn.value);
    arr = arr.filter(m => icSearchMatches(scope, q, m._group, m.promptText, m.resolvedText));
  }
  arr.sort((a, b) => icSortNewest ? b.createdAt - a.createdAt : a.createdAt - b.createdAt);
  return arr;
}

// The cache's rows as gallery items (§ shared gallery core). Meta records are close to the item model
// but not it, and the gap is exactly where the two stores meet: a row's `id` is a key in whichever store
// it was read from, so it becomes `cacheId` for a live row and `deepId` for an archived one. This is the
// only builder that can fill `deepId` in at all — the cache is the one surface that reads the archive's
// own listing, so it is the one surface holding the archive's own keys. Everything the cells draw —
// group, time, resolution — rides along on `_meta` instead of being copied out field by field, because
// only decorate() reads it and a copy would be one more thing to keep in step with icFilteredMeta.
function icGalleryItems(rows) {
  return rows.map(m => ({
    cacheId: m._deep ? null : m.id,
    deepId:  m._deep ? m.id : null,
    deep: !!m._deep,
    promptText: m.promptText || '',
    resolvedText: m.resolvedText || '',
    seed: m.seed, resolution: m.resolution, createdAt: m.createdAt,
    // The lightbox's caveat line. Same wording the export panel uses for the same fact — the archive
    // holds a re-encoded WebP at a fraction of the original's resolution.
    note: m._deep ? 'Archived · reduced resolution' : null,
    _meta: m,
  }));
}

const icFilterBtnsCtn = document.getElementById('icFilterBtns');
const icSortSelect = document.getElementById('icSort');
// Full render, not grid-only: icRenderFilters orders the group chips by the same icSortNewest, so a
// grid-only redraw would flip the grid and leave the chip row in the previous order.
icSortSelect.onchange = () => { icSortNewest = icSortSelect.value === 'newest'; icRenderGrid(); };

// One chip bar shown in up to this many rows, so more of it is visible at once. The rows scroll together;
// the second row is never a separate set of filters.
const IC_FILTER_MAX_ROWS = 2;

// Round-robin: row 1, row 2, … back to row 1, so neighbours in the order sit above each other and the
// start of the order fills the left-hand columns.
function icDealIntoRows(items, rows) {
  const out = Array.from({ length: rows }, () => []);
  items.forEach((item, i) => out[i % rows].push(item));
  return out;
}

// The fewest rows that fit without scrolling sideways, up to the max; past that, the max and a scroll.
// Moves the chip nodes rather than rebuilding them, so a re-deal on resize keeps their handlers.
function icLayoutChipRows(chips) {
  for (let rows = 1; rows <= IC_FILTER_MAX_ROWS; rows++) {
    icFilterBtnsCtn.replaceChildren(...icDealIntoRows(chips, rows).map(list => {
      const row = document.createElement('div');
      row.className = 'icFilterRow';
      row.append(...list);
      return row;
    }));
    if (rows === IC_FILTER_MAX_ROWS || icFilterBtnsCtn.scrollWidth <= icFilterBtnsCtn.clientWidth + 1) return;
  }
}
let icFilterChips = [];

// How many rows fit depends on the bar's width, so maximize/restore and window resizes re-deal the chips
// the last render built. Width only: re-dealing changes the bar's height, and reacting to that would loop.
let icFilterBtnsWidth = 0;
new ResizeObserver(() => {
  const w = icFilterBtnsCtn.clientWidth;
  if (w === icFilterBtnsWidth || !w || !icFilterChips.length) return;
  icFilterBtnsWidth = w;
  const keepLeft = icFilterBtnsCtn.scrollLeft;
  icLayoutChipRows(icFilterChips);
  icFilterBtnsCtn.scrollLeft = keepLeft;
}).observe(icFilterBtnsCtn);

// A plain mouse wheel only scrolls vertically and this bar only scrolls sideways, so over the bar the
// wheel is turned sideways — only while there is something to scroll to, and only for a mostly-vertical
// gesture, so a trackpad's own sideways swipe is left as it was.
icFilterBtnsCtn.addEventListener('wheel', (e) => {
  if (icFilterBtnsCtn.scrollWidth <= icFilterBtnsCtn.clientWidth + 1) return;
  if (Math.abs(e.deltaY) <= Math.abs(e.deltaX)) return;
  const unit = e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? icFilterBtnsCtn.clientWidth : 1;
  icFilterBtnsCtn.scrollLeft += e.deltaY * unit;
  e.preventDefault();
}, { passive: false });

function icRenderFilters() {
  // Every chip click and sort rebuilds the bar; without this it jumped back to the start each time.
  const keepLeft = icFilterBtnsCtn.scrollLeft;
  // "All" is the way out of any filter, so it's pinned outside the scroller; the rest are dealt into rows.
  const chips = [];

  const allBtn = document.createElement('button');
  allBtn.className = 'icFilterBtn' + (icFilterGroup === null ? ' icFilterActive' : '');
  allBtn.textContent = `All (${icMeta.length})`;
  allBtn.onclick = () => { icFilterGroup = null; icRenderGrid(); };
  document.getElementById('icFilterAll').replaceChildren(allBtn);

  const groupCounts = {};
  const groupLatest = {};
  for (const m of icMeta) {
    groupCounts[m._group] = (groupCounts[m._group] || 0) + 1;
    if (!groupLatest[m._group] || m.createdAt > groupLatest[m._group]) groupLatest[m._group] = m.createdAt;
  }
  const groupOrder = Object.keys(groupCounts);
  groupOrder.sort((a, b) => icSortNewest
    ? (groupLatest[b] || 0) - (groupLatest[a] || 0)
    : (groupLatest[a] || 0) - (groupLatest[b] || 0)
  );
  for (const group of groupOrder) {
    const btn = document.createElement('button');
    btn.className = 'icFilterBtn' + (icFilterGroup === group ? ' icFilterActive' : '');
    btn.textContent = `${icTruncate(group, 30)} (${groupCounts[group]})`;
    btn.title = group;
    btn.onclick = () => { icFilterGroup = group; icRenderGrid(); };
    chips.push(btn);
  }

  icFilterChips = chips;
  icLayoutChipRows(chips);
  icFilterBtnsCtn.scrollLeft = keepLeft;

  icSortSelect.value = icSortNewest ? 'newest' : 'oldest';
}

// The grid half of the split render, for callers that leave the filter chips standing — search, which
// narrows the grid without changing which groups exist. Sort is NOT one of them: it reorders the chips
// too, so it goes through icRenderGrid. The cells themselves come from the shared gallery core — this
// function owns the count, the empty state, and what a cell says.
function icRenderGridOnly() {
  const filtered = icFilteredMeta();
  icCount.textContent = `${filtered.length} image${filtered.length !== 1 ? 's' : ''}`;

  if (!filtered.length) {
    galTeardown(icGridInner);
    icGridInner.innerHTML = '';
    icGridCtn.style.display = 'none';
    // Nothing to show because of a filter is a different message from an empty cache, and it comes with
    // a way back.
    if (icFilterGroup !== null || icSearch.value.trim()) {
      const clear = document.createElement('button');
      clear.type = 'button';
      clear.className = 'icHdrBtn icClearFilters';
      clear.textContent = 'Clear filters';
      clear.onclick = icClearFilters;
      icEmpty.replaceChildren('No images match.', clear);
    } else {
      icEmpty.textContent = IC_EMPTY_DEFAULT;
    }
    icEmpty.style.display = 'flex';
    return;
  }
  icGridCtn.style.display = 'block';
  icEmpty.style.display = 'none';

  // Deliberately measured across the whole cache, not the filtered view: narrowing to one group would
  // otherwise strip the labels off exactly the cells you narrowed to.
  const multipleGroups = new Set(icMeta.map(m => m._group)).size > 1;
  const items = icGalleryItems(filtered);

  galRenderGrid(icGridInner, items, {
    root: icGridCtn,
    cellClass: 'icCell',
    decorate: (cell, it) => {
      const m = it._meta;
      if (it.deep) {
        cell.classList.add('icDeepCell');
        // Badged here rather than left to the core's rung badge — declared to the core via ownBadge
        // below, so it doesn't add a second one. Which store a row came from is known now and for
        // certain — archived entries are listed as their own rows — where a rung is only known once
        // the bytes arrive, so waiting for one would blank the badge until the cell scrolled into view.
        const badge = document.createElement('span');
        badge.className = 'galCellBadge';
        badge.textContent = 'archived';
        badge.title = 'The original aged out of the cache — this is the archived, reduced-resolution copy';
        cell.appendChild(badge);
      }
      if (multipleGroups) {
        const top = document.createElement('div');
        top.className = 'icCellGroup';
        top.textContent = icTruncate(m._group, 40);
        cell.appendChild(top);
      }
      const bottom = document.createElement('div');
      bottom.className = 'icCellTime';
      bottom.textContent = icRelativeTime(m.createdAt) + (m.resolution ? ' · ' + m.resolution : '');
      cell.appendChild(bottom);
    },
    // An archived row is badged by decorate above, from the store it was listed out of.
    ownBadge: (it) => it.deep,
    onCellClick: (i) => galOpenLightbox(items, i, icGridInner),
  });
}

function icRenderGrid() {
  icRenderFilters();
  icRenderGridOnly();
}

function icClearFilters() {
  icSearch.value = '';
  icFilterGroup = null;
  icRenderGrid();
}

// "Show archived"'s title: what the archive is, built from the live limits.
function archiveToggleTip(ttlHours, maxCount, dcEnabled, dcDays) {
  const span = ttlHours % 24 === 0 ? plural(ttlHours / 24, 'day') : plural(ttlHours, 'hour');
  const keeps = dcEnabled
    ? `The archive keeps it ${dcDays >= DC_TTL_DAYS_NEVER ? 'for good' : 'for ' + plural(dcDays, 'day')}, so you can look back over everything you've made without using much space. Archived images have a purple border.`
    : 'The archive is off in Settings, so there is nothing to show.';
  return `Also show archived images. When an image is older than the cache keeps it (${span}), or the cache is over its ${maxCount} images, it's shrunk to a small copy and moved to the archive. ${keeps}`;
}

async function icOpen() {
  const gen = ++icOpenGen;
  document.getElementById('icDeepLabel').title = archiveToggleTip(IC_TTL_HOURS, IC_MAX_COUNT, DC_ENABLED, DC_TTL_DAYS);
  icGridCtn.style.display = 'none';
  icEmpty.style.display = 'none';
  icLoadingEl.style.display = 'flex';
  icOverlay.classList.add('icOpen');

  try {
    await cleanExpiredImages();
    if (gen !== icOpenGen) return;
    icMeta = await getICMeta();
    if (gen !== icOpenGen) return;
    for (const m of icMeta) { m._group = icGroupLabel(m); m._deep = false; }
    if (icShowDeep) {
      const deepItems = await getDeepMeta();
      if (gen !== icOpenGen) return;
      for (const d of deepItems) { d._group = icGroupLabel(d); d._deep = true; }
      icMeta = icMeta.concat(deepItems);
    }
    icLoadingEl.style.display = 'none';
    icEmpty.textContent = IC_EMPTY_DEFAULT;   // a failed earlier open may have replaced it with the error text
    icFilterGroup = null;
    icSearch.value = '';
    icSetCellSize();
    icRenderGrid();
    refreshICSizeLabel();
  } catch(e) {
    if (gen === icOpenGen) {
      icLoadingEl.style.display = 'none';
      icEmpty.textContent = 'Failed to load image cache.';
      icEmpty.style.display = 'flex';
    }
  }
}

async function refreshICSizeLabel() {
  const el = document.getElementById('icSize');
  if (!el || !icDB) { if (el) el.textContent = ''; return; }
  try {
    const totalBytes = await getICBlobsTotalSize();
    el.textContent = `(${formatBytes(totalBytes)})`;
  } catch(e) { el.textContent = ''; }
}

function icClose() {
  icOpenGen++;
  icOverlay.classList.remove('icOpen');
  icLoadingEl.style.display = 'none';
  galTeardown(icGridInner);   // stops the observer and revokes whatever URLs the grid still holds
  icGridInner.innerHTML = '';
}

document.getElementById('showCacheBtn').onclick = icOpen;
document.getElementById('icCloseX').onclick = icClose;
icOverlay.addEventListener('click', (e) => { if (e.target === icOverlay) icClose(); });

let icSearchTimer = null;
icSearch.addEventListener('input', () => {
  clearTimeout(icSearchTimer);
  icSearchTimer = setTimeout(() => icRenderGridOnly(), 200);
});
// Grid only, for the same reason as the search itself.
icSearchIn.addEventListener('change', () => {
  localStorage.setItem('ipo_icSearchIn', icSearchIn.value);
  icSearch.placeholder = IC_SEARCH_PLACEHOLDERS[icSearchIn.value];
  icRenderGridOnly();
});

/* --- Image Cache Lightbox --- */

const icLightbox = document.getElementById('icLightbox');
const icLbImg = document.getElementById('icLbImg');
const icLbInfo = document.getElementById('icLbInfo');
const icLbActions = document.getElementById('icLbActions');
const icLbCounter = document.getElementById('icLbCounter');
const icLbPrev = document.getElementById('icLbPrev');
const icLbNext = document.getElementById('icLbNext');
let icLbItems = [];
let icLbIdx = 0;
let icLbBlobURL = null;
let icLbBlob = null;      // the shown image's bytes, for Download; null until they arrive
let icLbGen = 0;
let icLbExtras = null;    // which surface's extras the column was built for (null = core only)
let icLbOpener = null;    // what had focus before the lightbox opened, to hand it back on close

/* Render the lightbox info panel as labelled sections divided by an <hr>, so the
   resolved/picked prompt and the raw template read as clearly separate rather than one
   newline-joined block. `sections` is a list of { label?, note?, pill?, text } — falsy entries
   and entries with no note/text are skipped; text is set via textContent so prompt
   contents can't break layout. `pill` is a small badge beside the label. */
function lbSetInfo(el, sections) {
  el.replaceChildren();
  const valid = sections.filter(s => s && (s.text || s.note));
  valid.forEach((s, i) => {
    if (i > 0) el.appendChild(document.createElement('hr'));
    const block = document.createElement('div');
    if (s.label) {
      const lab = document.createElement('div');
      lab.className = 'icLbInfoLabel';
      lab.textContent = s.label;
      if (s.pill) {
        lab.classList.add('icLbInfoLabelRow');
        const pill = document.createElement('span');
        pill.className = 'icLbInfoPill';
        pill.textContent = s.pill;
        lab.appendChild(pill);
      }
      block.appendChild(lab);
    }
    if (s.note)  { const note = document.createElement('div'); note.className = 'icLbInfoNote'; note.textContent = s.note; block.appendChild(note); }
    if (s.text)  { const body = document.createElement('div'); body.textContent = s.text; block.appendChild(body); }
    el.appendChild(block);
  });
}

/* The action column, the same in every viewer: the core actions first, always in this order, then a
   divider, then whatever the surface adds. A surface leaves out a core action it doesn't have rather
   than reordering the rest. (The image-generator extension shares this layout, with Reuse prompt in
   front and Upscale at the end; this app has neither.) */
const LB_CORE = ['copy', 'queue', 'download'];
// `core` maps an LB_CORE key to { cls, label, title? }; `extras` is a list of the same.
function lbButtons(core, extras = []) {
  const list = LB_CORE.filter(k => core[k]).map(k => core[k]);
  if (extras.length) list.push({ divider: true }, ...extras);
  return list;
}

// "3 / 48", or nothing for a lone image.
function lbCounterText(pos, total) {
  return total > 1 && pos >= 0 ? `${pos + 1} / ${total}` : '';
}

// ipo-<when it was made, else now>.<extension from the MIME type>
function lbDownloadName(createdAt, mime, now = Date.now()) {
  const t = new Date(Number.isFinite(createdAt) ? createdAt : now);
  const p = n => String(n).padStart(2, '0');
  const stamp = `${t.getFullYear()}${p(t.getMonth() + 1)}${p(t.getDate())}-${p(t.getHours())}${p(t.getMinutes())}${p(t.getSeconds())}`;
  const ext = (((mime || '').split('/')[1] || 'png').split(';')[0]).replace('jpeg', 'jpg') || 'png';
  return `ipo-${stamp}.${ext}`;
}

// The answer on the button itself, which is where you're looking, then the label comes back. The label
// is kept from the first press, so a second press inside the 1.2s doesn't keep "Copied ✓" as the label.
function lbFlash(btn, text) {
  if (btn._lbLabel == null) btn._lbLabel = btn.textContent;
  clearTimeout(btn._lbTimer);
  btn.textContent = text;
  btn._lbTimer = setTimeout(() => { btn.textContent = btn._lbLabel; btn._lbLabel = null; }, 1200);
}

const LB_QUEUE_TITLE = 'Adds it as a ✏️ hand-written prompt — drawn before any AI prompt, after its 10s cooldown';
const LB_CORE_BUTTONS = {
  copy:     { cls: 'icLbCopy',     label: 'Copy prompt', title: 'Copy the prompt exactly as this image was drawn from it' },
  queue:    { cls: 'icLbQueue',    label: 'Add to queue', title: LB_QUEUE_TITLE },
  download: { cls: 'icLbDownload', label: 'Download', title: 'Save this image as a file' },
};
// The feed's own extras: what a tile in this session can do. Images in 📷 Image Cache, 🧺 Picked and the
// 🌳 tree can come from other sessions, so liking or saving them from there doesn't apply.
const LB_FEED_EXTRAS = [
  { cls: 'icLbLike', label: '👍 Like', title: 'Like this image, the same as tapping its tile' },
  { cls: 'icLbSave', label: '🖼️ Save', title: 'Save this image to 🖼️ Saved' },
  { cls: 'icLbTree', label: '🌳 Prompt tree', title: 'Open the prompt generation tree on this image’s prompt' },
];

function lbRenderActions(extras) {
  if (icLbExtras === extras && icLbActions.childElementCount) return;
  icLbExtras = extras;
  icLbActions.replaceChildren();
  for (const b of lbButtons(LB_CORE_BUTTONS, extras === 'feed' ? LB_FEED_EXTRAS : [])) {
    if (b.divider) { const hr = document.createElement('hr'); hr.className = 'icLbDivider'; icLbActions.appendChild(hr); continue; }
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = b.cls;
    btn.textContent = b.label;
    if (b.title) btn.title = b.title;
    icLbActions.appendChild(btn);
  }
}
const lbBtn = cls => icLbActions.querySelector('.' + cls);

/* Open the lightbox on `items`, at `idx`. Each item: resolvedText, promptText, and optionally _note,
   _cell (its tile, scrolled into view on ←/→), _resolveBlob(), seed, resolution, createdAt, and for
   feed tiles _task. `opts.extras` names the surface's own buttons: 'feed', or nothing for core only. */
function icOpenLightbox(items, idx, opts = {}) {
  icLbItems = items;
  icLbIdx = Math.max(0, Math.min(idx, items.length - 1));
  lbRenderActions(opts.extras || null);
  icLbShow();
  // Focus moves in, so Enter / Space / Tab can't reach the grid cell or tile behind the overlay (a
  // keyboard-opened cell would reopen at its own image; a focused tile would like itself).
  if (!icLightbox.classList.contains('icOpen')) icLbOpener = document.activeElement;
  icLightbox.classList.add('icOpen');
  icLightbox.focus({ preventScroll: true });
}

// restoreFocus: false when closing straight into another surface (🌳), which takes focus itself.
function icCloseLightbox(restoreFocus = true) {
  const wasOpen = icLightbox.classList.contains('icOpen');
  const cur = icLbItems[icLbIdx];
  icLbGen++;
  icLightbox.classList.remove('icOpen');
  if (icLbBlobURL) { URL.revokeObjectURL(icLbBlobURL); icLbBlobURL = null; }
  icLbBlob = null;
  icLbImg.removeAttribute('src');
  icLbItems = [];   // so a closed grid's items (and the cells they point at) aren't kept alive from here
  // Back to the cell you paged to if it takes focus, else to whatever opened the lightbox.
  if (wasOpen && restoreFocus) {
    const cell = cur && cur._cell;
    const back = cell && cell.isConnected && cell.tabIndex >= 0 ? cell : icLbOpener;
    if (back && back.isConnected && back.focus) back.focus({ preventScroll: true });
  }
  icLbOpener = null;
}

// The feed's 👍 / 🖼️ / 🌳 follow the tile they belong to.
function lbSyncFeedButtons(m) {
  const t = m && m._task;
  const like = lbBtn('icLbLike'), save = lbBtn('icLbSave'), tree = lbBtn('icLbTree');
  if (like) {
    like.hidden = !(t && t.ui && t.ui.like);
    const on = !!(t && t.ui && t.ui.upvoted);
    like.textContent = on ? '👍 Liked' : '👍 Like';
    like.setAttribute('aria-pressed', String(on));
  }
  if (save) {
    const ok = !!(t && t.ui && t.ui.save);
    save.hidden = !ok;
    const tile = ok ? t.ui.saveEl : null;
    const saved = !!(tile && tile._saved), saving = !!(tile && tile._saving);
    save.disabled = saved || saving;
    save.textContent = saved ? '✓ Saved' : saving ? 'Saving…' : '🖼️ Save';
    // A save started on the tile (or here) may still fail and need its retry back.
    if (saving) tile._saving.then(() => { if (icLbItems[icLbIdx] === m) lbSyncFeedButtons(m); });
  }
  if (tree) tree.hidden = !(t && st.prompts[t.promptId]);
}

const LB_THUMB_NOTE = 'Thumbnail only — original no longer cached';

// The info panel. Redrawn after a 👍 (the facts' like count changes) and once a thumbnail-only image is
// known to be all there is.
function lbRenderInfo(m) {
  const resolved = m.resolvedText || m.promptText || '';
  const hasTemplate = !!(m.promptText && m.resolvedText && m.promptText !== m.resolvedText);
  const details = lbDetailsText(m);
  const facts = typeof m._facts === 'function' ? m._facts() : m._facts;
  const note = [m._note, m._thumbShown ? LB_THUMB_NOTE : null].filter(Boolean).join(' · ');
  lbSetInfo(icLbInfo, [
    { label: 'Prompt', note: note || null, text: resolved },
    hasTemplate ? { label: 'Template', text: m.promptText } : null,
    details ? { label: 'Details', text: details } : null,
    facts ? { label: 'About this prompt', text: facts } : null,
  ]);
}

// A tile can change while the lightbox shows it: a restored card wires its 🖼️ Save once its original loads.
function lbFeedTileChanged(task) {
  const m = icLbItems[icLbIdx];
  if (m && m._task === task && icLightbox.classList.contains('icOpen')) lbSyncFeedButtons(m);
}

// Seed · size · how long it took, each only when known.
function lbDetailsText(m) {
  return [
    (m.seed != null && m.seed !== '') ? 'Seed ' + m.seed : '',
    m.resolution ? String(m.resolution).replace(/\s*x\s*/i, '×') : '',
    m.genMs ? 'took ' + fmtDur(m.genMs) : '',
  ].filter(Boolean).join(' · ');
}

async function icLbShow() {
  const m = icLbItems[icLbIdx];
  if (!m) return;
  if (icLbBlobURL) { URL.revokeObjectURL(icLbBlobURL); icLbBlobURL = null; }
  icLbBlob = null;
  icLbImg.removeAttribute('src');
  const gen = ++icLbGen;

  icLbCounter.textContent = lbCounterText(icLbIdx, icLbItems.length);
  icLbPrev.style.display = icLbIdx > 0 ? 'flex' : 'none';
  icLbNext.style.display = icLbIdx < icLbItems.length - 1 ? 'flex' : 'none';

  const resolved = m.resolvedText || m.promptText || '';
  m._thumbShown = false;
  lbRenderInfo(m);
  const copy = lbBtn('icLbCopy'), queue = lbBtn('icLbQueue'), dl = lbBtn('icLbDownload');
  copy.hidden = queue.hidden = !resolved;
  dl.disabled = true;
  dl.title = 'Waiting for the image…';
  lbSyncFeedButtons(m);

  // Every caller hands over its own `_resolveBlob()` — galOpenLightbox builds one from the shared
  // ladder, the tree's thumbnail strips and the feed supply theirs. There is no id→IndexedDB path left in
  // here, so this stays honestly source-agnostic instead of knowing about one caller's store.
  const blob = m._resolveBlob ? await m._resolveBlob() : null;
  if (gen !== icLbGen) return;
  if (blob) {
    icLbBlob = blob;
    icLbBlobURL = URL.createObjectURL(blob);
    icLbImg.src = icLbBlobURL;
    dl.disabled = false;
    dl.title = LB_CORE_BUTTONS.download.title;
  } else {
    // A tile whose original can't be read back still has its own <img>; show that, without Download,
    // and say so when it's only the stored thumbnail.
    if (m._src) icLbImg.src = m._src;
    if (m._src && m._srcIsThumb && m._srcIsThumb()) { m._thumbShown = true; lbRenderInfo(m); }
    dl.title = 'This image is no longer stored';
  }
}

// Paging stops at the ends rather than wrapping, so the counter and the hidden ◀ / ▶ say where you are.
function icLbNav(step) {
  const next = icLbIdx + step;
  if (next < 0 || next >= icLbItems.length) return;
  icLbIdx = next;
  icLbShow();
  // Scroll the grid (or the feed) behind the lightbox so the current image stays in view, same as the
  // extension's image-cache lightbox. galOpenLightbox resolves `_cell` from whichever grid drew the
  // item, so no lookup by id is needed and the grids don't have to be told apart. A set with no grid
  // behind it — the tree's thumbnail strips — simply has none, and nothing scrolls.
  icLbItems[icLbIdx]?._cell?.scrollIntoView({ behavior: 'instant', block: 'center', inline: 'nearest' });
}

document.getElementById('icLbClose').onclick = () => icCloseLightbox();
icLbPrev.onclick = (e) => { e.stopPropagation(); icLbNav(-1); };
icLbNext.onclick = (e) => { e.stopPropagation(); icLbNav(1); };
icLightbox.addEventListener('click', (e) => { if (e.target === icLightbox) icCloseLightbox(); });

icLbActions.addEventListener('click', async (e) => {
  const btn = e.target.closest('button');
  if (!btn || btn.disabled) return;
  e.stopPropagation();
  const m = icLbItems[icLbIdx];
  if (!m) return;
  const text = m.resolvedText || m.promptText || '';
  const t = m._task;
  if (btn.classList.contains('icLbCopy')) {
    if (!text) return;
    let ok = false;
    try { await navigator.clipboard.writeText(text); ok = true; } catch (_) {}
    lbFlash(btn, ok ? 'Copied ✓' : 'Copy failed');
  } else if (btn.classList.contains('icLbQueue')) {
    if (!text) return;
    const added = addPrompts([text], 'manual', { allowDuplicates: true });
    if (added.length) {
      // Head-of-queue placement is addPrompts()' job, for every 'manual' origin.
      logEvent('manual_prompts_injected', { count: 1, prompts: [text] });
      renderSidebar();
    }
    lbFlash(btn, added.length ? 'Queued ✓' : 'Failed');
  } else if (btn.classList.contains('icLbDownload')) {
    if (!icLbBlob) return;
    const url = URL.createObjectURL(icLbBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = lbDownloadName(m.createdAt, icLbBlob.type);
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  } else if (btn.classList.contains('icLbLike')) {
    if (t && t.ui && t.ui.like) t.ui.like();
    lbSyncFeedButtons(m);
    lbRenderInfo(m);
  } else if (btn.classList.contains('icLbSave')) {
    if (!(t && t.ui && t.ui.save)) return;
    btn.disabled = true;
    await t.ui.save();
    if (icLbItems[icLbIdx] === m) lbSyncFeedButtons(m);
  } else if (btn.classList.contains('icLbTree')) {
    const p = t && st.prompts[t.promptId];
    if (!p) return;
    icCloseLightbox(false);
    pgtOpen(p.id, { taskId: t.id });
  }
});

document.addEventListener('keydown', (e) => {
  if (!icLightbox.classList.contains('icOpen')) {
    if (icOverlay.classList.contains('icOpen') && e.key === 'Escape') icClose();
    return;
  }
  // stopImmediatePropagation so the later global Escape chain (which closes #exOverlay) doesn't also
  // fire when this lightbox is open over the export gallery — otherwise one Esc closes both surfaces.
  // Harmless no-op for the cache overlay (that chain has no #icOverlay branch).
  if (e.key === 'Escape') { e.stopImmediatePropagation(); icCloseLightbox(); }
  else if (e.key === 'ArrowLeft') { e.preventDefault(); icLbNav(-1); }
  else if (e.key === 'ArrowRight') { e.preventDefault(); icLbNav(1); }
  else if (e.key === 'Tab') {
    // Tab cycles through the lightbox's own visible buttons and never leaves it.
    const f = [...icLightbox.querySelectorAll('button')].filter(b => !b.hidden && !b.disabled && b.getClientRects().length);   // not offsetParent: ✕ and ◀ ▶ are position:fixed
    const i = f.indexOf(document.activeElement);
    if (!f.length) e.preventDefault();
    else if (e.shiftKey ? i <= 0 : (i < 0 || i === f.length - 1)) { e.preventDefault(); f[e.shiftKey ? f.length - 1 : 0].focus(); }
  }
});

/* ===================== Shared gallery core (gal*) =====================
   Three surfaces show a grid of cached images — the Image Cache, the Export panel, and the gallery the
   🌳 tree's "+N" opens — and each brings its own grid, its own way of getting bytes out of IndexedDB,
   and (until this landed) its own copy of the modal CSS. The lightbox was already shared; the grids
   never were.

   All three now run on this core, so a fix to lazy-loading, blob lifetime or the archived caveat lands
   in one place. What is left outside it is deliberate: each surface keeps its own overlay node and
   header chrome, and the tree's thumbnail strips keep pgtResolveBlob, because three fixed-size frames
   next to a node are not a scrolling grid and gain nothing from an observer.

   What lives here: the item model, the blob ladder, the cell + lazy-load + recycle machinery, and the
   handoff into the lightbox. What does NOT: each surface's header chrome (the cache's search / zoom /
   archived filters, the export panel's action buttons, the gallery's title and sort) and its overlay
   node. That chrome is genuinely different per surface; the grid underneath it never was. */

// A gallery item, whatever the source built it from:
//   key            optional stable id (unused by the core, handy for callers)
//   cacheId        the live cache's key ('meta'/'blobs'), or null
//   deepId         the archive's own key ('deep-meta'/'deep-blobs'), or null — NOT interchangeable with
//                  cacheId; see the ladder below
//   deep           caller-owned marker for "this row came from the archive". The core doesn't read it;
//                  the Image Cache uses it to ring and badge such cells
//   thumbSrc       an in-page thumbnail URL / data URL, last resort for bytes
//   imgEl          a live <img> still on the page, second-to-last resort
//   promptText     the template ({braced} wording), for the lightbox's Template block
//   resolvedText   what was actually drawn — the lightbox's main text and the cell caption
//   caption, badge, note   per-cell furniture + the lightbox's note line
//   idx, score, votes      sorting only (generation order, prompt score, prompt votes)

// One ladder, a superset of the three grid ladders it replaced: the live store, the live <img> on the
// page, the archive, then the page's own thumbnail. Ordered by fidelity rather than by cost — the first
// two rungs are the original bytes and the last two are reductions, so an in-page <img> outranks an
// archived WebP even though the WebP is the cheaper local read. Getting that backwards badges "archived"
// on an image sitting full-resolution a few pixels away in the page.
// A thumbnail is a legitimate last rung — an evicted original still displays at reduced resolution
// rather than as a blank frame, and the caller's `note` carries the caveat. The '' guard matters: an
// empty src would make fetch() request this page and hand back its own HTML as an image.
//
// THE TWO IDs ARE NOT INTERCHANGEABLE. 'deep-meta' is its own object store with its own autoincrementing
// key; archiving a live row creates a fresh record that merely remembers the old key in `originalId`.
// Both counters start at 1, so passing a live cacheId to getDeepBlob does not miss — it returns some
// other image's archived bytes. Hence a separate `deepId`, supplied only by a caller that genuinely
// holds an archive key (the Image Cache, which lists archived rows as rows of their own). An item with
// only a cacheId simply has no archive rung: there is no index on `originalId` to find one by.
//
// Returns which rung answered as well as the bytes, because the rung is the caveat: 'deep' means the
// original aged out into the archive and what you're looking at is a reduced-resolution WebP, 'thumb'
// means only the page's own thumbnail was left. Without the rung a caller has no way to tell a
// full-resolution hit from a downgrade.
// `error` separates "asked every rung and none of them has this image" from "a rung threw on the way
// past". Both come back without bytes, but only the first is a fact about the image: an aborted
// IndexedDB read (version-change transaction, quota pressure, a closing DB) says nothing except that
// this attempt failed, and a caller that treats it as an answer will caption a perfectly good image
// "unavailable" and never look again.
async function galBlobFrom(it) {
  if (!it) return { blob: null, rung: null, error: false };
  const store = (get, id) => () => (id == null ? null : get(id));
  const url   = (pick)    => () => { const u = pick() || ''; return u ? fetch(u).then(r => r.blob()) : null; };
  const ladder = [
    ['live',  store(getICBlob, it.cacheId)],
    ['img',   url(() => it.imgEl && it.imgEl.src)],
    ['deep',  store(getDeepBlob, it.deepId)],
    ['thumb', url(() => it.thumbSrc)],
  ];
  let error = false;
  for (const [rung, get] of ladder) {
    try { const b = await get(); if (b) return { blob: b, rung, error: false }; }
    catch (e) { error = true; }
  }
  return { blob: null, rung: null, error };
}

async function galBlob(it) { return (await galBlobFrom(it)).blob; }

// Revoke every URL the grid is still holding and stop watching it. Idempotent — safe to call before a
// re-render as well as on close.
function galTeardown(inner) {
  if (!inner) return;
  if (inner._galObs) { inner._galObs.disconnect(); inner._galObs = null; }
  for (const cell of inner.querySelectorAll('[data-blob-url]')) {
    try { URL.revokeObjectURL(cell.dataset.blobUrl); } catch (e) {}
    delete cell.dataset.blobUrl;
  }
}

/* The load/unload engine, on its own so it isn't welded to one layout.

   Give it an `owner` element and any cells you like; each cell needs `cell._galItem` set to a gallery
   item and needs to be obs.observe()'d. Scrolling a cell in walks the blob ladder and paints it;
   scrolling one out revokes its URL and drops the <img>, so a 400-image set costs a screenful of decoded
   images rather than 400. That unload half is the whole reason this is worth sharing: the export grid
   used to hold every URL it created until close, and moving it onto this engine is what fixed that.

   `owner` is the element galTeardown() will be handed — it holds `_galObs` (also the staleness token: a
   read that lands after a re-render sees a different observer parked there and drops its bytes) and it
   must be the ancestor of every cell, since teardown revokes by querying `[data-blob-url]` beneath it.
   The cells themselves can be laid out however the caller likes — a uniform grid, or the mega-tree's
   handful of image slots inside a node — which is what this shape buys over calling galRenderGrid: that
   one owns its container and rebuilds it from an item array, so it can only ever produce a grid.

   opts:
     root              the scroll container (defaults to the owner's parent)
     rootMargin        how far ahead to load (default 200px)
     placeholderClass  the element swapped for the image and back (default galCellPlaceholder)
     ownBadge          (item) => bool — this item's downgrade caveat is the caller's to state, so don't
                       add the rung badge. For a caller that knows the answer before the bytes arrive. */
function galCellObserver(owner, opts) {
  opts = opts || {};
  const phClass = opts.placeholderClass || 'galCellPlaceholder';
  const obs = new IntersectionObserver((entries) => {
    for (const e of entries) {
      const cell = e.target;
      cell._galVisible = e.isIntersecting;
      if (e.isIntersecting) {
        // galNa: this cell has already been resolved and has no bytes anywhere. Without the flag it
        // would re-walk the whole ladder — four IndexedDB misses — on every scroll past.
        // _galLoading: a read is already in flight. A fling-scroll crosses a cell out and back in long
        // before IndexedDB answers, and without this a second read starts; both would then paint, the
        // first URL becoming unreachable (teardown only revokes what dataset.blobUrl currently holds).
        if (cell.dataset.galNa === '1' || cell.querySelector('img') || cell._galLoading) continue;
        cell._galLoading = true;
        galBlobFrom(cell._galItem).then(({ blob, rung, error }) => {
          cell._galLoading = false;
          if (!cell.isConnected || owner._galObs !== obs) return;   // re-rendered underneath us
          if (!blob) {
            // A clean miss is permanent — every rung answered and none of them has this image — so
            // record it even if the cell has since scrolled out. A rung that THREW is not an answer,
            // and latching on one would caption a cached image "unavailable" for as long as the grid
            // lives, since galNa also blocks the retry. Leave that cell unresolved: it still holds its
            // placeholder, and the next scroll-in asks again.
            if (error) return;
            cell.dataset.galNa = '1';
            cell.classList.add('galCellNA');
            cell.querySelector('.' + phClass)?.remove();
            // On the item too, not just the tile: the lightbox's paging (galOpenLightbox) steps over it,
            // and the tile stops being clickable, so the two agree.
            cell._galItem.gone = true;
            galMarkGone(cell, true);
            return;
          }
          // Scrolled out while the read was in flight. Painting now would pin a decoded image nobody
          // can see, and no further boundary crossing is coming to unload it — which is how a
          // scroll-to-the-bottom would otherwise leave the whole set resident. The next scroll-in re-reads.
          if (!cell._galVisible) return;
          cell.querySelector('.' + phClass)?.remove();
          const url = URL.createObjectURL(blob);
          cell.dataset.blobUrl = url;
          const img = new Image();
          img.src = url; img.alt = '';
          cell.prepend(img);
          // Say so when the bytes came from a lower rung, rather than passing a downgrade off as the
          // original. Only reachable once resolved, which is why it isn't decorate()'s job. Skipped
          // only where opts.ownBadge says the caller states this item's caveat itself — asked of the
          // caller rather than sniffed out of the DOM, so that adding a decorative badge to a cell can
          // never silently cost it the caveat.
          if ((rung === 'deep' || rung === 'thumb') && !(opts.ownBadge && opts.ownBadge(cell._galItem))) {
            const badge = document.createElement('span');
            badge.className = 'galCellBadge';
            badge.textContent = rung === 'deep' ? 'archived' : 'thumb only';
            badge.title = rung === 'deep'
              ? 'The original aged out of the cache — this is the archived, reduced-resolution copy'
              : 'The original is no longer cached — this is the page thumbnail';
            cell.appendChild(badge);
          }
        });
      } else if (cell.dataset.blobUrl) {
        try { URL.revokeObjectURL(cell.dataset.blobUrl); } catch (err) {}
        delete cell.dataset.blobUrl;
        cell.querySelector('img')?.remove();
        cell.querySelector('.galCellBadge')?.remove();   // scroll-in re-walks the ladder and re-appends it — without this they stack
        const ph = document.createElement('div');
        ph.className = phClass;
        cell.prepend(ph);
      }
    }
  }, { root: opts.root || owner.parentElement, rootMargin: opts.rootMargin || '200px' });
  owner._galObs = obs;
  return obs;
}

/* Build a uniform grid of cells and hand them to galCellObserver. opts:
     root         the scroll container (defaults to the grid's parent)
     cellClass    per-surface cell class
     decorate     (cell, item, i) => void — the caller's own furniture, added over the placeholder
     onCellClick  (i, item, cell) => void
     ownBadge     forwarded to galCellObserver

   This owns `inner` outright — it clears it and rebuilds from `items`. A caller that needs image cells
   inside its own markup should call galCellObserver directly rather than trying to bend this. */
function galRenderGrid(inner, items, opts) {
  opts = opts || {};
  galTeardown(inner);
  inner.innerHTML = '';

  const obs = galCellObserver(inner, { root: opts.root, ownBadge: opts.ownBadge });

  items.forEach((it, i) => {
    const cell = document.createElement('div');
    cell.className = opts.cellClass || 'galCell';
    // One cell per item, in item order — the invariant galOpenLightbox's children[i] rides on. Written
    // out as an attribute so it can be seen in devtools; nothing reads it back.
    cell.dataset.idx = String(i);
    cell._galItem = it;
    const ph = document.createElement('div');
    ph.className = 'galCellPlaceholder';
    cell.appendChild(ph);
    if (opts.decorate) opts.decorate(cell, it, i);
    if (opts.onCellClick) {
      cell.style.cursor = 'pointer';
      // `gone` is read at click time: callers resolve it after the first render (galMarkGone).
      cell.onclick = () => { if (it.gone !== true) opts.onCellClick(i, it, cell); };
      // Keyboard: Tab to it, Enter / Space opens it, the same as a click (D4's focus ring shows where you are).
      cell.tabIndex = 0;
      cell.setAttribute('role', 'button');
      cell.setAttribute('aria-label', 'Open image: ' + String(it.resolvedText || it.promptText || '').slice(0, 80));
      cell.onkeydown = (e) => {
        if (e.target !== cell || (e.key !== 'Enter' && e.key !== ' ')) return;
        e.preventDefault();
        cell.onclick();
      };
    }
    if (it.gone === true) galMarkGone(cell, true);
    inner.appendChild(cell);
    obs.observe(cell);
  });
  return obs;
}

// An item resolved as gone — no bytes on any rung — dims, stops being clickable and says so. Shared so
// the lightbox's skip (galOpenLightbox) and the tile agree on one field, `item.gone`.
function galMarkGone(cell, gone) {
  if (!cell) return;
  cell.classList.toggle('galCellGone', !!gone);
  if (cell.onclick) { cell.style.cursor = gone ? 'default' : 'pointer'; cell.tabIndex = gone ? -1 : 0; }
}

// Hand a set to the shared lightbox, mapped through the per-item hooks it already understands. `inner`
// is the grid the items were drawn into, so ←/→ can scroll the cell behind the lightbox into view;
// pass null when there is no grid behind it.
// An item with `gone === true` (resolved: no bytes on any rung) is left out of the paging list, so ◀ ▶
// steps over it; the clicked grid index is mapped to its place in that shorter list, and each entry keeps
// `_cell` pointing at its OWN grid cell so ←/→ still scrolls the right tile into view.
// The caption is `markNote` (what the item is to you, e.g. "🔖 Influence on v3") joined with `note` (a
// caveat the caller rewrites, e.g. "Thumbnail only"), so neither writer clobbers the other.
function galOpenLightbox(items, idx, inner) {
  const lbItems = [];
  let start = 0;
  items.forEach((it, i) => {
    if (it.gone === true) return;
    if (i <= idx) start = lbItems.length;
    lbItems.push({
      resolvedText: it.resolvedText,
      promptText:   it.promptText,
      seed: it.seed, resolution: it.resolution, createdAt: it.createdAt,
      _note:  [it.markNote, it.note].filter(Boolean).join(' · ') || null,
      // galRenderGrid appends one cell per item, in item order, so the index IS the position — where a
      // `[data-idx]` lookup rescanned the whole grid once per item, making every lightbox open O(n²) over
      // a set the Image Cache routinely measures in thousands.
      _cell:  inner ? inner.children[i] || null : null,
      _resolveBlob: () => galBlob(it).catch(() => null),
    });
  });
  if (!lbItems.length) return;
  icOpenLightbox(lbItems, start);
}

// Sort in place. `idx` is generation order (higher = newer); score/votes drive "most upvoted" with idx
// as a stable tiebreak, so equal-scoring images stay in a predictable order rather than shuffling. An
// item with no idx (a gone image whose position nobody recorded, or an old session) sorts LAST under
// both Newest and Oldest — `?? 0` used to send it to the top under Oldest — and keeps its relative order.
// 'version' (🧺 Picked's Marked view) orders by `firstPos` = [instruction version, position in that
// version's list], pending marks carrying Infinity so they come last.
function galSortItems(items, mode) {
  const hasIdx = it => it.idx != null && !Number.isNaN(it.idx);
  const gen = dir => (a, b) => {
    const ha = hasIdx(a), hb = hasIdx(b);
    if (ha !== hb) return ha ? -1 : 1;
    return ha ? dir * (a.idx - b.idx) : 0;
  };
  const newest = gen(-1);
  if (mode === 'upvoted')      items.sort((a, b) => (b.score||0)-(a.score||0) || (b.votes||0)-(a.votes||0) || newest(a, b));
  else if (mode === 'oldest')  items.sort(gen(1));
  else if (mode === 'version') items.sort((a, b) => {
    const pa = a.firstPos || [Infinity, Infinity], pb = b.firstPos || [Infinity, Infinity];
    if (pa[0] !== pb[0]) return pa[0] < pb[0] ? -1 : 1;
    if (pa[1] !== pb[1]) return pa[1] < pb[1] ? -1 : 1;
    return newest(a, b);
  });
  else                         items.sort(newest);
  return items;
}

/* ===================== Gallery overlay (one set of images) =====================
   Opened by a thumbnail strip's "+N" in the 🌳 tree: a whole generation, everything one prompt drew,
   everything a 🧲 steer shaped. Browse-only — the lightbox already carries Copy prompt and Add to
   queue, and the set you're looking at is a view of the session, not something to export as a unit.

   Its own overlay rather than a reuse of the export panel's: both the tree and the export panel sit at
   z-index 320, and #pgtOverlay comes later in the document, so the export gallery reopened from inside
   the tree would paint BEHIND it. This one sits at 340, above the tree it was opened from. */

const galOverlay   = document.getElementById('galOverlay');
const galGrid      = document.getElementById('galGrid');
const galGridInner = document.getElementById('galGridInner');
const galSortSel   = document.getElementById('galSort');
let galItems = [];
let galSortMode = 'upvoted';   // agrees with the thumbnail strip that opened it (best-scoring first)

function galIsOpen() { return !!galOverlay && galOverlay.classList.contains('galOpen'); }

function galRenderSet() {
  galSortItems(galItems, galSortMode);
  document.getElementById('galCount').textContent =
    galItems.length + ' image' + (galItems.length === 1 ? '' : 's');
  galRenderGrid(galGridInner, galItems, {
    root: galGrid,
    cellClass: 'galCell',
    decorate: (cell, it) => {
      const cap = it.caption || it.resolvedText || it.promptText || '';
      if (cap) {
        const pr = document.createElement('div');
        pr.className = 'galCellPrompt';
        pr.textContent = cap;
        cell.title = cap;
        cell.appendChild(pr);
      }
      // .galCellTag, not .galCellBadge: this is the caller's own label and sits in the opposite corner,
      // so a set that labels its tiles still gets the "thumb only" caveat when one turns out to be a
      // downgrade. The two say different kinds of thing and shouldn't compete for one slot.
      if (it.badge) {
        const b = document.createElement('span');
        b.className = 'galCellTag';
        b.textContent = it.badge;
        cell.appendChild(b);
      }
    },
    onCellClick: (i) => galOpenLightbox(galItems, i, galGridInner),
  });
}

function galOpenSet(items, title) {
  if (!galOverlay || !items || !items.length) return;
  galItems = items.slice();
  const titleEl = document.getElementById('galTitle');
  titleEl.textContent = title || 'Images';
  titleEl.title = title || '';        // the header ellipsizes; hover gets the whole prompt
  if (galSortSel) galSortSel.value = galSortMode;
  galOverlay.classList.add('galOpen');
  galRenderSet();
  galGrid.scrollTop = 0;
}

function galClose() {
  if (!galOverlay) return;
  galOverlay.classList.remove('galOpen');
  galTeardown(galGridInner);
  galGridInner.innerHTML = '';
  galItems = [];
}

if (galOverlay) {
  galOverlay.addEventListener('click', (e) => { if (e.target === galOverlay) galClose(); });
  document.getElementById('galCloseX').onclick = galClose;
  galSortSel.onchange = () => { galSortMode = galSortSel.value; galRenderSet(); galGrid.scrollTop = 0; };
}

/* --- Image Cache Settings wiring --- */

const imgCacheEnabledChk = document.getElementById('imgCacheEnabledChk');
const imgCacheTtlSlider = document.getElementById('imgCacheTtlSlider');
const imgCacheMaxSlider = document.getElementById('imgCacheMaxSlider');
const imgCacheTtlValue = document.getElementById('imgCacheTtlValue');
const imgCacheMaxValue = document.getElementById('imgCacheMaxValue');

imgCacheEnabledChk.checked = IC_ENABLED;
imgCacheTtlSlider.value = IC_TTL_HOURS;
imgCacheMaxSlider.value = IC_MAX_COUNT;

function icUpdateTtlDisplay() { imgCacheTtlValue.textContent = (IC_TTL_HOURS / 24).toFixed(1) + 'd'; }
function icUpdateMaxDisplay() { imgCacheMaxValue.textContent = String(IC_MAX_COUNT); }
icUpdateTtlDisplay();
icUpdateMaxDisplay();

function formatBytes(n) {
  return n < 1024 * 1024
    ? (n / 1024).toFixed(0) + ' KB'
    : (n / (1024 * 1024)).toFixed(1) + ' MB';
}

async function getICBlobsTotalSize() { return icSumBlobSizes('blobs'); }

// Count + byte size of live-cache blobs whose id is referenced by a saved set.
async function getPinnedBlobsInfo() {
  if (!icDB) return { count: 0, bytes: 0 };
  const pinned = await getPinnedCacheIds();
  if (!pinned.size) return { count: 0, bytes: 0 };
  let count = 0, bytes = 0;
  await new Promise((resolve) => {
    const cur = icDB.transaction('blobs', 'readonly').objectStore('blobs').openCursor();
    cur.onsuccess = (e) => {
      const c = e.target.result;
      if (c) {
        if (pinned.has(c.key)) { count++; bytes += c.value?.size || 0; }
        c.continue();
      } else resolve();
    };
    cur.onerror = () => resolve();
  });
  return { count, bytes };
}

const imgCacheStats = document.getElementById('imgCacheStats');
const imgCachePinnedStats = document.getElementById('imgCachePinnedStats');
async function refreshICStats() {
  if (!icDB) { imgCacheStats.textContent = 'Cache unavailable'; return; }
  try {
    const tx = icDB.transaction(['meta', 'blobs'], 'readonly');
    const count = await new Promise((res) => {
      const r = tx.objectStore('meta').count();
      r.onsuccess = () => res(r.result);
      r.onerror = () => res(0);
    });
    const totalBytes = await getICBlobsTotalSize();
    imgCacheStats.textContent = `${count} image${count !== 1 ? 's' : ''} cached · ${formatBytes(totalBytes)}`;
  } catch(e) {
    imgCacheStats.textContent = 'Unable to read cache stats';
  }
  // Second line: how much of the cache is liked/pinned images.
  if (imgCachePinnedStats) {
    try {
      const { count: pc, bytes: pb } = await getPinnedBlobsInfo();
      if (pc > 0) {
        imgCachePinnedStats.style.display = 'block';
        imgCachePinnedStats.textContent = IC_PIN_SAVED
          ? `↳ ${pc} pinned (liked & marked) · ${formatBytes(pb)} — never evicted, off the limit`
          : `↳ ${pc} liked & marked ${pc !== 1 ? 'images' : 'image'} in cache · ${formatBytes(pb)} — turn on “Keep liked images cached” to protect`;
      } else {
        imgCachePinnedStats.style.display = 'none';
      }
    } catch(e) { imgCachePinnedStats.style.display = 'none'; }
  }
  refreshTrimPinnedControl();
}

imgCacheEnabledChk.onchange = () => {
  IC_ENABLED = imgCacheEnabledChk.checked;
  localStorage.setItem('ipo_imageCacheEnabled', String(IC_ENABLED));
};
imgCacheTtlSlider.oninput = () => {
  IC_TTL_HOURS = parseInt(imgCacheTtlSlider.value, 10);
  updateCacheBtnTitle();
  localStorage.setItem('ipo_imageCacheTtlHours', String(IC_TTL_HOURS));
  icUpdateTtlDisplay();
};
imgCacheMaxSlider.oninput = () => {
  IC_MAX_COUNT = parseInt(imgCacheMaxSlider.value, 10);
  updateCacheBtnTitle();
  localStorage.setItem('ipo_imageCacheMaxCount', String(IC_MAX_COUNT));
  icUpdateMaxDisplay();
};
document.getElementById('imgCacheTtlReset').onclick = () => {
  IC_TTL_HOURS = IC_TTL_DEFAULT;
  updateCacheBtnTitle();
  imgCacheTtlSlider.value = IC_TTL_HOURS;
  localStorage.removeItem('ipo_imageCacheTtlHours');
  icUpdateTtlDisplay();
};
document.getElementById('imgCacheMaxReset').onclick = () => {
  IC_MAX_COUNT = IC_MAX_DEFAULT;
  updateCacheBtnTitle();
  imgCacheMaxSlider.value = IC_MAX_COUNT;
  localStorage.removeItem('ipo_imageCacheMaxCount');
  icUpdateMaxDisplay();
};
// How many records an image-cache store holds — the count a clear-all confirm quotes.
async function icStoreCount(store) {
  if (!icDB) return 0;
  return new Promise(res => {
    const r = icDB.transaction(store, 'readonly').objectStore(store).count();
    r.onsuccess = () => res(r.result); r.onerror = () => res(0);
  });
}

document.getElementById('imgCacheClearBtn').onclick = async () => {
  const n = await icStoreCount('meta');
  const act = await confirmChoice({ title: 'Clear the image cache?',
    body: `${plural(n, 'full-size image')} from every session will be deleted (saved sessions keep thumbnails; the archive stays). This can't be undone.`,
    okLabel: `Delete ${plural(n, 'image')}`, danger: true });
  if (act !== 'ok') return;
  const btn = document.getElementById('imgCacheClearBtn');
  await clearICStore();
  refreshICStats();
  btn.textContent = '✅ Cleared!';
  setTimeout(() => btn.textContent = '🗑️ Clear Image Cache', 1500);
};

/* --- Trim Pinned Cache --- */

const trimPinnedGroup = document.getElementById('trimPinnedGroup');
const trimPinnedSlider = document.getElementById('trimPinnedSlider');
const trimPinnedReadout = document.getElementById('trimPinnedReadout');
const trimPinnedBtn = document.getElementById('trimPinnedBtn');

// Cached sorted pinned entries: { ids: number[], dates: number[] } sorted by createdAt asc.
// Loaded once when the control becomes visible or on explicit refresh; reused by the slider.
let _trimPinnedCache = null;

async function loadTrimPinnedData() {
  if (!icDB) { _trimPinnedCache = { ids: [], dates: [] }; return; }
  const pinned = await getPinnedCacheIds();
  if (!pinned.size) { _trimPinnedCache = { ids: [], dates: [] }; return; }
  // Walk the createdAt index — results come out sorted ascending automatically.
  const entries = [];
  await new Promise((resolve) => {
    const cur = icDB.transaction('meta', 'readonly').objectStore('meta').index('createdAt').openCursor();
    cur.onsuccess = (e) => {
      const c = e.target.result;
      if (!c) { resolve(); return; }
      if (pinned.has(c.primaryKey)) entries.push({ id: c.primaryKey, createdAt: c.key });
      c.continue();
    };
    cur.onerror = () => resolve();
  });
  _trimPinnedCache = { ids: entries.map(e => e.id), dates: entries.map(e => e.createdAt) };
}

function trimPinnedUpdateReadout() {
  if (!_trimPinnedCache) return;
  const pct = parseInt(trimPinnedSlider.value, 10);
  const total = _trimPinnedCache.ids.length;
  if (pct === 0 || total === 0) {
    trimPinnedReadout.textContent = total < 100
      ? `${total} pinned — need 100+ to trim`
      : 'Drag to select pinned images to archive';
    trimPinnedBtn.textContent = 'Archive pinned images';
    trimPinnedBtn.disabled = true;
    return;
  }
  const count = Math.max(1, Math.floor(total * pct / 100));
  const cutoffDate = _trimPinnedCache.dates[count - 1];
  let readout = `≈${count} image${count !== 1 ? 's' : ''}`;
  if (cutoffDate) {
    readout += ` · before ${new Date(cutoffDate).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}`;
  }
  trimPinnedReadout.textContent = readout;
  trimPinnedBtn.textContent = `Archive ≈${count} image${count !== 1 ? 's' : ''}`;
  trimPinnedBtn.disabled = false;
}

async function refreshTrimPinnedControl() {
  if (!trimPinnedGroup) return;
  if (!IC_PIN_SAVED) {
    trimPinnedGroup.style.display = 'none';
    trimPinnedSlider.value = 0;
    _trimPinnedCache = null;
    return;
  }
  trimPinnedGroup.style.display = '';
  await loadTrimPinnedData();
  const total = _trimPinnedCache ? _trimPinnedCache.ids.length : 0;
  const disabled = total < 100;
  trimPinnedSlider.disabled = disabled;
  if (disabled) trimPinnedSlider.value = 0;
  trimPinnedUpdateReadout();
}

let _trimConfirmTimeout = null;
function trimPinnedDisarmConfirm() {
  if (!_trimConfirmTimeout) return;
  clearTimeout(_trimConfirmTimeout);
  _trimConfirmTimeout = null;
  trimPinnedBtn.style.background = '';
  trimPinnedBtn.style.borderColor = '';
  trimPinnedBtn.style.color = '';
}

trimPinnedSlider.oninput = () => {
  // Moving the slider mid-confirm disarms it: the readout below rewrites the button label with the NEW
  // count, and an armed confirm under a new count would archive an amount the user never saw confirmed.
  trimPinnedDisarmConfirm();
  trimPinnedUpdateReadout();
};
trimPinnedBtn.onclick = async () => {
  if (_trimConfirmTimeout) {
    // Second click — execute the archive.
    clearTimeout(_trimConfirmTimeout);
    _trimConfirmTimeout = null;
    await executeTrimPinned();
    return;
  }
  // First click — enter confirm state with a 3 s timeout.
  const originalLabel = trimPinnedBtn.textContent;
  trimPinnedBtn.textContent = 'Confirm? (click again)';
  trimPinnedBtn.style.background = '#3d1515';
  trimPinnedBtn.style.borderColor = '#5a2020';
  trimPinnedBtn.style.color = '#ff6b6b';
  _trimConfirmTimeout = setTimeout(() => {
    trimPinnedDisarmConfirm();
    trimPinnedBtn.textContent = originalLabel;
  }, 3000);
};

async function executeTrimPinned() {
  const pct = parseInt(trimPinnedSlider.value, 10);
  if (pct === 0) return;
  // Re-fetch to get current state (could have changed since last slider drag).
  await loadTrimPinnedData();
  if (!_trimPinnedCache || !_trimPinnedCache.ids.length) return;
  const total = _trimPinnedCache.ids.length;
  const count = Math.max(1, Math.floor(total * pct / 100));
  const idsToArchive = _trimPinnedCache.ids.slice(0, count);

  trimPinnedBtn.disabled = true;
  trimPinnedSlider.disabled = true;
  trimPinnedBtn.textContent = `Archiving 0/${idsToArchive.length}…`;
  trimPinnedBtn.style.background = '';
  trimPinnedBtn.style.borderColor = '';
  trimPinnedBtn.style.color = '';

  let archived = 0;
  for (const id of idsToArchive) {
    try {
      const [metaRec, blob] = await Promise.all([icGetFromStore('meta', id), getICBlob(id)]);
      if (metaRec && blob) {
        await archiveToDeepCache(metaRec, blob);
        // Remove the original from the live cache.
        const dtx = icDB.transaction(['meta', 'blobs'], 'readwrite');
        dtx.objectStore('meta').delete(id);
        dtx.objectStore('blobs').delete(id);
        await new Promise(r => { dtx.oncomplete = r; dtx.onerror = () => r(); });
        archived++;
        trimPinnedBtn.textContent = `Archiving ${archived}/${idsToArchive.length}…`;
      }
    } catch (e) { console.warn('Trim archive error for id', id, e); }
  }

  // Reset and refresh.
  trimPinnedSlider.value = 0;
  _trimPinnedCache = null;
  refreshICStats();   // also calls refreshTrimPinnedControl
  refreshDCStats();
  trimPinnedBtn.textContent = `✅ Archived ${archived} image${archived !== 1 ? 's' : ''}`;
  setTimeout(() => {
    trimPinnedBtn.textContent = 'Archive pinned images';
    trimPinnedBtn.disabled = true;
  }, 1500);
}

/* --- Deep Cache Settings wiring --- */

const dcEnabledChk = document.getElementById('deepCacheEnabledChk');
const dcTtlSlider = document.getElementById('deepCacheTtlSlider');
const dcMaxSlider = document.getElementById('deepCacheMaxSlider');
const dcSizeSlider = document.getElementById('deepCacheSizeSlider');
const dcTtlValue = document.getElementById('deepCacheTtlValue');
const dcMaxValue = document.getElementById('deepCacheMaxValue');
const dcSizeValue = document.getElementById('deepCacheSizeValue');
const dcStats = document.getElementById('deepCacheStats');

dcEnabledChk.checked = DC_ENABLED;
dcTtlSlider.value = DC_TTL_DAYS;
dcMaxSlider.value = DC_MAX_COUNT;
dcSizeSlider.value = DC_SIZE_PCT;

function dcUpdateTtlDisplay() { dcTtlValue.textContent = DC_TTL_DAYS >= DC_TTL_DAYS_NEVER ? '∞' : DC_TTL_DAYS + 'd'; }
function dcUpdateMaxDisplay() { dcMaxValue.textContent = DC_MAX_COUNT >= DC_MAX_UNLIMITED ? '∞' : String(DC_MAX_COUNT); }
function dcUpdateSizeDisplay() { dcSizeValue.textContent = DC_SIZE_PCT + '% (~' + Math.round(DC_BASE_RES * DC_SIZE_PCT / 100) + 'px)'; }
dcUpdateTtlDisplay();
dcUpdateMaxDisplay();
dcUpdateSizeDisplay();

async function refreshDCStats() {
  if (!icDB) { dcStats.textContent = 'Archive unavailable'; return; }
  try {
    const count = await new Promise((res) => {
      const r = icDB.transaction('deep-meta', 'readonly').objectStore('deep-meta').count();
      r.onsuccess = () => res(r.result); r.onerror = () => res(0);
    });
    const totalBytes = await getDeepBlobsTotalSize();
    dcStats.textContent = `${count} image${count !== 1 ? 's' : ''} archived · ${formatBytes(totalBytes)}`;
  } catch(e) {
    dcStats.textContent = 'Unable to read archive stats';
  }
}

dcEnabledChk.onchange = () => {
  DC_ENABLED = dcEnabledChk.checked;
  localStorage.setItem('ipo_deepCacheEnabled', String(DC_ENABLED));
};
dcTtlSlider.oninput = () => {
  DC_TTL_DAYS = parseInt(dcTtlSlider.value, 10);
  localStorage.setItem('ipo_deepCacheTtlDays', String(DC_TTL_DAYS));
  dcUpdateTtlDisplay();
};
dcMaxSlider.oninput = () => {
  DC_MAX_COUNT = parseInt(dcMaxSlider.value, 10);
  localStorage.setItem('ipo_deepCacheMaxCount', String(DC_MAX_COUNT));
  dcUpdateMaxDisplay();
};
dcSizeSlider.oninput = () => {
  DC_SIZE_PCT = parseInt(dcSizeSlider.value, 10);
  localStorage.setItem('ipo_deepCacheSizePct', String(DC_SIZE_PCT));
  dcUpdateSizeDisplay();
};
document.getElementById('deepCacheTtlReset').onclick = () => {
  DC_TTL_DAYS = DC_TTL_DAYS_DEFAULT;
  dcTtlSlider.value = DC_TTL_DAYS;
  localStorage.removeItem('ipo_deepCacheTtlDays');
  dcUpdateTtlDisplay();
};
document.getElementById('deepCacheMaxReset').onclick = () => {
  DC_MAX_COUNT = DC_MAX_DEFAULT;
  dcMaxSlider.value = DC_MAX_COUNT;
  localStorage.removeItem('ipo_deepCacheMaxCount');
  dcUpdateMaxDisplay();
};
document.getElementById('deepCacheSizeReset').onclick = () => {
  DC_SIZE_PCT = DC_SIZE_PCT_DEFAULT;
  dcSizeSlider.value = DC_SIZE_PCT;
  localStorage.removeItem('ipo_deepCacheSizePct');
  dcUpdateSizeDisplay();
};

const sessionThumbSlider = document.getElementById('sessionThumbSlider');
const sessionThumbValue = document.getElementById('sessionThumbValue');
sessionThumbSlider.value = SESSION_THUMB_COUNT;
sessionThumbValue.textContent = String(SESSION_THUMB_COUNT);
sessionThumbSlider.oninput = () => {
  SESSION_THUMB_COUNT = parseInt(sessionThumbSlider.value, 10);
  localStorage.setItem('ipo_sessionThumbCount', String(SESSION_THUMB_COUNT));
  sessionThumbValue.textContent = String(SESSION_THUMB_COUNT);
};
document.getElementById('deepCacheClearBtn').onclick = async () => {
  const n = await icStoreCount('deep-meta');
  const act = await confirmChoice({ title: 'Clear the archive?',
    body: `${plural(n, 'archived image')} will be deleted. This can't be undone.`,
    okLabel: `Delete ${plural(n, 'image')}`, danger: true });
  if (act !== 'ok') return;
  const btn = document.getElementById('deepCacheClearBtn');
  await clearDeepStore();
  refreshDCStats();
  btn.textContent = '✅ Cleared!';
  setTimeout(() => btn.textContent = '🗑️ Clear Archive', 1500);
};

/* --- Grid header button wiring --- */

const icDeepToggle = document.getElementById('icDeepToggle');
icDeepToggle.checked = icShowDeep;
icDeepToggle.onchange = () => {
  icShowDeep = icDeepToggle.checked;
  localStorage.setItem('ipo_showDeepCache', icShowDeep ? '1' : '0');
  icOpen();
};

document.getElementById('icZoomOut').onclick = () => { icCellSizeIdx--; icSetCellSize(); };
document.getElementById('icZoomIn').onclick = () => { icCellSizeIdx++; icSetCellSize(); };

const icMaxBtn = document.getElementById('icMaximize');
const icModal = document.getElementById('icModal');
if (localStorage.getItem('ipo_icMaximized') === '1') {
  icModal.classList.add('icMaximized');
  icMaxBtn.title = 'Restore';
}
icMaxBtn.onclick = () => {
  const isMax = icModal.classList.toggle('icMaximized');
  localStorage.setItem('ipo_icMaximized', isMax ? '1' : '0');
  icMaxBtn.title = isMax ? 'Restore' : 'Maximize';
};

/* ===================== Export / Strategy / Help ===================== */

// --- small shared helpers ---
function slugify(s, max = 48) {
  const out = String(s || '').toLowerCase()
    .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, max).replace(/-+$/, '');
  return out || 'untitled';
}
function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => { try { URL.revokeObjectURL(url); } catch (e) {} }, 10000);
}
function exDateStamp() { return new Date().toISOString().slice(0, 10); }
function exExtFromType(type) {
  if (/webp/i.test(type)) return 'webp';
  if (/jpe?g/i.test(type)) return 'jpg';
  if (/png/i.test(type)) return 'png';
  if (/gif/i.test(type)) return 'gif';
  return 'img';
}

// --- Pinned (saved-set) cache ids: named sessions + autosave slot + live upvotes + 🔖/🚫 marks ---
// Marked images are pinned like liked ones so 🧺 Picked's Marked grid keeps their originals.
function addMarkCacheIds(set, pending, committed) {
  for (const r of infAllRecords(pending, committed)) if (r.cacheId != null) set.add(r.cacheId);
}
async function getPinnedCacheIds() {
  const set = new Set();
  for (const u of st.upvotedTasks) { const cid = likedCacheId(u); if (cid != null) set.add(cid); }
  // A live record can still be waiting on cacheImage for its id; its task already has it.
  const idx = infCacheIndex();
  for (const r of infAllRecords(st.markedInfluences, st.instInfluences)) {
    const t = infTaskOf(r, idx);
    const cid = t && t.cacheId != null ? t.cacheId : r.cacheId;
    if (cid != null) set.add(cid);
  }
  try {
    const db = await openSavedSessionDB();
    await new Promise((resolve) => {
      const cur = db.transaction('session', 'readonly').objectStore('session').openCursor();
      cur.onsuccess = (e) => {
        const c = e.target.result;
        if (!c) { resolve(); return; }
        // Every record, INCLUDING __autosave__ (unlike getAllSessions).
        const imgs = c.value && c.value.images;
        if (Array.isArray(imgs)) for (const im of imgs) if (im && im.cacheId != null) set.add(im.cacheId);
        const m = c.value && c.value.meta;
        if (m) addMarkCacheIds(set, m.markedInfluences, m.instInfluences);
        c.continue();
      };
      cur.onerror = () => resolve();
    });
  } catch (e) { console.warn('getPinnedCacheIds failed:', e); }
  return set;
}

// --- Minimal store-method (no compression) ZIP writer ---
const _crcTable = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    t[n] = c >>> 0;
  }
  return t;
})();
function crc32(bytes) {
  let c = 0xFFFFFFFF;
  for (let i = 0; i < bytes.length; i++) c = _crcTable[(c ^ bytes[i]) & 0xFF] ^ (c >>> 8);
  return (c ^ 0xFFFFFFFF) >>> 0;
}
function makeZipBlob(files) {
  const enc = new TextEncoder();
  const chunks = [];
  const central = [];
  let offset = 0;
  const u16 = (n) => new Uint8Array([n & 0xFF, (n >>> 8) & 0xFF]);
  const u32 = (n) => new Uint8Array([n & 0xFF, (n >>> 8) & 0xFF, (n >>> 16) & 0xFF, (n >>> 24) & 0xFF]);
  const push = (arr) => { chunks.push(arr); offset += arr.length; };
  const DOS_TIME = u16(0), DOS_DATE = u16(0x21); // 1980-01-01
  for (const f of files) {
    const nameBytes = enc.encode(f.name);
    const data = f.bytes;
    const crc = crc32(data);
    const localOffset = offset;
    push(u32(0x04034b50)); push(u16(20)); push(u16(0)); push(u16(0));
    push(DOS_TIME); push(DOS_DATE);
    push(u32(crc)); push(u32(data.length)); push(u32(data.length));
    push(u16(nameBytes.length)); push(u16(0));
    push(nameBytes); push(data);
    central.push(u32(0x02014b50), u16(20), u16(20), u16(0), u16(0),
      DOS_TIME, DOS_DATE, u32(crc), u32(data.length), u32(data.length),
      u16(nameBytes.length), u16(0), u16(0), u16(0), u16(0), u32(0),
      u32(localOffset), nameBytes);
  }
  const cdStart = offset;
  let cdSize = 0;
  for (const arr of central) { chunks.push(arr); cdSize += arr.length; offset += arr.length; }
  chunks.push(u32(0x06054b50), u16(0), u16(0), u16(files.length), u16(files.length),
    u32(cdSize), u32(cdStart), u16(0));
  return new Blob(chunks, { type: 'application/zip' });
}

// --- Export overlay ---
const exOverlay = document.getElementById('exOverlay');
const exGridInner = document.getElementById('exGridInner');
// Normalized [{ cacheId, thumbSrc, imgEl, promptId, promptText, resolvedText, score, votes, origin,
// avail, note, idx }]. No `deepId`: a task records the live cache key it was written under and nothing
// about the archive, so these items have no archive rung — see galBlobFrom on why the two keys can't
// stand in for each other. That shape is deliberately a gallery item (§ shared gallery core), so
// exBuildItems doubles as this surface's item builder and the grid takes exItems directly. Nothing maps
// them into a parallel array: availability resolves after the first render and writes back onto these
// objects, and the zip export reads the same ones, so a copy would quietly go stale.
let exItems = [];
let exSource = null;     // { kind:'current' } | { kind:'saved', name, data }
let exBusy = false;
let exResolving = false; // true while the current view's availability check runs (📦 stays off)
let exGen = 0;           // bumped on every teardown and view load; invalidates in-flight async UI writes
// 🧺 Picked's two views. Reset on every open (nothing persisted), like the sort.
let exView = 'upvoted';  // 'upvoted' | 'marked'
let exShowAnti = false;  // Marked view: also show 🚫-only images, at the bottom
let exSortMode = 'newest';
let exMarks = [];        // pkGroupMarks() for the open source, computed once per open
let exMarkOf = () => null;

/* ===================== 🧺 Picked: marked images =====================
   The pure half, kept free of st/DOM so node can test it. A mark record carries a taskId, a cacheId,
   both or neither (see infMatches), so two records are the same image when they share EITHER key — a
   merge, not a single map key: an image marked before cacheImage landed has only a taskId, and its later
   🚫 record only a cacheId. A record with neither key stands alone. */

// pending: [rec]; committed: { [instVersion]: [rec] }. Returns one group per image:
//   { recs, inf, anti, infVers, antiVers (ascending numbers), infPending, antiPending,
//     infFirst, antiFirst ([version, index in that version's list], pending = [Infinity, index]),
//     group ('inf' if it has any 🔖 record, else 'anti'), text, promptId, cacheId, taskId }
function pkGroupMarks(pending, committed) {
  const recs = [];
  // for…in keys are strings — Number() them, or v10 sorts before v9.
  const vers = Object.keys(committed || {}).map(Number).filter(v => !Number.isNaN(v)).sort((a, b) => a - b);
  for (const v of vers) (committed[v] || []).forEach((r, i) => { if (r) recs.push({ r, ver: v, pos: i }); });
  (pending || []).forEach((r, i) => { if (r) recs.push({ r, ver: Infinity, pos: i }); });

  const parent = recs.map((_, i) => i);
  const find = i => { while (parent[i] !== i) { parent[i] = parent[parent[i]]; i = parent[i]; } return i; };
  const union = (a, b) => { a = find(a); b = find(b); if (a !== b) parent[b] = a; };
  const byTask = new Map(), byCache = new Map();
  recs.forEach((x, i) => {
    const tid = x.r.taskId, cid = x.r.cacheId;
    if (tid) { if (byTask.has(tid)) union(byTask.get(tid), i); else byTask.set(tid, i); }
    if (cid != null) { const k = String(cid); if (byCache.has(k)) union(byCache.get(k), i); else byCache.set(k, i); }
  });

  const groups = new Map();
  recs.forEach((x, i) => {
    const root = find(i);
    let g = groups.get(root);
    if (!g) {
      g = { recs: [], inf: false, anti: false, infVers: [], antiVers: [], infPending: false, antiPending: false,
            infFirst: null, antiFirst: null, group: 'inf', text: '', promptId: null, cacheId: null, taskId: null };
      groups.set(root, g);
    }
    g.recs.push(x.r);
    const k = x.r.anti ? 'anti' : 'inf';
    g[k] = true;
    if (x.ver === Infinity) g[k + 'Pending'] = true;
    else if (!g[k + 'Vers'].includes(x.ver)) g[k + 'Vers'].push(x.ver);
    const f = g[k + 'First'];
    if (!f || x.ver < f[0] || (x.ver === f[0] && x.pos < f[1])) g[k + 'First'] = [x.ver, x.pos];
    if (!g.text && x.r.text) g.text = x.r.text;
    if (g.promptId == null && x.r.promptId) g.promptId = x.r.promptId;
    if (g.cacheId == null && x.r.cacheId != null) g.cacheId = x.r.cacheId;
    if (!g.taskId && x.r.taskId) g.taskId = x.r.taskId;
  });
  const out = [...groups.values()];
  for (const g of out) {
    g.infVers.sort((a, b) => a - b);
    g.antiVers.sort((a, b) => a - b);
    g.group = g.inf ? 'inf' : 'anti';
  }
  return out;
}

// (taskId, cacheId) → the image's group, or null. For tagging liked images in the Upvoted view.
function pkMarkLookup(groups) {
  const byTask = new Map(), byCache = new Map();
  for (const g of groups) for (const r of g.recs) {
    if (r.taskId) byTask.set(r.taskId, g);
    if (r.cacheId != null) byCache.set(String(r.cacheId), g);
  }
  return (taskId, cacheId) => (taskId && byTask.get(taskId)) || (cacheId != null && byCache.get(String(cacheId))) || null;
}

// ["v3", "v5", "pending"] — the .json's influenceFor / antiFor.
function pkForList(vers, pending) {
  return vers.map(v => 'v' + v).concat(pending ? ['pending'] : []);
}

// Tile corner badge: the earliest version and how many more, or "pending".
function pkVersionBadge(vers, pending) {
  if (!vers.length) return 'pending';
  const extra = vers.length - 1 + (pending ? 1 : 0);
  return 'v' + vers[0] + (extra ? ' +' + extra : '');
}

// Lightbox caption, one clause per kind.
function pkMarkNote(g) {
  if (!g) return null;
  const one = (icon, label, vers, pending) => vers.length
    ? `${icon} ${label} on ${vers.map(v => 'v' + v).join(', ')}${pending ? ', and pending' : ''}`
    : `${icon} ${label} (pending)`;
  const parts = [];
  if (g.inf) parts.push(one('🔖', 'Influence', g.infVers, g.infPending));
  if (g.anti) parts.push(one('🚫', 'Anti-influence', g.antiVers, g.antiPending));
  return parts.join(' · ') || null;
}

// The .json / .txt dedup by exported text, with the marks of EVERY item sharing that text unioned in, so
// the result doesn't depend on which of them the sort happened to put first. antiOnly: every item with
// that text is a 🚫-only image (→ the .txt's [ANTI] prefix).
function pkPromptMarks(items, keyOf) {
  const m = new Map();
  for (const it of items) {
    const k = keyOf(it);
    if (!k) continue;
    let e = m.get(k);
    if (!e) { e = { infVers: new Set(), antiVers: new Set(), infPending: false, antiPending: false, antiOnly: true }; m.set(k, e); }
    const g = it.mark;
    if (!g || g.inf || !g.anti) e.antiOnly = false;
    if (!g) continue;
    g.infVers.forEach(v => e.infVers.add(v));
    g.antiVers.forEach(v => e.antiVers.add(v));
    if (g.infPending) e.infPending = true;
    if (g.antiPending) e.antiPending = true;
  }
  const out = new Map();
  for (const [k, e] of m) {
    const num = s => [...s].sort((a, b) => a - b);
    out.set(k, {
      influenceFor: pkForList(num(e.infVers), e.infPending),
      antiFor: pkForList(num(e.antiVers), e.antiPending),
      antiOnly: e.antiOnly
    });
  }
  return out;
}

// Generation order for a live task. task.idx is unusable after a restore — both restore paths mint
// st.nextIdx++, so every liked card numbers before every unliked one — but both tag the card with the
// SAVED feed position (card.dataset.idx), and live cards tag task.idx there too.
function pkTaskIdx(task) {
  if (!task) return undefined;
  const d = task.ui && task.ui.card ? task.ui.card.dataset.idx : undefined;
  const n = d != null && d !== '' ? Number(d) : NaN;
  return Number.isNaN(n) ? task.idx : n;
}

// Group the open source's marks once per open. In the current session every record is resolved first:
// infTaskOf rebinds a record's taskId on a hit, which is what lets a cacheId-only record merge with a
// taskId-only one for the same image. One index for the whole pass — not infCacheIndex() per record.
function exPrepareMarks(source) {
  if (source.kind === 'current') {
    const idx = infCacheIndex();
    for (const r of infAllRecords(st.markedInfluences, st.instInfluences)) infTaskOf(r, idx);
    const groups = pkGroupMarks(st.markedInfluences, st.instInfluences);
    for (const g of groups) {
      g.task = null;
      for (const r of g.recs) { const t = infTaskOf(r, idx); if (t) { g.task = t; break; } }
    }
    return groups;
  }
  const meta = (source.data && source.data.meta) || {};
  return pkGroupMarks(meta.markedInfluences, meta.instInfluences);
}

function exBuildItems(source) {
  return exView === 'marked' ? exBuildMarkedItems(source) : exBuildUpvotedItems(source);
}

function exBuildUpvotedItems(source) {
  const items = [];
  if (source.kind === 'current') {
    for (const t of st.upvotedTasks) {
      const p = st.prompts[t.promptId] || {};
      const cacheId = t.cacheId != null ? t.cacheId : null;
      const mark = exMarkOf(t.taskId, cacheId);
      items.push({
        cacheId,
        thumbSrc: (t.imgEl && t.imgEl.src) ? t.imgEl.src : (t._thumb || ''),
        imgEl: t.imgEl || null,
        promptId: t.promptId,
        promptText: p.text || '',
        resolvedText: t.resolvedText || p.text || '',
        score: p.score, votes: p.votes, origin: p.origin || 'generated',
        avail: null, note: null,
        idx: pkTaskIdx(st.tasksById[t.taskId]),   // generation order, for the gallery sort
        mark, markNote: pkMarkNote(mark)
      });
    }
  } else {
    const data = source.data || {};
    const prompts = data.prompts || {};
    for (const im of (data.images || [])) {
      const p = prompts[im.promptId] || {};
      const cacheId = im.cacheId != null ? im.cacheId : null;
      const mark = exMarkOf(null, cacheId);
      items.push({
        cacheId,
        thumbSrc: im.thumbnail || '',
        imgEl: null,
        promptId: im.promptId,
        promptText: im.promptText || p.text || '',
        resolvedText: im.resolvedText || im.promptText || p.text || '',
        score: p.score, votes: p.votes, origin: p.origin || 'generated',
        avail: null, note: null,
        idx: im.idx,   // saved generation order; may be absent on old sessions (→ stable insertion order)
        mark, markNote: pkMarkNote(mark)
      });
    }
  }
  return items;
}

// The Marked view: every 🔖 image, plus 🚫-only ones when the checkbox is on. Gone images are kept — the
// stored wording is still worth seeing — and resolve to `gone` in exResolveAvailability.
function exBuildMarkedItems(source) {
  const items = [];
  const groups = exMarks.filter(g => g.group === 'inf' || exShowAnti);
  const firstOf = g => (g.group === 'inf' ? g.infFirst : g.antiFirst);
  if (source.kind === 'current') {
    const likedByTask = new Map(st.upvotedTasks.map(u => [u.taskId, u]));
    for (const g of groups) {
      const t = g.task;
      const pid = (t && t.promptId) || g.promptId;
      const p = st.prompts[pid] || {};
      const cacheId = (t && t.cacheId != null) ? t.cacheId : g.cacheId;
      const liked = t ? likedByTask.get(t.id) : null;
      items.push({
        cacheId,
        thumbSrc: (liked && liked._thumb) || (cacheId != null && st.markThumbs[cacheId]) || '',
        // Marked tasks keep their image on task.ui — .imgEl/._thumb exist only on upvotedTasks entries.
        imgEl: (t && t.ui && t.ui.imgEl) || null,
        promptId: pid,
        promptText: p.text || '',
        resolvedText: (t && t.resolvedText) || g.text || p.text || '',
        score: p.score, votes: p.votes, origin: p.origin || 'generated',
        avail: null, note: null,
        idx: t ? pkTaskIdx(t) : undefined,
        mark: g, markNote: pkMarkNote(g), firstPos: firstOf(g)
      });
    }
  } else {
    const data = source.data || {};
    const prompts = data.prompts || {};
    const likedByCid = new Map(), rowByCid = new Map();
    for (const im of (data.images || [])) if (im && im.cacheId != null) likedByCid.set(String(im.cacheId), im);
    for (const r of (data.feedManifest || [])) if (r && r.cacheId != null) rowByCid.set(String(r.cacheId), r);
    const thumbs = data.markThumbs || {};
    for (const g of groups) {
      const cid = g.cacheId;
      const liked = cid != null ? likedByCid.get(String(cid)) : null;
      const row = cid != null ? rowByCid.get(String(cid)) : null;
      const pid = g.promptId || (liked && liked.promptId) || (row && row.promptId);
      const p = prompts[pid] || {};
      items.push({
        cacheId: cid,
        thumbSrc: (liked && liked.thumbnail) || (cid != null && thumbs[cid]) || '',
        imgEl: null,
        promptId: pid,
        promptText: (liked && liked.promptText) || p.text || '',
        resolvedText: (liked && liked.resolvedText) || g.text || p.text || '',
        score: p.score, votes: p.votes, origin: p.origin || 'generated',
        avail: null, note: null,
        idx: liked && liked.idx != null ? liked.idx : (row ? row.idx : undefined),
        mark: g, markNote: pkMarkNote(g), firstPos: firstOf(g)
      });
    }
  }
  return items;
}

// The Marked view keeps 🚫-only images under every 🔖 one whatever the sort; each group sorts on its own.
function exSortItems(items, mode) {
  if (exView !== 'marked') return galSortItems(items, mode);
  const top = items.filter(it => !it.mark || it.mark.group !== 'anti');
  const bottom = items.filter(it => it.mark && it.mark.group === 'anti');
  galSortItems(top, mode);
  galSortItems(bottom, mode);
  items.length = 0;
  items.push(...top, ...bottom);
  return items;
}

const exPromptKey = it => (it.resolvedText || it.promptText || '').trim();

function exDistinctPrompts() {
  // Dedup by the actual exported text so distinct resolved variants of one prompt template
  // are each kept, and empty-text entries are dropped (they'd export nothing).
  const seen = new Set(); const out = [];
  for (const it of exItems) {
    const key = exPromptKey(it);
    if (!key || seen.has(key)) continue;
    seen.add(key); out.push(it);
  }
  return out;
}

function exSourceSlug() {
  return exSource && exSource.kind === 'saved' ? slugify(exSource.name, 40) : 'current';
}

// Chrome only — the grid itself is the shared one. Cells load lazily and unload on scroll-out, so a
// 400-image session costs a screenful of decoded images rather than 400, and the cell badges its own
// downgrade from whichever rung answered instead of waiting on exResolveAvailability.
// With only 🚫 marks and the box unticked, the Marked grid is empty for a reason the user can fix.
let exAntiCount = 0;
function exEmptyText(view, showAnti, antiCount) {
  if (view !== 'marked') return 'No liked images yet — tap an image to like it.';
  if (!showAnti && antiCount > 0) return `No 🔖 marks. Tick “Show 🚫 anti-influences” above to see ${plural(antiCount, '🚫 mark')}.`;
  return 'No images marked as influence yet. Hover an image’s ❓ and choose Mark as influence.';
}

function exRenderGrid() {
  const emptyEl = document.getElementById('exEmpty');
  const gridEl = document.getElementById('exGrid');
  const filtersEl = document.getElementById('exFilters');
  const antiWrap = document.getElementById('exAntiWrap');
  emptyEl.textContent = exEmptyText(exView, exShowAnti, exAntiCount);
  const empty = !exItems.length;
  // No point sorting an empty set — but the 🚫 checkbox must stay reachable: a session whose only marks
  // are 🚫 has an empty Marked grid until you tick it.
  document.getElementById('exSortWrap').style.display = empty ? 'none' : '';
  document.getElementById('exGallLabel').style.visibility = empty ? 'hidden' : '';
  if (filtersEl) filtersEl.style.display = (!empty || (antiWrap && antiWrap.style.display !== 'none')) ? 'flex' : 'none';
  if (empty) {
    galTeardown(exGridInner);
    exGridInner.innerHTML = '';
    gridEl.style.display = 'none';
    emptyEl.style.display = 'flex';
    return;
  }
  gridEl.style.display = 'block';
  emptyEl.style.display = 'none';
  // The grid's scroll container is #exGrid, which is exGridInner's parent — the core's default root.
  galRenderGrid(exGridInner, exItems, {
    cellClass: 'exCell',
    decorate: (cell, it) => {
      const pr = document.createElement('div');
      pr.className = 'exCellPrompt';
      pr.textContent = it.resolvedText || it.promptText || '(no prompt)';
      cell.title = it.resolvedText || it.promptText || '';
      cell.appendChild(pr);
      // 🔖 amber / 🚫 red outline, in both views. An image that is both is a 🔖 with a 🚫 corner badge.
      const g = it.mark;
      if (!g) return;
      cell.classList.add(g.group === 'inf' ? 'pkInf' : 'pkAnti');
      if (g.inf && g.anti) {
        const b = document.createElement('span');
        b.className = 'pkAntiBadge';
        b.textContent = '🚫';
        cell.appendChild(b);
      }
      if (exView === 'marked') {
        const tag = document.createElement('span');
        tag.className = 'galCellTag';
        tag.textContent = g.group === 'inf' ? pkVersionBadge(g.infVers, g.infPending) : pkVersionBadge(g.antiVers, g.antiPending);
        cell.appendChild(tag);
      }
      if (it.markNote) cell.title = it.markNote + '\n' + cell.title;
    },
    // The export grid doubles as a gallery: clicking a tile opens the (shared) image-cache lightbox.
    onCellClick: (i) => galOpenLightbox(exItems, i, exGridInner),
  });
}

// Kept rather than replaced by the grid's rung, which answers the same question for one cell at the
// moment it scrolls into view. The export buttons need the answer for the WHOLE set before anything is
// scrolled to: "📦 Images (3 of 7)", the note about originals that aged out, and the filter that decides
// what goes into the zip. Under the recycling grid, cells below the fold may never resolve at all.
// Narrower than the display ladder on purpose — see exGetFullResBlob.
//
// It does not ask the archive. It used to, with `getDeepBlob(it.cacheId)`, which was addressing the
// archive's keyspace with a live-cache key: a hit meant "some archived image happens to carry that
// number", not "this image was archived", so an item could be labelled archived and then shown a
// stranger's picture. A task only ever knows its live cacheId, and `originalId` — the archive's record
// of where a row came from — has no index to search by, so there is no cheap correct lookup to put in
// its place. An original that aged out therefore reads as what it verifiably is: gone from the cache,
// with the page's own thumbnail left to show.
async function exResolveAvailability(gen) {
  // One key read for the whole set; per-item blob reads only if that isn't available.
  const keys = await icBlobKeySet();
  // Snapshot: the sort dropdown reorders exItems in place mid-await, which would leave items behind the
  // live iterator's cursor stuck at avail:null — excluded from the zip and miscounted in the buttons.
  for (const it of exItems.slice()) {
    if (gen !== exGen) return;   // closed, reopened or switched view: these items are no longer shown
    if (exHasFullResImg(it)) it.avail = true;
    else {
      it.avail = false;
      if (it.cacheId != null) {
        if (keys) it.avail = keys.has(String(it.cacheId));
        else { try { if (await getICBlob(it.cacheId)) it.avail = true; } catch (e) {} }
      }
    }
    // Gone = no bytes on ANY display rung (not "no live card": an unliked marked image that wasn't
    // restored can still be in the cache, and a marked error card is live with nothing to show). A rung
    // that threw leaves it unknown, matching the grid's galNa rule. Anything holding a thumbnail or an
    // image element has bytes by construction — every liked item does — so only the bare ones are probed.
    if (it.avail || it.thumbSrc || it.imgEl) it.gone = false;
    else if (it.gone == null) {
      try { const r = await galBlobFrom(it); if (r.blob) it.gone = false; else if (!r.error) it.gone = true; } catch (e) {}
    }
    // The lightbox's caveat line, read at open time by galOpenLightbox. A gone item never opens.
    it.note = it.avail === false && it.gone !== true ? 'Thumbnail only — original no longer cached' : null;
  }
}

// A displayed image counts as the original unless it's a restored card's stored 128px thumbnail, which
// createRestoredCard tags until (and unless) the cached original replaces it.
function exHasFullResImg(it) {
  return !!(it.imgEl && it.imgEl.src && !it.imgEl._ipoThumbOnly);
}

function exRefreshButtons() {
  const total = exItems.length;
  const exportable = exItems.filter(it => it.avail === true).length;
  const hasPrompts = exDistinctPrompts().length > 0;
  const imgBtn = document.getElementById('exImagesBtn');
  // Mid-resolve the counts are partial: a sort change re-runs this, and an enabled button would zip only
  // the items checked so far.
  imgBtn.disabled = exBusy || exResolving || exportable === 0;
  imgBtn.title = exResolving && total ? 'Checking which full-size originals are still cached' : 'Download every full-resolution image below as a .zip';
  imgBtn.textContent = exResolving && total ? '📦 Checking…'
    : total === 0 ? '📦 Images (.zip)'
    : exportable === total ? `📦 Images (${total})`
    : `📦 Images (${exportable} of ${total})`;
  document.getElementById('exPromptsJsonBtn').disabled = exBusy || !hasPrompts;
  document.getElementById('exPromptsTxtBtn').disabled = exBusy || !hasPrompts;
  // A view switch reloads exItems under a new exGen, which would orphan a running export's progress line.
  for (const id of ['exViewUpvoted', 'exViewMarked', 'exShowAnti']) {
    const el = document.getElementById(id);
    if (el) el.disabled = exBusy;
  }
}

// Dims what can't be exported at full resolution and counts it for the note. No longer writes the
// per-cell badge: the shared grid badges "thumb only" from the rung that actually answered, which is the
// same verdict arrived at from the bytes on screen rather than from a probe made before them — and it
// carries a tooltip explaining the downgrade. The dim still comes from here, because it has to apply to
// every cell whether or not it has scrolled into view yet — which is why .exUnavailable washes the cell
// rather than dimming its <img>. Under the recycling grid most cells don't have one at any given moment,
// and dimming the image marked only the tiles you could already see.
function exApplyAvailability() {
  const cells = exGridInner.querySelectorAll('.exCell');
  const unavailable = exItems.filter(it => it.avail === false).length;
  exItems.forEach((it, i) => {
    if (cells[i]) {
      cells[i].classList.toggle('exUnavailable', it.avail === false);
      galMarkGone(cells[i], it.gone === true);
    }
  });
  const noteEl = document.getElementById('exNote');
  if (unavailable > 0) {
    noteEl.style.display = 'block';
    noteEl.innerHTML = `${unavailable} image${unavailable !== 1 ? 's' : ''} left out of the zip — no longer cached at full size. Turn on <b>Settings → Keep liked images cached</b> to prevent this.`;
  } else {
    noteEl.style.display = 'none';
  }
  exRefreshButtons();
}

// Deliberately the two original-resolution rungs only, where galBlobFrom walks all four. This is the
// export gate, not a display path: a zip presented as your originals must not quietly contain a page
// thumbnail, so an item that can only answer from the lower rungs is excluded (avail === false) rather
// than downgraded. Displaying it is a different question — the grid and the lightbox happily show the
// downgrade, labelled.
async function exGetFullResBlob(it) {
  if (it.cacheId != null) {
    try { const b = await getICBlob(it.cacheId); if (b) return b; } catch (e) {}
  }
  if (exHasFullResImg(it)) {
    try { const b = await fetch(it.imgEl.src).then(r => r.blob()); if (b) return b; } catch (e) {}
  }
  return null;
}

function exApplySort(mode) {
  exSortMode = mode;
  exSortItems(exItems, mode);
  exRenderGrid();          // rebuild cells in the new order (data-idx stays aligned to exItems)
  exApplyAvailability();   // re-dim by index; `avail` already lives on the items, so no re-resolve
}

async function exportImagesZip() {
  if (exBusy) return;
  const usable = exItems.filter(it => it.avail === true);
  if (!usable.length) return;
  const gen = exGen;                     // if the panel closes/reopens, stop touching its UI
  // Named now: a close/reopen (or another session's Picked) mid-export changes exSource and exView.
  const zipName = `ipo-${exSourceSlug()}-${exView}-images-${exDateStamp()}.zip`;
  exBusy = true; exRefreshButtons();
  const prog = document.getElementById('exProgress');
  prog.style.display = 'block';
  const setProg = (t) => { if (gen === exGen) prog.textContent = t; };
  const files = [];
  try {
    for (let i = 0; i < usable.length; i++) {
      setProg(`Preparing image ${i + 1} of ${usable.length}…`);
      const blob = await exGetFullResBlob(usable[i]);
      if (!blob) continue;              // original vanished between resolve and export
      const bytes = new Uint8Array(await blob.arrayBuffer());
      const ext = exExtFromType(blob.type);
      const base = slugify(usable[i].resolvedText || usable[i].promptText, 48);
      files.push({ name: `${String(files.length + 1).padStart(3, '0')}_${base}.${ext}`, bytes });
    }
    if (!files.length) { setProg('Nothing to export — originals could not be read.'); return; }
    setProg('Building zip…');
    downloadBlob(makeZipBlob(files), zipName);
    const missed = usable.length - files.length;
    setProg(`Exported ${files.length} image${files.length !== 1 ? 's' : ''}${missed > 0 ? ` (${missed} could not be read)` : ''}.`);
  } catch (e) {
    console.warn('Image export failed:', e);
    setProg('Export failed — see console.');
  } finally {
    exBusy = false; exRefreshButtons();
    setTimeout(() => { if (gen === exGen && !exBusy) prog.style.display = 'none'; }, 4000);
  }
}

function exportPromptsJson() {
  const marks = pkPromptMarks(exItems, exPromptKey);
  const list = exDistinctPrompts().map((it, i) => {
    const m = marks.get(exPromptKey(it));
    return {
      index: i + 1,
      promptText: it.promptText || '',
      resolvedText: it.resolvedText || '',
      score: it.score != null ? it.score : null,
      votes: it.votes != null ? it.votes : null,
      origin: it.origin || null,
      // Two fields, not one "mark": an image can be a 🔖 for v3 and a 🚫 for v5.
      ...(m && m.influenceFor.length ? { influenceFor: m.influenceFor } : {}),
      ...(m && m.antiFor.length ? { antiFor: m.antiFor } : {})
    };
  });
  if (!list.length) return;
  const payload = {
    source: exSource ? exSource.kind : 'current',
    sessionName: exSource && exSource.kind === 'saved' ? exSource.name : null,
    view: exView,
    exportedAt: new Date().toISOString(),
    count: list.length,
    prompts: list
  };
  downloadBlob(new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' }),
    `ipo-${exSourceSlug()}-${exView}-prompts-${exDateStamp()}.json`);
}

function exportPromptsTxt() {
  const marks = pkPromptMarks(exItems, exPromptKey);
  const list = exDistinctPrompts()
    .map(it => {
      const text = exPromptKey(it);
      const m = marks.get(text);
      return text && m && m.antiOnly ? '[ANTI] ' + text : text;   // so a 🚫 isn't pasted somewhere by mistake
    })
    .filter(Boolean);
  if (!list.length) return;
  downloadBlob(new Blob([list.join('\n\n') + '\n'], { type: 'text/plain' }),
    `ipo-${exSourceSlug()}-${exView}-prompts-${exDateStamp()}.txt`);
}

function exTeardown() {
  exGen++;                 // invalidate any in-flight export/resolve UI writes
  galTeardown(exGridInner); // stops the observer and revokes whatever URLs the grid still holds
  exGridInner.innerHTML = '';
  exItems = [];
  // NB: don't reset exBusy here — a running export's finally owns it, so a close/reopen
  // mid-export can't clear the guard and let a second export start concurrently.
}

function exClose() {
  exOverlay.classList.remove('exOpen');
  exTeardown();
  exSource = null;
  exMarks = []; exMarkOf = () => null;   // the groups hold live tasks (g.task) — let them go
}

async function exOpen(source) {
  exTeardown();
  exSource = source;
  document.getElementById('exSubtitle').textContent =
    source.kind === 'saved' ? '· ' + source.name : '· current session';
  document.getElementById('exProgress').style.display = 'none';
  // Every open lands on Upvoted, Newest first, 🚫 hidden (matches the cache view; nothing persisted).
  exView = 'upvoted';
  exShowAnti = false;
  exSortMode = 'newest';
  exMarks = exPrepareMarks(source);
  exMarkOf = pkMarkLookup(exMarks);
  exOverlay.classList.add('exOpen');
  await exLoadView();
}

// (Re)build the visible set as a fresh load — the open, a view switch and the 🚫 checkbox all come here.
// The new gen is what stops a still-running resolve from applying the old view's answers to the new
// items by index; the re-resolve is what gives the new items an `avail` (otherwise 📦 stays disabled).
// Sorted before the first render so the grid, lightbox order and exports all agree from the outset.
async function exLoadView() {
  exGen++;
  const gen = exGen;
  exItems = exBuildItems(exSource);
  exSortItems(exItems, exSortMode);
  exUpdateViewControls();
  exRenderGrid();
  document.getElementById('exNote').style.display = 'none';
  // Prompt buttons depend only on prompt count — enable immediately.
  const hasPrompts = exDistinctPrompts().length > 0;
  document.getElementById('exPromptsJsonBtn').disabled = exBusy || !hasPrompts;
  document.getElementById('exPromptsTxtBtn').disabled = exBusy || !hasPrompts;
  // Images button waits on the (async) full-res availability check.
  const imgBtn = document.getElementById('exImagesBtn');
  imgBtn.disabled = true;
  imgBtn.textContent = exItems.length ? '📦 Checking…' : '📦 Images (.zip)';
  if (exItems.length) imgBtn.title = 'Checking which full-size originals are still cached';
  exResolving = true;
  try { await exResolveAvailability(gen); }
  finally { if (gen === exGen) exResolving = false; }
  if (gen !== exGen) return; // panel was closed, reopened or switched view while resolving
  exApplyAvailability();
}

// The segmented switch (with counts), the 🚫 checkbox, and the Marked-only sort option. Counts come from
// the whole source, not the visible set, so 🔖 Marked shows its number before you switch to it.
function exUpdateViewControls() {
  const upCount = exSource.kind === 'current' ? st.upvotedTasks.length : ((exSource.data && exSource.data.images) || []).length;
  const infCount = exMarks.filter(g => g.group === 'inf').length;
  const antiCount = exMarks.filter(g => g.group === 'anti').length;
  const up = document.getElementById('exViewUpvoted');
  const mk = document.getElementById('exViewMarked');
  up.textContent = `👍 Upvoted (${upCount})`;
  mk.textContent = `🔖 Marked (${infCount})`;
  up.classList.toggle('pgtSegOn', exView === 'upvoted');
  mk.classList.toggle('pgtSegOn', exView === 'marked');
  up.setAttribute('aria-pressed', String(exView === 'upvoted'));
  mk.setAttribute('aria-pressed', String(exView === 'marked'));
  const antiWrap = document.getElementById('exAntiWrap');
  exAntiCount = antiCount;
  antiWrap.style.display = exView === 'marked' && antiCount > 0 ? '' : 'none';
  document.getElementById('exShowAnti').checked = exShowAnti;
  document.getElementById('exAntiLabel').textContent = `Show 🚫 anti-influences (${antiCount})`;
  // "By instruction version" means nothing for liked images; removed rather than hidden, since a hidden
  // <option> still shows in some browsers' pickers.
  const sel = document.getElementById('exSort');
  let opt = sel.querySelector('option[value="version"]');
  if (exView === 'marked' && !opt) {
    opt = document.createElement('option');
    opt.value = 'version';
    opt.textContent = 'By instruction version';
    sel.appendChild(opt);
  } else if (exView !== 'marked' && opt) {
    opt.remove();
  }
  sel.value = exSortMode;
}

function exSetView(view) {
  if (exBusy || view === exView) return;
  exView = view;
  if (view !== 'marked' && exSortMode === 'version') exSortMode = 'newest';
  document.getElementById('exGrid').scrollTop = 0;
  exLoadView();
}

document.getElementById('showExportBtn').onclick = () => exOpen({ kind: 'current' });
document.getElementById('exCloseX').onclick = exClose;
exOverlay.addEventListener('click', (e) => { if (e.target === exOverlay) exClose(); });
document.getElementById('exImagesBtn').onclick = exportImagesZip;
document.getElementById('exPromptsJsonBtn').onclick = exportPromptsJson;
document.getElementById('exPromptsTxtBtn').onclick = exportPromptsTxt;
document.getElementById('exSort').onchange = e => exApplySort(e.target.value);
document.getElementById('exViewUpvoted').onclick = () => exSetView('upvoted');
document.getElementById('exViewMarked').onclick = () => exSetView('marked');
document.getElementById('exShowAnti').onchange = e => {
  if (exBusy) { e.target.checked = exShowAnti; return; }
  exShowAnti = e.target.checked;
  exLoadView();
};

// --- Improvement Strategy popover ---
function updateStrategyButton() {
  const level = document.getElementById('strategyBtnLevel');
  const flags = document.getElementById('strategyBtnFlags');
  if (!level || !flags) return;
  const names = ['Faithful', 'Balanced', 'Creative'];
  const lv = Math.max(0, Math.min(2, st.creativity | 0));
  level.innerHTML = '';
  const gauge = document.createElement('span');
  gauge.className = 'strategyGauge';
  gauge.title = `Creativity: ${names[lv]} (${lv + 1} of 3)`;
  for (let i = 0; i < 3; i++) {
    const d = document.createElement('span');
    d.className = 'sgDot' + (i <= lv ? ' on' : '');
    gauge.appendChild(d);
  }
  level.appendChild(gauge);
  flags.innerHTML = '';
  const mk = (glyph, on, name) => {
    const s = document.createElement('span');
    s.className = on ? 'on' : 'off';
    s.textContent = glyph;
    s.title = name + (on ? ' on' : ' off');
    return s;
  };
  flags.appendChild(mk('🔀', !!st.allowPromptMixing, 'Mix in likes from earlier instructions'));
  flags.appendChild(mk('🎯', !!st.promoteUpvoted, 'Sometimes use a top-liked prompt as the instruction'));
  flags.appendChild(mk('⏳', !!st.freshPromptsOnly, 'Fresh prompts only'));
}

const strategyBtn = document.getElementById('strategyBtn');
const strategyPopover = document.getElementById('strategyPopover');
function setStrategyOpen(open) {
  strategyPopover.style.display = open ? 'block' : 'none';
  if (open) {
    // Keep the popover on-screen when vertical space is tight: it drops down from the toolbar
    // (top: 100% + 6px), so on a short viewport it used to run off the bottom with no way to
    // reach the lower controls. Cap its height to the gap below the button and let it scroll.
    const gap = 12;
    const top = strategyBtn.getBoundingClientRect().bottom + 6;
    strategyPopover.style.maxHeight = Math.max(140, window.innerHeight - top - gap) + 'px';
    keepToolbarPopoverOnScreen(strategyPopover, strategyBtn);
  }
}
strategyBtn.onclick = (e) => {
  e.stopPropagation();
  setMiscOpen(false);   // only one toolbar popover open at a time
  setPauseMenuOpen(false);
  setStrategyOpen(strategyPopover.style.display !== 'block');
};
strategyPopover.addEventListener('click', (e) => e.stopPropagation());
document.addEventListener('click', () => { setStrategyOpen(false); setMiscOpen(false); setPauseMenuOpen(false); });
updateStrategyButton();

// Clear steer history: null p.influenceText on every prompt that carries it, keeping p.influenced — so an
// UNUSED steered prompt stays badged and still counts as steered everywhere, and its ❓ panel just falls
// back to the generic "not recorded" line. A used prompt shed that flag on its first image, so it has no
// badge to keep and its steer row disappears entirely (no badge, no known steer → nothing to report).
// Scope is deliberately the durable per-prompt copy only; queued chips and the in-memory event log are
// left alone. Irreversible, so it confirms with a count.
const clearSteerHistoryBtn = document.getElementById('clearSteerHistoryBtn');
if (clearSteerHistoryBtn) {
  clearSteerHistoryBtn.onclick = async () => {
    const affected = getAllPrompts().filter(p => p && p.influenceText != null);
    if (!affected.length) {
      const prev = clearSteerHistoryBtn.textContent;
      clearSteerHistoryBtn.textContent = 'No steer history to clear';
      setTimeout(() => { clearSteerHistoryBtn.textContent = prev; }, 1500);
      return;
    }
    const n = affected.length;
    const act = await confirmChoice({ title: 'Clear steer history?',
      body: `Forgets what steered ${plural(n, 'prompt')}; their 🧲 badges stay. This can't be undone.`,
      okLabel: `Clear ${n}`, danger: true });
    if (act !== 'ok') return;
    // influenceInherited goes with it: it qualifies a steer we're about to forget, and leaving it set
    // would mean a later re-steer of the same prompt inherited a marker from history that no longer exists.
    affected.forEach(p => { p.influenceText = null; p.influenceInherited = null; });
    logEvent('steer_history_cleared', { count: n });
    if (_statsMode === 'tile') hideStats();   // a panel open on a just-cleared tile would be stale
    scheduleAutosave();
    clearSteerHistoryBtn.textContent = `✅ Cleared ${n}`;
    setTimeout(() => { clearSteerHistoryBtn.textContent = '🧹 Clear steer history'; }, 1500);
  };
}

// --- Misc popover (spin-off + steer history) ---
// Mirrors the Improvement Strategy popover: same shell, mutually exclusive open state.
const miscBtn = document.getElementById('miscBtn');
const miscPopover = document.getElementById('miscPopover');
const spinSlider = document.getElementById('spinSlider');
const spinSummary = document.getElementById('spinSummary');
const spinPreview = document.getElementById('spinPreview');
const spinNameInput = document.getElementById('spinNameInput');
const spinCreateBtn = document.getElementById('spinCreateBtn');
const spinStatus = document.getElementById('spinStatus');

let spinSliderValue = null;   // remembered handle position for the rest of the session

// Compute, from LIVE st, what a trim keeping the most-recent `keepN` prompt-bearing
// instruction versions would keep vs drop. Cheap (no thumbnail work) — safe on slider drag.
// A "version" here is a value of prompt.ver that actually appears on ≥1 prompt (a notch);
// this matches trimSessionData's own `vers` derivation exactly, so the preview never lies.
function spinOffPlan(keepN) {
  const prompts = st.prompts || {};
  const ids = Object.keys(prompts);
  const vers = [...new Set(ids.map(id => prompts[id] && prompts[id].ver).filter(v => v != null))].sort((a, b) => a - b);
  const M = vers.length;
  const keep = M ? Math.max(1, Math.min(keepN, M)) : 0;
  const cutoff = M ? vers[M - keep] : null;   // lowest kept version

  // Decision A: an upvoted image is kept ⟺ its generating prompt's ver ≥ cutoff.
  let totalUpvoted = 0, keptUpvoted = 0;
  for (const t of st.upvotedTasks) {
    if (!t || t.promptId == null) continue;
    totalUpvoted++;
    const p = prompts[t.promptId];
    if (p && cutoff != null && p.ver >= cutoff) keptUpvoted++;
  }
  let keptPrompts = 0;
  for (const id of ids) if (cutoff != null && prompts[id].ver >= cutoff) keptPrompts++;

  return { M, keep, cutoff, vers, totalUpvoted, keptUpvoted, totalPrompts: ids.length, keptPrompts };
}

function renderSpinPreview() {
  const plan = spinOffPlan(Number(spinSlider.value));
  const { M, keep, cutoff, vers, totalUpvoted, keptUpvoted, totalPrompts, keptPrompts } = plan;

  if (M === 0) {
    spinSummary.textContent = 'Nothing to trim yet — generate some prompts first.';
    spinPreview.innerHTML = '';
    return plan;
  }

  const dropped = M - keep;
  const full = keep >= M;
  const head = full
    ? `<b>Full copy</b> — keeps all ${M} instruction${M === 1 ? '' : 's'}`
    : `Keep last <b>${keep}</b> of ${M} instructions · <span class="spinDrop">drops ${dropped} older</span>`;
  spinSummary.innerHTML = `${head}<br>→ keeps <b>${keptUpvoted}/${totalUpvoted}</b> liked image${totalUpvoted === 1 ? '' : 's'} · <b>${keptPrompts}/${totalPrompts}</b> prompts`;

  // Version list, newest-first, dashed divider between kept and dropped.
  const rows = [];
  let dividerInserted = false;
  for (const v of [...vers].reverse()) {
    const kept = cutoff != null && v >= cutoff;
    if (!kept && !dividerInserted) { rows.push('<div class="spinCutoff">— cutoff —</div>'); dividerInserted = true; }
    const text = (st.instHistory && st.instHistory[v] != null && String(st.instHistory[v]).trim()) || '(instruction text not recorded)';
    rows.push(
      `<div class="spinVerRow ${kept ? 'kept' : 'dropped'}">` +
        `<span class="spinVerTag">v${v}</span>` +
        `<span class="spinVerText" title="${escapeHtml(text)}">${escapeHtml(text)}</span>` +
        `<span class="spinVerMark">${kept ? '✓' : '✕'}</span>` +
      `</div>`
    );
  }
  spinPreview.innerHTML = rows.join('');
  return plan;
}

// Default = the current session's name + an incremented number ("Foo" → "Foo 2" → "Foo 3"). Peels a
// trailing number off the source so repeated spin-offs read "Foo 3", not "Foo 2 2". Falls back to the
// instruction text (or "Session") when the current session is unnamed.
// Session names already in the store, read as keys when the Misc popover opens. Boot no longer builds
// st.savedSessionsList, and reading every session in full just to sharpen a suggested name would be a
// bad trade — but the keys alone cost nothing. Both sources are merged below because whichever is
// fresher varies: the list is only there once something has scanned, these only once Misc has opened.
let spinTakenNames = new Set();
let spinSuggestedName = '';       // last name this suggested, so a user's own typing is never overwritten

function defaultSpinName() {
  const taken = new Set([...spinTakenNames, ...(st.savedSessionsList || []).map(s => s.name)]);
  const src = st.currentSessionName || (st.instruction || '').slice(0, 24).trim() || 'Session';
  const m = src.match(/^(.*?)\s+(\d+)$/);
  const stem = ((m ? m[1] : src).trim()) || 'Session';
  let n = m ? parseInt(m[2], 10) + 1 : 2;
  while (taken.has(`${stem} ${n}`)) n++;
  return `${stem} ${n}`;
}

function refreshSpinOff() {
  const prompts = st.prompts || {};
  const M = new Set(Object.keys(prompts).map(id => prompts[id] && prompts[id].ver).filter(v => v != null)).size;

  spinSlider.min = 1;
  spinSlider.max = Math.max(1, M);
  spinSlider.disabled = M < 2;             // 0 or 1 notch → nothing to drag

  if (spinSliderValue == null) spinSliderValue = Math.max(1, Math.round(M / 2));   // default: midpoint
  spinSliderValue = Math.max(1, Math.min(spinSliderValue, Math.max(1, M)));
  spinSlider.value = spinSliderValue;

  spinCreateBtn.disabled = M < 1;          // M===0 → nothing to copy
  // Only suggest a name when there's actually something to spin off; before Start / with no prompts,
  // a prefilled name reads as if a session were ready to fork when none is.
  if (M >= 1) {
    if (!spinNameInput.value.trim()) spinNameInput.value = spinSuggestedName = defaultSpinName();
  } else {
    spinNameInput.value = spinSuggestedName = '';   // no live suggestion to catch up on later either
  }
  // The last create's ✅ / error line stays until the next create (which clears it itself), so closing
  // and reopening the popover doesn't lose the "Open it now →" link.
  renderSpinPreview();
}

// Pure trim of a snapshot: keep only prompts (and their images / feed rows) whose ver ≥ cutoff,
// where cutoff = the lowest of the most-recent `keepN` prompt-bearing versions. instVersion and
// per-prompt ver are preserved (not renumbered); instHistory is pruned to kept versions plus the
// active instruction's. The current session object is never touched — this operates on a copy.
function trimSessionData(data, keepN) {
  const prompts = data.prompts || {};
  const vers = [...new Set(Object.values(prompts).map(p => p && p.ver).filter(v => v != null))].sort((a, b) => a - b);
  if (!vers.length) return data;
  const keep = Math.max(1, Math.min(keepN, vers.length));
  const cutoff = vers[vers.length - keep];
  const keepId = id => prompts[id] != null && prompts[id].ver >= cutoff;

  const newPrompts = {};
  for (const id in prompts) if (prompts[id].ver >= cutoff) newPrompts[id] = prompts[id];

  const keptVers = new Set(Object.values(newPrompts).map(p => p.ver));
  keptVers.add(data.meta && data.meta.instVersion);         // always keep the active instruction's text
  const hist = (data.meta && data.meta.instHistory) || {};
  const newHist = {};
  for (const v in hist) if (keptVers.has(Number(v))) newHist[v] = hist[v];

  // 💭 why notes are pruned on exactly the same rule as the instruction text they annotate — a note for
  // a version this copy dropped would be an explanation of something that no longer exists here.
  const why = (data.meta && data.meta.instWhy) || {};
  const newWhy = {};
  for (const v in why) if (keptVers.has(Number(v))) newWhy[v] = why[v];

  // 🔖 / 🚫 mark records are DROPPED rather than ghosted when their prompt didn't make the cut. Elsewhere
  // the rule is "keep the knowledge, retire the link" — but shedding data is the entire point of a
  // spin-off, so a trimmed copy shouldn't carry a parent edge to something it deliberately forgot.
  // A record with NO promptId is a different case and survives: marks are keyed on the image, not the
  // prompt (you can bookmark an error card, or a restored image whose prompt was pruned long ago), and
  // such a record never had an edge to forget — it carries its own wording snapshot and stands alone.
  const keepInf = list => (list || []).filter(r => r && (r.promptId == null || newPrompts[r.promptId]));
  const oldInf = (data.meta && data.meta.instInfluences) || {};
  const newInf = {};
  for (const v in oldInf) {
    if (!keptVers.has(Number(v))) continue;
    const kept = keepInf(oldInf[v]);
    if (kept.length) newInf[v] = kept;
  }

  const newMeta = { ...data.meta, instHistory: newHist, instWhy: newWhy, instInfluences: newInf,
                    markedInfluences: keepInf(data.meta && data.meta.markedInfluences), savedAt: Date.now() };
  return {
    ...data,
    meta: newMeta,
    // `...data` would copy every thumbnail, including those of the records keepInf just dropped.
    markThumbs: pruneMarkThumbs(data.markThumbs, newMeta),
    prompts: newPrompts,
    order: (data.order || []).filter(id => newPrompts[id]),
    images: (data.images || []).filter(im => keepId(im.promptId)),
    feedManifest: (data.feedManifest || []).filter(r => keepId(r.promptId)),
  };
}

// Snapshot the live session, trim the copy, and persist it under a new name. The live
// session and its on-disk copy are never modified.
async function doSpinOff(newName, keepN) {
  const base = await buildSessionData(newName);   // real name (not the autosave slot) → meta.sessionName = newName
  const trimmed = trimSessionData(base, keepN);
  trimmed.meta = { ...trimmed.meta, sessionName: newName };
  const db = await openSavedSessionDB();
  await new Promise((res, rej) => {
    const tx = db.transaction('session', 'readwrite');
    tx.objectStore('session').put(trimmed, newName);
    tx.oncomplete = res;
    tx.onerror = () => rej(tx.error);
  });
  await refreshSessionsList();
  logEvent('session_spun_off', {
    name: newName, keepInstructions: keepN,
    images: trimmed.images.length, prompts: Object.keys(trimmed.prompts).length
  });
  return trimmed;
}

function setMiscOpen(open) {
  miscPopover.style.display = open ? 'block' : 'none';
  if (open) {
    // Same height-cap trick as the Strategy popover (item 1) — stay on-screen on short viewports.
    const gap = 12;
    const top = miscBtn.getBoundingClientRect().bottom + 6;
    miscPopover.style.maxHeight = Math.max(140, window.innerHeight - top - gap) + 'px';
    keepToolbarPopoverOnScreen(miscPopover, miscBtn);
    refreshSpinOff();
    // Then catch the suggested name up once the store's keys are in — rendered first and revised after,
    // so the popover never waits on a read, and only if the box still holds our own suggestion.
    // The empty-string check matters: refreshSpinOff deliberately BLANKS the box when there's nothing to
    // spin off, and a blank box would otherwise read as "still holds our suggestion" and get one written
    // into it — a ready-looking name beside a permanently disabled Create.
    getNamedSessionKeys().then(keys => {
      spinTakenNames = new Set(keys);
      if (spinSuggestedName && spinNameInput.value === spinSuggestedName) {
        spinNameInput.value = spinSuggestedName = defaultSpinName();
      }
    }).catch(() => {});
  }
}
miscBtn.onclick = (e) => {
  e.stopPropagation();
  setStrategyOpen(false);   // only one toolbar popover open at a time
  setPauseMenuOpen(false);
  setMiscOpen(miscPopover.style.display !== 'block');
};
miscPopover.addEventListener('click', (e) => e.stopPropagation());
// A rotate, window resize or keyboard open/close can strand a fixed popover off-screen after it
// was clamped on open — re-clamp whichever toolbar popover is showing.
window.addEventListener('resize', () => {
  if (typeof keepToolbarPopoverOnScreen !== 'function') return;
  const pm = document.getElementById('pauseMenu'), pmb = document.getElementById('pauseMenuBtn');
  const sp = document.getElementById('strategyPopover'), sb = document.getElementById('strategyBtn');
  const mp = document.getElementById('miscPopover'), mb = document.getElementById('miscBtn');
  if (pm && pm.style.display === 'block' && pmb) keepToolbarPopoverOnScreen(pm, pmb);
  if (sp && sp.style.display === 'block' && sb) keepToolbarPopoverOnScreen(sp, sb);
  if (mp && mp.style.display === 'block' && mb) keepToolbarPopoverOnScreen(mp, mb);
});

spinSlider.addEventListener('input', () => {
  spinSliderValue = Number(spinSlider.value);
  spinStatus.innerHTML = '';           // clear a stale success/error from a prior create
  renderSpinPreview();
});

spinCreateBtn.onclick = async () => {
  const name = spinNameInput.value.trim();
  if (!name) { spinStatus.innerHTML = '<span class="spinErr">Enter a name for the new session.</span>'; return; }
  // Re-read the on-disk list right before the collision check: the put() below overwrites by key, so a
  // session saved elsewhere (another tab) since this popover opened must not be silently clobbered.
  await refreshSessionsList();
  if ((st.savedSessionsList || []).some(s => s.name === name)) {
    spinStatus.innerHTML = `<span class="spinErr">A session named “${escapeHtml(name)}” already exists.</span>`;
    return;
  }
  const keepN = Number(spinSlider.value);
  const prevLabel = spinCreateBtn.textContent;
  spinCreateBtn.disabled = true;
  spinCreateBtn.textContent = 'Creating…';
  try {
    const trimmed = await doSpinOff(name, keepN);
    const imgN = trimmed.images.length;
    spinStatus.innerHTML =
      `✅ Created “${escapeHtml(name)}” — ${plural(imgN, 'liked image')}. ` +
      `<button type="button" class="spinOpen" id="spinOpenLink">Open it now →</button>`;
    let opening = false;
    const openIt = async () => {
      // Non-disruptive by default (nothing reloads on create); jumping in is one tap. The link outlives the
      // popover, so by the time it's pressed the copy may have been opened and worked in: load it as saved
      // now rather than the snapshot taken at creation, which the next autosave would write over that work.
      setMiscOpen(false);
      if (opening || st.currentSessionName === name) return;
      opening = true;
      try {
        const rec = await loadSession(name);
        if (!rec) { showToast(`“${shortSessionName(name, 18)}” is no longer saved`, { kind: 'error' }); return; }
        await settleAutosave();
        st.currentSessionName = name;
        await restoreSession(rec);
      } finally { opening = false; }
    };
    const openLink = document.getElementById('spinOpenLink');
    if (openLink) openLink.onclick = openIt;
    showToast(`Created “${shortSessionName(name, 18)}”`, { action: { label: 'Open', onClick: openIt } });
    spinNameInput.value = spinSuggestedName = defaultSpinName();   // re-suggest a fresh unique name for a second copy
  } catch (e) {
    spinStatus.innerHTML = `<span class="spinErr">Couldn’t create the copy: ${escapeHtml(String((e && e.message) || e))}</span>`;
  } finally {
    spinCreateBtn.textContent = prevLabel;
    spinCreateBtn.disabled = false;
  }
};

// --- Help / guide overlay ---
const helpModal = document.getElementById('helpModal');
// With an id, scrolls that item into view and flashes it — for "?" links that explain one control.
function openHelp(itemId) {
  helpModal.style.display = 'flex';
  const el = typeof itemId === 'string' ? document.getElementById(itemId) : null;
  if (!el) return;
  el.scrollIntoView({ block: el.classList.contains('helpGroup') ? 'start' : 'center' });
  el.classList.remove('helpFlash');
  void el.offsetWidth;   // restart the animation on a repeat click
  el.classList.add('helpFlash');
}
function closeHelp() { helpModal.style.display = 'none'; }
document.getElementById('helpBtn').onclick = () => openHelp();
document.getElementById('introHelpLink').onclick = (e) => { e.preventDefault(); openHelp(); };
document.getElementById('autosaveStatus').onclick = () => openSessionModal();
document.getElementById('helpCloseX').onclick = closeHelp;
for (const b of document.querySelectorAll('.helpToc button[data-help]')) b.onclick = () => openHelp(b.dataset.help);
helpModal.addEventListener('click', (e) => { if (e.target === helpModal) closeHelp(); });

// --- "Always show image marks" setting ---
// A DEVICE preference, not a session one: it's about how you like to read the grid, not about anything
// the session generated, so it lives in localStorage beside the other display prefs rather than in
// meta. Off by default. All the work is one body class; see the .promptFlags rules.
let ALWAYS_SHOW_FLAGS = localStorage.getItem('ipo_alwaysShowFlags') === 'true';
function applyAlwaysShowFlags() { document.body.classList.toggle('flagsAlwaysOn', ALWAYS_SHOW_FLAGS); }
applyAlwaysShowFlags();
const alwaysShowFlagsChk = document.getElementById('alwaysShowFlagsChk');
if (alwaysShowFlagsChk) {
  alwaysShowFlagsChk.checked = ALWAYS_SHOW_FLAGS;
  alwaysShowFlagsChk.onchange = () => {
    ALWAYS_SHOW_FLAGS = alwaysShowFlagsChk.checked;
    localStorage.setItem('ipo_alwaysShowFlags', String(ALWAYS_SHOW_FLAGS));
    applyAlwaysShowFlags();
  };
}

// --- "Keep liked images cached" setting ---
const pinSavedImagesChk = document.getElementById('pinSavedImagesChk');
if (pinSavedImagesChk) {
  pinSavedImagesChk.checked = IC_PIN_SAVED;
  pinSavedImagesChk.onchange = () => {
    IC_PIN_SAVED = pinSavedImagesChk.checked;
    localStorage.setItem('ipo_pinSavedImages', String(IC_PIN_SAVED));
    refreshICStats();
  };
}

const restoreUnlikedChk = document.getElementById('restoreUnlikedChk');
if (restoreUnlikedChk) {
  restoreUnlikedChk.checked = RESTORE_UNLIKED;
  restoreUnlikedChk.onchange = () => {
    RESTORE_UNLIKED = restoreUnlikedChk.checked;
    localStorage.setItem('ipo_restoreUnlikedFromCache', String(RESTORE_UNLIKED));
    // Takes effect on the next session restore; the current feed is left as-is.
  };
}

/* ===================== Prompt generation tree (overlay) ===================== */
// Lineage overlay for a prompt (or the prompt behind an image): where it came from and what it
// spawned. Nodes are prompts; images ride as thumbnails on the centered node + its direct children.
// The spine is walked via p.parent only; p.drewFrom mix-ins are a soft second edge shown on the
// centered node in both directions. Everything is computed live from st.prompts / st.tasksById on
// open and recomputed on re-center — no persisted graph. See oldplans/SPEC-prompt-generation-tree.md.

const PGT_THUMB_CAP = 3;     // thumbnails per node before "+N" (§3 tuning)
const PGT_SIBLING_CAP = 8;   // sibling/descendant boxes before "+N more"
const PGT_CHIP_CAP = 6;      // mix-in chips before an inline "+N"

let pgtCenterId = null;        // centered node: a prompt id, or a synthetic version-trunk id "v:<n>"
let pgtHighlightTaskId = null; // opened-from-image: the exact task to ring on the centered node (live only)
let pgtStack = [];             // back-stack of visited center ids (excludes the current one)
let pgtExpanded = null;        // Set of expanded "+N" region keys, reset on each open/re-center
let pgtObjectUrls = [];        // thumbnail object URLs to revoke on teardown
let pgtGen = 0;                // bumped on close/re-center to invalidate in-flight async thumb loads

function pgtEl() { return document.getElementById('pgtOverlay'); }

// A center is a prompt id, a synthetic version-trunk id "v:<n>", or a synthetic steer id "s:<text>".
// Prompt ids never contain a colon, so the two synthetic namespaces can't collide with a real one.
function pgtIsVer(id) { return typeof id === 'string' && id.startsWith('v:'); }
function pgtVerNum(id) { return parseInt(id.slice(2), 10); }
function pgtVerId(n) { return 'v:' + n; }
// The steer is keyed by its own text — the same key the 🧲 sweep and "steered first" already group by, so
// two batches shaped by the same steer land on one node rather than two identical-looking ones.
function pgtIsSteer(id) { return typeof id === 'string' && id.startsWith('s:'); }
function pgtSteerText(id) { return id.slice(2); }
function pgtSteerId(text) { return 's:' + text; }
function pgtIsSynthetic(id) { return pgtIsVer(id) || pgtIsSteer(id); }
function pgtPromptsSteeredBy(text) {
  return Object.values(st.prompts).filter(p => p && p.influenceText === text);
}

const pgtByCreated = (a, b) => (a.createdAt || 0) - (b.createdAt || 0) || String(a.id).localeCompare(String(b.id));
const pgtByScoreDesc = (a, b) => (b.score || 0) - (a.score || 0) || (b.votes || 0) - (a.votes || 0);

// --- lineage queries over st.prompts (cheap single passes; recomputed per render) ---

// Direct prompt-children: promote/upvote kids naming this prompt as their parent.
function pgtChildrenOf(pid) {
  return Object.values(st.prompts).filter(p =>
    p && p.parent && (p.parent.kind === 'promote' || p.parent.kind === 'upvote') && p.parent.promptId === pid);
}

// Prompts hanging directly off a version trunk: an instruction/manual parent (or none), OR a
// promote/upvote parent whose target no longer exists (dangling → falls back to its version root).
function pgtVersionChildren(ver) {
  return Object.values(st.prompts).filter(p => {
    if (!p || p.ver !== ver) return false;
    const par = p.parent;
    if (!par) return true;
    if (par.kind === 'instruction' || par.kind === 'manual') return true;
    return par.promptId == null || !st.prompts[par.promptId];   // dangling promote/upvote → root here
  });
}

// The centered node's structural parent id ("v:<n>" or a prompt id) — drives ancestors + siblings.
function pgtParentIdOf(pid) {
  const p = st.prompts[pid];
  if (!p) return null;
  const par = p.parent;
  if (par && (par.kind === 'promote' || par.kind === 'upvote') && par.promptId != null && st.prompts[par.promptId]) {
    return par.promptId;
  }
  return pgtVerId(p.ver || 1);   // instruction/manual/dangling → version trunk
}

// Every done image pointing at a prompt (live + restored cards both register in st.tasksById), in
// generation order (oldest first).
//
// Backed by one index built per render rather than a scan per call: a canvas can hold 17 boxes with
// thumbnails before anyone touches "+N more", and each one asking the whole task table itself turns a
// long session's tree into a visible freeze. pgtRender builds the index; the fallback scan keeps the
// function honest if anything ever calls it outside a render.
let pgtImgIdx = null;

// Same trick for "which prompts were born under version N" — see pgtVersionImages.
let pgtVerIdx = null;

function pgtBuildVersionIndex() {
  const idx = new Map();
  for (const pid in st.prompts) {
    const p = st.prompts[pid];
    if (!p || p.ver == null) continue;   // matches pgtVersionChildren's strict test
    let arr = idx.get(p.ver);
    if (!arr) idx.set(p.ver, arr = []);
    arr.push(p);
  }
  return idx;
}

function pgtBuildImageIndex() {
  const idx = new Map();
  for (const tid in st.tasksById) {
    const t = st.tasksById[tid];
    if (!t || t.state !== 'done' || t.promptId == null) continue;
    if (t.cacheId == null && !(t.ui && t.ui.imgEl)) continue;
    let arr = idx.get(t.promptId);
    if (!arr) idx.set(t.promptId, arr = []);
    arr.push(t);
  }
  for (const arr of idx.values()) arr.sort((a, b) => (a.idx ?? 0) - (b.idx ?? 0));
  return idx;
}

function pgtImagesOf(pid) {
  if (pgtImgIdx) return pgtImgIdx.get(pid) || [];
  const out = [];
  for (const tid in st.tasksById) {
    const t = st.tasksById[tid];
    if (t && t.state === 'done' && t.promptId === pid && (t.cacheId != null || (t.ui && t.ui.imgEl))) out.push(t);
  }
  return out.sort((a, b) => (a.idx ?? 0) - (b.idx ?? 0));
}

// Reverse mix-ins: prompts whose drewFrom names this one (§1.12 reverse edge).
function pgtSeededBy(pid) {
  return Object.values(st.prompts).filter(p => p && Array.isArray(p.drewFrom) && p.drewFrom.includes(pid));
}

// Ancestor ids from root down to the immediate parent (excludes the center itself).
function pgtAncestorChain(centerId) {
  const chain = [];
  if (pgtIsSteer(centerId)) return chain;           // a steer is a root: nothing produced it but you
  if (pgtIsVer(centerId)) {                         // a version center: older version trunks only
    for (let v = pgtVerNum(centerId) - 1; v >= 1; v--) chain.unshift(pgtVerId(v));
    return chain;
  }
  const guard = new Set();
  let id = centerId;
  while (true) {
    const pid = pgtParentIdOf(id);
    if (pid == null || guard.has(pid)) break;
    guard.add(pid);
    chain.unshift(pid);
    if (pgtIsVer(pid)) {                             // hit the trunk → chain older versions to v1
      for (let v = pgtVerNum(pid) - 1; v >= 1; v--) chain.unshift(pgtVerId(v));
      break;
    }
    id = pid;
  }
  return chain;
}

// Peers of the centered node = the other children of its parent (§3 "in context").
function pgtSiblingsOf(centerId) {
  const parentId = pgtParentIdOf(centerId);
  if (parentId == null) return [];
  const sibs = pgtIsVer(parentId) ? pgtVersionChildren(pgtVerNum(parentId)) : pgtChildrenOf(parentId);
  return sibs.filter(p => p.id !== centerId).sort(pgtByCreated);
}

// --- thumbnails (availability tiers mirror the export gallery: cache full-res → live imgEl → n/a) ---

async function pgtResolveBlob(task) {
  if (task.cacheId != null) { try { const b = await getICBlob(task.cacheId); if (b) return b; } catch (e) {} }
  if (task.ui && task.ui.imgEl && task.ui.imgEl.src) {
    try { const b = await fetch(task.ui.imgEl.src).then(r => r.blob()); if (b) return b; } catch (e) {}
  }
  return null;
}

// Where a lightbox gets a task's image: the cached original, else the tile's own <img> — unless that <img>
// is a restored card's stored 128px thumbnail, which is shown (marked as a thumbnail) but never handed
// over as the image, so Download can't save it as if it were the original. pgtResolveBlob above takes the
// thumbnail too, which is right for the tree's own small frames.
function lbTaskSource(t) {
  const img = () => t.ui && t.ui.imgEl;
  return {
    _src: img() ? img().src : null,
    _srcIsThumb: () => !!(img() && img()._ipoThumbOnly),
    _resolveBlob: async () => {
      if (t.cacheId != null) { try { const b = await getICBlob(t.cacheId); if (b) return b; } catch (e) {} }
      const el = img();
      if (!el || !el.src || el._ipoThumbOnly) return null;
      try { return await fetch(el.src).then(r => r.blob()); } catch (e) { return null; }
    },
  };
}

async function pgtLoadThumb(cell, task, gen) {
  const blob = await pgtResolveBlob(task);
  if (gen !== pgtGen) return;                       // a re-center/close superseded this load
  if (!blob) { cell.classList.add('pgtThumbNA'); cell.title = 'Original no longer available'; return; }
  const url = URL.createObjectURL(blob);
  pgtObjectUrls.push(url);
  const img = new Image();
  img.src = url; img.alt = '';
  cell.appendChild(img);
}

// Seed the shared lightbox with ALL of a strip's images, the clicked one focused, ←/→ walking the rest —
// reusing the export gallery's per-item hook contract. Each task names its own prompt rather than
// inheriting one, because a steer's strip mixes images from every prompt that steer shaped.
function pgtOpenLightbox(tasks, clickedIdx) {
  const items = tasks.map(t => {
    const p = st.prompts[t.promptId];
    return {
      resolvedText: t.resolvedText || (p ? p.text : ''),
      promptText:   p ? p.text : '',
      _note: (t.cacheId == null && !(t.ui && t.ui.imgEl)) ? 'No longer available' : null,
      ...lbTaskSource(t),
    };
  });
  icOpenLightbox(items, clickedIdx);
}

// A strip's tasks as gallery items. The tree keeps its live <img> at task.ui.imgEl where the export
// panel keeps it at item.imgEl — flattening that difference is exactly what the shared item model is
// for, so the gallery never learns there are two shapes.
function pgtGalleryItems(tasks) {
  return tasks.map(t => {
    const p = st.prompts[t.promptId] || {};
    const resolved = t.resolvedText || p.text || '';
    return {
      cacheId: t.cacheId != null ? t.cacheId : null,
      imgEl: (t.ui && t.ui.imgEl) || null,
      thumbSrc: '',
      promptText: p.text || '',
      resolvedText: resolved,
      caption: resolved,
      // No `note`: pgtImagesOf only ever yields tasks that have a cacheId or a live <img>, so the
      // "no longer available" case can't reach here. The grid badges an archived or thumbnail-only
      // hit itself once it knows which rung answered.
      idx: t.idx, score: p.score, votes: p.votes,
    };
  });
}

// One rule on every box that has a strip: a thumbnail opens the lightbox on that image, "+N" opens the
// whole set as a grid. "+N" exists exactly when a strip overflows PGT_THUMB_CAP, so the gallery shows
// up precisely when there is more to see than fits. `label` titles the gallery — the prompt's wording,
// the steer, or the instruction version.
function pgtThumbStrip(tasks, gen, label) {
  // pgtLoadThumb discards a load whose `gen` no longer matches pgtGen, which is how a re-render strands
  // the previous one's in-flight thumbs. An omitted gen would therefore never match and the strip would
  // paint empty frames with no error — so default to the render we're in, which is what a caller that
  // didn't thread one through meant anyway.
  if (gen == null) gen = pgtGen;
  const strip = document.createElement('div');
  strip.className = 'pgtThumbs';
  const shown = tasks.slice(0, PGT_THUMB_CAP);
  shown.forEach((t, i) => {
    const cell = document.createElement('div');
    cell.className = 'pgtThumb';
    if (pgtHighlightTaskId && t.id === pgtHighlightTaskId) cell.classList.add('pgtThumbHi');
    cell.onclick = (e) => { e.stopPropagation(); pgtOpenLightbox(tasks, i); };
    strip.appendChild(cell);
    pgtLoadThumb(cell, t, gen);
  });
  if (tasks.length > PGT_THUMB_CAP) {
    const more = document.createElement('div');
    more.className = 'pgtThumb pgtThumbMore';
    more.textContent = '+' + (tasks.length - PGT_THUMB_CAP);
    more.title = 'See all ' + tasks.length + ' images in a gallery';
    more.onclick = (e) => { e.stopPropagation(); galOpenSet(pgtGalleryItems(tasks), label || 'Images'); };
    strip.appendChild(more);
  }
  return strip;
}

// Everything a steer produced, best-scoring prompts first so the strip leads with its hits. Takes the
// prompt list the caller already computed — a steer box needs it for its chips too, and re-deriving it
// means a second full pass over st.prompts for the same answer.
function pgtSteerImages(prompts) {
  return prompts.slice().sort(pgtByScoreDesc).flatMap(p => pgtImagesOf(p.id));
}

// Everything an instruction version drew: every prompt BORN under it, pooled the same way a steer's
// images are. Deliberately wider than pgtVersionChildren — that's the trunk's direct children, while
// this also picks up promoted children whose structural parent is an older prompt (the boxes tagged
// "born vN"). Tasks carry no version of their own, so the prompt is the only thing that can answer
// "which instruction produced this"; a v1 prompt that finally draws during v3 therefore counts as v1's
// image, which is the right answer — the instruction that wrote the prompt owns what it produces.
//
// `p.ver !== ver` matches pgtVersionChildren exactly, including for a legacy prompt restored without a
// ver at all. Normalizing a missing ver to 1 here would put that prompt's images in v1's strip while
// the Descendants row below it — which does not normalize — left the prompt out, so one box would show
// images from a prompt it doesn't list.
//
// Indexed per render for the same reason pgtImagesOf is: a canvas can ask for several versions (the
// centred box, the parents row's previous version, one per reverse-🔖 edge), and a full pass over
// st.prompts each time is the per-node scan pgtImgIdx exists to avoid.
function pgtVersionImages(ver) {
  const prompts = pgtVerIdx ? (pgtVerIdx.get(ver) || []) : Object.values(st.prompts).filter(p => p && p.ver === ver);
  return prompts.slice().sort(pgtByScoreDesc).flatMap(p => pgtImagesOf(p.id));
}

// --- the hover card: one floating element for every clamped box on the canvas ---
//
// Every box here shows two-to-four lines of a string that can be paragraphs long. The full text used to
// ride on `title` — a NATIVE browser tooltip, which is uninteractable by definition: you cannot select
// out of it, cannot put a control in it, and it vanishes the instant the pointer moves. Reading a long
// instruction meant re-typing it off a tooltip.
//
// So the tooltip becomes a real element. ONE element, repositioned to whatever is hovered, because a
// canvas of boxes each carrying its own card would be a canvas of hundreds of text blocks.
//
// It reuses the ❓ panel's machinery wholesale rather than growing a parallel copy: statsRows for the
// 500-char cap and the "▾ Show all" button, markClamped for the measurement, placeStats for the
// viewport-clamped position. That is also what keeps it honest about the one rule this app now has for
// hover surfaces — NOTHING EXPANDS UNDER THE POINTER — since the button is the only thing that unfolds
// a row in either surface.
//
// z-index sits above the tree (320) and below the gallery (340) and lightbox (400), so a card left open
// when you click a thumbnail can never end up floating over the image you just opened.
//
// Touch: no hover means no card, exactly as the `title` it replaces had no tooltip. A tap already
// re-centres the tree, and overloading it would cost that. See feature list §19 on mobile.
let _pgtCard = null;
let _pgtCardTimer = null;
let _pgtCardOpenTimer = null;

function pgtCardEl() {
  if (!_pgtCard) {
    _pgtCard = document.createElement('div');
    _pgtCard.id = 'pgtCard';
    _pgtCard.style.display = 'none';
    // The hover-intent bridge, same shape as the ❓ panel's: the pointer has to be able to LEAVE the box
    // and land on the card to select text or press ▾ Show all, so resting anywhere inside counts as
    // still reading and the box's mouseleave close is cancelled on the way in.
    _pgtCard.addEventListener('mouseenter', pgtCardCancelClose);
    _pgtCard.addEventListener('mouseleave', pgtCardScheduleClose);
    // Nothing in here takes text, so the pointer is the whole story — no focus-keeps-it-open rule. One was
    // written for the 🧲 steer field this card used to carry; with that gone it would only mean that
    // pressing ▾ Show all (which leaves the button focused) pinned the card open until you clicked away.
    document.body.appendChild(_pgtCard);
  }
  return _pgtCard;
}

function pgtCardCancelClose() { clearTimeout(_pgtCardTimer); }
function pgtCardScheduleClose() {
  // Pressing ▾ Show all pins the card for the same reason it pins the ❓ panel: re-placing it can move it
  // out from under the pointer, and it must not evaporate the moment you asked to read the whole thing.
  if (_pgtCard && _pgtCard.dataset.pinned) return;
  clearTimeout(_pgtCardTimer);
  _pgtCardTimer = setTimeout(pgtCardHide, 180);
}
function pgtCardVisible() { return !!_pgtCard && _pgtCard.style.display !== 'none'; }
function pgtCardCancelOpen() { clearTimeout(_pgtCardOpenTimer); }

// Hover-intent on the way IN, for a surface packed tightly enough that the pointer crosses several targets
// on the way to the one it wants. Once a card is already up you have committed to reading them, so the
// switch between targets is immediate and the delay is only ever the cost of the FIRST card.
// The focused tree doesn't use this: its boxes are large and far apart, so waiting there is just lag.
function pgtCardShowAfter(ms, show) {
  pgtCardCancelOpen();
  // On touch the "hover" is the tap itself, so there's no crossing to wait out.
  if (pgtCardVisible() || STATS_NO_HOVER) { pgtCardCancelClose(); show(); return; }
  _pgtCardOpenTimer = setTimeout(show, ms);
}
function pgtCardHide() {
  clearTimeout(_pgtCardTimer);
  // Any explicit hide also cancels a card that was about to open — a drag, a zoom step, a re-render or a
  // mode switch must not be followed 300ms later by a card for whatever the pointer happened to be over.
  clearTimeout(_pgtCardOpenTimer);
  if (_pgtCard) { _pgtCard.style.display = 'none'; delete _pgtCard.dataset.pinned; delete _pgtCard.dataset.clickPin; }
}

/* opts:
     rows  extra [label, value, cls] rows appended after the wording (score · votes, provenance)
     foot  (card) => void — an action row, appended OUTSIDE .statsBody so it stays put while a long
           wording scrolls under it. Same trick the ❓ panel uses for its 🌳 button.

   The focused tree passes neither: there, the card carries text and nothing else, because that alone is
   the whole improvement — the wording stops fleeing the pointer and you can select it. The mega-tree's
   nodes have no text on them at all, so their card is the only place a node can be identified, and it
   carries the actions too. Same element either way, so the two can't drift apart visually. */
function pgtCardShow(anchor, title, text, opts) {
  opts = opts || {};
  pgtCardCancelClose();
  const box = pgtCardEl();
  const rows = [];
  if (text) rows.push(['', text, 'statsClampable pgtCardRow']);
  (opts.rows || []).forEach(r => rows.push(r));
  statsRows(box, rows, title);
  if (opts.foot) opts.foot(box);
  box._anchor = anchor;
  // Touch has no pointer-out to close it, so it gets a ✕.
  if (STATS_NO_HOVER) {
    const x = document.createElement('button');
    x.type = 'button';
    x.className = 'pgtCardX';
    x.textContent = '✕';
    x.setAttribute('aria-label', 'Close');
    x.onclick = (e) => { e.stopPropagation(); pgtCardHide(); };
    box.appendChild(x);
  }
  box.style.display = 'flex';
  markClamped(box);      // must run while visible: a display:none box measures every height as zero
  placeStats(box, anchor);
  return box;
}

// Wire an element as a card target. `text` is the full, unclamped string — the card caps it, the box
// keeps showing its own CSS-clamped preview.
function pgtCardAttach(el, title, text, opts) {
  if (!el || !text) return el;
  // A tap fires a compatibility mouseenter before its click, which would open the card for the click to close.
  el.addEventListener('mouseenter', () => { if (!STATS_NO_HOVER) pgtCardShow(el, title, text, opts); });
  el.addEventListener('mouseleave', pgtCardScheduleClose);
  // Touch: a tap on the text toggles its card instead of re-centring (the box's own click), so the
  // card a tap produced isn't swept away by the re-render that same tap would trigger.
  if (STATS_NO_HOVER) el.addEventListener('click', (e) => {
    e.stopPropagation();
    if (pgtCardVisible() && _pgtCard._anchor === el) { pgtCardHide(); return; }
    pgtCardShow(el, title, text, opts);
    _pgtCard.dataset.pinned = _pgtCard.dataset.clickPin = '1';
  });
  return el;
}

// --- boxes ---

function pgtTag(text, cls) {
  const s = document.createElement('span');
  s.className = 'pgtTag' + (cls ? ' ' + cls : '');
  s.textContent = text;
  return s;
}

// A prompt node. opts: { center, withThumbs, gen }. Score/votes and thumbnails ride together on the
// centered node, its siblings and its direct children — the generations you're actually comparing.
// Ancestors and chips stay text + labels only, so the spine above stays quiet.
function pgtPromptBox(p, opts) {
  opts = opts || {};
  const box = document.createElement('div');
  box.className = 'pgtBox' + (opts.center ? ' pgtCenter' : '');
  box.onclick = (e) => { if (!e.target.closest('.pgtThumb') && !e.target.closest('.pgtChip')) pgtRecenter(p.id); };

  const txt = document.createElement('div');
  txt.className = 'pgtText';
  txt.textContent = p.text;
  pgtCardAttach(txt, 'Prompt', p.text);
  box.appendChild(txt);

  const labels = document.createElement('div');
  labels.className = 'pgtLabels';
  // Not on the center: its steer gets a whole box of its own beside it (pgtSteerBox), and stating it
  // twice on the same node just crowds it.
  if (p.influenceText && !opts.center) {
    // The tag ellipsizes at 150px, so "(inherited)" would usually be the part clipped away — it goes in
    // the tooltip and as a modifier class instead, leaving the steer's wording as the visible text.
    const tag = pgtTag('🧲 ' + p.influenceText, 'pgtTagSteer' + (p.influenceInherited ? ' pgtTagSteerInh' : ''));
    tag.title = p.influenceInherited
      ? 'Steered by "' + p.influenceText + '" — inherited, this prompt was captured from a steered image'
      : 'Steered by "' + p.influenceText + '"';
    labels.appendChild(tag);
  }
  const o = p.origin || '';
  if (o.includes('promoted')) labels.appendChild(pgtTag('promoted'));
  if (o.includes('creative')) labels.appendChild(pgtTag('creative'));
  if (o.includes('mixed'))    labels.appendChild(pgtTag('mixed'));
  if (o === 'upvoted')        labels.appendChild(pgtTag('⭐ from upvote'));
  if (o === 'manual')         labels.appendChild(pgtTag('✏️ by hand'));
  if (opts.center || opts.withThumbs) {
    const sc = p.used ? (p.score || 0).toFixed(1) : '—';
    labels.appendChild(pgtTag(sc + ' · ' + (p.votes || 0) + '👍', 'pgtTagScore'));
  }
  if (labels.children.length) box.appendChild(labels);

  // born vN — a promoted child sitting under a parent from a different version (§1.11)
  if (p.parent && p.parent.kind === 'promote') {
    const par = st.prompts[p.parent.promptId];
    if (par && par.ver !== p.ver) {
      const b = document.createElement('div');
      b.className = 'pgtBorn';
      b.textContent = 'born v' + p.ver;
      box.appendChild(b);
    }
  }

  if (opts.withThumbs) {
    const imgs = pgtImagesOf(p.id);
    if (imgs.length) box.appendChild(pgtThumbStrip(imgs, opts.gen, p.text));
    // Say it outright on the centered node. A prompt with no strip is the normal case away from the feed
    // — most of what you click through is queued, promoted or upvoted and has never been drawn — and
    // silence there reads as "the thumbnails are broken" rather than "there is nothing to show yet".
    else if (opts.center) {
      const none = document.createElement('div');
      none.className = 'pgtNoImgs';
      none.textContent = p.used ? 'no images kept for this prompt' : 'not generated yet';
      box.appendChild(none);
    }
  }
  return box;
}

// opts: { center, withThumbs, gen } — same contract as pgtPromptBox. An instruction's thumbnails are
// everything its generation drew, so the box answers "what did this wording actually produce" without a
// click. They ride on the centred box, on the previous version in the parents row, and on the reverse
// 🔖 edge — the places an instruction sits beside boxes that already have thumbnails, where a bare one
// reads as broken. Not on the ancestors chain: the spine above stays text-only, and a session twelve
// versions deep would otherwise open on a wall of images above the node you came to see.
function pgtVersionBox(ver, opts) {
  opts = opts || {};
  const box = document.createElement('div');
  box.className = 'pgtBox pgtVerBox' + (opts.center ? ' pgtCenter' : '');
  box.onclick = (e) => { if (!e.target.closest('.pgtThumb')) pgtRecenter(pgtVerId(ver)); };
  const h = document.createElement('div');
  h.className = 'pgtVerTitle';
  h.textContent = 'Instruction v' + ver;
  box.appendChild(h);
  const t = (st.instHistory && st.instHistory[ver] != null && String(st.instHistory[ver]).trim())
    ? st.instHistory[ver] : '(instruction text not recorded)';
  const tx = document.createElement('div');
  tx.className = 'pgtText';
  tx.textContent = t;
  // 💭 goes into the card's text as well as onto the box, so a note too long for the box is still
  // readable somewhere — the box is CSS-clamped and the card is what un-clamps it.
  const vwhy = (st.instWhy && st.instWhy[ver]) || '';
  pgtCardAttach(tx, 'Instruction v' + ver, vwhy ? t + '\n\n💭 ' + vwhy : t);
  box.appendChild(tx);
  if (vwhy) {
    const w = document.createElement('div');
    w.className = 'pgtVerWhy';
    w.textContent = '💭 ' + vwhy;
    box.appendChild(w);
  }
  if (opts.withThumbs) {
    const imgs = pgtVersionImages(ver);
    if (imgs.length) box.appendChild(pgtThumbStrip(imgs, opts.gen, 'Instruction v' + ver));
    // Same reasoning as pgtPromptBox: on the centred box, silence reads as broken thumbnails rather
    // than as an empty generation, so say it outright.
    else if (opts.center) {
      const none = document.createElement('div');
      none.className = 'pgtNoImgs';
      none.textContent = 'no images from this instruction yet';
      box.appendChild(none);
    }
  }
  return box;
}

// The spine stays text-only so a session twelve versions deep doesn't open on a wall of thumbnails —
// EXCEPT the anchor, which opts in via `opts`. See pgtAncestorsEl for why that one is different.
function pgtAncestorNode(id, opts) {
  if (pgtIsVer(id)) return pgtVersionBox(pgtVerNum(id), opts || {});
  const p = st.prompts[id];
  return p ? pgtPromptBox(p, {}) : document.createComment('missing ancestor');
}

// --- 🔖 influence / 🚫 anti-influence parents ---

// The words a 🚫 box carries on top of its red outline, so the kind never rests on colour alone. Shared by
// every surface in this view that draws one end of a 🚫 edge.
function pgtAntiTitle() {
  const h = document.createElement('div');
  h.className = 'pgtAntiTitle';
  h.textContent = '🚫 Anti-influence';
  return h;
}

// A committed influence whose prompt has since been deleted still draws, carrying the wording snapshotted
// when you marked it. The edge is the fact worth keeping — dropping the box would quietly rewrite the
// instruction's history — but there is nothing left to re-center on, so it's muted and inert. Same
// principle as p.influenceText outliving a retired 🧲: keep the knowledge, retire the link.
function pgtGhostBox(rec) {
  const title = rec.anti ? '🚫 Anti-influence · prompt deleted' : '🔖 Influence · prompt deleted';
  const box = document.createElement('div');
  box.className = 'pgtBox pgtGhostBox' + (rec.anti ? ' pgtAntiBox' : '');
  const h = document.createElement('div');
  h.className = 'pgtGhostTitle' + (rec.anti ? ' pgtGhostTitleAnti' : '');
  h.textContent = title;
  box.appendChild(h);
  const t = document.createElement('div');
  t.className = 'pgtText';
  t.textContent = rec.text || '(wording not recorded)';
  pgtCardAttach(t, title, rec.text || '');
  box.appendChild(t);
  return box;
}

// An influence renders as an ORDINARY prompt box — thumbnails, clickable, re-centers like any other node.
// The row it sits in is what says "this influenced the instruction"; a special-looking box would make it
// read as an annotation rather than as a parent, which is exactly the claim being made.
// A 🚫 anti-influence is the exception, and deliberately: it sits in the SAME row making the same parent
// claim, so the row can no longer tell the two kinds apart — the box has to. Red outline, faint red tint,
// and a title line that says it in words.
function pgtInfluenceBox(rec, gen) {
  const p = rec.promptId != null ? st.prompts[rec.promptId] : null;
  if (!p) return pgtGhostBox(rec);
  const box = pgtPromptBox(p, { withThumbs: true, gen });
  if (rec.anti) {
    box.classList.add('pgtAntiBox');
    box.insertBefore(pgtAntiTitle(), box.firstChild);
  } else {
    box.classList.add('pgtInfBox');
  }
  return box;
}

// The parents of an instruction version: the version it replaced, plus every image marked as a 🔖
// influence or 🚫 anti-influence before it was applied — one row, so they read as peers, 🔖 before 🚫. Two
// marks of one kind on the same prompt are one edge here (infParentsForVersion dedupes); the Influences
// panel keeps both, because it's about images and this is about prompts.
function pgtParentRow(ver, gen) {
  const prevVer = ver > 1 ? ver - 1 : null;
  const infs = infParentsForVersion(ver);
  if (prevVer == null && !infs.length) return null;
  const wrap = document.createElement('div');
  wrap.className = 'pgtRow pgtParentRow';
  const head = document.createElement('div');
  head.className = 'pgtRowHead';
  // Each kind is counted separately and named only when present. The count matters beyond tidiness: the
  // row shares one "+N more" cap, and 🚫 draws last, so the heading is what still tells you an anti-influence
  // exists when a long run of 🔖 boxes has pushed it behind the cap.
  const nAnti = infs.filter(r => r.anti).length, nInf = infs.length - nAnti;
  const parts = [];
  if (nInf) parts.push(nInf + ' 🔖 influence' + (nInf === 1 ? '' : 's'));
  if (nAnti) parts.push(nAnti + ' 🚫 anti-influence' + (nAnti === 1 ? '' : 's'));
  head.textContent = infs.length
    ? 'Parents of v' + ver + ' — previous instruction + ' + parts.join(' + ')
    : 'Parent of v' + ver;
  wrap.appendChild(head);
  const inner = document.createElement('div');
  inner.className = 'pgtRowInner';
  // Thumbnails here especially: this row already puts 🔖 influence boxes (which have them) beside the
  // previous instruction, and a bare box among them reads as an image that failed to load.
  if (prevVer != null) inner.appendChild(pgtVersionBox(prevVer, { withThumbs: true, gen }));
  // Capped and expanded exactly like the siblings/descendants rows, for the same reason: a run that
  // marked twenty images shouldn't push the node you came to look at off the bottom of the canvas.
  const expanded = pgtExpanded.has('par');
  const shown = expanded ? infs : infs.slice(0, PGT_SIBLING_CAP);
  shown.forEach(rec => inner.appendChild(pgtInfluenceBox(rec, gen)));
  if (!expanded && infs.length > PGT_SIBLING_CAP) {
    const more = document.createElement('div');
    more.className = 'pgtBox pgtMore';
    more.textContent = '+' + (infs.length - PGT_SIBLING_CAP) + ' more';
    more.onclick = (e) => {
      e.stopPropagation();
      pgtExpanded.add('par');
      infs.slice(PGT_SIBLING_CAP).forEach(rec => inner.insertBefore(pgtInfluenceBox(rec, gen), more));
      more.remove();
      pgtDrawRails(inner.closest('#pgtCanvas'));   // the row just changed shape; its rails no longer fit
    };
    inner.appendChild(more);
  }
  wrap.appendChild(inner);
  return wrap;
}

// --- mix-in chip rows (centered node only) ---

// `cardTitle` names the RELATION, not the chip — a chip is 40 characters of a prompt, so out of context
// it reads the same whether this prompt drew from it or it drew from this one. The row's label says
// which, and the card has to keep saying it once the pointer has left the row.
function pgtChip(q, cardTitle) {
  const c = document.createElement('span');
  c.className = 'pgtChip';
  const full = q.text || '';
  c.textContent = full.length > 40 ? full.slice(0, 40) + '…' : full;
  pgtCardAttach(c, cardTitle, full);
  c.onclick = (e) => { e.stopPropagation(); pgtRecenter(q.id); };
  return c;
}

function pgtChipRow(label, prompts, cardTitle) {
  const row = document.createElement('div');
  row.className = 'pgtChipRow';
  const l = document.createElement('span');
  l.className = 'pgtChipLabel';
  l.textContent = label;
  row.appendChild(l);
  prompts.slice(0, PGT_CHIP_CAP).forEach(q => row.appendChild(pgtChip(q, cardTitle)));
  if (prompts.length > PGT_CHIP_CAP) {
    const more = document.createElement('span');
    more.className = 'pgtChip pgtChipMore';
    more.textContent = '+' + (prompts.length - PGT_CHIP_CAP);
    more.onclick = (e) => {   // expand inline (never re-centers, §3)
      e.stopPropagation();
      prompts.slice(PGT_CHIP_CAP).forEach(q => row.insertBefore(pgtChip(q, cardTitle), more));
      more.remove();
    };
    row.appendChild(more);
  }
  return row;
}

function pgtMixinRows(p) {
  const wrap = document.createElement('div');
  wrap.className = 'pgtMixins';
  const fwd = (p.drewFrom || []).map(id => st.prompts[id]).filter(Boolean).sort(pgtByScoreDesc);
  if (fwd.length) wrap.appendChild(pgtChipRow('🔗 drew from:', fwd, '🔗 This prompt drew from'));
  const rev = pgtSeededBy(p.id).sort(pgtByScoreDesc);
  if (rev.length) wrap.appendChild(pgtChipRow('🔗 seeded ' + rev.length + ':', rev, '🔗 This prompt seeded'));
  return wrap.children.length ? wrap : null;
}

// --- rows (siblings / descendants) with inline "+N more" ---

// A row item is normally a prompt, but the descendants row can also hold { __ver } markers: the reverse
// 🔖 edge, where a prompt you marked points forward at the instruction version it helped you write.
function pgtRowBox(item, boxOpts) {
  if (item && item.__ver != null) {
    const b = pgtVersionBox(item.__ver, { withThumbs: true, gen: boxOpts && boxOpts.gen });
    // The far end of a 🚫 edge gets the same red treatment as the near end in the parent row.
    if (item.__anti) {
      b.classList.add('pgtAntiEdge');
      b.insertBefore(pgtAntiTitle(), b.firstChild);
      b.title = 'You marked this prompt as an anti-influence before writing v' + item.__ver;
    } else {
      b.classList.add('pgtInfEdge');
      b.title = 'You marked this prompt as an influence before writing v' + item.__ver;
    }
    return b;
  }
  return pgtPromptBox(item, boxOpts);
}

// `lead` holds boxes that are not descendants and must not be counted or capped as if they were: today
// that's the reverse 🔖 edge (an instruction this prompt influenced). They render first and always render
// — the count in the header stays a true count of real children, and a prompt with a full row of them
// can't push its one instruction edge behind "+N more".
function pgtRow(headText, prompts, boxOpts, key, lead) {
  const wrap = document.createElement('div');
  wrap.className = 'pgtRow';
  const head = document.createElement('div');
  head.className = 'pgtRowHead';
  head.textContent = headText + ' (' + prompts.length + ')';
  wrap.appendChild(head);
  const inner = document.createElement('div');
  inner.className = 'pgtRowInner';
  (lead || []).forEach(p => inner.appendChild(pgtRowBox(p, boxOpts)));
  const expanded = pgtExpanded.has(key);
  const shown = expanded ? prompts : prompts.slice(0, PGT_SIBLING_CAP);
  shown.forEach(p => inner.appendChild(pgtRowBox(p, boxOpts)));
  if (!expanded && prompts.length > PGT_SIBLING_CAP) {
    const more = document.createElement('div');
    more.className = 'pgtBox pgtMore';
    more.textContent = '+' + (prompts.length - PGT_SIBLING_CAP) + ' more';
    // Append the rest inline (reusing the current pgtGen, so their thumbnails load without a full
    // re-render) instead of pgtRender() — a re-render would revoke + reload every existing thumbnail
    // and flicker. pgtExpanded still records the key so a later real re-render keeps this row open.
    more.onclick = (e) => {
      e.stopPropagation();
      pgtExpanded.add(key);
      prompts.slice(PGT_SIBLING_CAP).forEach(p => inner.insertBefore(pgtRowBox(p, boxOpts), more));
      more.remove();
      pgtDrawRails(inner.closest('#pgtCanvas'));   // the row just changed shape; its rails no longer fit
    };
    inner.appendChild(more);
  }
  wrap.appendChild(inner);
  return wrap;
}

// The horizontal rule a row's boxes hang from. Measured rather than expressed in CSS: it has to stop at
// the CENTRES of the outermost boxes (a full-width rule overshoots badly when a row holds two or three),
// and a row that wraps needs one rule per line, which only the laid-out positions can tell us. Called
// after every render and after a "+N more" expansion; safe to call twice on the same canvas.
function pgtDrawRails(canvas) {
  if (!canvas) return;
  canvas.querySelectorAll('.pgtRowInner').forEach(inner => {
    inner.querySelectorAll('.pgtRail').forEach(r => r.remove());
    const lines = new Map();
    for (const kid of inner.children) {
      const top = kid.offsetTop;
      if (!lines.has(top)) lines.set(top, []);
      lines.get(top).push(kid);
    }
    for (const boxes of lines.values()) {
      if (boxes.length < 2) continue;              // a lone box keeps its stub and needs no crossbar
      const mid = el => el.offsetLeft + el.offsetWidth / 2;
      const a = mid(boxes[0]), b = mid(boxes[boxes.length - 1]);
      const rail = document.createElement('div');
      rail.className = 'pgtRail';
      rail.style.left = Math.round(a) + 'px';
      rail.style.top = Math.round(boxes[0].offsetTop - 10) + 'px';
      rail.style.width = Math.round(b - a) + 'px';
      inner.appendChild(rail);
    }
  });
}

// --- centered node + ancestors assembly ---

// A short vertical rule between two stacked nodes. Purely decorative: without them the canvas reads as a
// list of rows rather than a descent, which is the whole point of the view.
function pgtLink() {
  const d = document.createElement('div');
  d.className = 'pgtLink';
  return d;
}

// The 🧲 steer that shaped the centered prompt, as its own box off to the side rather than a node in the
// parent chain — the steer didn't create the prompt (the brainstorm batch under its instruction did), it
// coloured it, so hanging it in the spine would claim a descent that isn't there. It carries the one thing
// the ❓ panel can't: the OTHER prompts the same steer produced, each a click away.
// opts: { center } — as a center it drops the chips (every steered prompt becomes its descendants row
// instead) and stops being a click target.
function pgtSteerBox(text, exceptPromptId, opts) {
  opts = opts || {};
  const box = document.createElement('div');
  box.className = 'pgtBox pgtSteerBox' + (opts.center ? ' pgtCenter' : '');
  const h = document.createElement('div');
  h.className = 'pgtSteerTitle';
  h.textContent = '🧲 Steered by';
  box.appendChild(h);
  const t = document.createElement('div');
  t.className = 'pgtText';
  t.textContent = '"' + text + '"';
  pgtCardAttach(t, '🧲 Steered by', text);
  box.appendChild(t);
  const kids = pgtPromptsSteeredBy(text);
  const note = (t) => { const n = document.createElement('div'); n.className = 'pgtSteerNone'; n.textContent = t; return n; };
  if (opts.center) {
    // Centred, every steered prompt is spelled out in the descendants row below — chips would repeat it.
    box.appendChild(note(kids.length + (kids.length === 1 ? ' prompt' : ' prompts') + ' carry this steer'));
  } else if (kids.length < 2) {
    box.appendChild(note('no other prompt from this steer'));
  } else {
    const wrap = document.createElement('div');
    wrap.className = 'pgtMixins';
    wrap.appendChild(pgtChipRow('also steered ' + (kids.length - 1) + ':',
      kids.filter(q => q.id !== exceptPromptId).sort(pgtByScoreDesc), '🧲 Also steered by this'));
    box.appendChild(wrap);
  }
  // A steer's images are every image its prompts drew, pooled — the fastest read on whether the steer
  // actually landed, and the one thing no single prompt box can show.
  const imgs = pgtSteerImages(kids);
  if (imgs.length) box.appendChild(pgtThumbStrip(imgs, opts.gen, '🧲 ' + text));
  if (opts.center) return box;
  // Clicking re-centers the whole tree on the steer, so it can be read as a node in its own right —
  // every prompt it shaped in one row — instead of only ever being an annotation on someone else.
  box.classList.add('pgtSteerLink');
  box.title = 'Center the tree on this steer';
  box.onclick = (e) => {
    if (!e.target.closest('.pgtChip') && !e.target.closest('.pgtThumb')) pgtRecenter(pgtSteerId(text));
  };
  return box;
}

// Mirror of the ▲ step-up control: the instruction spine continues DOWNWARD past a version center, and
// without this the only way back to a newer version is the ← Back button (§ successor links).
function pgtSuccessorEl(ver) {
  const newest = st.instVersion || ver;
  if (ver >= newest) return null;
  const el = document.createElement('div');
  el.className = 'pgtEarlier';
  const behind = newest - ver - 1;
  el.textContent = '▼ Instruction v' + (ver + 1) + (behind ? ' · ' + behind + ' newer after it' : '');
  el.title = 'Go down one instruction version';
  el.onclick = () => pgtRecenter(pgtVerId(ver + 1));
  return el;
}

function pgtAncestorsEl(chain, gen) {
  const wrap = document.createElement('div');
  wrap.className = 'pgtAncestors';
  const cv = pgtIsVer(pgtCenterId) ? pgtVerNum(pgtCenterId)
    : (st.prompts[pgtCenterId] ? (st.prompts[pgtCenterId].ver || 1) : 1);
  // Leading run of version trunks older than the centered version collapses behind one toggle (§3).
  const earlier = [], rest = [];
  for (const id of chain) {
    if (!rest.length && pgtIsVer(id) && pgtVerNum(id) < cv) earlier.push(id);
    else rest.push(id);
  }

  // Which instruction version's parents this block draws — the "anchor". A prompt born straight under an
  // instruction has it at the head of `rest`; a version center isn't in its own chain, so it anchors on
  // itself; a promoted prompt hanging off an OLDER prompt has no version box in `rest` at all, so the
  // nearest collapsed one is pulled out of the ▲ run and drawn. One instruction always renders as a real
  // box: grey toggle text can't carry thumbnails, can't show what the instruction replaced, and has
  // nowhere for the 🔖 influence parents to hang.
  let anchorVer = null;
  if (rest.length && pgtIsVer(rest[0])) anchorVer = pgtVerNum(rest[0]);
  else if (pgtIsVer(pgtCenterId)) anchorVer = cv;
  else if (earlier.length) { rest.unshift(earlier.pop()); anchorVer = pgtVerNum(rest[0]); }

  const parts = [];

  // The parent row below already shows the immediately previous version as a box, so the step-up control
  // points at the nearest one still COLLAPSED — one generation per click counted from what you can see.
  // It stays a single control however many versions a session has: arriving from v253 you want v252, not
  // the bottom of a 252-box stack ending at v1, and that's what the back-stack is for.
  const collapsed = (anchorVer != null && anchorVer > 1) ? earlier.slice(0, -1) : earlier;
  if (collapsed.length) {
    const prevId = collapsed[collapsed.length - 1];
    const tog = document.createElement('div');
    tog.className = 'pgtEarlier';
    tog.textContent = '▲ Instruction v' + pgtVerNum(prevId)
      + (collapsed.length > 1 ? ' · ' + (collapsed.length - 1) + ' older behind it' : '');
    tog.title = 'Go up one instruction version';
    tog.onclick = () => pgtRecenter(prevId);
    parts.push(tog);
  }

  if (anchorVer != null) {
    const parents = pgtParentRow(anchorVer, gen);
    if (parents) parts.push(parents);
  }

  rest.forEach((id, i) => {
    // The anchor is where the canvas scrolls to on open, so the parent row lands above the fold and
    // displaces nothing: what you see still opens on the instruction, with its ancestry a scroll away.
    // It's also the one ancestor that gets thumbnails: it opens directly beneath a parents row whose
    // previous-version and 🔖 influence boxes all carry them, so a bare box there reads as images that
    // failed to load rather than as "the spine is quiet". The rest of the chain stays text-only.
    const isAnchor = i === 0 && pgtIsVer(id);
    const node = pgtAncestorNode(id, isAnchor ? { withThumbs: true, gen } : null);
    if (isAnchor && node.classList) node.classList.add('pgtAnchor');
    parts.push(node);
  });

  parts.forEach((el, i) => {
    if (i) wrap.appendChild(pgtLink());   // pgtRender draws the drop below the block itself
    wrap.appendChild(el);
  });
  return wrap;
}

function pgtCenterEl(gen) {
  const wrap = document.createElement('div');
  wrap.className = 'pgtCenterWrap';
  if (pgtIsVer(pgtCenterId)) {
    const vb = pgtVersionBox(pgtVerNum(pgtCenterId), { center: true, withThumbs: true, gen });
    vb.classList.add('pgtAnchor');   // centered on a version, the instruction IS the scroll anchor
    wrap.appendChild(vb);
    return wrap;
  }
  if (pgtIsSteer(pgtCenterId)) {
    wrap.appendChild(pgtSteerBox(pgtSteerText(pgtCenterId), null, { center: true, gen }));
    return wrap;
  }
  const p = st.prompts[pgtCenterId];
  if (!p) {
    const gone = document.createElement('div');
    gone.className = 'pgtBox pgtCenter';
    gone.textContent = 'This prompt is no longer available.';
    wrap.appendChild(gone);
    return wrap;
  }
  const box = pgtPromptBox(p, { center: true, withThumbs: true, gen });
  const mix = pgtMixinRows(p);
  if (mix) box.appendChild(mix);
  // The steer rides alongside the center on a dotted tether (pgtSteerBox), so the row is [center]⋯[steer].
  // pgtPromptBox drops its own 🧲 tag for the center to keep the steer stated once.
  if (p.influenceText) {
    const row = document.createElement('div');
    row.className = 'pgtCenterRow';
    row.appendChild(box);
    const tether = document.createElement('div');
    tether.className = 'pgtTether';
    row.appendChild(tether);
    row.appendChild(pgtSteerBox(p.influenceText, p.id, { gen }));
    wrap.appendChild(row);
    return wrap;
  }
  wrap.appendChild(box);
  return wrap;
}

function pgtRenderBreadcrumb() {
  const back = document.getElementById('pgtBack');
  if (back) back.style.display = pgtStack.length ? 'inline-flex' : 'none';
  const bc = document.getElementById('pgtCrumb');
  if (!bc) return;
  if (pgtIsVer(pgtCenterId)) { bc.textContent = '· Instruction v' + pgtVerNum(pgtCenterId); return; }
  if (pgtIsSteer(pgtCenterId)) {
    const s = pgtSteerText(pgtCenterId);
    bc.textContent = '· 🧲 ' + (s.length > 44 ? s.slice(0, 44) + '…' : s);
    return;
  }
  const p = st.prompts[pgtCenterId];
  const t = p ? p.text : '';
  bc.textContent = '· ' + (t.length > 48 ? t.slice(0, 48) + '…' : t);
}

function pgtRender() {
  const canvas = document.getElementById('pgtCanvas');
  if (!canvas) return;
  pgtCardHide();             // it's anchored to a box that's about to be thrown away
  const gen = ++pgtGen;      // invalidate any thumb loads from the previous render
  pgtImgIdx = pgtBuildImageIndex();   // one task-table pass for every box on this canvas
  pgtVerIdx = pgtBuildVersionIndex(); // ditto, one prompt-table pass for every version box
  pgtRevokeUrls();
  canvas.innerHTML = '';

  // Generations are joined by a drawn rule (pgtLink) rather than left to float on the canvas gap: the
  // parent chain drops into this generation, and this generation drops into its descendants. Siblings
  // share the center's parent, so they hang off the SAME drop as the center and get no rule of their own.
  const anc = pgtAncestorChain(pgtCenterId);
  if (anc.length) { canvas.appendChild(pgtAncestorsEl(anc, gen)); canvas.appendChild(pgtLink()); }

  // Siblings carry thumbnails like the center and the descendants do: a row of peers you can't tell apart
  // by outcome is a row you have to click through one at a time to read.
  if (!pgtIsSynthetic(pgtCenterId)) {
    const sibs = pgtSiblingsOf(pgtCenterId);
    if (sibs.length) canvas.appendChild(pgtRow('Siblings', sibs, { withThumbs: true, gen }, 'sib'));
  }

  canvas.appendChild(pgtCenterEl(gen));

  const kids = pgtIsVer(pgtCenterId) ? pgtVersionChildren(pgtVerNum(pgtCenterId)).sort(pgtByCreated)
    : pgtIsSteer(pgtCenterId) ? pgtPromptsSteeredBy(pgtSteerText(pgtCenterId)).sort(pgtByCreated)
    : pgtChildrenOf(pgtCenterId).sort(pgtByCreated);
  // The 🔖 edge, drawn in reverse as well as forward (like drewFrom). Arriving at a marked prompt from an
  // image's ❓ 🌳 you'd otherwise get no hint that it changed the course of the session, which is the most
  // interesting thing about it. Passed as the row's `lead` rather than mixed into the children: these
  // aren't descendants, and counting them as such would both overstate "Descendants (N)" and spend a
  // real child's slot under the cap. 🚫 edges follow the 🔖 ones, mirroring the parent row's order.
  const infEdges = pgtIsSynthetic(pgtCenterId) ? []
    : infVersionsForPrompt(pgtCenterId, false).map(v => ({ __ver: v }))
        .concat(infVersionsForPrompt(pgtCenterId, true).map(v => ({ __ver: v, __anti: true })));
  if (kids.length || infEdges.length) {
    canvas.appendChild(pgtLink());
    canvas.appendChild(pgtRow(pgtIsSteer(pgtCenterId) ? 'Steered' : 'Descendants',
      kids, { withThumbs: true, gen }, 'desc', infEdges));
  }

  // The instruction spine runs newest-at-the-bottom, so the step-down control closes it off underneath
  // everything the version produced — the ▲ at the top of the ancestors block is its mirror image.
  if (pgtIsVer(pgtCenterId)) {
    const succ = pgtSuccessorEl(pgtVerNum(pgtCenterId));
    if (succ) { canvas.appendChild(pgtLink()); canvas.appendChild(succ); }
  }

  pgtDrawRails(canvas);      // after the canvas is populated: the rails are measured off the real layout
  pgtRenderBreadcrumb();
}

// --- open / re-center / back / close ---

function pgtRevokeUrls() {
  for (const u of pgtObjectUrls) { try { URL.revokeObjectURL(u); } catch (e) {} }
  pgtObjectUrls = [];
}

// Open scrolled to the owner instruction rather than to the very top, so the parent row (previous version
// + 🔖 influences) sits above the fold and displaces nothing: the canvas looks the way it always did, and
// the ancestry is a scroll up. Measured off rects, not offsetTop — a box inside a row is positioned
// against .pgtRowInner, not against the canvas.
function pgtScrollToAnchor() {
  const canvas = document.getElementById('pgtCanvas');
  if (!canvas) return;
  const a = canvas.querySelector('.pgtAnchor');
  if (!a) { canvas.scrollTop = 0; return; }
  const top = a.getBoundingClientRect().top - canvas.getBoundingClientRect().top;
  canvas.scrollTop = Math.max(0, canvas.scrollTop + top - 12);
}

// Both doors into the tree — the toolbar 🌳 and an image's ❓ 🌳 — come through here, and both land you
// in whichever MODE you used last (pgtMode). What differs between the doors is what gets centred and
// highlighted, not which view you get: opening on an image should not silently change the shape of the
// thing that opens.
function pgtOpen(centerId, opts) {
  opts = opts || {};
  pgtCenterId = centerId;
  pgtHighlightTaskId = opts.taskId || null;
  pgtStack = [];
  pgtExpanded = new Set();
  // Isolate is a reading gesture, not a saved state — drop it on re-open so you start on the full map.
  mgtIsolate = false;
  hideStats();                         // dismiss the ❓ panel that launched this
  pgtEl().classList.add('pgtOpen');
  pgtApplyMode({ reset: true });
  // If opening directly in session mode, auto-pin the subject so isolate is immediately usable.
  // Resolve pgtCenterId directly rather than via mgtEntryNodeId(): its newest-version fallback would
  // pin a node that was never the subject (e.g. when the subject is a steer drawn in badge mode).
  if (pgtMode === 'session' && !mgtSel && pgtCenterId != null) {
    const key = pgtIsVer(pgtCenterId) ? pgtCenterId : String(pgtCenterId);
    if (mgtById.has(key)) mgtSelect(key);
  }
}

function pgtRecenter(id) {
  if (id == null || id === pgtCenterId) return;
  pgtStack.push(pgtCenterId);
  pgtCenterId = id;
  pgtHighlightTaskId = null;            // the image ring only applies to the initial open-from-image
  pgtExpanded = new Set();
  pgtRender();
  pgtScrollToAnchor();
}

function pgtBack() {
  if (!pgtStack.length) return;
  pgtCenterId = pgtStack.pop();
  pgtHighlightTaskId = null;
  pgtExpanded = new Set();
  pgtRender();
  pgtScrollToAnchor();
}

// Rails are absolute pixels measured off a laid-out row, so a viewport change strands them over empty
// space while the boxes re-wrap underneath. Cheap enough to just redo — no re-render, no thumb reload.
window.addEventListener('resize', () => {
  if (pgtEl() && pgtEl().classList.contains('pgtOpen')) pgtDrawRails(document.getElementById('pgtCanvas'));
  pgtCardHide();     // placed in viewport coordinates against a box that just moved
});

// The card is position:fixed but anchored to a box that scrolls with the canvas, so a scroll strands it
// pointing at nothing. Dismiss rather than re-place: you scrolled, so you're done with what you were
// reading, and chasing the anchor on every scroll frame would make the canvas feel heavy.
// `.statsBody` inside the card is overscroll-behavior:contain, so reading a long card can't trip this.
document.getElementById('pgtCanvas').addEventListener('scroll', pgtCardHide, { passive: true });

function pgtClose() {
  pgtEl().classList.remove('pgtOpen');
  pgtCardHide();                       // it lives on <body>, so it would outlive the overlay otherwise
  pgtGen++;                            // strand any in-flight thumb loads
  pgtImgIdx = null;                    // don't pin a snapshot of the task table open across sessions
  pgtVerIdx = null;                    // ditto for the prompt table
  mgtSteerIdx = null;
  pgtRevokeUrls();
  mgtTeardown();                       // revokes the mega-tree's blob URLs and stops its observer
  const canvas = document.getElementById('pgtCanvas');
  if (canvas) canvas.innerHTML = '';
  pgtCenterId = null; pgtStack = []; pgtHighlightTaskId = null; pgtExpanded = null;
  // Mode and zoom deliberately SURVIVE a close — they're how you like to look at this, not what you were
  // looking at. Selection and scroll don't: they point at a node in a snapshot that's now gone.
  mgtSel = null; mgtHover = null;
  // The node graph holds a task list per node, so leaving it populated keeps a snapshot of the session's
  // images referenced for as long as the tree stays closed. mgtBuild replaces all three on the next open.
  mgtNodes = []; mgtById = new Map(); mgtEdgeList = [];
}

pgtEl().addEventListener('click', (e) => { if (e.target === pgtEl()) pgtClose(); });
document.getElementById('pgtCloseX').onclick = pgtClose;
document.getElementById('pgtBack').onclick = pgtBack;

/* ===================== 🌳 Mega-tree — the whole session on one canvas =====================

   The focused tree above answers "where did THIS prompt come from" — one generation at a time, text-first.
   This answers the other question: what shape did the whole session have. Same lineage graph, all of it at
   once, drawn ENTIRELY AS PICTURES — a session is a thing you recognise by its images, and a canvas of
   wrapped paragraphs is unreadable at any zoom. Wording lives in the hover card, one element for the whole
   canvas.

   Two views, one overlay, one set of queries. Everything structural is borrowed from the focused view —
   pgtParentIdOf / pgtChildrenOf for the spine, infParentsForVersion for 🔖, pgtImagesOf and
   pgtVersionImages for the pictures, galCellObserver for the bytes. What is genuinely new is only the
   three things a map needs and a list doesn't: a layout pass, an edge layer, and pan/zoom.

   Deliberately NOT borrowed: pgtDrawRails. Its connectors are absolute pixels measured off laid-out boxes
   and redrawn on resize; that cannot survive panning and zooming. Edges here are SVG inside the scaled
   layer, so they transform with the nodes for free. */

const MGT_TOP = 4;          // prompts drawn per instruction version (§3) — a constant, not a control
const MGT_TOP_ISOLATE = 9;  // 3×3 contact sheet when isolate tiles are large enough
const MGT_IMG = 112;        // the image square at 100% zoom
const MGT_FRAME = 4;        // padding ring — the clickable non-image chrome selection needs (§7.2)
const MGT_BORDER = 2;
const MGT_STRIP = 16;       // bottom chrome strip: the type glyph and the "+N"
const MGT_NODE_W = MGT_IMG + (MGT_FRAME + MGT_BORDER) * 2;   // 124
const MGT_NODE_H = MGT_NODE_W + MGT_STRIP;                   // 140
const MGT_GAP_X = 26;
const MGT_GAP_Y = 46;
const MGT_MARGIN = 52;      // room for the 🔖 edges that curve in from the left, and for orbit badges
const MGT_ZOOMS = [0.5, 0.75, 1, 1.5];
const MGT_ZOOM_100 = 2;                 // index of 100% — the zoom you OPEN at (§8), not fit-to-anything
const MGT_COLLAPSE_BELOW = 0.75;        // under this, a multi-image node shows only its best image (§6)
const MGT_ORBIT_CAP = 4;                // 🧲 badges around a version node before a "+N"
const MGT_SPACER_H = 40;               // collapsed empty-band spacer in isolate mode
const MGT_STEER_W = 62;                // half-sized steer node width
const MGT_STEER_H = 70;                // half-sized steer node height
const MGT_STEER_GAP = 8;               // gap between version node and its steer gutter nodes
const MGT_STEER_COL_W = MGT_STEER_W + MGT_STEER_GAP;  // 70 — extra column width when steer-nodes are on
const MGT_CONTACT_THRESHOLD = MGT_IMG * 3;              // 336 — tile size above which 3×3 replaces 2×2
// How long the pointer must rest on a square before its card opens. The focused tree opens instantly; this
// canvas packs squares 26px apart, so without a pause crossing it trails cards behind the pointer.
const MGT_CARD_DELAY = 330;

let pgtMode = 'focused';        // 'focused' | 'session' — view state, never persisted to disk
let mgtZoomIdx = MGT_ZOOM_100;
let mgtCollapsed = false;       // whether multi-image nodes are currently drawing one image
let mgtVerFrom = 1, mgtVerTo = 1;
let mgtNodes = [];              // laid-out nodes, in no particular order
let mgtSpacers = [];            // collapsed band spacers in isolate mode
let mgtById = new Map();
let mgtEdgeList = [];
let mgtContentW = 0, mgtContentH = 0;
let mgtSel = null;              // sticky highlight key — survives the pointer leaving (§7.2)
let mgtHover = null;            // transient highlight key; only consulted when nothing is selected
let mgtSteerIdx = null;         // steer text → prompts, built per render (see pgtImgIdx for the why)
let mgtDragged = false;         // a pan just happened, so the click that follows it isn't a click
let mgtIsolate = false;         // isolate sub-mode: show only the lineage of the pinned square
let mgtSteerMode = 'node';     // 'badge' | 'node' — how 🧲 steers are drawn (toggle, not persisted)

function mgtScrollEl() { return document.getElementById('mgtScroll'); }
function mgtLayerEl()  { return document.getElementById('mgtLayer'); }
function mgtSvgEl()    { return document.getElementById('mgtEdges'); }
function mgtZoom()     { return MGT_ZOOMS[mgtZoomIdx]; }

// --- what earns a node (§3) ---

// Votes FIRST, and this is the whole reason the mega-tree can't reuse pgtByScoreDesc: recomputeScore
// makes p.score a RATE (votes / used), so a prompt used once with one vote scores 1.0 and outranks a
// workhorse used ten times with eight votes. Ranking by score alone fills the canvas with one-hit
// wonders. Raw votes says "this earned it"; the rate breaks ties toward efficiency; recency breaks the
// rest.
const mgtByEarned = (a, b) =>
  (b.votes || 0) - (a.votes || 0) ||
  (b.score || 0) - (a.score || 0) ||
  (b.createdAt || 0) - (a.createdAt || 0);

// The whole session on one canvas, not a window of it. IntersectionObserver culls image blobs against
// the viewport, so rendering 250 versions is affordable — the bottleneck was always decoded bytes, not
// DOM nodes. What the windowed version could NOT do was let you see the shape of a session at a glance.
function mgtResetWindow() {
  mgtVerFrom = 1;
  mgtVerTo = Math.max(1, st.instVersion || 1);
}

function mgtBuildSteerIndex() {
  const idx = new Map();
  for (const pid in st.prompts) {
    const p = st.prompts[pid];
    if (!p || !p.influenceText) continue;
    let a = idx.get(p.influenceText);
    if (!a) idx.set(p.influenceText, a = []);
    a.push(p);
  }
  return idx;
}

// --- node constructors ---
//
// `tasks` are the real image tasks (what the lightbox wants); `centerId` is the id the FOCUSED view can
// re-centre on, or null where there is nothing left to centre on (a ghost 🔖). `label` titles the gallery
// that "+N" opens.

function mgtVerNode(v) {
  return {
    id: pgtVerId(v), kind: 'version', ver: v, centerId: pgtVerId(v), prompt: null,
    title: 'Instruction v' + v,
    text: (st.instHistory && st.instHistory[v] != null && String(st.instHistory[v]).trim())
      ? st.instHistory[v] : '(instruction text not recorded)',
    // 💭 kept as its OWN field rather than appended to `text` — `text` doubles as the gallery `label`
    // below, so folding the note in would put it in a gallery title.
    why: (st.instWhy && st.instWhy[v]) || '',
    tasks: pgtVersionImages(v), label: 'Instruction v' + v,
    createdAt: -1, orbit: null,
  };
}

function mgtPromptNode(p, outside) {
  return {
    id: String(p.id), kind: 'prompt', ver: p.ver, centerId: p.id, prompt: p,
    title: 'Prompt' + (p.ver ? ' · born v' + p.ver : ''),
    text: p.text || '',
    tasks: pgtImagesOf(p.id), label: p.text || 'Prompt',
    createdAt: p.createdAt || 0, outside: !!outside,
  };
}

// A committed 🔖 or 🚫 whose prompt has since been deleted. It keeps the cacheId, so the picture usually
// still resolves through the cache; when even that is gone the node draws as an empty frame and is NEVER
// omitted. Dropping it would quietly rewrite the instruction's history — make an instruction look like it
// came from nowhere — which is exactly the claim the edge exists to make. The record snapshots the wording
// at mark time, so the hover card can still say what it was: the node has no picture, it does not lack
// content. Unlike a prompt square, a ghost IS one mark of one kind, so it can carry that kind itself.
function mgtGhostNode(ver, rec, i) {
  const cacheId = rec.cacheId != null ? rec.cacheId : null;
  const task = { id: 'mgtGhost:' + ver + ':' + i, promptId: null, resolvedText: rec.text || '',
                 cacheId, ui: null, idx: 0 };
  return {
    id: 'g:' + ver + ':' + i, kind: 'ghost', ver, centerId: null, prompt: null, anti: !!rec.anti,
    title: rec.anti ? '🚫 Anti-influence · prompt deleted' : '🔖 Influence · prompt deleted',
    text: rec.text || '(wording not recorded)',
    tasks: cacheId != null ? [task] : [], label: rec.anti ? '🚫 anti-influence' : '🔖 influence',
    createdAt: 0,
  };
}

// --- 🧲 orbit badges (§5.1) ---
//
// A steer is NOT a node and has no parent edge — st.influenceQueue is a global FIFO consumed one entry per
// brainstorm batch, and it never attaches to a prompt. Inventing a parent edge for it would invent a
// relationship the data model does not have. What IS true is that a steer is consumed by one batch and a
// batch runs under exactly one instruction version — so it hangs off the version node as a badge, on a
// node that already has a layer.
//
// Only steers that demonstrably MATTERED are drawn, because a badge that appears for every steer says
// nothing. Two tiers, and they are not nested: marking is you saying "this should shape what comes next",
// upvoting is you saying "I liked this", and you can bookmark an image you never upvoted — so strong wins
// outright, with or without an upvote.
// Only 🔖 marks count toward strong. A 🚫 on a steered prompt is a steer you rejected, and "strong" means a
// steer that led somewhere good — letting a rejection earn the same badge would make the two unreadable.
function mgtSteerTier(text, v) {
  const kids = (mgtSteerIdx && mgtSteerIdx.get(text)) || [];
  const ids = new Set(kids.map(p => p.id));
  for (const k in st.instInfluences) {
    // A mark commits FORWARD, to a version at or after the prompt's own. Normally strictly after — but
    // keep-prompts mode re-stamps a kept prompt's ver to the very version its marks committed to, so
    // k === v is a legitimate hit, not a self-reference.
    if (Number(k) < v) continue;
    if ((st.instInfluences[k] || []).some(r => r && !r.anti && r.promptId != null && ids.has(r.promptId))) return 'strong';
  }
  return kids.some(p => (p.votes || 0) > 0) ? 'weak' : null;
}

// Steers consumed UNDER this version. `influenceInherited` prompts are excluded: that flag means the
// prompt was captured from an already-steered image rather than born in the steer's own batch, so counting
// it would credit this version with a steer some earlier batch actually consumed.
function mgtOrbitFor(v) {
  const born = (pgtVerIdx && pgtVerIdx.get(v)) || [];
  const seen = new Set(), out = [];
  for (const p of born) {
    if (!p.influenceText || p.influenceInherited || seen.has(p.influenceText)) continue;
    seen.add(p.influenceText);
    const tier = mgtSteerTier(p.influenceText, v);
    if (tier) out.push({ text: p.influenceText, tier });
  }
  out.sort((a, b) => (a.tier === b.tier) ? 0 : (a.tier === 'strong' ? -1 : 1));
  return out;
}

// --- isolate: lineage computation ---
//
// Walk the full edge graph outward from `startKey` and return the Set of every node ID in the strand —
// versions included, because an instruction version is as much a part of a prompt's history as a prompt.
//
// Every edge mgtBuild makes points from cause to effect (spine: older → newer version; parent: what it was
// born from → prompt; 🔖/🚫: marked image → the version it was applied to; 🔗: example → the prompt that drew
// from it; 🧲: steer → prompt it shaped). So ANCESTORS are the edges walked backwards: from a prompt under v7
// that reaches v7, v6…v1 along the spine, every image marked for any of them, and each of those images' own
// parents and steer — all the way back. 🔗 is the one exception, taken a single step (see the end).
//
// mgtBuild calls this on an UNCAPPED graph — every prompt with an image, every steer — so what it returns is
// limited only by the lineage, never by what the full map chose to draw.
//
// Versions used to be skipped here as "scaffolding", and that stranded every strand one step up: the marks
// point INTO a version, so a walk that never stood on one never found them.
//
// Siblings — prompts that only share an instruction with the seed — still can't get in. The upward walk
// never follows an edge forwards, and forwards is the only way to reach a sibling (version → prompt). The
// downward walk stops expanding a version's batch for the same reason; see below.
function mgtComputeLineage(startKey, nodes, edges) {
  const causes = new Map(), effects = new Map();   // id → ids one edge back / forward, every edge kind
  const link = (m, k, v) => { let a = m.get(k); if (!a) m.set(k, a = []); a.push(v); };
  for (const e of edges) { link(causes, e.b, e); link(effects, e.a, e); }

  // Seed: the pinned node, or for a steer key, the steer plus its shaped prompts.
  // mgtBuild always makes steer nodes while isolating; the mgtSteerIdx fallback is for a caller that doesn't.
  const seeds = [];
  if (typeof startKey === 'string' && startKey.startsWith('s:')) {
    if (nodes.has(startKey)) seeds.push(startKey);
    // Steer edges (node mode): direct edges from the steer node
    for (const e of edges) {
      if (e.kind === 'steer' && e.a === startKey && nodes.has(e.b)) seeds.push(e.b);
    }
    // Badge mode fallback: no steer edges exist, use the steer→prompt index directly
    if (seeds.length === 0 || (seeds.length === 1 && seeds[0] === startKey)) {
      const text = startKey.slice(2);
      for (const p of ((mgtSteerIdx && mgtSteerIdx.get(text)) || [])) {
        const pid = String(p.id);
        if (!p.influenceInherited && nodes.has(pid) && !seeds.includes(pid)) seeds.push(pid);
      }
    }
  } else if (nodes.has(startKey)) {
    seeds.push(startKey);
  }

  const isVer = id => nodes.has(id) && nodes.get(id).kind === 'version';

  // 🔗 drew-from lines are NOT walked here; they get one step at the end. Examples are sampled from upvoted
  // prompts, which drew from earlier upvoted prompts, so following them all the way back reaches most of the
  // session's upvoted prompts once prompt mixing is on. The focused view treats them the same way — chips on
  // a box, not ancestors.

  // UP: every other edge backwards, transitively. Nothing is special-cased — a version is walked through like
  // any other square, and that is what reaches the 🔖/🚫 images behind each instruction.
  const upSeen = new Set(seeds), up = seeds.slice();
  while (up.length) {
    for (const e of (causes.get(up.pop()) || [])) {
      if (e.kind === 'drew' || upSeen.has(e.a) || !nodes.has(e.a)) continue;
      upSeen.add(e.a); up.push(e.a);
    }
  }

  // DOWN: every edge forwards, transitively — except that a version reached on the way down only continues
  // along the spine. Its other forward edges lead to its whole batch, and that batch shares nothing with the
  // seed but the instruction: let it in and one 🔖 would pull every prompt of every later version onto the
  // canvas. The version's own square already pools that batch's images, so what it produced is still in
  // view as pictures. The spine is followed because every later instruction really was rewritten from this
  // one; leaving them out would label them "nothing in this lineage", which is false.
  // A version that IS a seed is the exception: its own prompts are exactly what pinning it asks about.
  const downSeen = new Set(seeds), down = seeds.map(id => [id, true]);
  while (down.length) {
    const [id, isSeed] = down.pop();
    const spineOnly = isVer(id) && !isSeed;
    for (const e of (effects.get(id) || [])) {
      if (e.kind === 'drew' || (spineOnly && e.kind !== 'spine')) continue;
      if (downSeen.has(e.b) || !nodes.has(e.b)) continue;
      downSeen.add(e.b); down.push([e.b, false]);
    }
  }

  // 🔗, one step each way: the examples behind anything the seed came from, and the prompts that drew on the
  // seed or on anything that came from it. What joins here is a leaf — its own origins aren't followed — and
  // cousins (other prompts that drew on an ancestor) and a descendant's other examples stay out.
  // 🧲, one step back from anything that came from the seed: the steers that shaped what came after it — for a
  // pinned instruction, every steer its own batches consumed; for a prompt, the steer on a promoted batch born
  // from it. The walk up already has the steers the seed came FROM; without this, pinning an instruction lit
  // its prompts but none of the steers that shaped them. Also a leaf: the steer's other prompts stay out.
  const set = new Set([...upSeen, ...downSeen]);
  for (const e of edges) {
    if (!nodes.has(e.a) || !nodes.has(e.b)) continue;
    if (e.kind === 'steer' && downSeen.has(e.b)) set.add(e.a);
    if (e.kind !== 'drew') continue;
    if (upSeen.has(e.b)) set.add(e.a);
    if (downSeen.has(e.a) && !isVer(e.a)) set.add(e.b);
  }
  return set;
}

// Assign column indices within each layer. Version nodes go first (column 0), then prompt/ghost nodes
// in createdAt order. Steer nodes are excluded — they live in the gutter, not in a column.
function mgtAssignColumns(byLayer) {
  for (const arr of byLayer.values()) {
    const vers = arr.filter(n => n.kind === 'version');
    const rest = arr.filter(n => n.kind !== 'version' && n.kind !== 'steer').sort(pgtByCreated);
    vers.forEach((n, i) => { n.col = i; });
    const base = Math.max(1, vers.length);
    rest.forEach((n, i) => { n.col = base + i; });
  }
}

// Position steer nodes in the gutter beside their version node.
function mgtPositionSteers(nodes, maxExtent) {
  let { maxX, maxY } = maxExtent;
  for (const n of nodes.values()) {
    if (n.kind !== 'steer') continue;
    const vn = nodes.get(pgtVerId(n.ver));
    if (!vn) continue;
    n.x = vn.x + MGT_NODE_W + MGT_STEER_GAP;
    n.y = vn.y + n.steerIdx * (MGT_STEER_H + 4);
    maxX = Math.max(maxX, n.x + MGT_STEER_W);
    maxY = Math.max(maxY, n.y + MGT_STEER_H);
  }
  return { maxX, maxY };
}

// --- build: nodes, layers, columns, edges ---

function mgtBuild() {
  pgtImgIdx = pgtBuildImageIndex();
  pgtVerIdx = pgtBuildVersionIndex();
  mgtSteerIdx = mgtBuildSteerIndex();

  const nodes = new Map();
  const add = n => { if (!nodes.has(n.id)) nodes.set(n.id, n); return nodes.get(n.id); };
  const inWindow = v => v != null && v >= mgtVerFrom && v <= mgtVerTo;

  for (let v = mgtVerFrom; v <= mgtVerTo; v++) add(mgtVerNode(v));

  // Isolate starts from the WHOLE session, not from the map. The map's rules for what earns a square — top 4
  // per version, only steers that mattered — are right for an overview and wrong for a lineage: a low-scoring
  // 🔗 example or an unvoted 🧲 steer still shaped the image you pinned. So while isolating, every candidate
  // goes in uncapped and the lineage walk (mgtComputeLineage) alone decides what stays. Only plain objects
  // are made for the candidates; DOM is still created for the strand alone.
  const isolating = !!(mgtIsolate && mgtSel);

  if (isolating) {
    // Every prompt that drew something. Straight off st.prompts rather than pgtVerIdx, so a restored legacy
    // prompt with no `ver` can still be an ancestor or a descendant — it hangs off v1, as the focused view
    // puts it. A prompt with no image is only drawn when the structural rules below need it (it shaped
    // something); an imageless descendant is a queued prompt that hasn't run yet, with nothing to show.
    for (const pid in st.prompts) {
      const p = st.prompts[pid];
      if (p && pgtImagesOf(p.id).length) add(mgtPromptNode(p));
    }
  } else {
    // Earned: the top 4 of each version, over prompts that actually drew something. A version nobody
    // upvoted needs no special case — everything ties at zero and its most recent prompts win, so the band
    // still shows what that instruction produced.
    //
    // A restored legacy prompt with no `ver` at all is absent from pgtVerIdx and so earns nothing here —
    // the same rule pgtVersionChildren and pgtVersionImages already follow, so it can't show up under one
    // instruction while being missing from another's list. It is still reachable: opening the tree on it
    // draws it as the centre below, and it hangs off v1 like the focused view puts it.
    for (let v = mgtVerFrom; v <= mgtVerTo; v++) {
      const born = ((pgtVerIdx.get(v) || [])).filter(p => p && pgtImagesOf(p.id).length);
      born.sort(mgtByEarned).slice(0, MGT_TOP).forEach(p => add(mgtPromptNode(p)));
    }
  }

  // Structural #1: whatever the tree was opened on is ALWAYS present, even when it is nobody's best —
  // otherwise you open the tree on an image and the image isn't there. The same goes for the pinned square:
  // isolate can pin a square the map never earned (a low-scoring example, say), and leaving isolate must
  // not drop the pin or the scroll back to it.
  for (const id of [pgtCenterId, mgtSel]) {
    if (id == null || pgtIsSynthetic(id)) continue;
    const p = st.prompts[id];
    if (p) add(mgtPromptNode(p, !inWindow(p.ver)));
  }

  // Structural #2: every 🔖 and 🚫 source. An influence can be marked from an image born many versions
  // earlier, so its edge may cross most of the canvas — and that crossing IS the interesting part (an old
  // image pulling a much later instruction toward it, or pushing it away), so it is drawn rather than hidden.
  // A source whose version has no drawn version node lands at layer 0, above everything, which reads
  // correctly: it is older than what you are looking at.
  const infPairs = [];
  for (let v = mgtVerFrom; v <= mgtVerTo; v++) {
    infParentsForVersion(v).forEach((rec, i) => {
      const p = rec.promptId != null ? st.prompts[rec.promptId] : null;
      const n = p ? add(mgtPromptNode(p, !inWindow(p.ver))) : add(mgtGhostNode(v, rec, i));
      infPairs.push([n.id, pgtVerId(v), !!rec.anti]);
    });
  }

  // Structural #2b: a 🧲 steer that mattered brings the prompts that made it matter — up to MGT_TOP of its
  // upvoted ones. The map shows a steer BECAUSE something it shaped was upvoted, and when that something lost
  // its version's top-4 race the steer was a node with no lines: clicking it lit nothing. Both steer modes,
  // so flipping Badges ↔ Nodes never changes which prompts are on the map. (Isolate already has them all.)
  if (!isolating) {
    const mattered = new Set();
    for (let v = mgtVerFrom; v <= mgtVerTo; v++) for (const b of mgtOrbitFor(v)) mattered.add(b.text);
    for (const text of mattered) {
      (mgtSteerIdx.get(text) || [])
        .filter(p => (p.votes || 0) > 0 && inWindow(p.ver) && pgtImagesOf(p.id).length)
        .sort(mgtByEarned).slice(0, MGT_TOP)
        .forEach(p => add(mgtPromptNode(p)));
    }
  }

  // Structural #3: the parent of anything drawn, so no node dangles. Fixpoint because a promoted child's
  // parent can itself be a promoted child. Bounded by the window: a parent from BEFORE it isn't pulled in
  // (that is what the window is for), and the child simply hangs off its own version trunk instead — the
  // same fallback pgtVersionChildren already applies to a dangling parent.
  // While isolating, a prompt's 🔗 examples are pulled in the same way, so one whose images have all left
  // the cache still exists for the lineage walk to reach.
  for (let pass = 0; pass < 64; pass++) {
    let grew = false;
    for (const n of Array.from(nodes.values())) {
      if (n.kind !== 'prompt') continue;
      const par = pgtParentIdOf(n.centerId);
      const needed = (par == null || pgtIsVer(par)) ? [] : [par];
      if (isolating && Array.isArray(n.prompt.drewFrom)) needed.push(...n.prompt.drewFrom);
      for (const id of needed) {
        const q = st.prompts[id];
        if (!q || nodes.has(String(q.id))) continue;
        if (!isolating && !inWindow(q.ver)) continue;
        add(mgtPromptNode(q));
        grew = true;
      }
    }
    if (!grew) break;
  }

  // The one edge that constrains layout. A parent that isn't drawn is not a parent for layout purposes —
  // the node becomes a root instead, rather than reaching off the canvas.
  const parentOf = (n) => {
    if (n.kind === 'version') { const prev = pgtVerId(n.ver - 1); return nodes.has(prev) ? prev : null; }
    if (n.kind !== 'prompt') return null;
    const par = pgtParentIdOf(n.centerId);
    if (par == null) return null;
    const key = pgtIsVer(par) ? par : String(par);
    return nodes.has(key) ? key : null;
  };

  // Layer = longest path from a root over parent edges. This is a real family tree, not fixed version
  // bands — but it LOOKS banded for the common case, because most prompts have parent.kind 'instruction'
  // so their parent IS the version node, and the v1→v2→… chain forces vk to layer k-1. Where the data
  // genuinely branches, a promoted child sits one layer below ITS parent, wherever it was born.
  // Only parent edges count: letting a 🔖 or a 🔗 push a node would let one long-range mark stretch the
  // whole canvas. The graph is acyclic by construction (parent/drewFrom only point at prompts that already
  // existed; a 🔖 always points forward), so the guard below is belt-and-braces.
  const layer = new Map(), visiting = new Set();
  const depth = (id) => {
    if (layer.has(id)) return layer.get(id);
    if (visiting.has(id)) return 0;
    visiting.add(id);
    const par = parentOf(nodes.get(id));
    const d = par == null ? 0 : depth(par) + 1;
    visiting.delete(id);
    layer.set(id, d);
    return d;
  };

  const byLayer = new Map();
  for (const n of nodes.values()) {
    n.layer = depth(n.id);
    if (!byLayer.has(n.layer)) byLayer.set(n.layer, []);
    byLayer.get(n.layer).push(n);
  }

  // --- steer nodes (steer-mode 'node', or always while isolating) ---
  // A steer is NOT an ancestor and never counts as a parent for layout — it occupies the gutter beside
  // its version's band, not a column in the layout grid. Created here so the edge builder and isolate
  // filter can see them.
  // One rule in both views: a steer is drawn when it shaped a drawn prompt — whatever its votes, however many
  // share a version. So every square on the map can light its steer when pinned, and no steer node is drawn
  // with nothing to connect to. Every steer that mattered is still on the full map, because Structural #2b
  // drew its upvoted prompts. This replaced four per version picked from the badge orbit, which dropped the
  // steer behind a top-voted square once four earlier ones had taken the places, and drew steers whose prompts
  // had lost the top-4 race as nodes with no lines, which lit nothing when clicked. Isolate
  // ignores the Badges/Nodes toggle because a badge can't say which prompt a steer shaped and the lineage
  // walk can't follow one.
  // Inherited prompts (an upvote child carrying its parent's steer text) get no edge: their parent is the
  // prompt the steer actually shaped, it is always their ancestor, and it brings the steer in.
  const steerNodes = isolating || mgtSteerMode === 'node';
  if (steerNodes) {
    for (const [text, ps] of (mgtSteerIdx || new Map())) {
      const kids = ps.filter(p => !p.influenceInherited && nodes.has(String(p.id)));
      if (!kids.length) continue;
      // Beside the version of the earliest prompt it shaped ON THE CANVAS (isolate re-anchors to the strand
      // after its filter), not the first version that ever consumed it.
      const v = Math.min(...kids.map(p => p.ver || 1));
      const tier = mgtSteerTier(text, v) || 'plain';
      const sid = pgtSteerId(text);
      nodes.set(sid, {
        id: sid, kind: 'steer', ver: v, centerId: null, prompt: null,
        title: tier === 'strong' ? '🧲 Steer · later marked as a 🔖 influence'
             : tier === 'weak' ? '🧲 Steer · its prompts were upvoted'
             : '🧲 Steer · nothing it shaped was upvoted or marked',
        text, tier, tasks: [], label: '🧲 ' + text,
        layer: depth(pgtVerId(v)),
        firstShaped: Math.min(...kids.map(p => p.createdAt || 0)),   // gutter stacking order, below
        steerIdx: 0,
        steerChildren: kids.map(p => String(p.id)),
      });
    }
  }

  // Column 0 is the instruction spine and is RESERVED even on a layer that has no version node, so the
  // spine reads as one straight vertical line down the left. That is what makes §5.1's payoff legible —
  // scanning the spine to see which instructions had steers that mattered, over time.
  // Note what a row therefore holds: v(k+1) in column 0, and beside it the prompts born under v(k). The
  // next instruction sits alongside the batch that motivated it, which is the honest reading of the data.
  // Order within a layer is createdAt ascending, NOT barycentre crossing-reduction: deterministic
  // positions mean a new node appends to the end of its layer and a refresh doesn't shuffle what you were
  // looking at. Steer nodes are excluded — they live in the gutter, not in a column.
  mgtAssignColumns(byLayer);

  // --- build edges BEFORE isolate filter, so the lineage walk has the full graph ---
  let edges = [];
  for (const n of nodes.values()) {
    if (n.kind === 'steer') continue;   // steer edges are added below, not via parentOf
    const par = parentOf(n);
    if (par) edges.push({ a: par, b: n.id, kind: n.kind === 'version' ? 'spine' : 'parent' });
  }
  for (const [a, b, anti] of infPairs) if (nodes.has(a) && nodes.has(b)) edges.push({ a, b, kind: anti ? 'anti' : 'inf' });
  // 🔗 drew-from, drawn on hover/select ONLY (or always in isolate, where the strand is small). See §2.
  for (const n of nodes.values()) {
    if (n.kind !== 'prompt' || !Array.isArray(n.prompt.drewFrom)) continue;
    for (const id of n.prompt.drewFrom) {
      const k = String(id);
      if (nodes.has(k)) edges.push({ a: k, b: n.id, kind: 'drew' });
    }
  }
  // Steer edges: steer node → each prompt it shaped
  if (steerNodes) {
    for (const n of nodes.values()) {
      if (n.kind !== 'steer') continue;
      for (const cid of (n.steerChildren || [])) {
        if (nodes.has(cid)) edges.push({ a: n.id, b: cid, kind: 'steer' });
      }
    }
  }

  // --- isolate filter ---
  // When active, keep only the transitive lineage of the pinned square plus the version spine.
  // Everything else is removed, and empty bands collapse to spacers.
  mgtSpacers = [];
  let lineage = null;                 // every node id in the strand, versions included — shared with position block
  if (isolating) {
    lineage = mgtComputeLineage(mgtSel, nodes, edges);
    // A version outside the strand is not removed HERE: if its band stays for some other reason it is drawn
    // as scaffolding, so the spine still reads as one line. The band pass below drops it with its band.
    for (const [id, n] of Array.from(nodes.entries())) {
      if (n.kind === 'version') continue;
      if (!lineage.has(id)) nodes.delete(id);
    }
    // A steer text can be consumed under several versions, but it is ONE node. Sit it beside the version of
    // the earliest prompt it shaped IN THIS STRAND, not the first time it was ever used — otherwise a steer
    // from v2 reused at v9 would hold v2's band open and draw a line across most of the canvas to reach v9.
    for (const n of nodes.values()) {
      if (n.kind !== 'steer') continue;
      const kept = n.steerChildren.map(id => nodes.get(id)).filter(Boolean);
      if (!kept.length) continue;        // a pinned steer with nothing drawn stays where it was built
      n.ver = Math.min(...kept.map(k => (k.prompt && k.prompt.ver) || 1));
      n.layer = depth(pgtVerId(n.ver));
      n.firstShaped = Math.min(...kept.map(k => k.createdAt || 0));   // gutter stacking order, below
    }
    // Spine and parent edges are the scaffolding itself and stay whenever both ends are drawn. Every other
    // kind is a claim about the strand, so it needs both ends IN the strand: an old 🔖 source that was also
    // marked for some unrelated later version must not draw a line to that version just because its band
    // survived for another reason. (Its hover card still lists every version it fed.)
    edges = edges.filter(e => nodes.has(e.a) && nodes.has(e.b)
      && (e.kind === 'spine' || e.kind === 'parent' || (lineage.has(e.a) && lineage.has(e.b))));
    // Rebuild byLayer after filtering
    byLayer.clear();
    for (const n of nodes.values()) {
      if (!byLayer.has(n.layer)) byLayer.set(n.layer, []);
      byLayer.get(n.layer).push(n);
    }
    // Re-assign columns after filtering (fewer nodes per layer → more room)
    mgtAssignColumns(byLayer);
  }

  // --- position computation ---
  // Two paths: normal (uniform band height) and isolate (empty bands collapsed to spacers, tiles derived
  // from the widest kept band).
  const steerColW = steerNodes ? MGT_STEER_COL_W : 0;

  // Stack each gutter's steers from the top, in the order they first shaped something on the canvas, so the
  // stack is the same on every ↻ Refresh. Counted per layer for the band heights below.
  const steerSlots = new Map(), steersInLayer = new Map();
  const steerOrder = (a, b) => (a.firstShaped || 0) - (b.firstShaped || 0) || a.text.localeCompare(b.text);
  for (const n of Array.from(nodes.values()).filter(n => n.kind === 'steer').sort(steerOrder)) {
    const i = steerSlots.get(n.ver) || 0;
    n.steerIdx = i;
    steerSlots.set(n.ver, i + 1);
    steersInLayer.set(n.layer, (steersInLayer.get(n.layer) || 0) + 1);
  }
  const steerStackH = l => { const k = steersInLayer.get(l) || 0; return k ? (k - 1) * (MGT_STEER_H + 4) + MGT_STEER_H : 0; };

  if (isolating) {
    // Derive tile size from the widest kept band (the one with the most prompt squares after filtering).
    let maxBandW = 0;
    for (const arr of byLayer.values()) {
      const promptCount = arr.filter(n => n.kind !== 'version' && n.kind !== 'steer').length;
      maxBandW = Math.max(maxBandW, promptCount);
    }
    // The widest band with maxBandW prompts at MGT_NODE_W each, plus the version column, must fit the
    // same space the full map uses. Derive a tile size that fills the freed width.
    // Floor at MGT_IMG (never smaller than normal), ceiling at 3×MGT_IMG (contact sheet territory).
    const isoNodeW = maxBandW <= 1 ? MGT_IMG * 3
      : Math.max(MGT_IMG, Math.min(MGT_IMG * 3, Math.floor(MGT_IMG * (MGT_TOP + 1) / (maxBandW + 1))));
    const isoNodeFull = isoNodeW + (MGT_FRAME + MGT_BORDER) * 2;
    const isoNodeH = isoNodeFull + MGT_STRIP;

    // Build spacers: merge adjacent empty bands. A band is empty when it has no prompt/ghost/steer nodes.
    // Version nodes in collapsed bands are HIDDEN (they're scaffolding but drawing them in a 40px spacer
    // would just be clutter — the spacer label already says which versions are there).
    const allLayers = Array.from(byLayer.keys()).sort((a, b) => a - b);
    let spacerStart = null;
    let spacerStartVer = null;
    const layerY = new Map();   // layer → y position (undefined for collapsed layers)
    const collapsedLayers = new Set();
    let y = MGT_MARGIN;

    // Version nodes that are the structural PARENT of a kept node. Most already are in the strand, but a
    // descendant can be born under a version that isn't (a prompt that drew from the pin, say); without its
    // band that prompt would float with no edge into the spine.
    const keptParentVers = new Set();
    for (const e of edges) {
      if (e.kind === 'parent' && nodes.has(e.a) && nodes.get(e.a).kind === 'version') keptParentVers.add(e.a);
    }
    for (const l of allLayers) {
      const arr = byLayer.get(l);
      const verNode = arr.find(n => n.kind === 'version');
      // A band stays if it has any non-version node, OR its version is itself in the strand (an ancestor, a
      // descendant, or the pin), OR its version is the parent of a kept node. Otherwise it really does hold
      // nothing in this lineage, and says so.
      const hasContent = arr.some(n => n.kind !== 'version')
        || (verNode && (lineage.has(verNode.id) || keptParentVers.has(verNode.id)));

      if (!hasContent) {
        collapsedLayers.add(l);
        if (spacerStart == null) { spacerStart = l; spacerStartVer = verNode ? verNode.ver : l + 1; }
      } else {
        if (spacerStart != null) {
          const endVer = verNode ? verNode.ver - 1 : spacerStartVer;
          mgtSpacers.push({ fromVer: spacerStartVer, toVer: endVer, y });
          y += MGT_SPACER_H;
          spacerStart = null;
        }
        layerY.set(l, y);
        // A band is as tall as the tallest thing in it. Walking back through every earlier instruction
        // keeps a lot of bands that hold only a version square (and maybe its 🧲 nodes); sized for the big
        // isolate tiles, those would be mostly empty space.
        const bandH = Math.max(
          arr.some(n => n.kind !== 'version' && n.kind !== 'steer') ? isoNodeH : MGT_NODE_H,
          steerStackH(l));
        y += bandH + MGT_GAP_Y;
      }
    }
    // Trailing spacer
    if (spacerStart != null) {
      const lastVer = mgtVerTo;
      mgtSpacers.push({ fromVer: spacerStartVer, toVer: lastVer, y });
      y += MGT_SPACER_H;
    }

    // Remove version nodes that fall inside collapsed bands — they'd be invisible inside a spacer and
    // would create dangling edges. The spacer label tells you which versions are there.
    // Also remove steer nodes whose version was collapsed (they have nowhere to anchor).
    for (const [id, n] of Array.from(nodes.entries())) {
      if (n.kind === 'version' && collapsedLayers.has(n.layer)) nodes.delete(id);
      if (n.kind === 'steer' && collapsedLayers.has(n.layer)) nodes.delete(id);
    }
    // Re-filter edges now that some version/steer nodes are removed
    edges = edges.filter(e => nodes.has(e.a) && nodes.has(e.b));
    // Reconnect the spine across collapsed gaps. Without this, removing intermediate version nodes
    // breaks the v1→vN chain — the surviving version nodes would float disconnected. The new edges
    // jump over spacers, so the spine reads as one continuous line with gaps labelled by the spacers.
    const survivingVers = Array.from(nodes.values())
      .filter(n => n.kind === 'version').sort((a, b) => a.ver - b.ver);
    for (let i = 1; i < survivingVers.length; i++) {
      const already = edges.some(e => e.kind === 'spine' && e.a === survivingVers[i - 1].id && e.b === survivingVers[i].id);
      if (!already) edges.push({ a: survivingVers[i - 1].id, b: survivingVers[i].id, kind: 'spine' });
    }

    // Position nodes
    let maxX = 0, maxY = 0;
    for (const n of nodes.values()) {
      if (n.kind === 'steer') continue;  // positioned below relative to their version node
      const ny = layerY.get(n.layer);
      if (ny == null) continue;          // shouldn't happen after filtering, but guard
      n.x = MGT_MARGIN + (n.col > 0 ? steerColW : 0) + n.col * (isoNodeFull + MGT_GAP_X);
      n.y = ny;
      // Override dimensions for non-version nodes in isolate mode (version nodes keep standard size)
      if (n.kind !== 'version') { n.isoW = isoNodeFull; n.isoH = isoNodeH; n.isoImg = isoNodeW; }
      // No orbit badges while isolating: the strand's steers are on the canvas as nodes, and a badge would
      // also advertise steers from outside the strand.
      if (n.kind === 'version') n.orbit = null;
      maxX = Math.max(maxX, n.x + (n.isoW || MGT_NODE_W));
      maxY = Math.max(maxY, n.y + (n.isoH || MGT_NODE_H));
    }
    // Position steer nodes in the gutter relative to their version node
    ({ maxX, maxY } = mgtPositionSteers(nodes, { maxX, maxY }));
    for (const sp of mgtSpacers) maxY = Math.max(maxY, sp.y + MGT_SPACER_H);   // a trailing spacer must stay inside the scroll extent
    mgtContentW = maxX + MGT_MARGIN;
    mgtContentH = maxY + MGT_MARGIN;
  } else {
    // Normal full-map layout: standard tile size, and bands of one height except where a 🧲 gutter needs more —
    // a stack of three steers is taller than a band plus its gap, and would sit on the next version's own.
    let maxX = 0, maxY = 0;
    const layerY = [];
    for (let l = 0, y = MGT_MARGIN; l <= Math.max(0, ...byLayer.keys()); l++) {
      layerY[l] = y;
      y += Math.max(MGT_NODE_H, steerStackH(l)) + MGT_GAP_Y;
    }
    for (const n of nodes.values()) {
      if (n.kind === 'steer') continue;
      n.x = MGT_MARGIN + (n.col > 0 ? steerColW : 0) + n.col * (MGT_NODE_W + MGT_GAP_X);
      n.y = layerY[n.layer];
      if (n.kind === 'version') n.orbit = (mgtSteerMode === 'badge') ? mgtOrbitFor(n.ver) : null;
      maxX = Math.max(maxX, n.x + MGT_NODE_W); maxY = Math.max(maxY, n.y + MGT_NODE_H);
    }
    // Position steer nodes in the gutter
    if (mgtSteerMode === 'node') ({ maxX, maxY } = mgtPositionSteers(nodes, { maxX, maxY }));
    mgtContentW = maxX + MGT_MARGIN;
    mgtContentH = maxY + MGT_MARGIN;
  }

  // Which kinds of mark leave each square, for its strip glyph (mgtMarkGlyph). Read off the FINAL edge list
  // — after isolate has filtered it — so the glyph never claims a line that isn't on the canvas.
  for (const e of edges) {
    if (e.kind !== 'inf' && e.kind !== 'anti') continue;
    const n = nodes.get(e.a);
    if (!n) continue;
    if (e.kind === 'anti') n.markAnti = true; else n.markInf = true;
  }

  mgtById = nodes;
  mgtNodes = Array.from(nodes.values());
  mgtEdgeList = edges;
}

// --- the hover card (§7.1) ---

// Nodes carry no text at all, so this is the ONLY place a node can be identified. It is the same element
// the focused tree uses (pgtCardShow) with rows and an action row added, so the two surfaces can't drift.
function mgtShowCard(anchor, n) {
  const rows = [];
  const p = n.prompt;
  if (n.kind === 'version' && n.why) rows.push(['💭 Why', n.why]);
  if (p) {
    rows.push(['Rank', promptLikeStats(p)]);
    if (p.origin) rows.push(['Origin', p.origin]);
    if (p.influenceText) rows.push(['🧲 Steered by', p.influenceText + (p.influenceInherited ? ' (inherited)' : '')]);
    const marked = infVersionsForPrompt(p.id, false);
    if (marked.length) rows.push(['🔖 Influenced', marked.map(v => 'v' + v).join(', ')]);
    const antiMarked = infVersionsForPrompt(p.id, true);
    if (antiMarked.length) rows.push(['🚫 Anti-influence', antiMarked.map(v => 'v' + v).join(', ')]);
    if (n.outside) {
      // Name the kind of line that actually pulled it onto the canvas.
      const by = [n.markInf && '🔖', n.markAnti && '🚫'].filter(Boolean);
      rows.push(['Note', 'Born before the versions on screen — drawn because a ' + (by.length ? by.join(' and a ') : '🔖') + ' points at it.']);
    }
  }
  rows.push(['Images', n.tasks.length ? String(n.tasks.length) : 'none kept']);
  pgtCardShow(anchor, n.title, n.text, { rows, foot: mgtCardFoot(n) });
}

function mgtCardFoot(n) {
  return (box) => {
    const row = document.createElement('div');
    row.className = 'mgtCardAct';
    if (n.centerId != null) {
      const b = document.createElement('button');
      b.type = 'button'; b.className = 'pgtOpenBtn';
      b.textContent = '🌳 Lineage';
      b.title = 'Switch to the focused view, centred here';
      // Pins the node first and lets pgtSetMode do the carrying, rather than setting pgtCenterId here:
      // one path decides what a mode switch centres on, so a card opened while a DIFFERENT node is pinned
      // can't hand the switch one subject and the pin another.
      b.onclick = () => { pgtCardHide(); mgtSelect(n.id); pgtSetMode('focused'); };
      row.appendChild(b);
    }
    if (n.tasks.length) {
      const b = document.createElement('button');
      b.type = 'button'; b.className = 'pgtOpenBtn';
      b.textContent = n.tasks.length + (n.tasks.length === 1 ? ' image' : ' images');
      b.title = 'Open every image in this set as a gallery';
      b.onclick = () => { pgtCardHide(); galOpenSet(pgtGalleryItems(n.tasks), n.label); };
      row.appendChild(b);
    }
    box.appendChild(row);
  };
}

// No 🧲 steer field here, deliberately. One was built and removed: a steer is GLOBAL — one FIFO, one entry
// consumed per brainstorm batch, never attached to a prompt — so a steer control sitting on a particular
// node reads as "steer from here", which is a promise the queue cannot keep. Starting the field empty
// avoided saying anything false but still put a control that acts on the whole session inside a surface
// that is about one square. The sidebar is where steering belongs, and it is the only place it lives.
// This view is a data VIEW; it changes nothing about generation.

// --- highlight and selection (§7.2) ---

// Everything a highlight lights up. `key` is a node id, or 's:<text>' for a 🧲 orbit badge — at badge size
// every 🧲 looks identical, so lighting that steer's prompts is the only thing that tells one from another.
function mgtRelated(key) {
  const set = new Set();
  if (typeof key === 'string' && key.startsWith('s:')) {
    // The steer node itself (when steer-nodes are enabled)
    if (mgtById.has(key)) set.add(key);
    const text = pgtSteerText(key);
    for (const p of ((mgtSteerIdx && mgtSteerIdx.get(text)) || [])) {
      if (mgtById.has(String(p.id))) set.add(String(p.id));
    }
    for (const n of mgtNodes) {
      if (n.kind === 'version' && n.orbit && n.orbit.some(b => b.text === text)) set.add(n.id);
    }
    return set;
  }
  if (!mgtById.has(key)) return set;
  set.add(key);
  // EVERY edge kind, not just the soft ones. This used to walk 🔗 drew-from and 🔖 influence only, on the
  // reasoning that the spine and parent edges are always drawn so you can already see them — but dimming
  // fades those to 10%, so highlighting a square actively HID the instruction it was born under while
  // lighting up its steers. The structural answer to "where does this square sit" is the main thing a
  // highlight is asked for; it cannot be the one thing the highlight removes.
  for (const e of mgtEdgeList) {
    if (e.a === key) set.add(e.b);
    if (e.b === key) set.add(e.a);
  }
  return set;
}

// What a PIN lights: the pinned square's whole lineage — everything it came from, back to v1, and everything
// that came from it — by the same walk isolate uses to choose its strand, run on what is drawn. So the two
// views agree, and isolate differs only in hiding the rest (and in drawing lineage squares the full map
// leaves out). Lighting just the neighbourhood, as a hover does, faded every step past the first and made the
// lineage look as if it stopped one instruction up.
function mgtPinLit(key) {
  const set = mgtComputeLineage(key, mgtById, mgtEdgeList);
  // A 🧲 pinned as a badge also lights the versions it orbits, as its hover does — a steer whose prompts
  // didn't make the map would otherwise light nothing at all.
  if (pgtIsSteer(key)) for (const id of mgtRelated(key)) set.add(id);
  return set;
}

// Selection wins over hover outright. Three things dim this canvas and all of them vanish the instant the
// pointer moves, which makes comparison impossible: you hover a 🧲 badge, four prompts light up across the
// canvas, you move to look at one closely, and the highlight is gone before you arrive. So a click pins it,
// and while something is pinned, brushing past other nodes does not steal it.
function mgtApplyHighlight() {
  const layerEl = mgtLayerEl();
  if (!layerEl) return;
  const key = mgtSel || mgtHover;
  // A pin lights the lineage; a hover lights only what the square is directly joined to — a lineage on hover
  // would light the spine back to v1 every time the pointer crossed a square.
  const lit = mgtSel ? mgtPinLit(mgtSel) : (mgtHover ? mgtRelated(mgtHover) : null);
  // Hover LIGHTS, only a pin DIMS. Now that mgtRelated counts parent and spine edges, virtually every square
  // has a neighbourhood, so dimming on hover would fade the whole canvas to 20% every time the pointer
  // crossed a square — on a grid this tight, constantly. Lighting is enough to answer "what is this joined
  // to" in passing; blanking everything else is the deliberate, comparison-grade gesture, so it waits for
  // the deliberate act. It also STAYS once the pointer leaves, which is the point of pinning.
  const dim = !!mgtSel && !!lit && lit.size > (lit.has(key) ? 1 : 0);
  layerEl.classList.toggle('mgtDimming', dim);
  for (const el of layerEl.querySelectorAll('.mgtNode')) {
    const id = el.dataset.node;
    el.classList.toggle('mgtLit', !!lit && lit.has(id));
    el.classList.toggle('mgtSelected', id === mgtSel);
  }
  // A pinned 🧲 needs its own mark: the pin ring above only ever lands on a node, so pinning a badge left
  // every badge on the canvas looking identical — including the one you had just pinned.
  for (const el of layerEl.querySelectorAll('.mgtBadge[data-steer]')) {
    el.classList.toggle('mgtBadgeSel', el.dataset.steer === mgtSel);
  }
  const svg = mgtSvgEl();
  if (svg) for (const path of svg.querySelectorAll('path')) {
    path.classList.toggle('mgtEdgeLit', !!lit && lit.has(path.dataset.a) && lit.has(path.dataset.b));
  }
}

function mgtSetHover(key) { if (mgtHover === key) return; mgtHover = key; if (!mgtSel) mgtApplyHighlight(); }
function mgtSelect(key) {
  mgtSel = key;
  // If the pin is cleared while isolate is active, auto-exit isolate — a strand with no subject makes
  // no sense, and Esc peels isolate before pin anyway, so this only fires on click-to-clear.
  if (!key && mgtIsolate) {
    mgtIsolate = false;
    mgtRender({ keepScroll: true });
    return;
  }
  mgtApplyHighlight();
  mgtUpdateTools();
}

const MGT_STEER_SEG_TITLE = 'How to draw steers: orbit badges on the spine, or half-sized nodes with visible connections';

// The session toolbar and legend, from state: the ⬡ button, the 🧲 Badges/Nodes control, and the legend keys
// whose truth depends on isolate.
function mgtUpdateTools() {
  const btn = document.getElementById('mgtIsolate');
  if (btn) {
    btn.disabled = !mgtSel;
    btn.classList.toggle('mgtIsoActive', !!mgtIsolate);
  }
  // Until something is pinned, ⬡ can't do anything — say how to pin, right beside it.
  const pinHint = document.getElementById('mgtPinHint');
  if (pinHint) pinHint.style.display = mgtSel ? 'none' : '';
  // Isolate always draws steers as nodes (mgtBuild), so the control shows Nodes and is locked — and says why
  // on the control itself. mgtSteerMode keeps the user's own choice for when isolate is turned off. Locked
  // with aria-disabled rather than `disabled`, because browsers disagree on showing a tooltip over a disabled
  // button, and that tooltip is the only explanation.
  const locked = !!(mgtIsolate && mgtSel);
  const shown = locked ? 'node' : mgtSteerMode;
  const seg = document.getElementById('mgtSteerSeg');
  if (seg) {
    seg.classList.toggle('mgtSegLocked', locked);
    seg.title = locked
      ? '⬡ Isolate always draws steers as nodes, so you can see which prompt each one shaped. Turn Isolate off to choose.'
      : MGT_STEER_SEG_TITLE;
  }
  for (const [id, mode] of [['mgtSteerBadge', 'badge'], ['mgtSteerNode', 'node']]) {
    const b = document.getElementById(id);
    if (!b) continue;
    b.classList.toggle('pgtSegOn', shown === mode);
    b.setAttribute('aria-pressed', String(shown === mode));
    b.setAttribute('aria-disabled', String(locked));
  }
  const keySteer = document.getElementById('mgtKeySteer');
  if (keySteer) keySteer.style.display = shown === 'node' ? '' : 'none';
  // 🔗 lines are drawn all the time while isolating, so the full map's "(only while highlighted)" would be false.
  const drewWhen = document.getElementById('mgtKeyDrewWhen');
  if (drewWhen) drewWhen.style.display = locked ? 'none' : '';
}

// --- node DOM ---

// --- steer node DOM ---
// Half-sized (62×70), shows the steer TEXT instead of images. The lines to its children show what it
// produced visually; the node itself is the question "what was the steer?" and the answer is text.
function mgtSteerNodeEl(n) {
  const el = document.createElement('div');
  el.className = 'mgtNode mgtNode-steer mgtSteer-' + n.tier;
  el.dataset.node = n.id;
  el.style.left = n.x + 'px';
  el.style.top = n.y + 'px';
  const body = document.createElement('div');
  body.className = 'mgtSteerBody';
  body.textContent = n.text;
  el.appendChild(body);
  el.addEventListener('mouseenter', () => {
    mgtSetHover(n.id);
    pgtCardShowAfter(MGT_CARD_DELAY, () => pgtCardShow(el, n.title, n.text));
  });
  el.addEventListener('mouseleave', () => { mgtSetHover(null); pgtCardCancelOpen(); pgtCardScheduleClose(); });
  el.addEventListener('click', (e) => {
    e.stopPropagation();
    if (mgtDragged) return;
    mgtSelect(mgtSel === n.id ? null : n.id);
  });
  return el;
}

// --- spacer DOM ---
// A thin labelled bar replacing a run of empty bands in isolate mode.
function mgtSpacerEl(sp) {
  const el = document.createElement('div');
  el.className = 'mgtSpacer';
  el.style.left = MGT_MARGIN + 'px';
  el.style.top = sp.y + 'px';
  el.style.width = Math.max(200, mgtContentW - MGT_MARGIN * 2) + 'px';
  el.textContent = sp.fromVer === sp.toVer
    ? ('v' + sp.fromVer + ' · nothing in this lineage')
    : ('v' + sp.fromVer + '–v' + sp.toVer + ' · nothing in this lineage');
  return el;
}

// A non-version square's strip glyph. A ghost IS one mark, so it shows that mark's kind. A prompt square is
// never tinted by kind — one prompt can be a 🔖 for v3 and a 🚫 for v5 — so instead its glyph names every
// kind of mark line leaving it (markInf / markAnti, set at the end of mgtBuild), and falls back to ▪ when
// none do. That's what lets you spot the marked squares without tracing lines back from the spine.
function mgtMarkGlyph(n) {
  if (n.kind === 'ghost') return n.anti ? '🚫' : '🔖';
  return ((n.markInf ? '🔖' : '') + (n.markAnti ? '🚫' : '')) || '▪';
}

function mgtNodeEl(n, obs) {
  // Steer nodes use their own DOM builder
  if (n.kind === 'steer') return mgtSteerNodeEl(n);

  const el = document.createElement('div');
  el.className = 'mgtNode mgtNode-' + n.kind + (n.outside ? ' mgtOutside' : '') + (n.kind === 'ghost' && n.anti ? ' mgtGhostAnti' : '');
  el.dataset.node = n.id;
  el.style.left = n.x + 'px';
  el.style.top = n.y + 'px';

  // Isolate mode: prompt nodes can be larger than standard, with derived dimensions on the node object.
  const nodeW = n.isoW || MGT_NODE_W;
  const nodeH = n.isoH || MGT_NODE_H;
  const imgSize = n.isoImg || MGT_IMG;
  if (n.isoW) { el.style.width = nodeW + 'px'; el.style.height = nodeH + 'px'; }

  const imgs = document.createElement('div');
  imgs.className = 'mgtImgs';
  if (n.isoImg) { imgs.style.width = imgSize + 'px'; imgs.style.height = imgSize + 'px'; }
  // Below 75% a 26px quadrant is visual noise that still costs four blob loads, so a multi-image node
  // collapses to its single best image. That threshold is exactly why zoom is discrete: continuous zoom
  // would need the same threshold and would thrash across it while you dragged.
  //
  // In isolate mode, when tiles are large enough (≥ 3× base = 336px), upgrade from 2×2 to 3×3: each cell
  // in a 3×3 at 336px is 112px — the same as a single full image at standard zoom. That is the contact
  // sheet the spec describes: a version square turns into a real review of what that instruction drew.
  const maxSlots = mgtCollapsed ? 1 : (imgSize >= MGT_CONTACT_THRESHOLD ? MGT_TOP_ISOLATE : MGT_TOP);
  const shown = pgtGalleryItems(n.tasks.slice(0, maxSlots));
  if (!shown.length) {
    // §1.2: an empty frame at full size, never an omitted node. "Something was here and it mattered" is
    // true; "nothing was here" is not.
    imgs.classList.add('mgtNoImg');
    imgs.textContent = n.kind === 'version' ? '▦' : (n.kind === 'ghost' ? mgtMarkGlyph(n) : '▪');
  } else {
    const gridClass = shown.length <= 1 ? 'mgtOne' : (shown.length <= 4 ? 'mgtQuad' : 'mgtQuad9');
    imgs.classList.add(gridClass);
    shown.forEach((it, i) => {
      const cell = document.createElement('div');
      cell.className = 'mgtCell';
      cell._galItem = it;                    // the only thing galCellObserver reads off a cell
      const ph = document.createElement('div');
      ph.className = 'galCellPlaceholder';
      cell.appendChild(ph);
      // Clicking an image is NOT overloaded — it opens the lightbox and never selects. On a 2×2 node,
      // clicking the top-right quadrant opens that image.
      cell.addEventListener('click', (e) => {
        e.stopPropagation();
        if (mgtDragged || !n.tasks.length) return;
        // The card sits BELOW the lightbox, so leaving it up doesn't obscure anything — it strands it:
        // the pointer ends up on an overlay instead of the node, no mouseleave ever fires, and the card
        // is still hanging there when the lightbox closes.
        pgtCardHide();
        pgtOpenLightbox(n.tasks, Math.min(i, n.tasks.length - 1));
      });
      imgs.appendChild(cell);
      obs.observe(cell);
    });
  }
  el.appendChild(imgs);

  // The chrome strip. It exists for two reasons at once: it is somewhere to put the "+N", and it is the
  // non-image surface §7.2's frame-click needs — a node that is entirely image has no frame to click.
  const strip = document.createElement('div');
  strip.className = 'mgtStrip';
  const glyph = document.createElement('span');
  glyph.className = 'mgtGlyph';
  // The one place a number is drawn on the canvas, and only on the spine. Without it you cannot tell which
  // instruction a row belongs to, which is the question the spine exists to answer.
  glyph.textContent = n.kind === 'version' ? ('▦ v' + n.ver) : mgtMarkGlyph(n);
  strip.appendChild(glyph);
  if (n.tasks.length > shown.length) {
    // Nothing is ever dropped, only not drawn: every undrawn image stays one click away.
    const more = document.createElement('button');
    more.type = 'button';
    more.className = 'mgtMore';
    more.textContent = '+' + (n.tasks.length - shown.length);
    more.title = 'See all ' + n.tasks.length + ' images in a gallery';
    more.addEventListener('click', (e) => {
      e.stopPropagation();
      if (mgtDragged) return;
      pgtCardHide();                 // same reason as the cell click: the gallery covers it, then leaves it
      galOpenSet(pgtGalleryItems(n.tasks), n.label);
    });
    strip.appendChild(more);
  }
  el.appendChild(strip);

  if (pgtHighlightTaskId && n.tasks.some(t => t.id === pgtHighlightTaskId)) el.classList.add('mgtRing');

  if (n.kind === 'version' && n.orbit && n.orbit.length) mgtAddOrbit(el, n);

  // The highlight is immediate — it's cheap, it's what you scan with, and it never covers anything. Only the
  // card waits, because that's the thing that lands on top of the squares around it.
  el.addEventListener('mouseenter', () => {
    mgtSetHover(n.id);
    pgtCardShowAfter(MGT_CARD_DELAY, () => mgtShowCard(el, n));
  });
  el.addEventListener('mouseleave', () => { mgtSetHover(null); pgtCardCancelOpen(); pgtCardScheduleClose(); });
  el.addEventListener('click', () => {
    if (mgtDragged) return;
    mgtSelect(mgtSel === n.id ? null : n.id);
  });
  return el;
}

function mgtAddOrbit(el, n) {
  const wrap = document.createElement('div');
  wrap.className = 'mgtOrbit';
  const shown = n.orbit.slice(0, MGT_ORBIT_CAP);
  shown.forEach(b => {
    const badge = document.createElement('span');
    // The tier is carried by the RING, not by size: 14px against 20px is unreadable without two badges
    // side by side, and usually there is only one. A ring is categorical — legible in isolation.
    badge.className = 'mgtBadge mgtBadge-' + b.tier;
    badge.dataset.steer = pgtSteerId(b.text);   // what mgtApplyHighlight marks the pinned one by
    badge.textContent = '🧲';       // no image in a badge: at ~16px it is unreadable and costs a blob load
    badge.addEventListener('mouseenter', () => {
      mgtSetHover(pgtSteerId(b.text));
      pgtCardShowAfter(MGT_CARD_DELAY, () => pgtCardShow(badge, b.tier === 'strong'
        ? '🧲 Steer · later marked as a 🔖 influence'
        : '🧲 Steer · its prompts were upvoted', b.text));
    });
    // Back onto the node it orbits, not into nothing — leaving the node entirely fires this and then the
    // node's own mouseleave, which schedules the close a moment later.
    badge.addEventListener('mouseleave', () => {
      mgtSetHover(n.id);
      pgtCardShowAfter(MGT_CARD_DELAY, () => mgtShowCard(el, n));
    });
    // Pins what the HOVER lit, not the node underneath. Without this the click bubbles to the node and you
    // pin the instruction you were standing on instead of the steer you were reading — the one gesture on
    // this canvas where what you see and what you'd get would disagree.
    badge.addEventListener('click', (e) => {
      e.stopPropagation();
      if (mgtDragged) return;
      const key = pgtSteerId(b.text);
      mgtSelect(mgtSel === key ? null : key);
    });
    wrap.appendChild(badge);
  });
  if (n.orbit.length > shown.length) {
    const more = document.createElement('span');
    more.className = 'mgtBadge mgtBadgeMore';
    more.textContent = '+' + (n.orbit.length - shown.length);
    more.title = n.orbit.slice(MGT_ORBIT_CAP).map(b => '🧲 ' + b.text).join('\n');
    // Several steers at once, so there is nothing single to pin — but it must not pin the node either.
    more.addEventListener('click', (e) => e.stopPropagation());
    wrap.appendChild(more);
  }
  el.appendChild(wrap);
}

// --- edges ---

// Spine and parent edges always descend exactly one layer, so bottom-centre → top-centre is right for them.
// 🔖 influence edges routinely do NOT descend, and that is the normal case rather than an exotic one: an
// Apply commits the marks made under the version you were on to the version it CREATES, so a prompt born
// under v6 points at v7 — which sits on the same row, in the spine column immediately to its left — and a
// kept prompt has its own version stamp bumped forward, which can leave it pointing UP a row. Drawn
// bottom-to-top those become tall S-loops that dive out of the row, sweep sideways behind every node in
// between, and climb back in. So anything that isn't a clean descent leaves and enters through the SIDES
// instead: a same-row edge is then a straight horizontal line and a rising one a flat side arc, and neither
// leaves the band it belongs to.
// Node dimensions, accounting for steer nodes (half-sized) and isolate-mode larger tiles.
function mgtNodeDims(n) {
  if (n.kind === 'steer') return [MGT_STEER_W, MGT_STEER_H];
  return [n.isoW || MGT_NODE_W, n.isoH || MGT_NODE_H];
}

function mgtEdgePath(a, b) {
  const [aw, ah] = mgtNodeDims(a);
  const [bw, bh] = mgtNodeDims(b);
  if (b.y >= a.y + ah) {
    const x1 = a.x + aw / 2, y1 = a.y + ah;
    const x2 = b.x + bw / 2, y2 = b.y;
    const bend = Math.max(24, (y2 - y1) / 2);
    return `M${x1},${y1} C${x1},${y1 + bend} ${x2},${y2 - bend} ${x2},${y2}`;
  }
  // Facing edges, so the curve occupies the gap between the two boxes rather than crossing either of them.
  const leftward = b.x < a.x;
  const x1 = leftward ? a.x : a.x + aw;
  const x2 = leftward ? b.x + bw : b.x;
  const y1 = a.y + ah / 2, y2 = b.y + bh / 2;
  const bend = (leftward ? -1 : 1) * Math.max(MGT_GAP_X, Math.abs(x2 - x1) / 2);
  return `M${x1},${y1} C${x1 + bend},${y1} ${x2 - bend},${y2} ${x2},${y2}`;
}

function mgtDrawEdges() {
  const svg = mgtSvgEl();
  if (!svg) return;
  svg.setAttribute('width', String(mgtContentW));
  svg.setAttribute('height', String(mgtContentH));
  svg.setAttribute('viewBox', `0 0 ${mgtContentW} ${mgtContentH}`);
  const NS = 'http://www.w3.org/2000/svg';
  const frag = document.createDocumentFragment();
  for (const e of mgtEdgeList) {
    const a = mgtById.get(e.a), b = mgtById.get(e.b);
    if (!a || !b) continue;
    const path = document.createElementNS(NS, 'path');
    path.setAttribute('d', mgtEdgePath(a, b));
    path.setAttribute('class', 'mgtEdge mgtEdge-' + e.kind);
    path.dataset.a = e.a;
    path.dataset.b = e.b;
    frag.appendChild(path);
  }
  svg.appendChild(frag);
}

// --- view: zoom, pan, scroll ---

function mgtApplyView() {
  const layerEl = mgtLayerEl(), sizer = document.getElementById('mgtSizer');
  if (!layerEl || !sizer) return;
  const z = mgtZoom();
  layerEl.style.width = mgtContentW + 'px';
  layerEl.style.height = mgtContentH + 'px';
  layerEl.style.transform = 'scale(' + z + ')';
  // The sizer is what the scrollbars measure. Without it the scaled layer still reports its UNSCALED box
  // to the scroll container and the bars lie in both directions.
  sizer.style.width = Math.round(mgtContentW * z) + 'px';
  sizer.style.height = Math.round(mgtContentH * z) + 'px';
  const lbl = document.getElementById('mgtZoomLbl');
  if (lbl) lbl.textContent = Math.round(z * 100) + '%';
  document.getElementById('mgtZoomIn').disabled = mgtZoomIdx >= MGT_ZOOMS.length - 1;
  document.getElementById('mgtZoomOut').disabled = mgtZoomIdx <= 0;
}

function mgtSetZoom(i) {
  i = Math.max(0, Math.min(MGT_ZOOMS.length - 1, i));
  if (i === mgtZoomIdx) return;
  const scroll = mgtScrollEl();
  const oldZ = mgtZoom();
  // Zoom about the middle of what you're looking at, not about the origin — otherwise every step throws
  // away your place on the map.
  const cx = (scroll.scrollLeft + scroll.clientWidth / 2) / oldZ;
  const cy = (scroll.scrollTop + scroll.clientHeight / 2) / oldZ;
  mgtZoomIdx = i;
  pgtCardHide();
  const collapse = mgtZoom() < MGT_COLLAPSE_BELOW;
  if (collapse !== mgtCollapsed) { mgtCollapsed = collapse; mgtRender({ keepScroll: true }); }
  else mgtApplyView();
  const z = mgtZoom();
  scroll.scrollLeft = Math.max(0, cx * z - scroll.clientWidth / 2);
  scroll.scrollTop = Math.max(0, cy * z - scroll.clientHeight / 2);
}

function mgtScrollToNode(id) {
  const n = mgtById.get(id);
  const scroll = mgtScrollEl();
  if (!n || !scroll) return;
  const z = mgtZoom();
  const [w, h] = mgtNodeDims(n);
  scroll.scrollLeft = Math.max(0, (n.x + w / 2) * z - scroll.clientWidth / 2);
  scroll.scrollTop = Math.max(0, (n.y + h / 2) * z - scroll.clientHeight / 2);
}

// Drag-to-pan by setting scrollLeft/Top on a NATIVE scroll container, rather than by reimplementing pan as
// a transform. Trackpad, momentum, touch and keyboard all come free that way, and IntersectionObserver —
// which is the entire image-recycling story here — gets the real scroll root it wants.
function mgtInitPan() {
  const scroll = mgtScrollEl();
  if (!scroll) return;
  let active = false, sx = 0, sy = 0, sl = 0, stp = 0, pid = null;
  scroll.addEventListener('pointerdown', (e) => {
    if (e.button !== 0 || e.target.closest('button, input')) return;
    active = true; mgtDragged = false; pid = e.pointerId;
    sx = e.clientX; sy = e.clientY; sl = scroll.scrollLeft; stp = scroll.scrollTop;
  });
  scroll.addEventListener('pointermove', (e) => {
    if (!active || e.pointerId !== pid) return;
    const dx = e.clientX - sx, dy = e.clientY - sy;
    // A few pixels of slop, so a click with a shaky hand is still a click and not a one-pixel pan that
    // eats it.
    if (!mgtDragged && Math.abs(dx) + Math.abs(dy) < 5) return;
    if (!mgtDragged) {
      mgtDragged = true;
      scroll.classList.add('mgtPanning');
      pgtCardHide();
      try { scroll.setPointerCapture(pid); } catch (err) {}
    }
    scroll.scrollLeft = sl - dx;
    scroll.scrollTop = stp - dy;
  });
  const end = () => {
    if (!active) return;
    active = false;
    scroll.classList.remove('mgtPanning');
    // Cleared on the next macrotask, i.e. AFTER the click this pointerup is about to generate — which is
    // how a drag that ends over a node avoids selecting it.
    setTimeout(() => { mgtDragged = false; }, 0);
  };
  scroll.addEventListener('pointerup', end);
  scroll.addEventListener('pointercancel', end);
  // Clicking bare canvas clears the pinned selection — the same "click again to let go" the node itself has.
  scroll.addEventListener('click', (e) => {
    if (mgtDragged || e.target.closest('.mgtNode') || e.target.closest('button')) return;
    // Also the dismissal for a card pinned open by ▾ Show all, which by design no longer closes when the
    // pointer wanders off it.
    pgtCardHide();
    if (mgtSel) mgtSelect(null);
  });
  scroll.addEventListener('scroll', pgtCardHide, { passive: true });
}

// --- render ---

function mgtTeardown() {
  const layerEl = mgtLayerEl();
  if (!layerEl) return;
  galTeardown(layerEl);          // disconnects the observer and revokes every URL still held
  for (const el of Array.from(layerEl.querySelectorAll('.mgtNode, .mgtSpacer'))) el.remove();
  const svg = mgtSvgEl();
  if (svg) svg.innerHTML = '';
}

/* opts:
     reset       recompute the version range from whatever the tree was opened on
     keepScroll  don't move the viewport (a zoom step or a manual refresh, not a new subject) */
function mgtRender(opts) {
  opts = opts || {};
  const scroll = mgtScrollEl();
  if (!scroll) return;
  pgtCardHide();
  mgtTeardown();
  if (opts.reset) mgtResetWindow();
  mgtCollapsed = mgtZoom() < MGT_COLLAPSE_BELOW;
  mgtBuild();

  // No "nothing to draw" state, deliberately: mgtBuild always emits a node per version in the window, so
  // even a session that kept no images at all still draws its instruction spine as empty frames — which
  // is the honest picture, and a message that can never appear is worse than no message.
  const layerEl = mgtLayerEl();
  mgtDrawEdges();
  const obs = galCellObserver(layerEl, { root: scroll, rootMargin: '300px' });
  const frag = document.createDocumentFragment();
  for (const n of mgtNodes) frag.appendChild(mgtNodeEl(n, obs));
  // Spacers: thin labelled bars for collapsed empty bands in isolate mode
  for (const sp of mgtSpacers) frag.appendChild(mgtSpacerEl(sp));
  layerEl.appendChild(frag);
  // Toggle the isolate-active class so CSS can show 🔗 drew-from edges by default
  layerEl.classList.toggle('mgtIsolateActive', !!mgtIsolate);
  mgtApplyView();

  // A selection made before a refresh survives it, as long as it still lights something up — §4's ordering
  // is deterministic, so a refresh appends rather than shuffles, and losing your pin to an autosave-driven
  // redraw would defeat the point of pinning. Asked through mgtRelated rather than mgtById because a pinned
  // 🧲 badge's key is not a node id and a membership test would have dropped every steer pin on sight.
  if (mgtSel && !mgtRelated(mgtSel).size) {
    mgtSel = null;
    // Pin is gone — clear isolate state so the button doesn't stay active-but-disabled
    if (mgtIsolate) mgtIsolate = false;
  }
  mgtHover = null;
  mgtApplyHighlight();
  mgtUpdateTools();

  if (!opts.keepScroll) mgtScrollToNode(mgtEntryNodeId());
  mgtRenderCrumb();
}

// The node you arrived at: the image's prompt if you came from an image's ❓, otherwise whatever the
// focused view would have centred on.
function mgtEntryNodeId() {
  if (pgtCenterId != null) {
    const key = pgtIsVer(pgtCenterId) ? pgtCenterId : String(pgtCenterId);
    if (mgtById.has(key)) return key;
  }
  return pgtVerId(Math.min(mgtVerTo, Math.max(mgtVerFrom, st.instVersion || 1)));
}

function mgtRenderCrumb() {
  const bc = document.getElementById('pgtCrumb');
  if (!bc) return;
  const span = mgtVerFrom === mgtVerTo ? ('v' + mgtVerFrom) : ('v' + mgtVerFrom + '–v' + mgtVerTo);
  const iso = mgtIsolate ? ' · ⬡ isolating' : '';
  bc.textContent = `· ${span} · ${mgtNodes.length} nodes${iso}`;
}

// --- mode switching (§8) ---

function pgtApplyMode(opts) {
  opts = opts || {};
  const focused = pgtMode === 'focused';
  const show = (id, on, disp) => { const el = document.getElementById(id); if (el) el.style.display = on ? (disp || '') : 'none'; };
  show('pgtCanvas', focused);
  show('mgtScroll', !focused);
  show('mgtTools', !focused, 'flex');
  show('pgtHint', focused);
  show('mgtHint', !focused);
  const segF = document.getElementById('pgtModeFocused'), segS = document.getElementById('pgtModeSession');
  segF.classList.toggle('pgtSegOn', focused);
  segS.classList.toggle('pgtSegOn', !focused);
  segF.setAttribute('aria-pressed', String(focused));
  segS.setAttribute('aria-pressed', String(!focused));
  pgtCardHide();
  if (focused) {
    mgtTeardown();     // stop the mega-tree holding decoded images for a canvas nobody is looking at
    pgtRender();
    pgtScrollToAnchor();
  } else {
    // ← Back is a focused-mode control: the mega-tree has no re-centre, so it has no back stack.
    const back = document.getElementById('pgtBack');
    if (back) back.style.display = 'none';
    // Mirror of the mgtTeardown() in the focused branch: drop the focused canvas's decoded images while
    // the map is up. Nothing is lost — pgtRender rebuilds the focused view from scratch on the way back.
    pgtRevokeUrls();
    const pc = document.getElementById('pgtCanvas');
    if (pc) pc.innerHTML = '';
    mgtRender({ reset: opts.reset });
  }
}

// Switching keeps your SUBJECT rather than resetting it — the two views are the same data at two scales,
// so flipping between them should feel like zooming out, not like starting again.
function pgtSetMode(m) {
  if (m === pgtMode) return;
  if (m === 'focused') {
    const key = mgtSel || mgtHover;
    // A pinned 🧲 is carried across as itself: the focused view centres on a steer perfectly well (pgtIsSteer
    // has a whole branch for it), but a steer key is not a node id, so looking it up in mgtById found
    // nothing and the switch silently kept whatever the PREVIOUS subject had been.
    const center = pgtIsSteer(key) ? key : ((key && mgtById.get(key)) || {}).centerId;
    if (center != null) { pgtCenterId = center; pgtStack = []; pgtExpanded = new Set(); }
  }
  pgtMode = m;
  logEvent('tree_mode', { mode: m });
  pgtApplyMode({ reset: m === 'session' });
  // Carry the focused view's subject into the session map as a pin, mirroring the reverse
  // direction (session→focused carries mgtSel→pgtCenterId). Without this the isolate button
  // is greyed out until you manually click a node, even though you arrived with a clear subject.
  // Resolve pgtCenterId directly rather than via mgtEntryNodeId(): its newest-version fallback would
  // pin a node that was never the subject (e.g. a steer subject drawn in badge mode resolves to no node).
  if (m === 'session' && !mgtSel && pgtCenterId != null) {
    const key = pgtIsVer(pgtCenterId) ? pgtCenterId : String(pgtCenterId);
    if (mgtById.has(key)) mgtSelect(key);
  }
}

document.getElementById('pgtModeFocused').onclick = () => pgtSetMode('focused');
document.getElementById('pgtModeSession').onclick = () => pgtSetMode('session');
document.getElementById('mgtZoomIn').onclick = () => mgtSetZoom(mgtZoomIdx + 1);
document.getElementById('mgtZoomOut').onclick = () => mgtSetZoom(mgtZoomIdx - 1);
// Snapshot-on-open, like the focused view — but a whole-session map is something you leave open while
// images keep landing, so there is a manual redraw. Safe precisely because §4's ordering is deterministic:
// new nodes append to the end of their layer rather than reshuffling the ones you were reading.
document.getElementById('mgtRefresh').onclick = () => mgtRender({ keepScroll: true });

// ⬡ Isolate: toggle the isolate sub-mode on/off. Only clickable when a pin exists.
document.getElementById('mgtIsolate').onclick = () => {
  if (!mgtSel) return;
  mgtIsolate = !mgtIsolate;
  mgtRender({ keepScroll: true });
  // Both ways, land on the pin: it's what you were reading, and mgtBuild draws it on the full map too even
  // when the map never earned it. A steer pinned in Badges mode has no node there — fall back to the entry.
  mgtScrollToNode(mgtSel && mgtById.has(mgtSel) ? mgtSel : mgtEntryNodeId());
};

// 🧲 steer toggle: switch between orbit badges and half-sized gutter nodes.
function mgtSetSteerMode(mode) {
  if (mode === mgtSteerMode || mgtIsolate) return;   // locked to nodes while isolating — see mgtUpdateTools
  mgtSteerMode = mode;
  mgtRender({ keepScroll: true });                    // ends in mgtUpdateTools: the control and legend follow
}
document.getElementById('mgtSteerBadge').onclick = () => mgtSetSteerMode('badge');
document.getElementById('mgtSteerNode').onclick = () => mgtSetSteerMode('node');

mgtInitPan();

// --- Escape closes the new surfaces (topmost first) ---
document.addEventListener('keydown', (e) => {
  if (e.key !== 'Escape') return;
  // The ❓ image-details panel is genuinely topmost (z-index 10000) and, since ▾ Show all pins it open,
  // it is the one floating surface that can outlive the pointer — so it takes the first press. Before
  // pinning it always closed itself and needed no key.
  if (_statsMode === 'tile') { hideStats(); return; }
  const pubGallery = document.getElementById('publicGalleryOverlay');   // z-index 999
  if (pubGallery) { pubGallery.remove(); return; }
  if (pauseMenu.style.display === 'block') { setPauseMenuOpen(false); return; }
  if (miscPopover.style.display === 'block') { setMiscOpen(false); return; }
  if (strategyPopover.style.display === 'block') { setStrategyOpen(false); return; }
  if (settingsModal.style.display === 'flex') { closeSettings(); return; }
  if (promptsModal.style.display === 'flex') { closePromptsModal(); return; }
  if (logModal.style.display === 'flex') { closeLogModal(); return; }
  if (commentsModal.style.display === 'flex') { closeComments(); return; }
  // Peel one layer per press, topmost first: gallery (340) → influences (330) → export / tree (320).
  // The gallery genuinely does stack over the tree — it's opened from it — so its order matters rather
  // than merely being defensive.
  if (galIsOpen()) { galClose(); return; }
  if (infIsOpen()) { infClose(); return; }   // writes the instruction back to the composer on its way out
  if (exOverlay.classList.contains('exOpen')) { exClose(); return; }
  const pgt = document.getElementById('pgtOverlay');   // same layer as #exOverlay; lightbox (z-index 400) sits above and eats the first Esc itself
  if (pgt && pgt.classList.contains('pgtOpen')) {
    // Peel order inside the session view: isolate → pin → close. Each is a layer that dims or narrows
    // the canvas, and each press peels the topmost one. The focused view has no isolate layer.
    if (pgtMode === 'session' && mgtIsolate) {
      pgtCardHide();
      mgtIsolate = false;
      mgtRender({ keepScroll: true });
      return;
    }
    // The pinned square dims the rest of the canvas, so clearing it is what Esc means while one is
    // pinned. The hover card comes off with it — a card pinned open by ▾ Show all is above the canvas
    // and stays put on its own, so leaving it hanging over an un-dimmed tree would peel out of order.
    if (pgtMode === 'session' && mgtSel) { pgtCardHide(); mgtSelect(null); return; }
    pgtClose(); return;
  }
  if (helpModal.style.display === 'flex') { closeHelp(); return; }
});

/* ===================== Boot ===================== */

document.addEventListener('DOMContentLoaded', ()=>{
  if (st.instruction) instInput.value = st.instruction;
  showReadyState();
  updateInfluencesBtn();   // cold open: before Start the button is present but greyed out
  setSaved();
  setupSentinelObserver();
  setupCardObserver();
  
  showSavedBtn.onclick = ()=>{ const g = ensureGallery(); if (g) g.show(); };

  // Centred on the CURRENT instruction, which is the one you're working under — every other way into
  // the tree starts from an image's ❓ and centres on that prompt instead.
  // The pre-Start check is here because .tbtn.disabled is only a look (see updateToolbarState) — and
  // before Start there is no st.instHistory[1], so the tree would open on "(instruction text not recorded)".
  if (showTreeBtn) showTreeBtn.onclick = () => { if (st.started) pgtOpen(pgtVerId(st.instVersion || 1)); };

  document.getElementById('showGalleryBtn').onclick = () => {
    const bg = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? '#242424' : 'white';
    const url = `https://image-generation.perchance.org/gallery?channel=${window.generatorName}&subChannel=public&sort=trending&timeRange=1-month&contentFilter=pg13`;
    const overlay = document.createElement('div');
    overlay.id = 'publicGalleryOverlay';   // so the global Escape handler can find and close it
    overlay.style.cssText = 'backdrop-filter:brightness(0.3);position:fixed;top:0;left:0;right:0;bottom:0;z-index:999;';
    overlay.innerHTML = `<div style="position:fixed;top:5vh;bottom:5vh;left:5vh;right:5vh;background:${bg};border-radius:3px;"><iframe src="${url}" style="border:0;width:100%;height:100%;border-radius:3px;"></iframe></div>`;
    overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };
    const x = document.createElement('button');
    x.className = 'modalCloseX';
    x.setAttribute('aria-label', 'Close');
    x.textContent = '✕';
    x.style.cssText = 'position:fixed;top:calc(5vh - 14px);right:calc(5vh - 14px);z-index:1000;';
    x.onclick = () => overlay.remove();
    overlay.appendChild(x);
    document.body.appendChild(overlay);
  };

  document.getElementById('sidebarCollapseBtn').onclick = () => toggleSidebar(false);
  document.getElementById('sidebarExpandBtn').onclick = () => toggleSidebar(true);
  document.getElementById('composerCollapseBtn').onclick = () => toggleComposer(false);
  document.getElementById('composerExpandBtn').onclick = () => toggleComposer(true);
  if (st.composerVisible === false) toggleComposer(false);

  setInterval(() => {
    if (st.started && !st.paused) {
      renderSidebar();
    }
  }, 100);
  
  document.getElementById('resumeBtn').onclick = async () => {
    const cand = resumeCandidate();
    if (!cand) return;
    hideResumePanel();
    // Named session adopts its name; the recovery slot stays unnamed so it keeps
    // autosaving to the slot until the user explicitly Saves (and names) it.
    if (!cand.isAutosave) st.currentSessionName = cand.name;
    await restoreSession(cand.data);
  };

  document.getElementById('resumeSaveBtn').onclick = async () => {
    const cand = resumeCandidate();
    if (!cand || !cand.isAutosave) return;
    const meta = cand.data.meta || {};
    const defaultName = (meta.instruction || '').slice(0, 40).trim()
      || `Session – ${new Date(meta.savedAt || Date.now()).toLocaleDateString()}`;
    // askSessionName checks against the keys in the store, not st.savedSessionsList: at this point in a
    // boot nothing has scanned it, so a list check would compare against an empty array and let the
    // rename below overwrite a real session. Keys also catch one saved in another tab.
    const trimmed = await askSessionName({ title: 'Name this run', value: defaultName });
    if (!trimmed) return;
    // Promote the recovery slot to a named session in place — a plain rename of the
    // __autosave__ key — without touching live st (the session is never restored/resumed).
    await renameSession(AUTOSAVE_SLOT, trimmed);
    st.autosaveSlot = null;
    st.hasSavedSessions = true;
    // It just became the newest named session and we're already holding its data, so hand it straight
    // to the panel instead of re-reading the whole store to rediscover what we did.
    noteLatestSession(trimmed);
    st.resumeCand = { name: trimmed, data: cand.data, isAutosave: false };
    if (st.sessionsListLoaded) await refreshSessionsList();
    refreshResumePanel();
  };

  document.getElementById('allSessionsBtn').onclick = () => {
    openSessionModal();
  };

  document.getElementById('resumePanelClose').onclick = () => {
    hideResumePanel();
  };

  // Best-effort flush of any pending autosave when the tab is backgrounded or closed.
  window.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') flushAutosaveOnHide();
  });
  window.addEventListener('pagehide', flushAutosaveOnHide);

  checkForSavedSession();
  initICDB().then(() => cleanExpiredImages());
});
</script>
